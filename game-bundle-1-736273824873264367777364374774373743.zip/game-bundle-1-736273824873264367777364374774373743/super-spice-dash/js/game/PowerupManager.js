/**
 * @author Greenish Games
 */

/**
 * @author Greenish Games
 */

var GAME = GAME || {};


GAME.PowerupManager = function(engine)
{
	this.engine = engine;
	
	
}

// constructor

GAME.PowerupManager.prototype.update = function()
{
	
}

GAME.PowerupManager.prototype.restart = function()
{
	//this.destroyAll();
}

GAME.PowerupManager.prototype.activateMagnet = function()
{
	
}

