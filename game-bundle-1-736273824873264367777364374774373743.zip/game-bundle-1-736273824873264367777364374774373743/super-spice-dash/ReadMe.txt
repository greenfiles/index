Important Note: 

Please DON'T remove Google Analytics from index.html file, otherwise your game will not work fine.