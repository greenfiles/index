! function(f) {
    if ("object" == typeof exports && "undefined" != typeof module) module.exports = f();
    else if ("function" == typeof define && define.amd) define([], f);
    else {
        var g;
        g = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : this, g.p3lib = f()
    }
}(function() {
    return function e(t, n, r) {
        function s(o, u) {
            if (!n[o]) {
                if (!t[o]) {
                    var a = "function" == typeof require && require;
                    if (!u && a) return a(o, !0);
                    if (i) return i(o, !0);
                    var f = new Error("Cannot find module '" + o + "'");
                    throw f.code = "MODULE_NOT_FOUND", f
                }
                var l = n[o] = {
                    exports: {}
                };
                t[o][0].call(l.exports, function(e) {
                    var n = t[o][1][e];
                    return s(n ? n : e)
                }, l, l.exports, e, t, n, r)
            }
            return n[o].exports
        }
        for (var i = "function" == typeof require && require, o = 0; o < r.length; o++) s(r[o]);
        return s
    }({
        1: [function(require, module, exports) {
            function AI(game, focus, skill, view) {
                Car.call(this, view), this.turnAccel = 4200, this.turnSlowRadius = 280, this.turnTargetRadius = 1, this.turnNoise = -80 + 160 * Math.random(), this.baseSpread = 2.4, this.baseAccel = 0, this.leadTarget = null, this._game = game, this._focus = focus, this._skill = skill, this._time = Math.random(), this._emitterOffset = new PIXI.Point(90, 40), this._switchLaneTimer = null, this.baseAccel = 2.4 + this._skill * this.baseSpread, this.switchRandomLane()
            }
            var Car = require("./Car"),
                Common = require("./Common");
            require("./GameScene"), require("./LightningView"), require("./Point4");
            module.exports = AI, AI.prototype = Object.create(Car.prototype), AI.prototype.constructor = AI, AI.FOCUS_TYPE_LEAD = 0, AI.FOCUS_TYPE_REAR = 1, AI.FOCUS_TYPE_NORMAL = 2, AI.prototype.destroy = function() {
                this._switchLaneTimer && (Common.animator.remove(this._switchLaneTimer), this._switchLaneTimer.dispose(), this._switchLaneTimer = null), Car.prototype.destroy.call(this)
            }, AI.prototype.update = function() {
                ++this._time, this.acceleration = this.calculateAccel(), this.acceleration += 1 * Math.sin(.004 * this._time);
                var width = Common.engine.view.segmentWidth,
                    x = this.laneIndex * Math.floor(.5 * width / (this.laneCount - 1)),
                    distance = x - this.offset.x,
                    direction = distance / Math.abs(distance),
                    time = 1;
                distance > this.laneArriveRadius ? this.turnSpeed = direction * this.turnAccel : this.turnSpeed = direction * (this.turnAccel * Math.min(1, Math.abs(distance / this.laneArriveRadius))), this.turnSpeed /= time, Car.prototype.update.call(this)
            }, AI.prototype.calculateAccel = function() {
                var d1, d2, d3, distance, direction, acceleration = this.baseAccel;
                if (this._focus == AI.FOCUS_TYPE_LEAD) {
                    d1 = this.realDistance, d2 = this.leadTarget.realDistance, d3 = this._game.player.realDistance;
                    var acc = 0;
                    d3 > d2 ? (distance = d3 - d1, acc = Math.max(this.leadTarget.baseAccel, .6 * this._game.player.acceleration)) : (distance = d2 - d1, acc = this.leadTarget.baseAccel), direction = Math.abs(distance) > 0 ? distance / Math.abs(distance) : 1, acceleration = this._skill * (acc + this.baseSpread) + direction * Math.abs(.2 * distance)
                } else this._focus == AI.FOCUS_TYPE_REAR && (d1 = this.realDistance, d3 = this._game.player.realDistance, d1 > d3 && (distance = d3 - d1, direction = Math.abs(distance) > 0 ? distance / Math.abs(distance) : 1, acceleration = this._skill * (this.baseAccel + this.baseSpread) + direction * Math.abs(.04 * distance)));
                return acceleration
            }, AI.prototype.updateView = function() {
                var curvature = 4 * this.engine.getAverageTrackCurvature(this.distance, 2);
                curvature += 1.4 * this.calculatePerpProduct(this.engine.camera.target), curvature += .0014 * -this.pos2d.x;
                var gradient = this.engine.getTrackGradient(this.distance) - this.engine.getTrackGradient(this.engine.camera.target.distance);
                this._view.update(this.distance, 160 * curvature, .6 * gradient, this.velocity, .08 * this.turnVelocity)
            }, AI.prototype.switchRandomLane = function() {
                var laneCount = this.laneCount - 1;
                this.laneIndex = Math.floor(Math.random() * (1 + laneCount - -laneCount)) + -laneCount, this._switchLaneTimer = delay(this.switchRandomLane, 2 + 4 * Math.random(), this)
            }, AI.prototype.updateEmitters = function() {}, Object.defineProperty(AI.prototype, "focus", {
                get: function() {
                    return this._focus
                }
            }), Object.defineProperty(AI.prototype, "skill", {
                get: function() {
                    return this._skill
                }
            })
        }, {
            "./Car": 13,
            "./Common": 23,
            "./GameScene": 36,
            "./LightningView": 52,
            "./Point4": 62
        }],
        2: [function(require, module, exports) {
            function AchievementData(id, name, description, iconTexture) {
                this.id = id, this.name = name, this.description = description, this.iconTexture = iconTexture || PIXI.Texture.EMPTY, this.earned = !1
            }
            require("./Common");
            module.exports = AchievementData
        }, {
            "./Common": 23
        }],
        3: [function(require, module, exports) {
            function AchievementPopup(name, description, iconTexture) {
                iconTexture = iconTexture || PIXI.Texture.EMPTY, PIXI.Sprite.call(this, Common.assets.getTexture("ui_trophies_bar")), this.anchor.x = .5, this._name = name, this._description = description, webfont ? (this._nameText = new PIXI.Text(name, {
                    font: "34px Arial",
                    fill: "#FFFFFF",
                    align: "right"
                }), this._nameText.x = r2l ? .5 * this.texture.width - this._nameText.width - 40 : .5 * -this.texture.width + 40, this._nameText.y = .5 * -this._nameText.height - 18 + .5 * this.texture.height, this.addChild(this._nameText)) : (this._nameText = new PIXI.extras.BitmapText(name, {
                    font: "34px Great Escape",
                    fill: "#FFFFFF",
                    align: "right"
                }), this._nameText.x = r2l ? .5 * this.texture.width - this._nameText.textWidth - 40 : .5 * -this.texture.width + 40, this._nameText.y = .5 * -this._nameText.textHeight - 18 + .5 * this.texture.height, this.addChild(this._nameText)), webfont ? (this._descriptionText = new PIXI.Text(description.toString(), {
                    font: "20px Arial",
                    fill: "#95B5B9",
                    align: "center"
                }), this._descriptionText.x = r2l ? .5 * this.texture.width - this._descriptionText.width - 40 : .5 * -this.texture.width + 40, this._descriptionText.y = .5 * -this._descriptionText.height + 22 + .5 * this.texture.height, this.addChild(this._descriptionText)) : (this._descriptionText = new PIXI.extras.BitmapText(description.toString(), {
                    font: "20px Great Escape",
                    align: "center"
                }), this._descriptionText.x = r2l ? .5 * this.texture.width - this._descriptionText.textWidth - 40 : .5 * -this.texture.width + 40, this._descriptionText.y = .5 * -this._descriptionText.textHeight + 22 + .5 * this.texture.height, this._descriptionText.tint = 9811385, this.addChild(this._descriptionText)), this._icon = new PIXI.Sprite(iconTexture), this._icon.x = r2l ? .5 * -this.texture.width + 80 : .5 * this.texture.width - 80, this._icon.y = .5 * this.texture.height, this._icon.anchor = new PIXI.Point(.5, .5), this.addChild(this._icon)
            }
            var Common = require("./Common");
            module.exports = AchievementPopup, AchievementPopup.prototype = Object.create(PIXI.Sprite.prototype), AchievementPopup.prototype.constructor = AchievementPopup
        }, {
            "./Common": 23
        }],
        4: [function(require, module, exports) {
            function AchievementTypes() {}
            module.exports = AchievementTypes, AchievementTypes.COMPLETE_FIRST_RACE = 0, AchievementTypes.WIN_FIRST_RACE = 1, AchievementTypes.WIN_BEGINNER_SERIES = 2, AchievementTypes.WIN_WORLD_SERIES = 3, AchievementTypes.WIN_ADVANCED_WORLD_SERIES = 4, AchievementTypes.WIN_USA_SERIES = 5, AchievementTypes.WIN_ITALY_SERIES = 6, AchievementTypes.WIN_GERMANY_SERIES = 7, AchievementTypes.WIN_JAPAN_SERIES = 8, AchievementTypes.WIN_BRAZIL_SERIES = 9, AchievementTypes.WIN_ALL_RACES_ONE_LOCATION = 10, AchievementTypes.WIN_ALL_RACES_ALL_COUNTRIES = 11, AchievementTypes.RACE_ALL_TRACKS = 12, AchievementTypes.RACE_ONCE_WITH_ALL_CARS = 13, AchievementTypes.WIN_SERIES_IN_EACH_CAR = 14, AchievementTypes.CHANGE_CAR_COLOR = 15, AchievementTypes.APPLY_STICKER = 16, AchievementTypes.APPLY_X_STICKERS = 17, AchievementTypes.COLLECT_X_COINS_IN_RACE = 18, AchievementTypes.EARN_X_COINS = 19, AchievementTypes.SPEND_X_COINS = 20, AchievementTypes.WIN_CLEAN_RACE = 21
        }, {}],
        5: [function(require, module, exports) {
            function AchievementsManager() {
                this.view = new PIXI.Container, this._achievements = {}, this._achievementCount = 0, this._queue = []
            }
            var AchievementPopup = (require("./AchievementData"), require("./AchievementPopup")),
                Common = require("./Common");
            module.exports = AchievementsManager, AchievementsManager.prototype.register = function(data) {
                var id = data.id;
                return this.getAchievement(id) ? !1 : (this._achievements[id] = data, ++this._achievementCount, !0)
            }, AchievementsManager.prototype.award = function(id) {
                function next() {
                    if (this._queue.length) {
                        var achievement = this._queue[0],
                            popup = new AchievementPopup(achievement.name, achievement.description, achievement.iconTexture);
                        popup.x = .5 * p3.View.width, popup.y = p3.View.height - popup.height - 20, this.view.addChild(popup);
                        var y = popup.y;
                        popup.y = p3.View.height + popup.height;
                        var tl = new TimelineMax;
                        tl.append(TweenMax.to(popup, .4, {
                            y: y,
                            ease: Back.easeOut,
                            easeParams: [2]
                        })), tl.append(TweenMax.to(popup, .4, {
                            delay: 2,
                            y: popup.y,
                            ease: Back.easeIn,
                            easeParams: [1],
                            onComplete: function() {
                                delay(function() {
                                    this._queue.shift(), next.call(this)
                                }, .6, this)
                            },
                            onCompleteScope: this
                        }))
                    }
                }
                if (!Common.saveData.isNewPlayer) {
                    var achievement = this.getAchievement(id);
                    achievement && !achievement.earned && (achievement.earned = !0, this._queue.push(achievement), 1 == this._queue.length && next.call(this)), Common.saveData.save()
                }
            }, AchievementsManager.prototype.save = function() {
                var achievement, data = [];
                for (var id in this._achievements) this._achievements.hasOwnProperty(id) && (achievement = this._achievements[id], achievement.earned && data.push(achievement.id));
                return data
            }, AchievementsManager.prototype.load = function(data) {
                for (var id, achievement, i = 0; i < data.length; ++i) id = data[i], achievement = this._achievements[id], achievement && (achievement.earned = !0)
            }, AchievementsManager.prototype.getAchievement = function(id) {
                return this._achievements[id]
            }, Object.defineProperty(AchievementsManager.prototype, "achievements", {
                get: function() {
                    var arr = [];
                    for (var id in this._achievements) this._achievements.hasOwnProperty(id) && arr.push(this._achievements[id]);
                    return arr
                }
            })
        }, {
            "./AchievementData": 2,
            "./AchievementPopup": 3,
            "./Common": 23
        }],
        6: [function(require, module, exports) {
            function AchievementsScene() {
                Scene.call(this), this.signals.back = new signals.Signal, this.signals.settings = new signals.Signal, this._header = null, this._titleText = null, this._helpButton = null, this._backButton = null, this._settingsButton = null, this._scrollView = null, this._scroller = null
            }
            var Common = require("./Common"),
                Scene = require("./Scene"),
                Scroller = require("./Scroller"),
                ScrollView = require("./ScrollView");
            module.exports = AchievementsScene, AchievementsScene.prototype = Object.create(Scene.prototype), AchievementsScene.prototype.constructor = AchievementsScene, AchievementsScene.prototype.init = function() {
                var bg = new PIXI.Sprite(Common.assets.getTexture("ui_bg_main_menu"));
                this.addChild(bg), this._header = new PIXI.Sprite(Common.assets.getTexture("ui_top_bar")), this._header.x = .5 * Common.STAGE_WIDTH, this._header.y = 120, this._header.anchor = new PIXI.Point(.5, .5), this.addChild(this._header), webfont ? (this._titleText = new PIXI.Text(Common.copy.achievements[Common.language], {
                    font: "48px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._titleText.x = .5 * (Common.STAGE_WIDTH - this._titleText.width), this._titleText.y = 96, this.addChild(this._titleText)) : (this._titleText = new PIXI.extras.BitmapText(Common.copy.achievements[Common.language], {
                    font: "48px Great Escape",
                    align: "center"
                }), this._titleText.x = .5 * (Common.STAGE_WIDTH - this._titleText.textWidth), this._titleText.y = 86, this.addChild(this._titleText)), this._backButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_back")), this._backButton.y = 120, this._backButton.animate = !0, this._backButton.overSoundName = "sfx_ui_btn_rollover_00", this._backButton.downSoundName = "sfx_ui_btn_press_00", this._backButton.signals.click.add(this.onBackButtonClick, this), this.addChild(this._backButton), this._helpButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_help")), this._helpButton.animate = !0, this._helpButton.overSoundName = "sfx_ui_btn_rollover_00", this._helpButton.downSoundName = "sfx_ui_btn_press_00", this._helpButton.signals.click.add(this.onHelpButtonClick, this), this.addChild(this._helpButton), this._settingsButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_settings")), this._settingsButton.y = 120, this._settingsButton.animate = !0, this._settingsButton.overSoundName = "sfx_ui_btn_rollover_00", this._settingsButton.downSoundName = "sfx_ui_btn_press_00", this._settingsButton.signals.click.add(this.onSettingsButtonClick, this), this.addChild(this._settingsButton), this._scrollView = new ScrollView(800, 602, 0, 540), this._scrollView.x = .5 * Common.STAGE_WIDTH - 400, this._scrollView.y = .5 * Common.STAGE_HEIGHT - 218, this._scrollView.signals.scroll.add(this.onScrollViewScroll, this), this.addChild(this._scrollView), this._scroller = new Scroller(1), this._scroller.x = .5 * Common.STAGE_WIDTH + 380, this._scroller.y = .5 * (Common.STAGE_HEIGHT - this._scroller.height) + 80, this._scroller.visible = !p3.Device.isMobile, this._scroller.signals.scroll.add(this.onScrollerScroll, this), this.addChild(this._scroller), this.load(), Common.input.signals.mouseUp.add(this.onStageMouseUp, this), Common.tracking.track(new p3.TrackingDataPlaydomGameAction("garage", "view_achievements"))
            }, AchievementsScene.prototype.dispose = function() {
                Common.animator.removeAll(), Common.input.signals.mouseUp.remove(this.onStageMouseUp), Scene.prototype.dispose.call(this)
            }, AchievementsScene.prototype.appear = function() {
                this.animateIn()
            }, AchievementsScene.prototype.show = function() {}, AchievementsScene.prototype.animateIn = function(callback, scope) {}, AchievementsScene.prototype.animateOut = function(callback, scope) {}, AchievementsScene.prototype.resize = function() {
                this.x = .5 * (p3.View.width - Common.STAGE_WIDTH), this._header.width = p3.View.width, this._settingsButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width - this._settingsButton.width) - 28, this._helpButton.x = this._settingsButton.x - 112, this._helpButton.y = this._settingsButton.y, this._backButton.x = .5 * (Common.STAGE_WIDTH - p3.View.width + this._backButton.width) + 28
            }, AchievementsScene.prototype.update = function() {
                this._scrollView.update()
            }, AchievementsScene.prototype.load = function() {
                for (var award, data, spacing = 120, achievements = Common.achievements.achievements, i = 0; i < achievements.length; ++i) data = achievements[i], award = new PIXI.Sprite(Common.assets.getTexture("ui_trophies_bar")), award.x = .5 * this._scrollView.frameWidth, award.y = 120 + i * spacing, award.anchor = new PIXI.Point(.5, .5), this._scrollView.content.addChild(award), webfont ? (award.name = new PIXI.Text(data.name, {
                    font: "34px Arial",
                    fill: "#FFFFFF",
                    align: "right"
                }), award.name.x = r2l ? .5 * award.texture.width - award.name.width - 40 : .5 * -award.texture.width + 40, award.name.y = .5 * -award.name.height - 18, award.addChild(award.name)) : (award.name = new PIXI.extras.BitmapText(data.name, {
                    font: "34px Great Escape",
                    align: "right"
                }), award.name.x = r2l ? .5 * award.texture.width - award.name.textWidth - 40 : .5 * -award.texture.width + 40, award.name.y = .5 * -award.name.textHeight - 18, award.addChild(award.name)), webfont ? (award.desc = new PIXI.Text(data.description, {
                    font: "20px Arial",
                    fill: "#95B5B9",
                    align: "right"
                }), award.desc.x = r2l ? .5 * award.texture.width - award.desc.width - 40 : .5 * -award.texture.width + 40, award.desc.y = .5 * -award.desc.height + 22, award.addChild(award.desc)) : (award.desc = new PIXI.extras.BitmapText(data.description, {
                    font: "20px Great Escape",
                    align: "right"
                }), award.desc.x = r2l ? .5 * award.texture.width - award.desc.textWidth - 40 : .5 * -award.texture.width + 40, award.desc.y = .5 * -award.desc.textHeight + 22, award.desc.tint = 9811385, award.addChild(award.desc)), award.image = new PIXI.Sprite(data.earned ? data.iconTexture : Common.assets.getTexture("ui_trophies_slot")), award.image.x = r2l ? .5 * -award.texture.width + 80 : .5 * award.texture.width - 80, award.image.anchor = new PIXI.Point(.5, .5), award.addChild(award.image);
                this._scrollView.contentHeight = 120 + 120 * achievements.length - this._scrollView.frameHeight
            }, AchievementsScene.prototype.onBackButtonClick = function(button) {
                this.signals.back.dispatch(this)
            }, AchievementsScene.prototype.onHelpButtonClick = function(button) {
                this.signals.pause.dispatch(this)
            }, AchievementsScene.prototype.onSettingsButtonClick = function(button) {
                this.signals.settings.dispatch(this)
            }, AchievementsScene.prototype.onScrollerScroll = function(scroller, fraction) {
                var value = fraction * this._scrollView.contentHeight;
                this._scrollView.scroll(0, value, !0)
            }, AchievementsScene.prototype.onScrollViewScroll = function(scrollView, position) {
                var value = position.y / this._scrollView.contentHeight * this._scroller.innerHeight;
                this._scroller.scroll(value)
            }, AchievementsScene.prototype.onStageMouseUp = function(event) {
                this._scroller.onMouseUp(null), this._scrollView.onMouseUp(null)
            }
        }, {
            "./Common": 23,
            "./Scene": 83,
            "./ScrollView": 87,
            "./Scroller": 88
        }],
        7: [function(require, module, exports) {
            function Application() {}
            var AudioParams = require("./AudioParams"),
                AchievementData = require("./AchievementData"),
                AchievementsManager = require("./AchievementsManager"),
                AchievementsScene = require("./AchievementsScene"),
                AchievementTypes = require("./AchievementTypes"),
                CarData = (require("./Award"), require("./CarData")),
                Common = require("./Common"),
                CommsScene = require("./CommsScene"),
                ContinueSeriesPopupScene = require("./ContinueSeriesPopupScene"),
                CountryTypes = require("./CountryTypes"),
                CutoutTransition = require("./CutoutTransition"),
                CutsceneScene = require("./CutsceneScene"),
                DailyBonusScene = require("./DailyBonusScene"),
                ErrorPopupScene = require("./ErrorPopupScene"),
                GameScene = require("./GameScene"),
                Garage = require("./Garage"),
                GarageColorScene = require("./GarageColorScene"),
                GarageDecalsScene = require("./GarageDecalScene"),
                GarageEngineScene = require("./GarageEngineScene"),
                GarageKitScene = require("./GarageKitScene"),
                GarageModelScene = require("./GarageModelScene"),
                GaragePitstopScene = require("./GaragePitstopScene"),
                HelpScene = require("./HelpScene"),
                LeaderboardScene = require("./LeaderboardScene"),
                NameScene = require("./NameScene"),
                PauseScene = require("./PauseScene"),
                PhotoScene = require("./PhotoScene"),
                PurchasePopupScene = require("./PurchasePopupScene"),
                RaceModeScene = require("./RaceModeScene"),
                RedeemCodeScene = require("./RedeemCodeScene"),
                ResultScene = require("./ResultScene"),
                RewardPopupScene = require("./RewardPopupScene"),
                SaveData = require("./SaveData"),
                SettingsScene = require("./SettingsScene"),
                SeriesTypes = require("./SeriesTypes"),
                SplashScene = require("./SplashScene"),
                SingleRaceScene = require("./SingleRaceScene"),
                SeriesRaceScene = require("./SeriesRaceScene"),
                TrackData = require("./TrackData"),
                TrackLoaderScene = require("./TrackLoaderScene"),
                TrackSeriesData = require("./TrackSeriesData"),
                TrackManager = require("./TrackManager"),
                Transition = require("./Transition"),
                TrophyScene = require("./TrophyScene"),
                WelcomeScene = require("./WelcomeScene");
            module.exports = Application, Application.prototype.init = function() {
                var garage = new Garage;
                Common.garage = garage, garage.registerCar(new CarData(0, "model 1")), garage.registerCar(new CarData(1, "model 2")), garage.registerCar(new CarData(2, "model 3")), garage.registerCar(new CarData(3, "model 4")), garage.registerCar(new CarData(4, "model 5"));
                var trackManager = new TrackManager;
                Common.trackManager = trackManager;
                var copy = Common.copy,
                    language = Common.language;
                trackManager.registerTrack(new TrackData(100, CountryTypes.TUTORIAL, "Tutorial 1", "tutorial", TrackData.DIFFICULTY_EASY), []), trackManager.registerTrack(new TrackData(0, CountryTypes.USA, copy.country_usa[language] + " 1", copy.country_usa[language], TrackData.DIFFICULTY_EASY), []), trackManager.registerTrack(new TrackData(1, CountryTypes.USA, copy.country_usa[language] + " 2", copy.country_usa[language], TrackData.DIFFICULTY_INTERMEDIATE), [0]), trackManager.registerTrack(new TrackData(2, CountryTypes.USA, copy.country_usa[language] + " 3", copy.country_usa[language], TrackData.DIFFICULTY_INTERMEDIATE), [0]), trackManager.registerTrack(new TrackData(3, CountryTypes.USA, copy.country_usa[language] + " 4", copy.country_usa[language], TrackData.DIFFICULTY_HARD), [1, 2]), trackManager.registerTrack(new TrackData(4, CountryTypes.ITALY, copy.country_italy[language] + " 1", copy.country_italy[language], TrackData.DIFFICULTY_EASY), []), trackManager.registerTrack(new TrackData(5, CountryTypes.ITALY, copy.country_italy[language] + " 2", copy.country_italy[language], TrackData.DIFFICULTY_INTERMEDIATE), [4]), trackManager.registerTrack(new TrackData(6, CountryTypes.ITALY, copy.country_italy[language] + " 3", copy.country_italy[language], TrackData.DIFFICULTY_INTERMEDIATE), [4]), trackManager.registerTrack(new TrackData(7, CountryTypes.ITALY, copy.country_italy[language] + " 4", copy.country_italy[language], TrackData.DIFFICULTY_HARD), [5, 6]), trackManager.registerTrack(new TrackData(8, CountryTypes.GERMANY, copy.country_germany[language] + " 1", copy.country_germany[language], TrackData.DIFFICULTY_EASY), []), trackManager.registerTrack(new TrackData(9, CountryTypes.GERMANY, copy.country_germany[language] + " 2", copy.country_germany[language], TrackData.DIFFICULTY_INTERMEDIATE), [8]), trackManager.registerTrack(new TrackData(10, CountryTypes.GERMANY, copy.country_germany[language] + " 3", copy.country_germany[language], TrackData.DIFFICULTY_INTERMEDIATE), [8]), trackManager.registerTrack(new TrackData(11, CountryTypes.GERMANY, copy.country_germany[language] + " 4", copy.country_germany[language], TrackData.DIFFICULTY_HARD), [9, 10]), trackManager.registerTrack(new TrackData(12, CountryTypes.JAPAN, copy.country_japan[language] + " 1", copy.country_japan[language], TrackData.DIFFICULTY_EASY), []), trackManager.registerTrack(new TrackData(13, CountryTypes.JAPAN, copy.country_japan[language] + " 2", copy.country_japan[language], TrackData.DIFFICULTY_INTERMEDIATE), [12]), trackManager.registerTrack(new TrackData(14, CountryTypes.JAPAN, copy.country_japan[language] + " 3", copy.country_japan[language], TrackData.DIFFICULTY_INTERMEDIATE), [12]), trackManager.registerTrack(new TrackData(15, CountryTypes.JAPAN, copy.country_japan[language] + " 4", copy.country_japan[language], TrackData.DIFFICULTY_HARD), [13, 14]), trackManager.registerTrack(new TrackData(16, CountryTypes.BRAZIL, copy.country_brazil[language] + " 1", copy.country_brazil[language], TrackData.DIFFICULTY_EASY), []), trackManager.registerTrack(new TrackData(17, CountryTypes.BRAZIL, copy.country_brazil[language] + " 2", copy.country_brazil[language], TrackData.DIFFICULTY_INTERMEDIATE), [16]), trackManager.registerTrack(new TrackData(18, CountryTypes.BRAZIL, copy.country_brazil[language] + " 3", copy.country_brazil[language], TrackData.DIFFICULTY_INTERMEDIATE), [16]), trackManager.registerTrack(new TrackData(19, CountryTypes.BRAZIL, copy.country_brazil[language] + " 4", copy.country_brazil[language], TrackData.DIFFICULTY_HARD), [17, 18]), trackManager.registerSeries(new TrackSeriesData(0, SeriesTypes.BEGINNER, copy.series_beginner[language], TrackData.DIFFICULTY_EASY, [0, 12, 8, 4]), [], []), trackManager.registerSeries(new TrackSeriesData(1, SeriesTypes.WORLD, copy.series_world[language], TrackData.DIFFICULTY_INTERMEDIATE, [0, 13, 9, 7]), [], []), trackManager.registerSeries(new TrackSeriesData(2, SeriesTypes.USA, copy.series_usa[language], TrackData.DIFFICULTY_EASY, [0, 1, 2, 3]), [], []), trackManager.registerSeries(new TrackSeriesData(3, SeriesTypes.ITALY, copy.series_italy[language], TrackData.DIFFICULTY_EASY, [4, 5, 6, 7]), [], []), trackManager.registerSeries(new TrackSeriesData(4, SeriesTypes.GERMANY, copy.series_germany[language], TrackData.DIFFICULTY_EASY, [8, 9, 10, 11]), [], []), trackManager.registerSeries(new TrackSeriesData(5, SeriesTypes.JAPAN, copy.series_japan[language], TrackData.DIFFICULTY_HARD, [12, 13, 14, 15]), [], []), trackManager.registerSeries(new TrackSeriesData(6, SeriesTypes.BRAZIL, copy.series_brazil[language], TrackData.DIFFICULTY_HARD, [16, 17, 18, 19]), [], []), trackManager.registerSeries(new TrackSeriesData(7, SeriesTypes.ADVANCED, copy.series_advanced[language], TrackData.DIFFICULTY_HARD, [3, 15, 11, 7]), [], []);
                var achievements = new AchievementsManager;
                Common.stage.addChild(achievements.view), Common.achievements = achievements, achievements.register(new AchievementData(AchievementTypes.COMPLETE_FIRST_RACE, Common.copy.achievement1.name[Common.language], Common.copy.achievement1.description[Common.language], Common.assets.getTexture("ui_icon_achievement_first_race"))), achievements.register(new AchievementData(AchievementTypes.WIN_FIRST_RACE, Common.copy.achievement2.name[Common.language], Common.copy.achievement2.description[Common.language], Common.assets.getTexture("ui_icon_achievement_win"))), achievements.register(new AchievementData(AchievementTypes.WIN_BEGINNER_SERIES, Common.copy.achievement3.name[Common.language], Common.copy.achievement3.description[Common.language], Common.assets.getTexture("ui_icon_achievement_beginner"))), achievements.register(new AchievementData(AchievementTypes.WIN_WORLD_SERIES, Common.copy.achievement4.name[Common.language], Common.copy.achievement4.description[Common.language], Common.assets.getTexture("ui_icon_achievement_world"))), achievements.register(new AchievementData(AchievementTypes.WIN_ADVANCED_WORLD_SERIES, Common.copy.achievement5.name[Common.language], Common.copy.achievement5.description[Common.language], Common.assets.getTexture("ui_icon_achievement_advanced"))), achievements.register(new AchievementData(AchievementTypes.WIN_USA_SERIES, Common.copy.achievement6.name[Common.language], Common.copy.achievement6.description[Common.language], Common.assets.getTexture("ui_icon_achievement_usa"))), achievements.register(new AchievementData(AchievementTypes.WIN_ITALY_SERIES, Common.copy.achievement7.name[Common.language], Common.copy.achievement7.description[Common.language], Common.assets.getTexture("ui_icon_achievement_italy"))), achievements.register(new AchievementData(AchievementTypes.WIN_GERMANY_SERIES, Common.copy.achievement8.name[Common.language], Common.copy.achievement8.description[Common.language], Common.assets.getTexture("ui_icon_achievement_germany"))), achievements.register(new AchievementData(AchievementTypes.WIN_JAPAN_SERIES, Common.copy.achievement9.name[Common.language], Common.copy.achievement9.description[Common.language], Common.assets.getTexture("ui_icon_achievement_japan"))), achievements.register(new AchievementData(AchievementTypes.WIN_BRAZIL_SERIES, Common.copy.achievement10.name[Common.language], Common.copy.achievement10.description[Common.language], Common.assets.getTexture("ui_icon_achievement_brazil"))), achievements.register(new AchievementData(AchievementTypes.WIN_ALL_RACES_ONE_LOCATION, Common.copy.achievement11.name[Common.language], Common.copy.achievement11.description[Common.language], Common.assets.getTexture("ui_icon_achievement_first_race"))), achievements.register(new AchievementData(AchievementTypes.WIN_ALL_RACES_ALL_COUNTRIES, Common.copy.achievement12.name[Common.language], Common.copy.achievement12.description[Common.language], Common.assets.getTexture("ui_icon_achievement_first_race"))), achievements.register(new AchievementData(AchievementTypes.RACE_ALL_TRACKS, Common.copy.achievement13.name[Common.language], Common.copy.achievement13.description[Common.language], Common.assets.getTexture("ui_icon_achievement_explorer"))), achievements.register(new AchievementData(AchievementTypes.RACE_ONCE_WITH_ALL_CARS, Common.copy.achievement14.name[Common.language], Common.copy.achievement14.description[Common.language], Common.assets.getTexture("ui_icon_achievement_first_race"))), achievements.register(new AchievementData(AchievementTypes.WIN_SERIES_IN_EACH_CAR, Common.copy.achievement15.name[Common.language], Common.copy.achievement15.description[Common.language], Common.assets.getTexture("ui_icon_achievement_first_race"))), achievements.register(new AchievementData(AchievementTypes.CHANGE_CAR_COLOR, Common.copy.achievement16.name[Common.language], Common.copy.achievement16.description[Common.language], Common.assets.getTexture("ui_icon_achievement_colours"))), achievements.register(new AchievementData(AchievementTypes.APPLY_STICKER, Common.copy.achievement17.name[Common.language], Common.copy.achievement17.description[Common.language], Common.assets.getTexture("ui_icon_achievement_sticker"))), achievements.register(new AchievementData(AchievementTypes.APPLY_X_STICKERS, Common.copy.achievement18.name[Common.language], Common.copy.achievement18.description[Common.language], Common.assets.getTexture("ui_icon_achievement_sticker"))), achievements.register(new AchievementData(AchievementTypes.COLLECT_X_COINS_IN_RACE, Common.copy.achievement19.name[Common.language], Common.copy.achievement19.description[Common.language], Common.assets.getTexture("ui_icon_achievement_coin_collect"))), achievements.register(new AchievementData(AchievementTypes.EARN_X_COINS, Common.copy.achievement20.name[Common.language], Common.copy.achievement20.description[Common.language], Common.assets.getTexture("ui_icon_achievement_coin_earn"))), achievements.register(new AchievementData(AchievementTypes.SPEND_X_COINS, Common.copy.achievement21.name[Common.language], Common.copy.achievement21.description[Common.language], Common.assets.getTexture("ui_icon_achievement_coin_spend"))), achievements.register(new AchievementData(AchievementTypes.WIN_CLEAN_RACE, Common.copy.achievement22.name[Common.language], Common.copy.achievement22.description[Common.language], Common.assets.getTexture("ui_icon_achievement_squeaky_clean"))), Common.saveData = new SaveData, Common.saveData.load() && console.log("SAVE LOADED");
                var params = new AudioParams;
                params.fadeIn = 1, Common.audio.playMusic("music_cars_splashmenu", params);
                var reward = Common.saveData.getReward(); - 1 != reward.index ? this.showDailyBonusScene(reward) : Common.saveData.isNewPlayer ? this.showWelcomeScene() : this.showSplashScene(!1)
            }, Application.prototype.showSplashScene = function(animate) {
                animate = "boolean" == typeof animate ? animate : !0;
                var scene = new SplashScene;
                scene.signals.play.add(function() {
                    this.showGarageScene()
                }, this), scene.signals.name.add(function() {
                    this.showNameScene()
                }, this), scene.signals.next.add(function() {
                    this.showCommsScene()
                }, this), scene.signals.previous.add(function() {
                    this.showRedeemCodeScene()
                }, this), scene.signals.pause.add(function() {
                    this.showHelpScene(), Common.tracking.track(new p3.TrackingDataPlaydomGameAction("splash", "click_help"))
                }, this);
                var texture = Common.assets.getTexture("transition_mask"),
                    transition = animate ? new CutoutTransition(texture, 0) : new Transition;
                Common.scene.add(scene, transition);
                var params = new AudioParams;
                return params.fadeIn = 1, Common.audio.playMusic("music_cars_splashmenu", params), scene
            }, Application.prototype.showDailyBonusScene = function(reward) {
                var scene = new DailyBonusScene(reward);
                scene.signals.next.add(function(scene, reward) {
                    var popup = this.showRewardPopupScene(reward);
                    popup.signals.next.add(function() {
                        Common.saveData.isNewPlayer ? this.showWelcomeScene() : this.showSplashScene(!1)
                    }, this, 1)
                }, this);
                var texture = Common.assets.getTexture("transition_mask"),
                    transition = new CutoutTransition(texture, 0);
                return Common.scene.add(scene, transition), scene
            }, Application.prototype.showWelcomeScene = function() {
                var scene = new WelcomeScene;
                scene.signals.next.add(function() {
                    var name = this.showNameScene();
                    name.signals.next.add(function() {
                        this.showTutorialScene()
                    }, this, 1)
                }, this);
                var texture = Common.assets.getTexture("transition_mask"),
                    transition = new CutoutTransition(texture, 0);
                return Common.scene.add(scene, transition), scene
            }, Application.prototype.showNameScene = function() {
                var scene = new NameScene,
                    texture = Common.assets.getTexture("transition_mask"),
                    transition = new CutoutTransition(texture, 0);
                return transition.push = !0, transition.replace = !1, Common.scene.add(scene, transition), scene
            }, Application.prototype.showRewardPopupScene = function(value) {
                var scene = new RewardPopupScene(value);
                scene.signals.next.add(function() {
                    Common.scene.remove()
                }, this);
                var transition = new Transition;
                return transition.push = !0, transition.replace = !1, Common.scene.add(scene, transition), scene
            }, Application.prototype.showHelpScene = function(type) {
                var prev = Common.scene.top;
                this.blurIn(prev);
                var scene = new HelpScene(type);
                scene.signals.next.add(function() {
                    Common.scene.remove()
                }, this), scene.signals.out.add(function() {
                    this.blurOut(prev)
                }, this);
                var transition = new Transition;
                return transition.push = !0, transition.replace = !1, Common.scene.add(scene, transition), scene
            }, Application.prototype.showSettingsScene = function() {
                var prev = Common.scene.top;
                this.blurIn(prev);
                var scene = new SettingsScene;
                scene.signals.next.add(function() {
                    Common.scene.remove()
                }, this), scene.signals.name.add(function() {
                    var name = this.showNameScene();
                    name.signals.next.add(function() {
                        var texture = Common.assets.getTexture("transition_mask"),
                            transition = new CutoutTransition(texture, 0);
                        Common.scene.remove(transition)
                    }, this, 1)
                }, this), scene.signals.tutorial.add(function() {
                    this.showTutorialScene()
                }, this), scene.signals.out.add(function() {
                    this.blurOut(prev)
                }, this);
                var transition = new Transition;
                return transition.push = !0, transition.replace = !1, Common.scene.add(scene, transition), scene
            }, Application.prototype.showGarageScene = function(type) {
                type = type || 0;
                var scene, texture, transition;
                switch (type) {
                    case 0:
                        scene = new GarageModelScene, scene.signals.next.add(function() {
                            this.showRaceModeScene()
                        }, this), scene.signals.previous.add(function() {
                            this.showSplashScene()
                        }, this), scene.signals.trophy.add(function() {
                            this.showTrophyScene()
                        }, this), scene.signals.name.add(function() {
                            var name = this.showNameScene();
                            name.signals.next.add(function() {
                                var texture = Common.assets.getTexture("transition_mask"),
                                    transition = new CutoutTransition(texture, 0);
                                Common.scene.remove(transition)
                            }, this, 1)
                        }, this), scene.signals.photo.add(function(scene, itemName) {
                            this.showPhotoScene(itemName)
                        }, this), scene.signals.color.add(function() {
                            this.showGarageScene(1)
                        }, this), scene.signals.engine.add(function() {
                            this.showGarageScene(2)
                        }, this), scene.signals.kit.add(function() {
                            this.showGarageScene(3)
                        }, this), scene.signals.decals.add(function() {
                            this.showGarageScene(4)
                        }, this), scene.signals.pause.add(function() {
                            this.showHelpScene(), Common.tracking.track(new p3.TrackingDataPlaydomGameAction("garage", "click_help"))
                        }, this), scene.signals.settings.add(function() {
                            this.showSettingsScene(), Common.tracking.track(new p3.TrackingDataPlaydomGameAction("garage", "click_settings"))
                        }, this), texture = Common.assets.getTexture("transition_mask"), transition = new CutoutTransition(texture, 0), Common.scene.add(scene, transition);
                        break;
                    case 1:
                        scene = new GarageColorScene, scene.signals.previous.add(function(scene, purchase) {
                            Common.scene.remove(), purchase && Common.scene.signals.remove.addOnce(function() {
                                var model = Common.scene.top;
                                model.animateCoins(), model.updateCashText(!0), model.playColorAnimation()
                            }, this)
                        }, this), scene.signals.trophy.add(function() {
                            this.showTrophyScene()
                        }, this), scene.signals.purchase.add(function(scene, itemName) {
                            var confirm = this.showPurchasePopupScene(itemName);
                            confirm.signals.next.add(function() {
                                Common.scene.signals.remove.addOnce(function() {
                                    scene.purchaseColor()
                                }, this)
                            }, this, 1)
                        }, this), scene.signals.name.add(function() {
                            var name = this.showNameScene();
                            name.signals.next.add(function() {
                                var texture = Common.assets.getTexture("transition_mask"),
                                    transition = new CutoutTransition(texture, 0);
                                Common.scene.remove(transition)
                            }, this, 1)
                        }, this), scene.signals.pause.add(function() {
                            this.showHelpScene(), Common.tracking.track(new p3.TrackingDataPlaydomGameAction("garage", "click_help"))
                        }, this), scene.signals.settings.add(function() {
                            this.showSettingsScene(), Common.tracking.track(new p3.TrackingDataPlaydomGameAction("garage", "click_settings"))
                        }, this), transition = new Transition, transition.push = !0, Common.scene.add(scene, transition);
                        break;
                    case 2:
                        scene = new GarageEngineScene, scene.signals.previous.add(function() {
                            Common.scene.remove(), Common.scene.signals.remove.addOnce(function() {
                                var model = Common.scene.top;
                                model.updateCashText(!1)
                            }, this)
                        }, this), scene.signals.trophy.add(function() {
                            this.showTrophyScene()
                        }, this), scene.signals.purchase.add(function(scene, itemName, type) {
                            var confirm = this.showPurchasePopupScene(itemName);
                            confirm.signals.next.add(function() {
                                switch (type) {
                                    case 0:
                                        scene.upgradeSpeed();
                                        break;
                                    case 1:
                                        scene.upgradeBoost()
                                }
                            }, this, 1)
                        }, this), scene.signals.name.add(function() {
                            var name = this.showNameScene();
                            name.signals.next.add(function() {
                                var texture = Common.assets.getTexture("transition_mask"),
                                    transition = new CutoutTransition(texture, 0);
                                Common.scene.remove(transition)
                            }, this, 1)
                        }, this), scene.signals.pause.add(function() {
                            this.showHelpScene(), Common.tracking.track(new p3.TrackingDataPlaydomGameAction("garage", "click_help"))
                        }, this), scene.signals.settings.add(function() {
                            this.showSettingsScene(), Common.tracking.track(new p3.TrackingDataPlaydomGameAction("garage", "click_settings"))
                        }, this), transition = new Transition, transition.push = !0, Common.scene.add(scene, transition);
                        break;
                    case 3:
                        scene = new GarageKitScene, scene.signals.previous.add(function() {
                            Common.scene.remove(), Common.scene.signals.remove.addOnce(function() {
                                var model = Common.scene.top;
                                model.updateCashText(!1)
                            }, this)
                        }, this), scene.signals.trophy.add(function() {
                            this.showTrophyScene()
                        }, this), scene.signals.purchase.add(function(scene, itemName, type) {
                            var confirm = this.showPurchasePopupScene(itemName);
                            confirm.signals.next.add(function() {
                                switch (type) {
                                    case -1:
                                        scene.purchaseKit();
                                        break;
                                    case 0:
                                        scene.upgradeKit();
                                        break;
                                    case 1:
                                        scene.upgradeTyre()
                                }
                            }, this, 1)
                        }, this), scene.signals.name.add(function() {
                            var name = this.showNameScene();
                            name.signals.next.add(function() {
                                var texture = Common.assets.getTexture("transition_mask"),
                                    transition = new CutoutTransition(texture, 0);
                                Common.scene.remove(transition)
                            }, this, 1)
                        }, this), scene.signals.pause.add(function() {
                            this.showHelpScene(), Common.tracking.track(new p3.TrackingDataPlaydomGameAction("garage", "click_help"))
                        }, this), scene.signals.settings.add(function() {
                            this.showSettingsScene(), Common.tracking.track(new p3.TrackingDataPlaydomGameAction("garage", "click_settings"))
                        }, this), transition = new Transition, transition.push = !0, Common.scene.add(scene, transition);
                        break;
                    case 4:
                        scene = new GarageDecalsScene, scene.signals.previous.add(function(scene, purchase) {
                            Common.scene.remove(), purchase && Common.scene.signals.remove.addOnce(function() {
                                var model = Common.scene.top;
                                model.animateCoins(), model.updateCashText(!0), model.playDecalAnimation()
                            }, this)
                        }, this), scene.signals.trophy.add(function() {
                            this.showTrophyScene()
                        }, this), scene.signals.purchase.add(function(scene, itemName) {
                            var confirm = this.showPurchasePopupScene(itemName);
                            confirm.signals.next.add(function() {
                                Common.scene.signals.remove.addOnce(function() {
                                    scene.purchaseDecal()
                                }, this)
                            }, this, 1)
                        }, this), scene.signals.name.add(function() {
                            var name = this.showNameScene();
                            name.signals.next.add(function() {
                                var texture = Common.assets.getTexture("transition_mask"),
                                    transition = new CutoutTransition(texture, 0);
                                Common.scene.remove(transition)
                            }, this, 1)
                        }, this), scene.signals.pause.add(function() {
                            this.showHelpScene(), Common.tracking.track(new p3.TrackingDataPlaydomGameAction("garage", "click_help"))
                        }, this), scene.signals.settings.add(function() {
                            this.showSettingsScene(), Common.tracking.track(new p3.TrackingDataPlaydomGameAction("garage", "click_settings"))
                        }, this), transition = new Transition, transition.push = !0, Common.scene.add(scene, transition)
                }
                var params = new AudioParams;
                return params.fadeIn = 1, Common.audio.playMusic("music_cars_splashmenu", params), scene
            }, Application.prototype.showPurchasePopupScene = function(itemName) {
                var scene = new PurchasePopupScene(itemName);
                scene.signals.next.add(function() {
                    Common.scene.remove()
                }, this), scene.signals.previous.add(function() {
                    Common.scene.remove()
                }, this);
                var transition = new Transition;
                return transition.push = !0, transition.replace = !1, Common.scene.add(scene, transition), scene
            }, Application.prototype.showPhotoScene = function(target) {
                var prev = Common.scene.top;
                this.blurIn(prev, 1);
                var scene = new PhotoScene(target);
                scene.signals.next.add(function() {
                    Common.scene.remove()
                }, this), scene.signals.out.add(function() {
                    this.blurOut(prev)
                }, this);
                var transition = new Transition;
                return transition.push = !0, transition.replace = !1, Common.scene.add(scene, transition), scene
            }, Application.prototype.showTrophyScene = function() {
                var texture, transition, scene = new TrophyScene;
                return scene.signals.achievements.add(function() {
                    this.showAchievementsScene()
                }, this), scene.signals.settings.add(function() {
                    this.showSettingsScene(), Common.tracking.track(new p3.TrackingDataPlaydomGameAction("garage", "click_settings"))
                }, this), scene.signals.back.add(function() {
                    texture = Common.assets.getTexture("transition_mask"), transition = new CutoutTransition(texture, 0), Common.scene.remove(transition)
                }, this), scene.signals.pause.add(function() {
                    this.showHelpScene(HelpScene.TYPE_TROPHIES), Common.tracking.track(new p3.TrackingDataPlaydomGameAction("garage", "click_help"))
                }, this), texture = Common.assets.getTexture("transition_mask"), transition = new CutoutTransition(texture, 0), transition.push = !0, Common.scene.add(scene, transition), scene
            }, Application.prototype.showAchievementsScene = function() {
                var texture, transition, scene = new AchievementsScene;
                return scene.signals.settings.add(function() {
                    this.showSettingsScene(), Common.tracking.track(new p3.TrackingDataPlaydomGameAction("garage", "click_settings"))
                }, this), scene.signals.back.add(function() {
                    texture = Common.assets.getTexture("transition_mask"), transition = new CutoutTransition(texture, 0), Common.scene.remove(transition)
                }, this), scene.signals.pause.add(function() {
                    this.showHelpScene(HelpScene.TYPE_ACHIEVEMENTS), Common.tracking.track(new p3.TrackingDataPlaydomGameAction("garage", "click_help"))
                }, this), texture = Common.assets.getTexture("transition_mask"), transition = new CutoutTransition(texture, 0), transition.push = !0, Common.scene.add(scene, transition), scene
            }, Application.prototype.showRaceModeScene = function() {
                var scene = new RaceModeScene;
                scene.signals.next.add(function(scene, type) {
                    switch (type) {
                        case 0:
                            this.showSingleRaceScene();
                            break;
                        case 1:
                            this.showSeriesRaceScene()
                    }
                }, this), scene.signals.previous.add(function() {
                    this.showGarageScene()
                }, this), scene.signals.settings.add(function() {
                    this.showSettingsScene(), Common.tracking.track(new p3.TrackingDataPlaydomGameAction("race_mode", "click_settings"))
                }, this);
                var texture = Common.assets.getTexture("transition_mask"),
                    transition = new CutoutTransition(texture, 0);
                Common.scene.add(scene, transition);
                var params = new AudioParams;
                return params.fadeIn = 1, Common.audio.playMusic("music_cars_preracesetup", params), scene
            }, Application.prototype.showSingleRaceScene = function() {
                var scene = new SingleRaceScene;
                scene.signals.next.add(function() {
                    if (Common.garage.isOptimalKit()) {
                        var cut = this.showCutsceneScene();
                        cut.signals.next.add(function() {
                            this.showTrackLoaderScene()
                        }, this, 1)
                    } else this.showPitstopScene()
                }, this), scene.signals.previous.add(function() {
                    this.showRaceModeScene()
                }, this), scene.signals.settings.add(function() {
                    this.showSettingsScene(), Common.tracking.track(new p3.TrackingDataPlaydomGameAction("single_race", "click_settings"))
                }, this);
                var texture = Common.assets.getTexture("transition_mask"),
                    transition = new CutoutTransition(texture, 0);
                Common.scene.add(scene, transition);
                var params = new AudioParams;
                return params.fadeIn = 1, Common.audio.playMusic("music_cars_preracesetup", params), scene
            }, Application.prototype.showSeriesRaceScene = function(nextRace) {
                nextRace = "boolean" == typeof nextRace ? nextRace : !1;
                var scene = new SeriesRaceScene(nextRace);
                scene.signals.next.add(function() {
                    if (Common.garage.isOptimalKit()) {
                        var cut = this.showCutsceneScene();
                        cut.signals.next.add(function() {
                            this.showTrackLoaderScene()
                        }, this, 1)
                    } else this.showPitstopScene()
                }, this), scene.signals.previous.add(function() {
                    this.showRaceModeScene()
                }, this), scene.signals.settings.add(function() {
                    this.showSettingsScene(), Common.tracking.track(new p3.TrackingDataPlaydomGameAction("series_race", "click_settings"))
                }, this), scene.signals["continue"].add(function() {
                    var cont = this.showContinueSeriesPopupScene();
                    cont.signals.next.add(function(reset) {
                        if (reset) {
                            var tm = Common.trackManager;
                            tm.currentSeries.reset(), scene.loadTracks(tm.currentSeries.id)
                        } else Common.scene.signals.remove.addOnce(function() {
                            this.showPitstopScene()
                        }, this)
                    }, this, 1)
                }, this);
                var texture = Common.assets.getTexture("transition_mask"),
                    transition = new CutoutTransition(texture, 0);
                Common.scene.add(scene, transition);
                var params = new AudioParams;
                return params.fadeIn = 1, Common.audio.playMusic("music_cars_preracesetup", params), scene
            }, Application.prototype.showContinueSeriesPopupScene = function() {
                var prev = Common.scene.top;
                this.blurIn(prev);
                var scene = new ContinueSeriesPopupScene;
                scene.signals.next.add(function(reset) {
                    Common.scene.remove()
                }, this), scene.signals.previous.add(function() {
                    Common.scene.remove()
                }, this), scene.signals.out.add(function() {
                    this.blurOut(prev)
                }, this);
                var transition = new Transition;
                return transition.push = !0, transition.replace = !1, Common.scene.add(scene, transition), scene
            }, Application.prototype.showPitstopScene = function() {
                var texture, transition, scene = new GaragePitstopScene;
                return scene.signals.next.add(function() {
                    var cut = this.showCutsceneScene();
                    cut.signals.next.add(function() {
                        this.showTrackLoaderScene()
                    }, this, 1)
                }, this), scene.signals.previous.add(function() {
                    texture = Common.assets.getTexture("transition_mask"), transition = new CutoutTransition(texture, 0), Common.scene.remove(transition)
                }, this), scene.signals.purchase.add(function(scene, itemName, type) {
                    var confirm = this.showPurchasePopupScene(itemName);
                    confirm.signals.next.add(function() {
                        switch (type) {
                            case -1:
                                scene.purchaseKit();
                                break;
                            case 0:
                                scene.upgradeKit();
                                break;
                            case 1:
                                scene.upgradeTyre()
                        }
                    }, this, 1)
                }, this), scene.signals.pause.add(function() {
                    this.showHelpScene(), Common.tracking.track(new p3.TrackingDataPlaydomGameAction("garage", "click_help"))
                }, this), scene.signals.settings.add(function() {
                    this.showSettingsScene(), Common.tracking.track(new p3.TrackingDataPlaydomGameAction("garage", "click_settings"))
                }, this), texture = Common.assets.getTexture("transition_mask"), transition = new CutoutTransition(texture, 0), transition.push = !0, Common.scene.add(scene, transition), scene
            }, Application.prototype.showCutsceneScene = function() {
                Common.garage.avatar = Common.garage.saveAvatar();
                var scene = new CutsceneScene,
                    texture = Common.assets.getTexture("transition_mask"),
                    transition = new CutoutTransition(texture, 0);
                return Common.scene.add(scene, transition), scene
            }, Application.prototype.showTrackLoaderScene = function() {
                var scene = new TrackLoaderScene;
                Common.scene.signals.add.addOnce(function() {
                    var tm = Common.trackManager;
                    tm.loadTrackAssets(tm.currentTrack.country, function(event) {
                        scene.loaded = event.progress / 100
                    }, function() {
                        scene.loaded = 1;
                        var tutorial = "tutorial" == tm.currentTrack.country,
                            that = this;
                        setTimeout(function() {
                            that.showGameScene.call(that, tutorial)
                        }, 2e3)
                    }, this)
                }, this);
                var transition = new Transition;
                return Common.scene.add(scene, transition), scene
            }, Application.prototype.showGameScene = function(tutorial, retry) {
                Common.score = 0, Common.garage.avatar = Common.garage.saveAvatar();
                var scene = new GameScene(tutorial, retry);
                scene.signals.next.add(function(scene, position, prize, pickups, seriesFinished) {
                    this.showResultScene(position, prize, pickups, seriesFinished, tutorial)
                }, this), scene.signals.previous.add(function() {}, this), scene.signals.pause.add(function() {
                    this.showPauseScene(tutorial)
                }, this);
                var texture = Common.assets.getTexture("transition_mask"),
                    transition = new CutoutTransition(texture, 0);
                return Common.scene.add(scene, transition), scene
            }, Application.prototype.showTutorialScene = function() {
                var tutorial = 100;
                Common.trackManager.selectTrack(tutorial), this.showTrackLoaderScene()
            }, Application.prototype.showPauseScene = function(tutorial) {
                var prev = Common.scene.top;
                this.blurIn(prev), Common.animator.paused = !0;
                var scene = new PauseScene;
                scene.signals.next.add(function() {
                    Common.animator.paused = !1, Common.scene.remove(), this.blurOut(prev)
                }, this), scene.signals.previous.add(function() {
                    Common.animator.paused = !1;
                    var quit = this.showPurchasePopupScene();
                    quit.signals.next.addOnce(function() {
                        this.showGarageScene()
                    }, this, 1)
                }, this), scene.signals.pause.add(function() {
                    Common.animator.paused = !1, this.showHelpScene(HelpScene.TYPE_GAME), Common.tracking.track(new p3.TrackingDataPlaydomGameAction("game", "click_help"))
                }, this), scene.signals.restart.add(function() {
                    Common.animator.paused = !1, this.showGameScene(tutorial, !0)
                }, this);
                var transition = new Transition;
                return transition.push = !0, transition.replace = !1, Common.scene.add(scene, transition), scene
            }, Application.prototype.showResultScene = function(position, prize, pickups, seriesFinished, tutorial) {
                var trackManager = Common.trackManager,
                    scene = new ResultScene(position, prize, pickups, seriesFinished);
                scene.signals.next.add(function() {
                    tutorial ? this.showGarageScene() : trackManager.isSeries ? this.showSeriesRaceScene(!0) : this.showSingleRaceScene()
                }, this), scene.signals.previous.add(function() {
                    this.showGarageScene()
                }, this), scene.signals.retry.add(function() {
                    this.showGameScene(tutorial)
                }, this), scene.signals.leader.add(function() {
                    this.showLeaderboardScene(), Common.tracking.track(new p3.TrackingDataPlaydomGameAction("race_results", "view_leaderboard"))
                }, this), scene.signals.settings.add(function() {
                    this.showSettingsScene(), Common.tracking.track(new p3.TrackingDataPlaydomGameAction("results", "click_settings"))
                }, this), scene.signals.pause.add(function() {
                    this.showHelpScene(), Common.tracking.track(new p3.TrackingDataPlaydomGameAction("results", "click_help"))
                }, this);
                var texture = Common.assets.getTexture("transition_mask"),
                    transition = new CutoutTransition(texture, 0);
                Common.scene.add(scene, transition);
                var params = new AudioParams;
                return params.fadeIn = 1, Common.audio.playMusic("music_cars_raceresults", params), scene
            }, Application.prototype.showLeaderboardScene = function() {
                var scene = new LeaderboardScene;
                scene.signals.next.add(function() {
                    Common.scene.remove()
                }, this);
                var transition = new Transition;
                return transition.push = !0, transition.replace = !1, Common.scene.add(scene, transition), scene
            }, Application.prototype.showCommsScene = function() {
                var scene = new CommsScene;
                scene.signals.previous.add(function() {
                    this.showSplashScene()
                }, this);
                var texture = Common.assets.getTexture("transition_mask"),
                    transition = new CutoutTransition(texture, 0);
                return Common.scene.add(scene, transition), scene
            }, Application.prototype.showRedeemCodeScene = function() {
                var scene = new RedeemCodeScene;
                scene.signals.error.add(function(error) {
                    this.showErrorPopupScene(error)
                }, this), scene.signals.reward.add(function(value) {
                    this.showRewardPopupScene(value)
                }, this), scene.signals.previous.add(function() {
                    this.showSplashScene()
                }, this);
                var texture = Common.assets.getTexture("transition_mask"),
                    transition = new CutoutTransition(texture, 0);
                return Common.scene.add(scene, transition), scene
            }, Application.prototype.showErrorPopupScene = function(type) {
                var prev = Common.scene.top;
                this.blurIn(prev);
                var scene = new ErrorPopupScene(type);
                scene.signals.next.add(function() {
                    Common.scene.remove()
                }, this), scene.signals.out.add(function() {
                    this.blurOut(prev)
                }, this);
                var transition = new Transition;
                return transition.push = !0, transition.replace = !1, Common.scene.add(scene, transition), scene
            }, Application.prototype.blurIn = function(scene, delay) {
                delay = delay || 0;
                var blur = new PIXI.filters.BlurFilter;
                blur.passes = 3, blur.blurX = blur.blurY = 0, scene.filters = [blur], TweenMax.to(blur, .2, {
                    delay: delay,
                    blurX: 8,
                    blurY: 8,
                    ease: Power1.easeInOut
                })
            }, Application.prototype.blurOut = function(scene, delay) {
                delay = delay || 0;
                var blur = scene.filters[0];
                TweenMax.to(blur, .4, {
                    delay: delay,
                    blurX: 0,
                    blurY: 0,
                    ease: Power1.easeInOut,
                    onComplete: function() {
                        scene.filters = null
                    },
                    onCompleteScope: this
                })
            }
        }, {
            "./AchievementData": 2,
            "./AchievementTypes": 4,
            "./AchievementsManager": 5,
            "./AchievementsScene": 6,
            "./AudioParams": 9,
            "./Award": 10,
            "./CarData": 15,
            "./Common": 23,
            "./CommsScene": 24,
            "./ContinueSeriesPopupScene": 25,
            "./CountryTypes": 27,
            "./CutoutTransition": 29,
            "./CutsceneScene": 30,
            "./DailyBonusScene": 31,
            "./ErrorPopupScene": 34,
            "./GameScene": 36,
            "./Garage": 37,
            "./GarageColorScene": 38,
            "./GarageDecalScene": 39,
            "./GarageEngineScene": 40,
            "./GarageKitScene": 41,
            "./GarageModelScene": 42,
            "./GaragePitstopScene": 43,
            "./HelpScene": 47,
            "./LeaderboardScene": 51,
            "./NameScene": 55,
            "./PauseScene": 58,
            "./PhotoScene": 59,
            "./PurchasePopupScene": 65,
            "./RaceModeScene": 70,
            "./RedeemCodeScene": 75,
            "./ResultScene": 76,
            "./RewardPopupScene": 77,
            "./SaveData": 82,
            "./SeriesRaceScene": 89,
            "./SeriesTypes": 90,
            "./SettingsScene": 91,
            "./SingleRaceScene": 93,
            "./SplashScene": 96,
            "./TrackData": 101,
            "./TrackLoaderScene": 102,
            "./TrackManager": 103,
            "./TrackSeriesData": 104,
            "./Transition": 105,
            "./TrophyScene": 106,
            "./WelcomeScene": 117
        }],
        8: [function(require, module, exports) {
            function AudioManager() {
                this._cache = {}, this._music = null, this._isMuted = !1
            }
            var AudioParams = require("./AudioParams");
            module.exports = AudioManager, AudioManager.prototype.addSounds = function(sounds, extensions, basePath) {
                basePath = basePath || "";
                var howl, name, url, urls, extension, i, j;
                for (i = 0; i < sounds.length; ++i) {
                    for (url = basePath + sounds[i], url = url.split("/"), name = url[url.length - 1], urls = [], j = 0; j < extensions.length; ++j) extension = extensions[j], urls.push(url.join("/") + extension);
                    howl = new Howl({
                        urls: urls,
                        volume: 1,
                        loop: !1,
                        autoplay: !1,
                        onloaderror: function() {
                            console.warn("Error loading sound - " + name)
                        }
                    }), howl.name = name, this._cache[name] = howl
                }
            }, AudioManager.prototype.removeSounds = function(sounds) {
                for (var name, n, howl, i = 0; i < sounds.length; ++i) {
                    name = sounds[i];
                    for (n in this._cache)
                        if (this._cache.hasOwnProperty(key) && (howl = this._cache[key], howl.name == n)) {
                            howl.unload(), delete this._cache[name];
                            break
                        }
                }
            }, AudioManager.prototype.playSound = function(name, params) {
                params = params || new AudioParams, "string" != typeof name && (name = name[Math.floor(Math.random() * name.length)]);
                var howl = this._cache[name];
                return howl ? (howl.volume(params.volume), howl.loop(params.loop), p3.Device && p3.Device.isAndroidStockBrowser && (howl.buffer = !0), params.fadeIn > 0 ? this.fadeIn(howl, params.fadeIn) : howl.play(), howl) : (console.warn("Could not find sound - " + name), null)
            }, AudioManager.prototype.playMusic = function(name, params) {
                if (params = params || new AudioParams, "string" != typeof name && (name = name[Math.floor(Math.random() * (name.length - 1))]), this._music && this._music.name == name) return this._music;
                var howl = this._cache[name];
                return howl ? (howl.volume(params.volume), howl.loop(!0), howl.__onend = function() {
                    params.callback && params.callback.call(params.scope)
                }, howl.on("end", howl.__onend), p3.Device && p3.Device.isAndroidStockBrowser && (howl.buffer = !0), params.fadeIn > 0 ? (this._music && this._music.name != name && this.fadeOut(this._music, params.fadeIn, function(howl) {
                    howl.stop()
                }, this), this.fadeIn(howl, params.fadeIn)) : (this._music && this.stopMusic(), howl.play()), this._music = howl, howl) : (console.warn("Could not find music - " + name), null)
            }, AudioManager.prototype.stopSound = function(name) {
                var howl;
                for (var n in this._cache)
                    if (this._cache.hasOwnProperty(n) && (howl = this._cache[n], howl.name == name)) {
                        howl.stop();
                        break
                    }
            }, AudioManager.prototype.stopMusic = function(name) {
                name = name || this._music.name, this._music && this._music.name == name && (this._music.__onend && this._music.off("end", this._music.__onend), this._music.stop(), this._music = null)
            }, AudioManager.prototype.mute = function(value) {
                this._isMuted = value, this._isMuted ? Howler.mute() : Howler.unmute()
            }, AudioManager.prototype.fadeIn = function(howl, duration, callback, scope) {
                duration = duration || 1, howl.volume(0), howl.play(), howl.__volume = howl._volume, TweenMax.killTweensOf(howl), TweenMax.to(howl, duration, {
                    __volume: 1,
                    ease: Power1.easeInOut,
                    onUpdate: function() {
                        howl.volume(howl.__volume)
                    },
                    onUpdateScope: this,
                    onComplete: callback,
                    onCompleteParams: [howl],
                    onCompleteScope: scope
                })
            }, AudioManager.prototype.fadeOut = function(howl, duration, callback, scope) {
                duration = duration || 1, howl.__volume = howl._volume, TweenMax.killTweensOf(howl), TweenMax.to(howl, duration, {
                    __volume: 0,
                    ease: Power1.easeInOut,
                    onUpdate: function() {
                        howl.volume(howl.__volume)
                    },
                    onUpdateScope: this,
                    onComplete: callback,
                    onCompleteParams: [howl],
                    onCompleteScope: scope
                })
            }, Object.defineProperty(AudioManager.prototype, "isMute", {
                get: function() {
                    return this._isMuted
                }
            })
        }, {
            "./AudioParams": 9
        }],
        9: [function(require, module, exports) {
            function AudioParams() {
                this.volume = 1, this.loop = !1, this.delay = 0, this.fadeIn = 0, this.priority = 0, this.callback = null, this.scope = window
            }
            module.exports = AudioParams
        }, {}],
        10: [function(require, module, exports) {
            function Award(id, name, description, texture) {
                this.id = id, this.name = name, this.description = description, this.texture = texture || PIXI.Texture.EMPTY, this.unlocked = !1
            }
            module.exports = Award
        }, {}],
        11: [function(require, module, exports) {
            function BernoulliView(avatar) {
                CarView.call(this, 16777215, avatar);
                var chassisOffset = new PIXI.Point(0, -2);
                this._shadow.offset = new PIXI.Point(0, 26), this._wheels.front.left.offset = new PIXI.Point(-108, 32), this._wheels.front.right.offset = new PIXI.Point(108, 32), this._wheels.rear.left.offset = new PIXI.Point(-138, 78), this._wheels.rear.right.offset = new PIXI.Point(138, 78), this._front.offset = new PIXI.Point(chassisOffset.x, 16 + chassisOffset.y), this._mid.offset = new PIXI.Point(chassisOffset.x, 16 + chassisOffset.y), this._back.offset = new PIXI.Point(chassisOffset.x, 20 + chassisOffset.y), this.addChild(this._wheels.rear.left), this.addChild(this._wheels.rear.right)
            }
            var CarView = (require("./CarShader"), require("./CarView")),
                Common = require("./Common");
            module.exports = BernoulliView, BernoulliView.prototype = Object.create(CarView.prototype), BernoulliView.prototype.constructor = BernoulliView, BernoulliView.prototype.update = function(distance, curvature, gradient, velocity, turnVelocity) {
                var scalar = 140;
                this._curvature += .4 * (turnVelocity + curvature - this._curvature), this._curvature = Math.max(-scalar, Math.min(scalar, this._curvature)), this._front.x = .4 * this._curvature + this._front.offset.x, this._front.y = -gradient * scalar * 1.6 + this._front.offset.y, this._mid.x = .1 * this._curvature + this._mid.offset.x, this._mid.y = -gradient * scalar * 1.3 + this._mid.offset.y, this._back.x = .14 * -this._curvature + this._back.offset.x, this._back.y = gradient * scalar + this._back.offset.y, this._shadow.x = this._back.x, this._shadow.y = this._wheels.rear.left.y + this._shadow.offset.y, this._front.rotation = 8e-4 * this._curvature, this._back.rotation = 8e-4 * this._curvature, this._wheels.front.left.x = this._front.x + this._wheels.front.left.offset.x, this._wheels.front.left.y = gradient * scalar + this._wheels.front.left.offset.y, this._wheels.front.right.x = this._front.x + this._wheels.front.right.offset.x, this._wheels.front.right.y = gradient * scalar + this._wheels.front.right.offset.y, this._wheels.rear.left.x = this._back.x + this._wheels.rear.left.offset.x, this._wheels.rear.left.y = gradient * scalar + this._wheels.rear.left.offset.y, this._wheels.rear.right.x = this._back.x + this._wheels.rear.right.offset.x, this._wheels.rear.right.y = gradient * scalar + this._wheels.rear.right.offset.y;
                var theta;
                theta = .008 * turnVelocity, 0 > theta && (theta *= .112), this._wheels.front.left.rotation = theta, theta = .008 * turnVelocity, theta > 0 && (theta *= .112), this._wheels.front.right.rotation = theta, theta = .008 * turnVelocity, 0 > theta && (theta *= .112), this._wheels.rear.left.rotation = theta, theta = .008 * turnVelocity, theta > 0 && (theta *= .112), this._wheels.rear.right.rotation = theta, velocity = Math.max(0, velocity), this._wheels.front.left.animationSpeed = velocity / .2, this._wheels.front.right.animationSpeed = velocity / .2, this._wheels.rear.left.animationSpeed = velocity / .2, this._wheels.rear.right.animationSpeed = velocity / .2
            }, BernoulliView.prototype.createFrontLayer = function() {
                return new PIXI.Sprite(Common.assets.getTexture("car_bernoulli_body_00"))
            }, BernoulliView.prototype.createMidLayer = function() {
                return new PIXI.Sprite(Common.assets.getTexture("car_bernoulli_body_01"))
            }, BernoulliView.prototype.createBackLayer = function() {
                var back = new PIXI.Sprite(Common.assets.getTexture("car_bernoulli_body_02")),
                    spoiler = this.createSpoilerLayer();
                return spoiler.y = 20, back.addChild(spoiler), back
            }, BernoulliView.prototype.createSpoilerLayer = function() {
                var spoiler = new PIXI.Sprite(Common.assets.getTexture("car_bernoulli_spoiler_02"));
                return spoiler.anchor = new PIXI.Point(.5, 1), spoiler
            }, BernoulliView.prototype.createFrontWheel = function() {
                var sequence = new p3.MovieClipSequence;
                return sequence.addTextures([Common.assets.getTexture("car_bernoulli_wheels_front_0"), Common.assets.getTexture("car_bernoulli_wheels_front_1"), Common.assets.getTexture("car_bernoulli_wheels_front_2"), Common.assets.getTexture("car_bernoulli_wheels_front_3")]), new p3.MovieClip(sequence)
            }, BernoulliView.prototype.createRearWheel = function() {
                var sequence = new p3.MovieClipSequence;
                return sequence.addTextures([Common.assets.getTexture("car_bernoulli_wheels_rear_0"), Common.assets.getTexture("car_bernoulli_wheels_rear_1"), Common.assets.getTexture("car_bernoulli_wheels_rear_2"), Common.assets.getTexture("car_bernoulli_wheels_rear_3")]), new p3.MovieClip(sequence)
            }, BernoulliView.prototype.createShadow = function() {
                return new PIXI.Sprite(Common.assets.getTexture("car_bernoulli_shadow"))
            }
        }, {
            "./CarShader": 19,
            "./CarView": 21,
            "./Common": 23
        }],
        12: [function(require, module, exports) {
            function BoostView(avatar) {
                CarView.call(this, 16777215, avatar);
                var chassisOffset = new PIXI.Point(0, 6);
                this._shadow.offset = new PIXI.Point(0, 26), this._wheels.front.left.offset = new PIXI.Point(-82, 26), this._wheels.front.right.offset = new PIXI.Point(82, 26), this._wheels.rear.left.offset = new PIXI.Point(-124, 78), this._wheels.rear.right.offset = new PIXI.Point(124, 78), this._front.offset = new PIXI.Point(chassisOffset.x, -8 + chassisOffset.y), this._mid.offset = new PIXI.Point(chassisOffset.x, -4 + chassisOffset.y), this._back.offset = new PIXI.Point(chassisOffset.x, chassisOffset.y)
            }
            var CarView = (require("./CarShader"), require("./CarView")),
                Common = require("./Common");
            module.exports = BoostView, BoostView.prototype = Object.create(CarView.prototype), BoostView.prototype.constructor = BoostView, BoostView.prototype.update = function(distance, curvature, gradient, velocity, turnVelocity) {
                var scalar = 140;
                this._curvature += .4 * (turnVelocity + curvature - this._curvature), this._curvature = Math.max(-scalar, Math.min(scalar, this._curvature)), this._front.x = .4 * this._curvature + this._front.offset.x, this._front.y = -gradient * scalar * 1.6 + this._front.offset.y, this._mid.x = .1 * this._curvature + this._mid.offset.x, this._mid.y = -gradient * scalar * 1.3 + this._mid.offset.y, this._back.x = .14 * -this._curvature + this._back.offset.x, this._back.y = gradient * scalar + this._back.offset.y, this._shadow.x = this._back.x, this._shadow.y = this._wheels.rear.left.y + this._shadow.offset.y, this._front.rotation = 8e-4 * this._curvature, this._back.rotation = 8e-4 * this._curvature, this._wheels.front.left.x = this._front.x + this._wheels.front.left.offset.x, this._wheels.front.left.y = gradient * scalar + this._wheels.front.left.offset.y, this._wheels.front.right.x = this._front.x + this._wheels.front.right.offset.x, this._wheels.front.right.y = gradient * scalar + this._wheels.front.right.offset.y, this._wheels.rear.left.x = this._back.x + this._wheels.rear.left.offset.x, this._wheels.rear.left.y = gradient * scalar + this._wheels.rear.left.offset.y, this._wheels.rear.right.x = this._back.x + this._wheels.rear.right.offset.x, this._wheels.rear.right.y = gradient * scalar + this._wheels.rear.right.offset.y;
                var theta;
                theta = .008 * turnVelocity, 0 > theta && (theta *= .112), this._wheels.front.left.rotation = theta, theta = .008 * turnVelocity, theta > 0 && (theta *= .112), this._wheels.front.right.rotation = theta, theta = .008 * turnVelocity, 0 > theta && (theta *= .112), this._wheels.rear.left.rotation = theta, theta = .008 * turnVelocity, theta > 0 && (theta *= .112), this._wheels.rear.right.rotation = theta, velocity = Math.max(0, velocity), this._wheels.front.left.animationSpeed = velocity / .2, this._wheels.front.right.animationSpeed = velocity / .2, this._wheels.rear.left.animationSpeed = velocity / .2, this._wheels.rear.right.animationSpeed = velocity / .2
            }, BoostView.prototype.createFrontLayer = function() {
                return new PIXI.Sprite(Common.assets.getTexture("car_boost_body_00"))
            }, BoostView.prototype.createMidLayer = function() {
                return new PIXI.Sprite(Common.assets.getTexture("car_boost_body_01"))
            }, BoostView.prototype.createBackLayer = function() {
                var back = new PIXI.Sprite(Common.assets.getTexture("car_boost_body_02")),
                    spoiler = this.createSpoilerLayer();
                return spoiler.y = -14, back.addChild(spoiler), back
            }, BoostView.prototype.createSpoilerLayer = function() {
                var spoiler = new PIXI.Sprite(Common.assets.getTexture("car_boost_spoiler_02"));
                return spoiler.anchor = new PIXI.Point(.5, 1), spoiler
            }, BoostView.prototype.createFrontWheel = function() {
                var sequence = new p3.MovieClipSequence;
                return sequence.addTextures([Common.assets.getTexture("car_boost_wheels_front_0"), Common.assets.getTexture("car_boost_wheels_front_1"), Common.assets.getTexture("car_boost_wheels_front_2"), Common.assets.getTexture("car_boost_wheels_front_3")]), new p3.MovieClip(sequence)
            }, BoostView.prototype.createRearWheel = function() {
                var sequence = new p3.MovieClipSequence;
                return sequence.addTextures([Common.assets.getTexture("car_boost_wheels_rear_0"), Common.assets.getTexture("car_boost_wheels_rear_1"), Common.assets.getTexture("car_boost_wheels_rear_2"), Common.assets.getTexture("car_boost_wheels_rear_3")]), new p3.MovieClip(sequence)
            }, BoostView.prototype.createShadow = function() {
                return new PIXI.Sprite(Common.assets.getTexture("car_boost_shadow"))
            }
        }, {
            "./CarShader": 19,
            "./CarView": 21,
            "./Common": 23
        }],
        13: [function(require, module, exports) {
            function Car(view) {
                this.signals = {}, this.signals.lap = new signals.Signal, this.signals.nitro = new signals.Signal, this.acceleration = 4.6, this.velocity = 0, this.turnAccel = 12e3, this.turnSpeed = 0, this.turnVelocity = 0, this.linearDamping = .994, this.turnDamping = .914, this.brakeDamping = .97, this.minBrakeSpeed = 2, this.nitroFuel = 0, this.nitroFuelMax = 200,
                    this.nitroTick = 2, this.nitroDecay = 48, this.nitroMultiplier = 1.4, this.nitroSuperMultiplier = 1.2, this.nitroMin = .14 * this.nitroFuelMax, this.lap = 0, this.realDistance = -1, this.driving = !1, this.laneIndex = 0, this.laneSpacing = 80, this.laneCount = 2, this.laneArriveRadius = 400, this.distanceOffset = 0, this.isHit = !1, this._nitroActive = !1, this._nitroSuperBoost = !1, this._dustEmitter = null, this._lastLap = this.lap, view = view || new SaloonView(16777215), view.startEngine(), RoadEntity.call(this, RoadEntity.TYPE_MOVING, view)
            }
            var Common = require("./Common"),
                Point4 = (require("./LightningView"), require("./Point4")),
                Powerup = require("./Powerup"),
                RaceEmitter = require("./RaceEmitter"),
                RoadEntity = require("./RoadEntity"),
                SaloonView = require("./V8View");
            module.exports = Car, Car.prototype = Object.create(RoadEntity.prototype), Car.prototype.constructor = Car, Car.prototype.destroy = function() {
                this.signals.lap.dispose()
            }, Car.prototype.update = function() {
                if (RoadEntity.prototype.update.call(this), -1 == this.realDistance && (this.realDistance = this.distance), this.driving) {
                    var acceleration = this.acceleration;
                    this._nitroActive && this.nitroFuel > 0 && (acceleration *= this.nitroMultiplier * (this._nitroSuperBoost ? this.nitroSuperMultiplier : 1)), this.velocity += acceleration * p3.Timestep.deltaTime
                }
                this.velocity *= this.linearDamping, this.distance += this.velocity * p3.Timestep.deltaTime, this.realDistance += this.velocity * p3.Timestep.deltaTime;
                var coef = Math.min(1, this.velocity / 8);
                this.turnVelocity += this.turnSpeed * coef * p3.Timestep.deltaTime, this.turnVelocity *= this.turnDamping, this.offset.x += this.turnVelocity * p3.Timestep.deltaTime, Math.abs(this.velocity) < .01 && (this.velocity = 0), Math.abs(this.turnVelocity) < .01 && (this.turnVelocity = 0), this.updateView(), this.updateEmitters(), this.updateNitro(), this.lap = Math.floor(this.finalDistance / (this.engine.track.length - 1)), this._lastLap != this.lap && (this._lastLap = this.lap, this.signals.lap.dispatch(this))
            }, Car.prototype.updateNitro = function() {
                this._nitroActive ? this.nitroFuel -= this.nitroDecay * p3.Timestep.deltaTime : this.driving && (this.nitroFuel += this.nitroTick * p3.Timestep.deltaTime), this.nitroFuel = Math.max(0, Math.min(this.nitroFuelMax, this.nitroFuel)), this.nitroFuel <= 0 && this.stopNitro()
            }, Car.prototype.updateView = function() {
                var curvature = 2 * this.engine.getTrackCurvature(this.distance),
                    gradient = this.engine.getTrackGradient(this.distance);
                this._view.update(this.distance, 160 * curvature, .36 * gradient, this.velocity, .026 * this.turnVelocity)
            }, Car.prototype.updateEmitters = function() {
                var emit = Math.abs(this.engine.getTrackCurvature(this.distance) * this.velocity * 1.2) > .4;
                this._dustEmitter || (this._dustEmitter = new RaceEmitter(this.engine, [Common.assets.getTexture("particle_car_dust1"), Common.assets.getTexture("particle_car_dust2"), Common.assets.getTexture("particle_car_dust3"), Common.assets.getTexture("particle_car_dust4")], Common.assets.getJSON("car_dust")), this._dustEmitter.zDepthOffset = 1), this._dustEmitter.emit = emit, this._dustEmitter.zSpeed = .78 * this.velocity, this._dustEmitter.acceleration.z = -2, this._dustEmitter.update(p3.Timestep.deltaTime), this._dustEmitter.updateOwnerPos(this.distance + .6, this.getEmitterPosition())
            }, Car.prototype.getEmitterPosition = function() {
                return new PIXI.Point(this.offset.x + this.view.back.x, this.offset.y + this.view.back.y + 54)
            }, Car.prototype.brake = function() {
                this.velocity > this.minBrakeSpeed && (this.velocity *= this.brakeDamping)
            }, Car.prototype.startNitro = function() {
                return this.nitroFuel > this.nitroMin && !this._nitroActive ? (this._nitroActive = !0, this.nitroFuel == this.nitroFuelMax && (this._nitroSuperBoost = !0), this.signals.nitro.dispatch(!0, this._nitroSuperBoost), !0) : !1
            }, Car.prototype.stopNitro = function() {
                return this._nitroActive ? (this._nitroActive = !1, this._nitroSuperBoost = !1, this.signals.nitro.dispatch(!1, !1), !0) : !1
            }, Car.prototype.usePowerup = function(id) {
                switch (id) {
                    case Powerup.TYPE_INSTANT_BOOST:
                        this.nitroFuel += .1 * this.nitroFuelMax, this.nitroFuel = Math.min(this.nitroFuelMax, this.nitroFuel)
                }
            }, Car.prototype.getHeading = function() {
                var p1 = this.global3d.clone(),
                    p2 = this.engine.getPointAt(this.distance + Math.max(.001, this.velocity)),
                    h = new Point4(p2.x - p1.x, p2.y - p1.y, p2.z - p1.z);
                return h.normalize(), h
            }, Car.prototype.calculateDotProduct = function(car) {
                var h1 = this.getHeading(),
                    h2 = car.getHeading();
                return h1.x * h2.x + h1.y * h2.y
            }, Car.prototype.calculatePerpProduct = function(car) {
                var h1 = this.getHeading(),
                    h2 = car.getHeading();
                return h1.y * h2.x + -h1.x * h2.y
            }, Object.defineProperty(Car.prototype, "finalDistance", {
                get: function() {
                    return this.realDistance + this.distanceOffset
                }
            }), Object.defineProperty(Car.prototype, "nitroActive", {
                get: function() {
                    return this._nitroActive
                }
            }), Object.defineProperty(Car.prototype, "nitroSuperBoost", {
                get: function() {
                    return this._nitroSuperBoost
                }
            })
        }, {
            "./Common": 23,
            "./LightningView": 52,
            "./Point4": 62,
            "./Powerup": 63,
            "./RaceEmitter": 67,
            "./RoadEntity": 79,
            "./V8View": 115
        }],
        14: [function(require, module, exports) {
            function CarColorData(name, color, cost, unlocked) {
                this.name = name, this.color = color, this.cost = cost, this.unlocked = unlocked
            }
            require("./Common");
            module.exports = CarColorData
        }, {
            "./Common": 23
        }],
        15: [function(require, module, exports) {
            function CarData(id, model, colors, engines, kits, decals) {
                this.id = id, this.model = model, this.color = 0, this.engine = 0, this.kit = 0, this.decal = 0;
                var copy = Common.copy,
                    language = Common.language,
                    config = Common.config.cars[0];
                this.colors = colors || [new CarColorData(copy.color_white[language], 16777215, config.colors.white.cost, !0), new CarColorData(copy.color_red[language], 15931416, config.colors.red.cost, !1), new CarColorData(copy.color_orange[language], 16737813, config.colors.orange.cost, !1), new CarColorData(copy.color_yellow[language], 16766481, config.colors.yellow.cost, !1), new CarColorData(copy.color_limegreen[language], 9230336, config.colors.limegreen.cost, !1), new CarColorData(copy.color_darkgreen[language], 218384, config.colors.darkgreen.cost, !1), new CarColorData(copy.color_lightblue[language], 4502486, config.colors.lightblue.cost, !1), new CarColorData(copy.color_blue[language], 884431, config.colors.blue.cost, !1), new CarColorData(copy.color_darkblue[language], 149144, config.colors.darkblue.cost, !1), new CarColorData(copy.color_purple[language], 6037137, config.colors.purple.cost, !1), new CarColorData(copy.color_lightpink[language], 15701438, config.colors.lightpink.cost, !1), new CarColorData(copy.color_hotpink[language], 15876462, config.colors.hotpink.cost, !1), new CarColorData(copy.color_barrelgrey[language], 4342344, config.colors.darkgrey.cost, !1), new CarColorData(copy.color_black[language], 784, config.colors.black.cost, !1), new CarColorData(copy.color_lightgrey[language], 9935772, config.colors.lightgrey.cost, !1)], this.decals = decals || [new CarDecalData("none", 0, !0), new CarDecalData(copy.decal1[language], config.decals.decal1.cost, !1), new CarDecalData(copy.decal2[language], config.decals.decal2.cost, !1), new CarDecalData(copy.decal3[language], config.decals.decal3.cost, !1), new CarDecalData(copy.decal4[language], config.decals.decal4.cost, !1), new CarDecalData(copy.decal5[language], config.decals.decal5.cost, !1)], this.engines = engines || [new CarEngineData(0, 0, [
                    [1, 0],
                    [1.02, config.engines.speed[0]],
                    [1.04, config.engines.speed[1]],
                    [1.06, config.engines.speed[2]],
                    [1.08, config.engines.speed[3]],
                    [1.1, config.engines.speed[4]]
                ], [
                    [1, 0],
                    [1.02, config.engines.boost[0]],
                    [1.04, config.engines.boost[1]],
                    [1.06, config.engines.boost[2]],
                    [1.08, config.engines.boost[3]],
                    [1.1, config.engines.boost[4]]
                ])], this.kits = kits || [new CarKitData(copy.kit_desert[language], 0, 0, [
                    [.994, 0],
                    [.9942, config.kits.kit3.kit[0]],
                    [.9943, config.kits.kit3.kit[1]],
                    [.9944, config.kits.kit3.kit[2]],
                    [.9946, config.kits.kit3.kit[3]]
                ], [
                    [1, 0],
                    [1.01, config.kits.kit3.tyre[0]],
                    [1.02, config.kits.kit3.tyre[1]],
                    [1.03, config.kits.kit3.tyre[2]],
                    [1.04, config.kits.kit3.tyre[3]]
                ], 0, !0), new CarKitData(copy.kit_street[language], 0, 0, [
                    [.994, 0],
                    [.9942, config.kits.kit4.kit[0]],
                    [.9943, config.kits.kit4.kit[1]],
                    [.9944, config.kits.kit4.kit[2]],
                    [.9946, config.kits.kit4.kit[3]]
                ], [
                    [1, 0],
                    [1.01, config.kits.kit4.tyre[0]],
                    [1.02, config.kits.kit4.tyre[1]],
                    [1.03, config.kits.kit4.tyre[2]],
                    [1.04, config.kits.kit4.tyre[3]]
                ], 0, !0), new CarKitData(copy.kit_aerodynamic[language], 0, 0, [
                    [.994, 0],
                    [.9942, config.kits.kit5.kit[0]],
                    [.9943, config.kits.kit5.kit[1]],
                    [.9944, config.kits.kit5.kit[2]],
                    [.9946, config.kits.kit5.kit[3]]
                ], [
                    [1, 0],
                    [1.01, config.kits.kit5.tyre[0]],
                    [1.02, config.kits.kit5.tyre[1]],
                    [1.03, config.kits.kit5.tyre[2]],
                    [1.04, config.kits.kit5.tyre[3]]
                ], 0, !0), new CarKitData(copy.kit_urban[language], 0, 0, [
                    [.994, 0],
                    [.9942, config.kits.kit1.kit[0]],
                    [.9943, config.kits.kit1.kit[1]],
                    [.9944, config.kits.kit1.kit[2]],
                    [.9946, config.kits.kit1.kit[3]]
                ], [
                    [1, 0],
                    [1.01, config.kits.kit1.tyre[0]],
                    [1.02, config.kits.kit1.tyre[1]],
                    [1.03, config.kits.kit1.tyre[2]],
                    [1.04, config.kits.kit1.tyre[3]]
                ], 0, !0), new CarKitData(copy.kit_jungle[language], 0, 0, [
                    [.994, 0],
                    [.9942, config.kits.kit2.kit[0]],
                    [.9943, config.kits.kit2.kit[1]],
                    [.9944, config.kits.kit2.kit[2]],
                    [.9946, config.kits.kit2.kit[3]]
                ], [
                    [1, 0],
                    [1.01, config.kits.kit2.tyre[0]],
                    [1.02, config.kits.kit2.tyre[1]],
                    [1.03, config.kits.kit2.tyre[2]],
                    [1.04, config.kits.kit2.tyre[3]]
                ], 0, !0)]
            }
            var Common = require("./Common"),
                CarColorData = require("./CarColorData"),
                CarDecalData = require("./CarDecalData"),
                CarEngineData = require("./CarEngineData"),
                CarKitData = require("./CarKitData");
            module.exports = CarData, CarData.prototype.reset = function() {
                switch (this.color = 0, this.engine = 0, this.decal = 0, this.id) {
                    case 0:
                        this.kit = 1;
                        break;
                    case 1:
                        this.kit = 0;
                        break;
                    case 2:
                        this.kit = 2;
                        break;
                    case 3:
                        this.kit = 4;
                        break;
                    case 4:
                        this.kit = 3
                }
            }
        }, {
            "./CarColorData": 14,
            "./CarDecalData": 16,
            "./CarEngineData": 17,
            "./CarKitData": 18,
            "./Common": 23
        }],
        16: [function(require, module, exports) {
            function CarDecalData(name, cost, unlocked) {
                this.name = name, this.cost = cost, this.unlocked = unlocked
            }
            require("./Common");
            module.exports = CarDecalData
        }, {
            "./Common": 23
        }],
        17: [function(require, module, exports) {
            function CarEngineData(speedLevel, boostLevel, speedData, boostData) {
                this.speedLevel = speedLevel, this.boostLevel = boostLevel, this.speedData = speedData, this.boostData = boostData
            }
            require("./Common");
            module.exports = CarEngineData, CarEngineData.prototype.getSpeedValue = function(level) {
                return this.speedData[level][0]
            }, CarEngineData.prototype.getBoostValue = function(level) {
                return this.boostData[level][0]
            }, CarEngineData.prototype.getSpeedCost = function(level) {
                return this.speedData[level][1]
            }, CarEngineData.prototype.getBoostCost = function(level) {
                return this.boostData[level][1]
            }, Object.defineProperty(CarEngineData.prototype, "isSpeedMaxed", {
                get: function() {
                    return this.speedLevel >= this.speedData.length - 1
                }
            }), Object.defineProperty(CarEngineData.prototype, "isBoostMaxed", {
                get: function() {
                    return this.boostLevel >= this.boostData.length - 1
                }
            })
        }, {
            "./Common": 23
        }],
        18: [function(require, module, exports) {
            function CarKitData(name, kitLevel, tyreLevel, kitData, tyreData, cost, unlocked) {
                this.name = name, this.kitLevel = kitLevel, this.tyreLevel = tyreLevel, this.kitData = kitData, this.tyreData = tyreData, this.cost = cost, this.unlocked = unlocked
            }
            require("./Common");
            module.exports = CarKitData, CarKitData.prototype.getKitValue = function(level) {
                return this.kitData[level][0]
            }, CarKitData.prototype.getTyreValue = function(level) {
                return this.tyreData[level][0]
            }, CarKitData.prototype.getKitCost = function(level) {
                return this.kitData[level][1]
            }, CarKitData.prototype.getTyreCost = function(level) {
                return this.tyreData[level][1]
            }, Object.defineProperty(CarKitData.prototype, "isKitMaxed", {
                get: function() {
                    return this.kitLevel >= this.kitData.length - 1
                }
            }), Object.defineProperty(CarKitData.prototype, "isTyreMaxed", {
                get: function() {
                    return this.tyreLevel >= this.tyreData.length - 1
                }
            })
        }, {
            "./Common": 23
        }],
        19: [function(require, module, exports) {
            function CarShader(paintColor, maskOffset, shininess, shineOffset) {
                maskOffset = maskOffset || new PIXI.Point, shininess = "number" == typeof shininess ? shininess : .6, shineOffset = shineOffset || new PIXI.Point;
                var color = p3.Color.hex2rgb(paintColor);
                PIXI.AbstractFilter.call(this, null, ["precision lowp float;", "varying vec2 vTextureCoord;", "varying vec4 vColor;", "uniform sampler2D uSampler;", "uniform vec4 uPaintColor;", "uniform vec2 uMaskOffset;", "uniform float uShininess;", "uniform vec2 uShineOffset;", "void main(void) {", "vec4 color = texture2D(uSampler, vTextureCoord);", "vec4 paint = vec4(1.0);", "if (uMaskOffset.x + uMaskOffset.y > 0.0) {", "vec4 mask  = texture2D(uSampler, vTextureCoord + uMaskOffset);", "paint = vec4(clamp(uPaintColor.rgb + mask.rgb, 0.0, 1.0), 1.0);", "} else {", "paint = vec4(clamp(uPaintColor.rgb, 0.0, 1.0), 1.0);", "}", "vec4 shine     = texture2D(uSampler, vTextureCoord + uShineOffset) * uShininess;", "gl_FragColor   = color * paint + shine;", "}"].join("\n"), {
                    uPaintColor: {
                        type: "v4",
                        value: {
                            x: color.r / 255,
                            y: color.g / 255,
                            z: color.b / 255,
                            w: 1
                        }
                    },
                    uMaskOffset: {
                        type: "v2",
                        value: {
                            x: maskOffset.x,
                            y: maskOffset.y
                        }
                    },
                    uShineOffset: {
                        type: "v2",
                        value: {
                            x: shineOffset.x,
                            y: shineOffset.y
                        }
                    },
                    uShininess: {
                        type: "f",
                        value: shininess
                    }
                })
            }
            module.exports = CarShader, CarShader.prototype = Object.create(PIXI.AbstractFilter.prototype), CarShader.prototype.constructor = CarShader, Object.defineProperty(CarShader.prototype, "paintColor", {
                get: function() {
                    return this._paintColor
                },
                set: function(value) {
                    var color = p3.Color.hex2rgb(value);
                    this.uniforms.uPaintColor.value = {
                        x: color.r / 255,
                        y: color.g / 255,
                        z: color.b / 255,
                        w: 1
                    }
                }
            })
        }, {}],
        20: [function(require, module, exports) {
            function CarSpine(spineData) {
                this._tinted = [], this._decal = null, this._paintColor = null, this._decalTheme = 0, this._kits = [], PIXI.spine.Spine.call(this, spineData)
            }
            var Common = require("./Common"),
                CarShader = require("./CarShader");
            module.exports = CarSpine, CarSpine.prototype = Object.create(PIXI.spine.Spine.prototype), CarSpine.prototype.constructor = CarSpine, CarSpine.prototype.createSprite = function(slot, attachment) {
                var maskOffset, sprite = PIXI.spine.Spine.prototype.createSprite(slot, attachment),
                    name = attachment.name;
                return -1 != name.indexOf("body_") ? (maskOffset = new PIXI.Point((sprite.texture.width + 2) / sprite.texture.baseTexture.width, 0), sprite.shader = new CarShader(this._paintColor, maskOffset, 0), this._tinted.push(sprite)) : -1 != name.indexOf("eyes") ? (sprite.shader = new CarShader(this._paintColor, null, 0), this._tinted.push(sprite)) : -1 != name.indexOf("decal") ? this._decal = sprite : -1 != name.indexOf("special") && (sprite.name = name, sprite.visible = !1, this._kits.push(sprite), this._kits.sort(function(a, b) {
                    var split = a.name.split("_");
                    return a = parseInt(split[split.length - 1]), split = b.name.split("_"), b = parseInt(split[split.length - 1]), a - b
                })), sprite
            }, Object.defineProperty(CarSpine.prototype, "paintColor", {
                get: function() {
                    return this._paintColor
                },
                set: function(value) {
                    this._paintColor = value;
                    for (var sprite, i = 0; i < this._tinted.length; ++i) sprite = this._tinted[i], sprite.shader.paintColor = value
                }
            }), Object.defineProperty(CarSpine.prototype, "decalTheme", {
                get: function() {
                    return this._decalTheme
                },
                set: function(value) {
                    var car = Common.garage.myCar;
                    this._decalTheme = value, this._decal.texture = value > 0 ? Common.assets.getTexture("car_" + p3.Utils.padNumber(car.id, 2) + "_garage_decal_" + p3.Utils.padNumber(value - 1, 2)) : PIXI.Texture.EMPTY
                }
            }), Object.defineProperty(CarSpine.prototype, "kitTheme", {
                get: function() {
                    return this._kitTheme
                },
                set: function(value) {
                    this._kitTheme = value;
                    for (var kit, i = 0; i < this._kits.length; ++i) kit = this._kits[i], kit.visible = !1;
                    switch (value) {
                        case 0:
                            this._kits[0].visible = !0, this._kits[1].visible = !0, this.skeleton.setSkinByName("wheels_standard");
                            break;
                        case 1:
                            this.skeleton.setSkinByName("wheels_drift");
                            break;
                        case 2:
                            this._kits[4].visible = !0, this.skeleton.setSkinByName("wheels_standard");
                            break;
                        case 3:
                            this._kits[2].visible = !0, this.skeleton.setSkinByName("wheels_drift");
                            break;
                        case 4:
                            this._kits[0].visible = !0, this._kits[3].visible = !0, this.skeleton.setSkinByName("wheels_dirt");
                            break;
                        default:
                            this.skeleton.setSkinByName("wheels_standard")
                    }
                    this.skeleton.setSlotsToSetupPose()
                }
            })
        }, {
            "./CarShader": 19,
            "./Common": 23
        }],
        21: [function(require, module, exports) {
            function CarView(color, avatar) {
                PIXI.Container.call(this), this._color = "number" == typeof color ? color : 16777215, this._avatar = avatar || PIXI.Texture.EMPTY, this._shininess = .4, this._curvature = 0, this._shadow = this.createShadow(), this._shadow.alpha = .8, this._shadow.anchor = new PIXI.Point(.5, .5), this._shadow.offset = new PIXI.Point, this.addChild(this._shadow), this._wheels = {}, this._wheels.front = {}, this._wheels.rear = {}, this._wheels.front.left = this.createFrontWheel(), this._wheels.front.left.anchor = new PIXI.Point(.5, .5), this._wheels.front.left.offset = new PIXI.Point, this._wheels.front.left.looping = !0, this._wheels.front.left.play(), this.addChild(this._wheels.front.left), this._wheels.front.right = this.createFrontWheel(), this._wheels.front.right.anchor = new PIXI.Point(.5, .5), this._wheels.front.right.offset = new PIXI.Point, this._wheels.front.right.looping = !0, this._wheels.front.right.scale.x = -1, this._wheels.front.right.play(), this.addChild(this._wheels.front.right), this._front = this.createFrontLayer(), this._front.anchor = new PIXI.Point(.5, .5), this._front.offset = new PIXI.Point, this.addChild(this._front), this._mid = this.createMidLayer(), this._mid.anchor = new PIXI.Point(.5, .5), this._mid.offset = new PIXI.Point, this.addChild(this._mid), this._wheels.rear.left = this.createRearWheel(), this._wheels.rear.left.anchor = new PIXI.Point(.5, .5), this._wheels.rear.left.offset = new PIXI.Point, this._wheels.rear.left.looping = !0, this._wheels.rear.left.play(), this.addChild(this._wheels.rear.left), this._wheels.rear.right = this.createRearWheel(), this._wheels.rear.right.anchor = new PIXI.Point(.5, .5), this._wheels.rear.right.offset = new PIXI.Point, this._wheels.rear.right.looping = !0, this._wheels.rear.right.scale.x = -1, this._wheels.rear.right.play(), this.addChild(this._wheels.rear.right), this._back = this.createBackLayer(), this._back.anchor = new PIXI.Point(.5, .5), this._back.offset = new PIXI.Point, this.addChild(this._back)
            }
            var Common = require("./Common");
            module.exports = CarView, CarView.prototype = Object.create(PIXI.Container.prototype), CarView.prototype.constructor = CarView, CarView.prototype.destroy = function() {
                this.stopEngine()
            }, CarView.prototype.update = function(distance, curvature, gradient, velocity, turnVelocity) {}, CarView.prototype.startEngine = function() {
                this.stopEngine(), TweenMax.to(this._front.scale, .04, {
                    y: this._front.scale.y - .04,
                    yoyo: !0,
                    repeat: -1
                }), TweenMax.to(this._mid.scale, .04, {
                    delay: .01,
                    y: this._mid.scale.y - .03,
                    yoyo: !0,
                    repeat: -1
                }), TweenMax.to(this._back.offset, .03, {
                    y: this._back.offset.y - 4,
                    yoyo: !0,
                    repeat: -1
                }), TweenMax.to(this._back.scale, .04, {
                    delay: .02,
                    y: this._back.scale.y - .02,
                    yoyo: !0,
                    repeat: -1
                })
            }, CarView.prototype.stopEngine = function() {
                TweenMax.killTweensOf(this._front.scale), TweenMax.killTweensOf(this._mid.scale), TweenMax.killTweensOf(this._back.scale)
            }, CarView.prototype.createFrontLayer = function() {
                return new PIXI.Sprite
            }, CarView.prototype.createMidLayer = function() {
                return new PIXI.Sprite
            }, CarView.prototype.createBackLayer = function() {
                return new PIXI.Sprite
            }, CarView.prototype.createSpoilerLayer = function() {
                return new PIXI.Sprite
            }, CarView.prototype.createShadow = function() {
                return new PIXI.Sprite
            }, CarView.prototype.createFrontWheel = function() {
                var sequence = new p3.MovieClipSequence;
                return new p3.MovieClip(sequence)
            }, CarView.prototype.createRearWheel = function() {
                var sequence = new p3.MovieClipSequence;
                return new p3.MovieClip(sequence)
            }, CarView.prototype.getDecalTexture = function(id) {
                var car = Common.garage.myCar,
                    name = car.decal > 0 ? "car_" + p3.Utils.padNumber(car.id, 2) + "_decal_" + p3.Utils.padNumber(car.decal - 1, 2) + "_" + p3.Utils.padNumber(id, 2) : null;
                return name ? Common.assets.getTexture(name) : PIXI.Texture.EMPTY
            }, Object.defineProperty(CarView.prototype, "avatar", {
                get: function() {
                    return this._avatar
                }
            }), Object.defineProperty(CarView.prototype, "front", {
                get: function() {
                    return this._front
                }
            }), Object.defineProperty(CarView.prototype, "mid", {
                get: function() {
                    return this._mid
                }
            }), Object.defineProperty(CarView.prototype, "back", {
                get: function() {
                    return this._back
                }
            }), Object.defineProperty(CarView.prototype, "wheels", {
                get: function() {
                    return this._wheels
                }
            })
        }, {
            "./Common": 23
        }],
        22: [function(require, module, exports) {
            function CoinBurst(start, end, count, animator) {
                this.signals = {}, this.signals.coin = new signals.Signal, this._start = start, this._end = end, this._count = count, this._animator = animator, this._coins = [], this._completeCount = 0, PIXI.Container.call(this);
                for (var coin, t, i = 0; i < Math.min(20, count); ++i) coin = this.createCoin(), this.addChild(coin), this._coins.push(coin), t = TweenMax.delayedCall(.2 + .4 * Math.random(), this.animateToEnd, [coin], this), this._animator && this._animator.add(t)
            }
            var Common = require("./Common");
            module.exports = CoinBurst, CoinBurst.prototype = Object.create(PIXI.Container.prototype), CoinBurst.prototype.constructor = CoinBurst, CoinBurst.prototype.destroy = function() {
                this.parent.removeChild(this.parent), this.signals.coin.dispose()
            }, CoinBurst.prototype.update = function() {
                for (var coin, gravity = 2e3, i = 0; i < this._coins.length; ++i) coin = this._coins[i], coin.animate && (coin.velocity.y += gravity * p3.Timestep.deltaTime, coin.velocity.x *= coin.linearDamping, coin.velocity.y *= coin.linearDamping, coin.x += coin.velocity.x * p3.Timestep.deltaTime, coin.y += coin.velocity.y * p3.Timestep.deltaTime, coin.rotation += coin.angularVelocity * p3.Timestep.deltaTime)
            }, CoinBurst.prototype.createCoin = function() {
                var coin = new PIXI.Sprite(Common.assets.getTexture("ui_icon_coin"));
                return coin.position = this._start.clone(), coin.anchor = new PIXI.Point(.5, .5), coin.velocity = new PIXI.Point(800 * Math.random() + -400, -(400 * Math.random() + 400)), coin.angularVelocity = 16 * Math.random() + -8, coin.linearDamping = .98, coin.animate = !0, coin
            }, CoinBurst.prototype.animateToEnd = function(coin) {
                coin.animate = !1;
                var t;
                t = TweenMax.to(coin.scale, 1, {
                    x: .9,
                    y: .9,
                    ease: Power1.easeInOut
                }), this._animator && this._animator.add(t), t = TweenMax.to(coin, 1, {
                    ease: Power1.easeOut,
                    bezier: [{
                        x: .5 * Common.STAGE_WIDTH + 240,
                        y: .5 * Common.STAGE_HEIGHT - 60
                    }, {
                        x: this._end.x,
                        y: this._end.y
                    }],
                    onComplete: function() {
                        coin.parent.removeChild(coin), this.signals.coin.dispatch(this, coin, this._completeCount), ++this._completeCount == this._coins.length && this.destroy(), 1 == this._completeCount && Common.audio.playSound("sfx_coins_rewarded_00")
                    },
                    onCompleteScope: this
                }), this._animator && this._animator.add(t)
            }, Object.defineProperty(CoinBurst.prototype, "count", {
                get: function() {
                    return this._count
                }
            })
        }, {
            "./Common": 23
        }],
        23: [function(require, module, exports) {
            function Common() {}
            module.exports = Common, Common.STAGE_WIDTH = 1900, Common.STAGE_HEIGHT = 768, Common.GAME_LANE_COUNT = 2, Common.GAME_OBJECT_SCALE = 800, Common.stage = null, Common.renderer = null, Common.timestep = null, Common.animator = null, Common.scene = null, Common.assets = null, Common.audio = null, Common.engine = null, Common.camera = null, Common.player = null, Common.tracking = null, Common.copy = null, Common.language = "gb", Common.touch = new PIXI.Point(0, 0), Common.touching = !1, Common.paused = !1, Common.isWebGL = !1, Common.score = 0, Common.achievements = null, Common.garage = null, Common.trackManager = null, Common.saveData = null
        }, {}],
        24: [function(require, module, exports) {
            function CommsScene() {
                Scene.call(this), this._header = null, this._titleText = null, this._panel = null, this._backButton = null, this._muteButton = null, this._nextButton = null, this._prevButton = null, this._commsIndex = 0, this._comms = null, this._transitionTimer = null
            }
            var Common = require("./Common"),
                Scene = require("./Scene");
            module.exports = CommsScene, CommsScene.prototype = Object.create(Scene.prototype), CommsScene.prototype.constructor = CommsScene, CommsScene.prototype.init = function() {
                this._comms = Common.config.comms.slice();
                var bg = new PIXI.Sprite(Common.assets.getTexture("ui_bg_main_menu"));
                this.addChild(bg), this._header = new PIXI.Sprite(Common.assets.getTexture("ui_top_bar")), this._header.x = .5 * Common.STAGE_WIDTH, this._header.y = 120, this._header.anchor = new PIXI.Point(.5, .5), this.addChild(this._header), webfont ? (this._titleText = new PIXI.Text(Common.copy.comms_screen[Common.language], {
                    font: "48px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._titleText.x = .5 * (Common.STAGE_WIDTH - this._titleText.width), this._titleText.y = 96, this.addChild(this._titleText)) : (this._titleText = new PIXI.extras.BitmapText(Common.copy.comms_screen[Common.language], {
                    font: "48px Great Escape",
                    align: "center"
                }), this._titleText.x = .5 * (Common.STAGE_WIDTH - this._titleText.textWidth), this._titleText.y = 86, this.addChild(this._titleText));
                var texture = Common.assets.getTexture("ui_comms_screen");
                this._panel = new PIXI.Sprite(texture), this._panel.x = .5 * Common.STAGE_WIDTH - 2, this._panel.y = 460, this._panel.anchor = new PIXI.Point(.5, .5), this._panel.interactive = !0, this._panel.buttonMode = !0, this.addChild(this._panel);
                var that = this;
                this._panel.click = this._panel.tap = function() {
                    var url = that._comms[that._commsIndex].url;
                    url.length && window.top.open(url, "_BLANK")
                };
                var name = this._comms[this._commsIndex].name;
                this._panel.comms = new PIXI.Sprite(Common.assets.getTexture(name)), this._panel.comms.anchor = new PIXI.Point(.5, .5), this._panel.addChild(this._panel.comms), this._muteButton = new p3.MuteButton(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_sound_on"), Common.assets.getTexture("ui_icon_sound_off")), this._muteButton.y = 120, this._muteButton.animate = !0, this._muteButton.visible = !1, this._muteButton.overSoundName = "sfx_ui_btn_rollover_00", this._muteButton.downSoundName = "sfx_ui_btn_press_00", this.addChild(this._muteButton), this._backButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_home")), this._backButton.y = 120, this._backButton.animate = !0, this._backButton.overSoundName = "sfx_ui_btn_rollover_00", this._backButton.downSoundName = "sfx_ui_btn_press_00", this._backButton.signals.click.add(this.onBackButtonClick, this), this.addChild(this._backButton), this._nextButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_arrow")), this._nextButton.x = this._panel.x + .5 * this._panel.width - 20, this._nextButton.y = this._panel.y, this._nextButton.scale.x = this._nextButton.defaultScale.x = -1, this._nextButton.animate = !0, this._nextButton.overSoundName = "sfx_ui_btn_rollover_00", this._nextButton.downSoundName = "sfx_ui_btn_press_00", this._nextButton.signals.click.add(this.onNextButtonClick, this), this.addChild(this._nextButton), this._prevButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_arrow")), this._prevButton.x = this._panel.x - .5 * this._panel.width + 20, this._prevButton.y = this._panel.y, this._prevButton.animate = !0, this._prevButton.overSoundName = "sfx_ui_btn_rollover_00", this._prevButton.downSoundName = "sfx_ui_btn_press_00", this._prevButton.signals.click.add(this.onPrevButtonClick, this), this.addChild(this._prevButton), this._transitionTimer = new p3.Timer(6, -1), this._transitionTimer.signals.timer.add(this.onTransitionTimer, this), this._transitionTimer.start(), Common.tracking.track(new p3.TrackingDataPlaydomGameAction("main", "comms"))
            }, CommsScene.prototype.dispose = function() {
                Common.animator.removeAll(), this._transitionTimer.dispose(), this._transitionTimer = null, Scene.prototype.dispose.call(this)
            }, CommsScene.prototype.appear = function() {
                this.animateIn()
            }, CommsScene.prototype.show = function() {}, CommsScene.prototype.animateIn = function(callback, scope) {
                this._muteButton.scale = new PIXI.Point, this._muteButton.visible = !0, TweenMax.to(this._muteButton.scale, .4, {
                    delay: .3,
                    x: 1,
                    y: 1,
                    ease: Back.easeOut,
                    easeParams: [2]
                })
            }, CommsScene.prototype.animateOut = function(callback, scope) {}, CommsScene.prototype.resize = function() {
                this.x = .5 * (p3.View.width - Common.STAGE_WIDTH), this._header.width = p3.View.width, this._backButton.x = .5 * (Common.STAGE_WIDTH - p3.View.width + Math.abs(this._backButton.width)) + 28, this._muteButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width - Math.abs(this._muteButton.width)) - 28
            }, CommsScene.prototype.update = function() {
                this._transitionTimer.update()
            }, CommsScene.prototype.transitionComms = function() {
                var name = this._comms[this._commsIndex].name,
                    texture = Common.assets.getTexture(name),
                    next = new PIXI.Sprite(texture);
                next.alpha = 0, next.anchor = new PIXI.Point(.5, .5), this._panel.comms.parent.addChild(next);
                var prev = this._panel.comms;
                this._panel.comms = next, TweenMax.to(next, .2, {
                    alpha: 1,
                    ease: Power1.easeInOut,
                    onComplete: function() {
                        prev.parent.removeChild(prev)
                    },
                    onCompleteScope: this
                })
            }, CommsScene.prototype.onNextButtonClick = function(button) {
                ++this._commsIndex, this._commsIndex >= this._comms.length && (this._commsIndex = 0), this.transitionComms(), this._transitionTimer.reset(), this._transitionTimer.start()
            }, CommsScene.prototype.onPrevButtonClick = function(button) {
                --this._commsIndex, this._commsIndex < 0 && (this._commsIndex = this._comms.length - 1), this.transitionComms(), this._transitionTimer.reset(), this._transitionTimer.start()
            }, CommsScene.prototype.onBackButtonClick = function(button) {
                this.signals.previous.dispatch()
            }, CommsScene.prototype.onTransitionTimer = function(timer) {
                this.onNextButtonClick()
            }
        }, {
            "./Common": 23,
            "./Scene": 83
        }],
        25: [function(require, module, exports) {
            function ContinueSeriesPopupScene() {
                Scene.call(this), this._overlay = null, this._panel = null, this._titleText = null, this._infoText = null, this._backButton = null, this._yesButton = null, this._noButton = null
            }
            var Common = require("./Common"),
                Scene = require("./Scene");
            module.exports = ContinueSeriesPopupScene, ContinueSeriesPopupScene.prototype = Object.create(Scene.prototype), ContinueSeriesPopupScene.prototype.constructor = ContinueSeriesPopupScene, ContinueSeriesPopupScene.prototype.init = function() {
                var graphics = new PIXI.Graphics;
                graphics.beginFill(0, .64), graphics.drawRect(0, 0, 1, 1), graphics.endFill(), this._overlay = new PIXI.Sprite(graphics.generateTexture()), this._overlay.width = p3.View.width, this._overlay.height = p3.View.height, this._overlay.visible = !1, this.addChild(this._overlay), this._panel = new PIXI.Container, this._panel.x = .5 * Common.STAGE_WIDTH, this._panel.y = .5 * Common.STAGE_HEIGHT, this._panel.visible = !1, this.addChild(this._panel), this._panel.header = new PIXI.Sprite(Common.assets.getTexture("ui_popup_top")), this._panel.header.x = .5 * -this._panel.header.width, this._panel.addChild(this._panel.header), this._panel.content = new PIXI.Sprite(Common.assets.getTexture("ui_popup_bottom_carbon_small")), this._panel.content.x = .5 * -this._panel.content.width, this._panel.content.y = this._panel.header.y + this._panel.header.height, this._panel.addChild(this._panel.content), this._panel.header.y -= .5 * (this._panel.header.height + this._panel.content.height), this._panel.content.y -= .5 * (this._panel.header.height + this._panel.content.height), this._titleText = new PIXI.extras.BitmapText("Continue Series?", {
                    font: "48px Great Escape",
                    align: "center"
                }), this._titleText.x = .5 * (this._panel.header.width - this._titleText.textWidth), this._titleText.y = 24, this._panel.header.addChild(this._titleText);
                var series = Common.trackManager.currentSeries;
                this._infoText = new PIXI.extras.BitmapText("Do you want to continue the\n" + series.name + " series you started?", {
                        font: "48px Great Escape",
                        align: "center"
                    }), this._infoText.x = .5 * (this._panel.content.texture.width - this._infoText.textWidth), this._infoText.y = 68, this._panel.content.addChild(this._infoText), this._yesButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_big_up"), Common.assets.getTexture("ui_btn_navigation_big_over"), Common.assets.getTexture("ui_btn_navigation_big_down"), Common.assets.getTexture("ui_icon_tick")), this._yesButton.x = 140, this._yesButton.y = 180, this._yesButton.animate = !0, this._yesButton.overSoundName = "sfx_ui_btn_rollover_00", this._yesButton.downSoundName = "sfx_ui_btn_press_00", this._yesButton.clickSoundName = "sfx_ui_btn_play_00", this._yesButton.signals.click.add(this.onYesButtonClick, this), this._panel.addChild(this._yesButton), this._noButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_big_up"), Common.assets.getTexture("ui_btn_navigation_big_over"), Common.assets.getTexture("ui_btn_navigation_big_down"), Common.assets.getTexture("ui_icon_close_big")), this._noButton.x = -140, this._noButton.y = 180, this._noButton.animate = !0, this._noButton.overSoundName = "sfx_ui_btn_rollover_00", this._noButton.downSoundName = "sfx_ui_btn_press_00", this._noButton.signals.click.add(this.onNoButtonClick, this), this._panel.addChild(this._noButton), this._backButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_back")),
                    this._backButton.x = .5 * (-this._panel.header.width + this._backButton.width) + 18, this._backButton.y = -176, this._backButton.animate = !0, this._backButton.overSoundName = "sfx_ui_btn_rollover_00", this._backButton.downSoundName = "sfx_ui_btn_press_00", this._backButton.clickSoundName = "sfx_ui_btn_play_00", this._backButton.signals.click.add(this.onBackButtonClick, this), this._panel.addChild(this._backButton)
            }, ContinueSeriesPopupScene.prototype.dispose = function() {
                Common.animator.removeAll(), Scene.prototype.dispose.call(this)
            }, ContinueSeriesPopupScene.prototype.appear = function() {
                this.animateIn()
            }, ContinueSeriesPopupScene.prototype.show = function() {}, ContinueSeriesPopupScene.prototype.animateIn = function(callback, scope) {
                Scene.prototype.animateIn.call(this, callback, scope), this._overlay.alpha = 0, this._overlay.visible = !0, TweenMax.to(this._overlay, .2, {
                    alpha: 1,
                    ease: Power1.easeInOut
                });
                var x = this._panel.x;
                this._panel.x = .5 * (Common.STAGE_WIDTH - p3.View.width - this._panel.width), this._panel.visible = !0, TweenMax.to(this._panel, .3, {
                    x: x,
                    ease: Back.easeOut,
                    easeParams: [1]
                })
            }, ContinueSeriesPopupScene.prototype.animateOut = function(callback, scope) {
                Scene.prototype.animateOut.call(this, callback, scope), TweenMax.to(this._overlay, .4, {
                    alpha: 0,
                    ease: Power1.easeInOut,
                    onComplete: function() {
                        this._overlay.visible = !1
                    },
                    onCompleteScope: this
                }), TweenMax.to(this._panel, .26, {
                    x: .5 * (Common.STAGE_WIDTH + p3.View.width + this._panel.width),
                    ease: Back.easeIn,
                    easeParams: [1],
                    onComplete: function() {
                        this._panel.visible = !1, callback && callback.call(scope)
                    },
                    onCompleteScope: this
                })
            }, ContinueSeriesPopupScene.prototype.resize = function() {
                this.x = .5 * (p3.View.width - Common.STAGE_WIDTH), this._overlay.x = .5 * (Common.STAGE_WIDTH - p3.View.width), this._overlay.y = .5 * (Common.STAGE_HEIGHT - p3.View.height), this._overlay.width = p3.View.width, this._overlay.height = p3.View.height
            }, ContinueSeriesPopupScene.prototype.update = function() {}, ContinueSeriesPopupScene.prototype.onYesButtonClick = function(button) {
                this.animateOut(function() {
                    this.signals.next.dispatch(this, !1)
                }, this)
            }, ContinueSeriesPopupScene.prototype.onNoButtonClick = function(button) {
                this.animateOut(function() {
                    this.signals.next.dispatch(this, !0)
                }, this)
            }, ContinueSeriesPopupScene.prototype.onBackButtonClick = function(button) {
                this.animateOut(function() {
                    this.signals.previous.dispatch(this)
                }, this)
            }
        }, {
            "./Common": 23,
            "./Scene": 83
        }],
        26: [function(require, module, exports) {
            function ControlTypes() {}
            module.exports = ControlTypes, ControlTypes.CONTROLS_ROOKIE = "rookie", ControlTypes.CONTROLS_EXPERT = "pro"
        }, {}],
        27: [function(require, module, exports) {
            function CountryTypes() {}
            module.exports = CountryTypes, CountryTypes.TUTORIAL = "tutorial", CountryTypes.USA = "usa", CountryTypes.ITALY = "italy", CountryTypes.GERMANY = "germany", CountryTypes.JAPAN = "japan", CountryTypes.BRAZIL = "brazil"
        }, {}],
        28: [function(require, module, exports) {
            function CutoutShader(texture, scale, ratio) {
                scale = scale || .5, ratio = ratio || new PIXI.Point(1, 1), PIXI.AbstractFilter.call(this, null, ["precision highp float;", "varying vec2 vTextureCoord;", "varying vec4 vColor;", "uniform sampler2D uCutoutMap;", "uniform float uScale;", "uniform vec2 uRatio;", "void main(void) {", "vec2 textureCoord  = (((vTextureCoord - vec2(0.5, 0.5)) * uRatio) * uScale) + vec2(0.5, 0.5);", "vec4 mask          = texture2D(uCutoutMap, textureCoord);", "float alpha        = 1.0 - mask.a;", "gl_FragColor       = vec4(vColor.r * alpha, vColor.g * alpha, vColor.b * alpha, vColor.a * alpha);", "}"].join("\n"), {
                    uCutoutMap: {
                        type: "sampler2D",
                        value: texture
                    },
                    uScale: {
                        type: "f",
                        value: 1 / Math.max(.001, scale)
                    },
                    uRatio: {
                        type: "v2",
                        value: {
                            x: ratio.x,
                            y: ratio.y
                        }
                    }
                }), texture.baseTexture.isPowerOfTwo = !1
            }
            module.exports = CutoutShader, CutoutShader.prototype = Object.create(PIXI.AbstractFilter.prototype), CutoutShader.prototype.constructor = CutoutShader, Object.defineProperty(CutoutShader.prototype, "scale", {
                get: function() {
                    return 1 / this.uniforms.uScale.value
                },
                set: function(value) {
                    this.uniforms.uScale.value = 1 / Math.max(.001, value)
                }
            }), Object.defineProperty(CutoutShader.prototype, "ratio", {
                get: function() {
                    return new PIXI.Point(this.uniforms.uRatio.value.x, this.uniforms.uRatio.value.y)
                },
                set: function(value) {
                    this.uniforms.uRatio.value.x = value.x, this.uniforms.uRatio.value.y = value.y
                }
            })
        }, {}],
        29: [function(require, module, exports) {
            function CutoutTransition(texture, color, duration) {
                this.startScale = 8, this.endScale = 0, this._texture = texture, this._color = color || 0, this._duration = duration || 2, this._cutout = null, Transition.call(this), this.requiresWebGL = !0
            }
            var CutoutShader = require("./CutoutShader"),
                FadeTransition = require("./FadeTransition"),
                Transition = require("./Transition");
            module.exports = CutoutTransition, CutoutTransition.prototype = Object.create(Transition.prototype), CutoutTransition.prototype.constructor = CutoutTransition, CutoutTransition.prototype.init = function() {
                var quad = new PIXI.Graphics;
                quad.drawRect(0, 0, 1, 1);
                var ratio = new PIXI.Point(0, 0),
                    canvasRatio = p3.View.width / p3.View.height,
                    textureRatio = this._texture.width / this._texture.height;
                canvasRatio / textureRatio > 1 ? (ratio.x = 1, ratio.y = 1 / (canvasRatio / textureRatio)) : (ratio.x = 1 / (canvasRatio / textureRatio), ratio.y = 1), this._cutout = new PIXI.Sprite(quad.generateTexture()), this._cutout.scale = new PIXI.Point(p3.View.width, p3.View.height), this._cutout.tint = this._color, this._cutout.shader = new CutoutShader(this._texture, 0, ratio), this.addChild(this._cutout)
            }, CutoutTransition.prototype["in"] = function() {
                this._cutout.shader.scale = this.startScale, TweenMax.to(this._cutout.shader, .5 * this._duration, {
                    scale: this.endScale,
                    ease: Power2.easeInOut,
                    onComplete: function() {
                        Transition.prototype["in"].call(this, this)
                    },
                    onCompleteScope: this
                })
            }, CutoutTransition.prototype.out = function() {
                this._cutout.shader.scale = this.endScale, TweenMax.to(this._cutout.shader, .5 * this._duration, {
                    scale: this.startScale,
                    ease: Power2.easeInOut,
                    onComplete: function() {
                        Transition.prototype.out.call(this, this)
                    },
                    onCompleteScope: this
                })
            }, CutoutTransition.prototype.resize = function() {
                var ratio = new PIXI.Point(0, 0),
                    canvasRatio = p3.View.width / p3.View.height,
                    textureRatio = this._texture.width / this._texture.height;
                canvasRatio / textureRatio > 1 ? (ratio.x = 1, ratio.y = 1 / (canvasRatio / textureRatio)) : (ratio.x = 1 / (canvasRatio / textureRatio), ratio.y = 1), this._cutout.scale = new PIXI.Point(p3.View.width, p3.View.height), this._cutout.shader.ratio = ratio
            }, CutoutTransition.prototype.fallback = function() {
                return new FadeTransition(this._color)
            }
        }, {
            "./CutoutShader": 28,
            "./FadeTransition": 35,
            "./Transition": 105
        }],
        30: [function(require, module, exports) {
            function CutsceneScene() {
                Scene.call(this), this._me = null, this._opponent = null, this._top = null, this._bottom = null, this._topBg = null, this._bottomBg = null, this._skipButton = null, this._borderTop = null, this._borderMid = null, this._borderBottom = null, this._header = null, this._ambienceLoopSFX = null, this._revLoopSFX = null, this._message = null
            }
            var AudioParams = require("./AudioParams"),
                Common = require("./Common"),
                CountryTypes = require("./CountryTypes"),
                MessagePopup = require("./MessagePopup"),
                Scene = require("./Scene");
            module.exports = CutsceneScene, CutsceneScene.prototype = Object.create(Scene.prototype), CutsceneScene.prototype.constructor = CutsceneScene, CutsceneScene.prototype.init = function() {
                var texture, country = Common.trackManager.currentTrack.country;
                switch (this._top = new PIXI.Container, this._top.y = 40, this.addChild(this._top), this._top.mask = new PIXI.Graphics, this._top.addChild(this._top.mask), country) {
                    case CountryTypes.BRAZIL:
                        texture = Common.assets.getTexture("ui_cutscene_bg_bz");
                        break;
                    case CountryTypes.GERMANY:
                        texture = Common.assets.getTexture("ui_cutscene_bg_de");
                        break;
                    case CountryTypes.ITALY:
                        texture = Common.assets.getTexture("ui_cutscene_bg_pc");
                        break;
                    case CountryTypes.JAPAN:
                        texture = Common.assets.getTexture("ui_cutscene_bg_tk");
                        break;
                    case CountryTypes.USA:
                        texture = Common.assets.getTexture("ui_cutscene_bg_rs")
                }
                switch (this._topBg = new PIXI.Sprite(texture), this._topBg.scale = new PIXI.Point(2, 2), this._top.addChild(this._topBg), this._bottom = new PIXI.Container, this._bottom.y = 380, this.addChild(this._bottom), this._bottom.mask = new PIXI.Graphics, this._bottom.addChild(this._bottom.mask), this._bottomBg = new PIXI.Sprite(texture), this._bottomBg.scale = new PIXI.Point(-2, 2), this._bottomBg.anchor.x = 1, this._bottom.addChild(this._bottomBg), this._me = new PIXI.Sprite(Common.garage.avatar), this._me.x = .5 * Common.STAGE_WIDTH - 240, this._me.y = 210, this._me.scale = new PIXI.Point(1.6, 1.6), this._me.anchor = new PIXI.Point(.5, .5), this._top.addChild(this._me), country) {
                    case CountryTypes.BRAZIL:
                        texture = Common.assets.getTexture("ui_cutscene_car_bz");
                        break;
                    case CountryTypes.GERMANY:
                        texture = Common.assets.getTexture("ui_cutscene_car_de");
                        break;
                    case CountryTypes.ITALY:
                        texture = Common.assets.getTexture("ui_cutscene_car_pc");
                        break;
                    case CountryTypes.JAPAN:
                        texture = Common.assets.getTexture("ui_cutscene_car_tk");
                        break;
                    case CountryTypes.USA:
                        texture = Common.assets.getTexture("ui_cutscene_car_rs")
                }
                this._opponent = new PIXI.Sprite(texture), this._opponent.x = .5 * Common.STAGE_WIDTH + 240, this._opponent.y = 250, this._opponent.scale = new PIXI.Point(1.6, 1.6), this._opponent.anchor = new PIXI.Point(.5, .5), this._bottom.addChild(this._opponent), this._borderMid = new PIXI.Graphics, this._borderMid.y = 368, this._borderMid.startH = 40, this._borderMid.beginFill(0), this._borderMid.drawRect(.5 * (Common.STAGE_WIDTH - p3.View.width), .5 * -this._borderMid.startH, p3.View.width, this._borderMid.startH), this._borderMid.endFill(), this.addChild(this._borderMid), this._borderTop = new PIXI.Graphics, this._borderTop.startH = 60, this._borderTop.endH = this._borderMid.y - this._borderTop.y - .5 * this._borderMid.startH, this._borderTop.beginFill(0), this._borderTop.drawRect(.5 * (Common.STAGE_WIDTH - p3.View.width), 0, p3.View.width, this._borderTop.endH), this._borderTop.endFill(), this.addChild(this._borderTop), this._borderBottom = new PIXI.Graphics, this._borderBottom.y = p3.View.height, this._borderBottom.startH = 80, this._borderBottom.endH = Math.abs(this._borderMid.y - this._borderBottom.y) - .5 * this._borderMid.startH, this._borderBottom.beginFill(0), this._borderBottom.drawRect(.5 * (Common.STAGE_WIDTH - p3.View.width), -this._borderBottom.endH, p3.View.width, this._borderBottom.endH), this._borderBottom.endFill(), this.addChild(this._borderBottom), this._header = new PIXI.Sprite(Common.assets.getTexture("ui_cutscene_live")), this._header.x = .5 * Common.STAGE_WIDTH, this._header.y = -6, this._header.anchor.x = .5, this._header.visible = !1, this.addChild(this._header), this._announcer = new MessagePopup(-1, MessagePopup.CHARACTER_DARRELL, "1"), this._announcer.y = p3.View.height - this._announcer.height - 20, this._announcer.interactiveChildren = !1, this._announcer.visible = !1, this.addChild(this._announcer), this._skipButton = new p3.Button(Common.assets.getTexture("ui_btn_confirm_up"), Common.assets.getTexture("ui_btn_confirm_over"), Common.assets.getTexture("ui_btn_confirm_down"), Common.assets.getTexture("ui_icon_play")), this._skipButton.y = .5 * Common.STAGE_HEIGHT + 260, this._skipButton.animate = !0, this._skipButton.overSoundName = "sfx_ui_btn_rollover_00", this._skipButton.downSoundName = "sfx_ui_btn_press_00", this._skipButton.signals.click.add(this.onSkipButtonClick, this), this.addChild(this._skipButton)
            }, CutsceneScene.prototype.dispose = function() {
                TweenMax.killAll(), Common.animator.removeAll(), this._ambienceLoopSFX && (this._ambienceLoopSFX.stop(), this._ambienceLoopSFX = null), this._revLoopSFX && (this._revLoopSFX.stop(), this._revLoopSFX = null), Scene.prototype.dispose.call(this)
            }, CutsceneScene.prototype.appear = function() {
                this.animateIn();
                var name, params, track = Common.trackManager.currentTrack;
                switch (track.country) {
                    case CountryTypes.BRAZIL:
                        name = "sfx_ambience_brazil_00";
                        break;
                    case CountryTypes.GERMANY:
                        name = "sfx_ambience_germany_00";
                        break;
                    case CountryTypes.ITALY:
                        name = "sfx_ambience_italy_00";
                        break;
                    case CountryTypes.JAPAN:
                        name = "sfx_ambience_tokyo_00";
                        break;
                    case CountryTypes.USA:
                        name = "sfx_ambience_usa_desert_00";
                        break;
                    default:
                        name = "sfx_ambience_usa_desert_00"
                }
                params = new AudioParams, params.loop = !0, this._ambienceLoopSFX = Common.audio.playSound(name, params), params = new AudioParams, params.loop = !0, this._revLoopSFX = Common.audio.playSound(["sfx_race_start_idle_revs_00", "sfx_race_start_idle_revs_01", "sfx_race_start_idle_revs_02"], params)
            }, CutsceneScene.prototype.show = function() {}, CutsceneScene.prototype.animateIn = function(callback, scope) {
                this._borderTop.value = this._borderTop.endH, TweenMax.to(this._borderTop, .4, {
                    value: this._borderTop.startH,
                    ease: Power2.easeOut,
                    onUpdate: function() {
                        this._borderTop.clear(), this._borderTop.beginFill(0), this._borderTop.drawRect(.5 * (Common.STAGE_WIDTH - p3.View.width), 0, p3.View.width, this._borderTop.value), this._borderTop.endFill()
                    },
                    onUpdateScope: this
                }), this._borderBottom.value = this._borderBottom.endH, TweenMax.to(this._borderBottom, .4, {
                    delay: .14,
                    value: this._borderBottom.startH,
                    ease: Power2.easeOut,
                    onUpdate: function() {
                        this._borderBottom.clear(), this._borderBottom.beginFill(0), this._borderBottom.drawRect(.5 * (Common.STAGE_WIDTH - p3.View.width), -this._borderBottom.value, p3.View.width, this._borderBottom.value), this._borderBottom.endFill()
                    },
                    onUpdateScope: this
                });
                var to = this._me.x;
                this._me.x = this._me.x - 500, TweenMax.to(this._me, .34, {
                    x: to,
                    ease: Power2.easeOut
                }), to = this._topBg.x, this._topBg.x = this._topBg.x - 80, TweenMax.to(this._topBg, 1, {
                    x: to,
                    ease: Power2.easeOut
                }), to = this._opponent.x, this._opponent.x = this._opponent.x + 500, TweenMax.to(this._opponent, .34, {
                    delay: .14,
                    x: to,
                    ease: Power2.easeOut
                }), to = this._bottomBg.x, this._bottomBg.x = this._bottomBg.x + 80, TweenMax.to(this._bottomBg, 1, {
                    delay: .14,
                    x: to,
                    ease: Power2.easeOut
                }), TweenMax.delayedCall(.2, function() {
                    this._announcer.visible = !0, this._announcer.animateIn(function() {
                        var name, country = Common.trackManager.currentTrack.country;
                        switch (country) {
                            case CountryTypes.BRAZIL:
                                name = Common.copy.cutscene_host_brazil[Common.language];
                                break;
                            case CountryTypes.GERMANY:
                                name = Common.copy.cutscene_host_germany[Common.language];
                                break;
                            case CountryTypes.ITALY:
                                name = Common.copy.cutscene_host_italy[Common.language];
                                break;
                            case CountryTypes.JAPAN:
                                name = Common.copy.cutscene_host_japan[Common.language];
                                break;
                            case CountryTypes.USA:
                                name = Common.copy.cutscene_host_usa[Common.language]
                        }
                        this._announcer.message = this.getDialogue(), this._announcer.show(10, function() {
                            this.animateOut(function() {
                                this.signals.next.dispatch()
                            }, this)
                        }, this)
                    }, this)
                }, null, this)
            }, CutsceneScene.prototype.animateOut = function(callback, scope) {
                TweenMax.to(this._borderTop, .2, {
                    value: this._borderTop.endH,
                    ease: Power2.easeIn,
                    onUpdate: function() {
                        this._borderTop.clear(), this._borderTop.beginFill(0), this._borderTop.drawRect(.5 * (Common.STAGE_WIDTH - p3.View.width), 0, p3.View.width, this._borderTop.value), this._borderTop.endFill()
                    },
                    onUpdateScope: this
                }), TweenMax.to(this._borderBottom, .2, {
                    value: this._borderBottom.endH,
                    ease: Power2.easeIn,
                    onUpdate: function() {
                        this._borderBottom.clear(), this._borderBottom.beginFill(0), this._borderBottom.drawRect(.5 * (Common.STAGE_WIDTH - p3.View.width), -this._borderBottom.value, p3.View.width, this._borderBottom.value), this._borderBottom.endFill()
                    },
                    onUpdateScope: this
                }), TweenMax.delayedCall(.4, callback, null, scope)
            }, CutsceneScene.prototype.resize = function() {
                this.x = .5 * (p3.View.width - Common.STAGE_WIDTH), this._skipButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width) - 120, this._top.mask.clear(), this._top.mask.beginFill(16711680), this._top.mask.drawRect(.5 * (Common.STAGE_WIDTH - p3.View.width), 0, p3.View.width, 320), this._top.mask.endFill(), this._bottom.mask.clear(), this._bottom.mask.beginFill(16711680), this._bottom.mask.drawRect(.5 * (Common.STAGE_WIDTH - p3.View.width), 0, p3.View.width, 320), this._bottom.mask.endFill(), this._announcer.x = .5 * (Common.STAGE_WIDTH - p3.View.width) + 20
            }, CutsceneScene.prototype.update = function() {}, CutsceneScene.prototype.getDialogue = function() {
                var tm = Common.trackManager,
                    series = tm.currentSeries,
                    track = tm.currentTrack,
                    country = track.country,
                    index = 0;
                series && (index = 0 == series.currentTrack ? 1 : 4 == series.currentTrack ? 2 : 3);
                var arr = ["cutscene_announcer_single_race_", "cutscene_announcer_first_race_", "cutscene_announcer_last_race_", "cutscene_announcer_next_race_"],
                    name = Common.copy["cutscene_host_" + country][Common.language],
                    str = Common.copy[arr[index] + country][Common.language];
                return str = str.replace("[NAME1]", Common.garage.name), str = str.replace("[NAME2]", name)
            }, CutsceneScene.prototype.onSkipButtonClick = function(button) {
                this.signals.next.dispatch()
            }
        }, {
            "./AudioParams": 9,
            "./Common": 23,
            "./CountryTypes": 27,
            "./MessagePopup": 54,
            "./Scene": 83
        }],
        31: [function(require, module, exports) {
            function DailyBonusScene(reward) {
                Scene.call(this), this._reward = reward, this._header = null, this._titleText = null, this._infoText = null, this._muteButton = null, this._rewardWheel = null, this._rewardCoin = null, this._rewardArrow = null, this._emitter = null
            }
            var Common = require("./Common"),
                Scene = require("./Scene");
            module.exports = DailyBonusScene, DailyBonusScene.prototype = Object.create(Scene.prototype), DailyBonusScene.prototype.constructor = DailyBonusScene, DailyBonusScene.prototype.init = function() {
                var bg = new PIXI.Sprite(Common.assets.getTexture("ui_bg_main_menu"));
                this.addChild(bg), this._header = new PIXI.Sprite(Common.assets.getTexture("ui_top_bar")), this._header.x = .5 * Common.STAGE_WIDTH, this._header.y = 120, this._header.anchor = new PIXI.Point(.5, .5), this.addChild(this._header), webfont ? (this._titleText = new PIXI.Text(Common.copy.daily_bonus[Common.language], {
                    font: "48px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._titleText.x = .5 * (Common.STAGE_WIDTH - this._titleText.width), this._titleText.y = 96, this.addChild(this._titleText)) : (this._titleText = new PIXI.extras.BitmapText(Common.copy.daily_bonus[Common.language], {
                    font: "48px Great Escape",
                    align: "center"
                }), this._titleText.x = .5 * (Common.STAGE_WIDTH - this._titleText.textWidth), this._titleText.y = 86, this.addChild(this._titleText)), webfont ? (this._infoText = new PIXI.Text(Common.copy.daily_bonus_info[Common.language], {
                    font: "48px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._infoText.x = .5 * (Common.STAGE_WIDTH - this._infoText.width), this._infoText.y = 680, this._infoText.visible = !1, this.addChild(this._infoText)) : (this._infoText = new PIXI.extras.BitmapText(Common.copy.daily_bonus_info[Common.language], {
                    font: "48px Great Escape",
                    align: "center"
                }), this._infoText.x = .5 * (Common.STAGE_WIDTH - this._infoText.textWidth), this._infoText.y = 680, this._infoText.visible = !1, this.addChild(this._infoText)), this._muteButton = new p3.MuteButton(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_sound_on"), Common.assets.getTexture("ui_icon_sound_off")), this._muteButton.y = 120, this._muteButton.animate = !0, this._muteButton.visible = !1, this._muteButton.overSoundName = "sfx_ui_btn_rollover_00", this._muteButton.downSoundName = "sfx_ui_btn_press_00", this.addChild(this._muteButton), this._rewardWheel = new PIXI.Sprite(Common.assets.getTexture("ui_fortune_wheel")), this._rewardWheel.x = .5 * Common.STAGE_WIDTH, this._rewardWheel.y = .5 * Common.STAGE_HEIGHT + 42, this._rewardWheel.anchor = new PIXI.Point(.5, .5), this._rewardWheel.interactive = !0, this._rewardWheel.buttonMode = !0, this._rewardWheel.visible = !1, this._rewardWheel.click = this._rewardWheel.tap = this.onRewardButtonClick.bind(this), this.addChild(this._rewardWheel);
                var text = new PIXI.Sprite(Common.assets.getTexture("ui_fortune_wheel_text"));
                text.anchor = new PIXI.Point(.5, .5), this._rewardWheel.addChild(text);
                for (var label, reward, rewards = Common.config.bonus, angle = 2 * Math.PI / rewards.length, radius = 124, i = 0; i < rewards.length; ++i) reward = rewards[i], label = new PIXI.extras.BitmapText(reward.toString(), {
                    font: "32px Great Escape",
                    align: "center"
                }), label.x = Math.cos(i * angle) * radius + .5 * -label.textWidth * Math.cos(i * angle) - .5 * -label.textHeight * Math.sin(i * angle), label.y = Math.sin(i * angle) * radius + .5 * -label.textHeight * Math.cos(i * angle) + .5 * -label.textWidth * Math.sin(i * angle), label.rotation = i * angle, this._rewardWheel.addChild(label);
                this._rewardWheel.rotation = this._reward.index * -angle - 6.5 * Math.PI, this._rewardCoin = new PIXI.Sprite(Common.assets.getTexture("ui_icon_coin")), this._rewardCoin.x = this._rewardWheel.x, this._rewardCoin.y = this._rewardWheel.y, this._rewardCoin.anchor = new PIXI.Point(.5, .5), this._rewardCoin.hitArea = new PIXI.Rectangle, this._rewardCoin.visible = !1, this.addChild(this._rewardCoin), this._rewardArrow = new PIXI.Sprite(Common.assets.getTexture("ui_fortune_wheel_arrow")), this._rewardArrow.x = this._rewardWheel.x + 214, this._rewardArrow.y = this._rewardWheel.y, this._rewardArrow.anchor = new PIXI.Point(.5, .5), this._rewardArrow.hitArea = new PIXI.Rectangle, this.addChild(this._rewardArrow);
                var container = new PIXI.Container;
                this.addChild(container);
                var config = Common.assets.getJSON("particle_bonus_wheel_spin");
                this._emitter = new cloudkid.Emitter(container, [Common.assets.getTexture("particle_car_dust1"), Common.assets.getTexture("particle_car_dust2"), Common.assets.getTexture("particle_car_dust3"), Common.assets.getTexture("particle_car_dust4")], config), this._emitter.emit = !1, this._emitter.updateOwnerPos(this._rewardWheel.x, this._rewardWheel.y)
            }, DailyBonusScene.prototype.dispose = function() {
                Common.animator.removeAll(), Scene.prototype.dispose.call(this)
            }, DailyBonusScene.prototype.appear = function() {
                this.animateIn()
            }, DailyBonusScene.prototype.show = function() {}, DailyBonusScene.prototype.spinToWin = function() {
                var tl = new TimelineMax({
                    onComplete: function() {
                        TweenMax.to(this._rewardWheel, 2.4, {
                            rotation: this._rewardWheel.rotation + 6.5 * Math.PI,
                            ease: Back.easeInOut,
                            easeParams: [.8],
                            onComplete: function() {
                                delay(function() {
                                    this.signals.next.dispatch(this, this._reward.value)
                                }, 1, this)
                            },
                            onCompleteScope: this
                        }), TweenMax.to(this, 1.4, {
                            delay: .8,
                            onStart: function() {
                                this._emitter.emit = !0
                            },
                            onStartScope: this,
                            onComplete: function() {
                                this._emitter.emit = !1
                            },
                            onCompleteScope: this
                        })
                    },
                    onCompleteScope: this
                });
                tl.append(TweenMax.to(this._rewardWheel.scale, .2, {
                    x: 1.2,
                    y: 1.2,
                    ease: Power0.easeNone
                })), tl.append(TweenMax.to(this._rewardWheel.scale, .4, {
                    x: 1,
                    y: 1,
                    ease: Back.easeOut,
                    easeParams: [2]
                }))
            }, DailyBonusScene.prototype.animateIn = function(callback, scope) {
                this._rewardWheel.scale = new PIXI.Point, this._rewardWheel.visible = !0, TweenMax.to(this._rewardWheel.scale, .4, {
                    x: 1,
                    y: 1,
                    ease: Back.easeOut,
                    easeParams: [3]
                }), this._rewardCoin.scale = new PIXI.Point, this._rewardCoin.visible = !0, TweenMax.to(this._rewardCoin.scale, .4, {
                    x: 1,
                    y: 1,
                    ease: Back.easeOut,
                    easeParams: [3]
                }), this._muteButton.scale = new PIXI.Point, this._muteButton.visible = !0, TweenMax.to(this._muteButton.scale, .4, {
                    delay: .3,
                    x: 1,
                    y: 1,
                    ease: Back.easeOut,
                    easeParams: [2]
                }), this._infoText.alpha = 0, this._infoText.visible = !0, TweenMax.to(this._infoText, .2, {
                    delay: .4,
                    alpha: 1,
                    ease: Power1.easeInOut
                })
            }, DailyBonusScene.prototype.animateOut = function(callback, scope) {}, DailyBonusScene.prototype.resize = function() {
                this.x = .5 * (p3.View.width - Common.STAGE_WIDTH), this._header.width = p3.View.width, this._muteButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width - Math.abs(this._muteButton.width)) - 28
            }, DailyBonusScene.prototype.update = function() {
                this._emitter.update(p3.Timestep.deltaTime)
            }, DailyBonusScene.prototype.onRewardButtonClick = function(button) {
                this._muteButton.interactive = !1, this._rewardWheel.interactive = !1, this.spinToWin()
            }
        }, {
            "./Common": 23,
            "./Scene": 83
        }],
        32: [function(require, module, exports) {
            function DesaturationShader(strength, red, green, blue) {
                red = void 0 != red ? red : .3, green = void 0 != green ? green : .59, blue = void 0 != blue ? blue : .11, PIXI.AbstractFilter.call(this, null, ["precision mediump float;", "varying vec2 vTextureCoord;", "varying vec4 vColor;", "uniform sampler2D uSampler;", "uniform float uStrength;", "uniform vec3 uRatio;", "void main (void) {", "   vec4 color = texture2D(uSampler, vTextureCoord) * vColor;", "   if (uStrength > 0.0) {", "       float intensity = uRatio.x * color.x + uRatio.y * color.y + uRatio.z * color.z;", "       color.x = intensity * uStrength + color.x * (1.0 - uStrength);", "       color.y = intensity * uStrength + color.y * (1.0 - uStrength);", "       color.z = intensity * uStrength + color.z * (1.0 - uStrength);", "   }", "   gl_FragColor = color;", "}"].join("\n"), {
                    uStrength: {
                        type: "1f",
                        value: strength
                    },
                    uRatio: {
                        type: "3fv",
                        value: [red, green, blue]
                    }
                })
            }
            module.exports = DesaturationShader, DesaturationShader.prototype = Object.create(PIXI.AbstractFilter.prototype), DesaturationShader.prototype.constructor = DesaturationShader, Object.defineProperty(DesaturationShader.prototype, "strength", {
                get: function() {
                    return this.uniforms.uStrength.value
                },
                set: function(value) {
                    this.uniforms.uStrength.value = value
                }
            }), Object.defineProperty(DesaturationShader.prototype, "red", {
                get: function() {
                    return this.uniforms.uRatio.value[0]
                },
                set: function(value) {
                    this.uniforms.uRatio.value[0] = value
                }
            }), Object.defineProperty(DesaturationShader.prototype, "green", {
                get: function() {
                    return this.uniforms.uRatio.value[1]
                },
                set: function(value) {
                    this.uniforms.uRatio.value[1] = value
                }
            }), Object.defineProperty(DesaturationShader.prototype, "blue", {
                get: function() {
                    return this.uniforms.uRatio.value[2]
                },
                set: function(value) {
                    this.uniforms.uRatio.value[2] = value
                }
            })
        }, {}],
        33: [function(require, module, exports) {
            function DriftView(color, avatar) {
                CarView.call(this, color, avatar);
                var chassisOffset = new PIXI.Point(0, -2);
                this._shadow.offset = new PIXI.Point(0, 20), this._wheels.front.left.visible = !1, this._wheels.front.right.visible = !1, this._wheels.rear.left.offset = new PIXI.Point(-124, 78), this._wheels.rear.right.offset = new PIXI.Point(124, 78), this._front.offset = new PIXI.Point(chassisOffset.x, -4 + chassisOffset.y), this._mid.offset = new PIXI.Point(chassisOffset.x, chassisOffset.y), this._back.offset = new PIXI.Point(chassisOffset.x, chassisOffset.y)
            }
            var CarShader = require("./CarShader"),
                CarView = require("./CarView"),
                Common = require("./Common");
            module.exports = DriftView, DriftView.prototype = Object.create(CarView.prototype), DriftView.prototype.constructor = DriftView, DriftView.prototype.update = function(distance, curvature, gradient, velocity, turnVelocity) {
                var scalar = 140;
                this._curvature += .4 * (turnVelocity + curvature - this._curvature), this._curvature = Math.max(-scalar, Math.min(scalar, this._curvature)), this._front.x = .3 * this._curvature + this._front.offset.x, this._front.y = -gradient * scalar * 1.6 + this._front.offset.y, this._mid.x = .1 * this._curvature + this._mid.offset.x, this._mid.y = -gradient * scalar * 1.3 + this._mid.offset.y, this._back.x = .2 * -this._curvature + this._back.offset.x, this._back.y = gradient * scalar + this._back.offset.y, this._shadow.x = this._back.x, this._shadow.y = this._wheels.rear.left.y + this._shadow.offset.y, this._front.rotation = 8e-4 * this._curvature, this._back.rotation = 8e-4 * this._curvature, this._wheels.front.left.x = this._front.x + this._wheels.front.left.offset.x, this._wheels.front.left.y = gradient * scalar + this._wheels.front.left.offset.y, this._wheels.front.right.x = this._front.x + this._wheels.front.right.offset.x, this._wheels.front.right.y = gradient * scalar + this._wheels.front.right.offset.y, this._wheels.rear.left.x = this._back.x + this._wheels.rear.left.offset.x, this._wheels.rear.left.y = gradient * scalar + this._wheels.rear.left.offset.y, this._wheels.rear.right.x = this._back.x + this._wheels.rear.right.offset.x, this._wheels.rear.right.y = gradient * scalar + this._wheels.rear.right.offset.y;
                var theta;
                theta = .008 * turnVelocity, 0 > theta && (theta *= .112), this._wheels.front.left.rotation = theta, theta = .008 * turnVelocity, theta > 0 && (theta *= .112), this._wheels.front.right.rotation = theta, theta = .008 * turnVelocity, 0 > theta && (theta *= .112), this._wheels.rear.left.rotation = theta, theta = .008 * turnVelocity, theta > 0 && (theta *= .112), this._wheels.rear.right.rotation = theta, velocity = Math.max(0, velocity), this._wheels.front.left.animationSpeed = velocity / .2, this._wheels.front.right.animationSpeed = velocity / .2, this._wheels.rear.left.animationSpeed = velocity / .2, this._wheels.rear.right.animationSpeed = velocity / .2
            }, DriftView.prototype.createFrontLayer = function() {
                var bodyTexture = Common.assets.getTexture("car_04_body_00"),
                    maskTexture = Common.assets.getTexture("car_04_mask_00"),
                    shineTexture = Common.assets.getTexture("car_04_shine_00"),
                    maskOffset = new PIXI.Point(maskTexture._uvs.x0 - bodyTexture._uvs.x0, maskTexture._uvs.y0 - bodyTexture._uvs.y0),
                    shineOffset = new PIXI.Point(shineTexture._uvs.x0 - bodyTexture._uvs.x0, shineTexture._uvs.y0 - bodyTexture._uvs.y0),
                    front = new PIXI.Sprite(bodyTexture);
                front.shader = new CarShader(this._color, maskOffset, this._shininess, shineOffset);
                var decal = new PIXI.Sprite(this.getDecalTexture(0));
                return front.addChild(decal), new PIXI.Sprite(front.generateTexture(Common.renderer, 1, PIXI.SCALE_MODES.DEFAULT))
            }, DriftView.prototype.createMidLayer = function() {
                var bodyTexture = Common.assets.getTexture("car_04_body_01"),
                    maskTexture = Common.assets.getTexture("car_04_mask_01"),
                    shineTexture = Common.assets.getTexture("car_04_shine_01"),
                    maskOffset = new PIXI.Point(maskTexture._uvs.x0 - bodyTexture._uvs.x0, maskTexture._uvs.y0 - bodyTexture._uvs.y0),
                    shineOffset = new PIXI.Point(shineTexture._uvs.x0 - bodyTexture._uvs.x0, shineTexture._uvs.y0 - bodyTexture._uvs.y0),
                    mid = new PIXI.Sprite(bodyTexture);
                mid.shader = new CarShader(this._color, maskOffset, this._shininess, shineOffset);
                var decal = new PIXI.Sprite(this.getDecalTexture(1));
                mid.addChild(decal);
                var kit = Common.garage.myCar.kit;
                if (0 == kit || 4 == kit) {
                    var topLights = new PIXI.Sprite(Common.assets.getTexture("car_04_specialkit_00"));
                    mid.addChild(topLights)
                }
                if (0 == kit) {
                    var spareTyre = new PIXI.Sprite(Common.assets.getTexture("car_04_specialkit_01"));
                    mid.addChild(spareTyre)
                }
                if (3 == kit) {
                    var neonLights = new PIXI.Sprite(Common.assets.getTexture("car_04_specialkit_02"));
                    mid.addChild(neonLights)
                }
                return new PIXI.Sprite(mid.generateTexture(Common.renderer, 1, PIXI.SCALE_MODES.DEFAULT))
            }, DriftView.prototype.createBackLayer = function() {
                var bodyTexture = Common.assets.getTexture("car_04_body_02"),
                    maskTexture = Common.assets.getTexture("car_04_mask_02"),
                    shineTexture = Common.assets.getTexture("car_04_shine_02"),
                    maskOffset = new PIXI.Point(maskTexture._uvs.x0 - bodyTexture._uvs.x0, maskTexture._uvs.y0 - bodyTexture._uvs.y0),
                    shineOffset = new PIXI.Point(shineTexture._uvs.x0 - bodyTexture._uvs.x0, shineTexture._uvs.y0 - bodyTexture._uvs.y0),
                    back = new PIXI.Sprite(bodyTexture);
                back.shader = new CarShader(this._color, maskOffset, this._shininess, shineOffset);
                var decal = new PIXI.Sprite(this.getDecalTexture(2));
                back.addChild(decal);
                var name = Common.garage.name,
                    plate = new PIXI.Sprite(Common.garage.saveLicensePlate(name));
                plate.x = .5 * back.width, plate.y = 178, plate.scale = new PIXI.Point(.5, .5), plate.anchor.x = .5, back.addChild(plate);
                var spoiler = this.createSpoilerLayer();
                return spoiler.y = 5, back.addChild(spoiler), new PIXI.Sprite(back.generateTexture(Common.renderer, 1, PIXI.SCALE_MODES.DEFAULT))
            }, DriftView.prototype.createSpoilerLayer = function() {
                var bodyTexture = Common.assets.getTexture("car_04_spoiler_02"),
                    maskTexture = Common.assets.getTexture("car_04_maskspoiler_02"),
                    maskOffset = new PIXI.Point(maskTexture._uvs.x0 - bodyTexture._uvs.x0, maskTexture._uvs.y0 - bodyTexture._uvs.y0),
                    spoiler = new PIXI.Sprite(bodyTexture);
                return spoiler.shader = new CarShader(this._color, maskOffset, 0), new PIXI.Sprite(spoiler.generateTexture(Common.renderer, 1, PIXI.SCALE_MODES.DEFAULT))
            }, DriftView.prototype.createRearWheel = function() {
                var sequence = new p3.MovieClipSequence;
                return sequence.addTextures([Common.assets.getTexture("car_04_wheels_rear_0"), Common.assets.getTexture("car_04_wheels_rear_1"), Common.assets.getTexture("car_04_wheels_rear_2"), Common.assets.getTexture("car_04_wheels_rear_3")]), new p3.MovieClip(sequence)
            }, DriftView.prototype.createShadow = function() {
                return new PIXI.Sprite(Common.assets.getTexture("car_04_shadow"))
            }
        }, {
            "./CarShader": 19,
            "./CarView": 21,
            "./Common": 23
        }],
        34: [function(require, module, exports) {
            function ErrorPopupScene(type) {
                Scene.call(this), this._type = type, this._overlay = null, this._panel = null, this._titleText = null, this._icon = null, this._infoText = null, this._closeButton = null
            }
            var Common = require("./Common"),
                Scene = require("./Scene");
            module.exports = ErrorPopupScene, ErrorPopupScene.prototype = Object.create(Scene.prototype), ErrorPopupScene.prototype.constructor = ErrorPopupScene, ErrorPopupScene.prototype.init = function() {
                var graphics = new PIXI.Graphics;
                graphics.beginFill(0, .64), graphics.drawRect(0, 0, 1, 1), graphics.endFill(), this._overlay = new PIXI.Sprite(graphics.generateTexture()), this._overlay.width = p3.View.width, this._overlay.height = p3.View.height, this._overlay.visible = !1, this.addChild(this._overlay), this._panel = new PIXI.Container, this._panel.x = .5 * Common.STAGE_WIDTH, this._panel.y = .5 * Common.STAGE_HEIGHT, this._panel.visible = !1, this.addChild(this._panel), this._panel.header = new PIXI.Sprite(Common.assets.getTexture("ui_popup_top")), this._panel.header.x = .5 * -this._panel.header.width, this._panel.addChild(this._panel.header), this._panel.content = new PIXI.Sprite(Common.assets.getTexture("ui_popup_bottom_carbon")),
                    this._panel.content.x = .5 * -this._panel.content.width, this._panel.content.y = this._panel.header.y + this._panel.header.height, this._panel.addChild(this._panel.content), this._panel.header.y -= .5 * (this._panel.header.height + this._panel.content.height), this._panel.content.y -= .5 * (this._panel.header.height + this._panel.content.height), webfont ? (this._titleText = new PIXI.Text(Common.copy.code_error_title[Common.language], {
                        font: "48px Arial",
                        fill: "#FFFFFF",
                        align: "center"
                    }), this._titleText.x = .5 * (this._panel.header.width - this._titleText.width), this._titleText.y = 24, this._panel.header.addChild(this._titleText)) : (this._titleText = new PIXI.extras.BitmapText(Common.copy.code_error_title[Common.language], {
                        font: "48px Great Escape",
                        align: "center"
                    }), this._titleText.x = .5 * (this._panel.header.width - this._titleText.textWidth), this._titleText.y = 16, this._panel.header.addChild(this._titleText)), this._icon = new PIXI.Sprite(Common.assets.getTexture("ui_icon_error")), this._icon.y = -20, this._icon.anchor = new PIXI.Point(.5, .5), this._panel.addChild(this._icon);
                var str;
                switch (this._type) {
                    case 0:
                        str = Common.copy.code_error_wrong[Common.language];
                        break;
                    case 1:
                        str = Common.copy.code_error_invalid[Common.language]
                }
                webfont ? (this._infoText = new PIXI.Text(str, {
                    font: "32px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._infoText.x = .5 * -this._infoText.width, this._infoText.y = 120, this._panel.addChild(this._infoText)) : (this._infoText = new PIXI.extras.BitmapText(str, {
                    font: "32px Great Escape",
                    align: "center"
                }), this._infoText.x = .5 * -this._infoText.textWidth, this._infoText.y = 120, this._panel.addChild(this._infoText)), this._closeButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_btn_close")), this._closeButton.x = .5 * (this._panel.header.width - this._closeButton.width) - 18, this._closeButton.y = -240, this._closeButton.animate = !0, this._closeButton.overSoundName = "sfx_ui_btn_rollover_00", this._closeButton.downSoundName = "sfx_ui_btn_press_00", this._closeButton.signals.click.add(this.onCloseButtonClick, this), this._panel.addChild(this._closeButton)
            }, ErrorPopupScene.prototype.dispose = function() {
                Common.animator.removeAll(), Scene.prototype.dispose.call(this)
            }, ErrorPopupScene.prototype.appear = function() {
                this.animateIn()
            }, ErrorPopupScene.prototype.show = function() {}, ErrorPopupScene.prototype.animateIn = function(callback, scope) {
                Scene.prototype.animateIn.call(this, callback, scope), this._overlay.alpha = 0, this._overlay.visible = !0, TweenMax.to(this._overlay, .2, {
                    alpha: 1,
                    ease: Power1.easeInOut
                });
                var x = this._panel.x;
                this._panel.x = .5 * (Common.STAGE_WIDTH - p3.View.width - this._panel.width), this._panel.visible = !0, TweenMax.to(this._panel, .3, {
                    x: x,
                    ease: Back.easeOut,
                    easeParams: [1]
                })
            }, ErrorPopupScene.prototype.animateOut = function(callback, scope) {
                Scene.prototype.animateOut.call(this, callback, scope), TweenMax.to(this._overlay, .4, {
                    alpha: 0,
                    ease: Power1.easeInOut,
                    onComplete: function() {
                        this._overlay.visible = !1
                    },
                    onCompleteScope: this
                }), TweenMax.to(this._panel, .26, {
                    x: .5 * (Common.STAGE_WIDTH + p3.View.width + this._panel.width),
                    ease: Back.easeIn,
                    easeParams: [1],
                    onComplete: function() {
                        this._panel.visible = !1, callback && callback.call(scope)
                    },
                    onCompleteScope: this
                })
            }, ErrorPopupScene.prototype.resize = function() {
                this.x = .5 * (p3.View.width - Common.STAGE_WIDTH), this._overlay.x = .5 * (Common.STAGE_WIDTH - p3.View.width), this._overlay.y = .5 * (Common.STAGE_HEIGHT - p3.View.height), this._overlay.width = p3.View.width, this._overlay.height = p3.View.height
            }, ErrorPopupScene.prototype.update = function() {}, ErrorPopupScene.prototype.onCloseButtonClick = function(button) {
                this._closeButton.onMouseOut(), this.animateOut(function() {
                    this.signals.next.dispatch()
                }, this)
            }
        }, {
            "./Common": 23,
            "./Scene": 83
        }],
        35: [function(require, module, exports) {
            function FadeTransition(color, duration) {
                this._color = color || 0, this._duration = duration || .8, this._quad = null, Transition.call(this)
            }
            var Transition = (require("./Common"), require("./Transition"));
            module.exports = FadeTransition, FadeTransition.prototype = Object.create(Transition.prototype), FadeTransition.prototype.constructor = FadeTransition, FadeTransition.prototype.init = function() {
                this._quad = new PIXI.Graphics, this._quad.visible = !1, this._quad.beginFill(this._color), this._quad.drawRect(0, 0, p3.View.width, p3.View.height), this._quad.endFill(), this.addChild(this._quad)
            }, FadeTransition.prototype["in"] = function() {
                this._quad.alpha = 0, this._quad.visible = !0, TweenMax.to(this._quad, .5 * this._duration, {
                    alpha: 1,
                    ease: Power2.easeInOut,
                    onComplete: function() {
                        Transition.prototype["in"].call(this, this)
                    },
                    onCompleteScope: this
                })
            }, FadeTransition.prototype.out = function() {
                TweenMax.to(this._quad, .5 * this._duration, {
                    alpha: 0,
                    ease: Power2.easeInOut,
                    onComplete: function() {
                        this._quad.visible = !1, Transition.prototype.out.call(this, this)
                    },
                    onCompleteScope: this
                })
            }, FadeTransition.prototype.resize = function() {
                this._quad.clear(), this._quad.beginFill(this._color), this._quad.drawRect(0, 0, p3.View.width, p3.View.height), this._quad.endFill()
            }
        }, {
            "./Common": 23,
            "./Transition": 105
        }],
        36: [function(require, module, exports) {
            function GameScene(tutorial, retry) {
                this._hud = null, this._engine = null, this._player = null, this._skybox = null, this._ai = [], this._pickups = [], this._powerups = [], this._obstacles = [], this._tutorialIndex = 0, this._tutorialTriggers = [], this._currentTutorial = null, this._squeakyClean = !0, this._isTutorial = tutorial, this._isRetry = retry, this._collectedPickups = [], this._countryAmbienceSFX = null, this._raceAmbienceSFX = null, this._crashRearEmitter = null, this._crashLeftEmitter = null, this._crashRightEmitter = null, this._trackingContext = "", this._time = 0, this._racing = !1, this._offroad = !1, Scene.call(this)
            }
            var AchievementTypes = require("./AchievementTypes"),
                AI = require("./AI"),
                AudioParams = require("./AudioParams"),
                Common = (require("./Car"), require("./Common")),
                ControlTypes = require("./ControlTypes"),
                CountryTypes = require("./CountryTypes"),
                Obstacle = require("./Obstacle"),
                Player = require("./Player"),
                Pickup = require("./Pickup"),
                Powerup = require("./Powerup"),
                Hud = require("./Hud"),
                RaceEngine = require("./RaceEngine"),
                RaceScene = require("./RaceView"),
                RaceTrack = require("./RaceTrack"),
                RoadEntity = require("./RoadEntity"),
                Scene = require("./Scene"),
                Skybox = require("./Skybox"),
                SplashOverlayEffect = require("./SplashOverlayEffect"),
                TutorialBoost = (require("./TrackData"), require("./TutorialBoost")),
                TutorialBrake = require("./TutorialBrake"),
                TutorialHud = require("./TutorialHud"),
                TutorialPoint = require("./TutorialPoint"),
                TutorialSteering = require("./TutorialSteering"),
                BernoulliView = require("./BernoulliView"),
                BoostView = require("./BoostView"),
                GorvetteView = require("./GorvetteView"),
                LightningView = require("./LightningView"),
                SchnellView = require("./SchnellView"),
                ThreatView = require("./ThreatView"),
                TodorokiView = require("./TodorokiView"),
                VelosoView = require("./VelosoView");
            module.exports = GameScene, GameScene.prototype = Object.create(Scene.prototype), GameScene.prototype.constructor = GameScene, GameScene.prototype.init = function() {
                var name = Common.trackManager.currentTrack.trackName,
                    track = new RaceTrack(name),
                    view = new RaceScene;
                view.x = .5 * Common.STAGE_WIDTH, view.drawDistance = p3.Device.isMobile ? 8 : 16, this.addChild(view), this._hud = new Hud, this._hud.init(), this._hud.signals.pause.add(function() {
                    this.signals.pause.dispatch(this)
                }, this), this._hud.signals.boost.add(function() {
                    this._player.startNitro()
                }, this), this.addChild(this._hud), this._hud.announcer.visible = !this._isTutorial, this._engine = new RaceEngine(track, view), this._engine.init(), Common.engine = this._engine, this._engine.camera.vanishingPoint = new PIXI.Point(0, p3.View.height - 350), Common.camera = this._engine.camera;
                var color = Common.garage.myCar.colors[Common.garage.myCar.color].color;
                this._player = new Player(color, Common.garage.avatar), this._player.id = 0, this._player.view.y = .5 * p3.View.height + 240, this._player.view.scale = new PIXI.Point(.8, .8), this._player.renderInWorld = !1, this._player.zDepthOffset = .6, this._player.distanceOffset = 1.2, this._player.signals.lap.add(this.onLap, this), this._player.signals.nitro.add(this.onPlayerNitro, this), this._engine.addEntity(this._player, 0), this._engine.camera.target = this._player;
                var config = Common.assets.getJSON("particles_car_rear_impact");
                this._crashRearEmitter = new cloudkid.Emitter(this, [Common.assets.getTexture("particle_standard")], config), this._crashRearEmitter.emit = !1, Common.animator.add(this._crashRearEmitter), config = Common.assets.getJSON("particles_car_leftside_impact"), this._crashLeftEmitter = new cloudkid.Emitter(this, [Common.assets.getTexture("particle_standard")], config), this._crashLeftEmitter.emit = !1, Common.animator.add(this._crashLeftEmitter), config = Common.assets.getJSON("particles_car_rightside_impact"), this._crashRightEmitter = new cloudkid.Emitter(this, [Common.assets.getTexture("particle_standard")], config), this._crashRightEmitter.emit = !1, Common.animator.add(this._crashRightEmitter);
                var country = Common.trackManager.currentTrack.country;
                this._skybox = new Skybox(country, this._engine.camera), this.addChildAt(this._skybox, 0), this.createAI(), this.prepareStartingGrid(), this.placeObjects();
                var tm = Common.trackManager;
                this._trackingContext = this._isTutorial ? "tutorial" : (tm.currentSeries ? "series" : "single") + "_" + tm.currentTrack.country + "_level_" + (tm.currentSeries ? tm.currentSeries.currentTrack : tm.currentTrack.id)
            }, GameScene.prototype.dispose = function() {
                Common.animator.removeAll(), this._hud.destroy(), this._player.destroy(), this.clearAI(), this._currentTutorial && (this._currentTutorial.destroy(), this._currentTutorial = null), Common.audio.stopSound("sfx_race_start_idle_revs_00"), Common.audio.stopSound("sfx_race_start_idle_revs_01"), Common.audio.stopSound("sfx_race_start_idle_revs_02"), this.stopAmbience(), Scene.prototype.dispose.call(this)
            }, GameScene.prototype.appear = function() {
                this.start(), this.playMusic(), this.playAmbience(.4)
            }, GameScene.prototype.show = function() {
                this._player.muteEngine(!1)
            }, GameScene.prototype.hide = function() {
                this._player.muteEngine(!0)
            }, GameScene.prototype.resize = function() {
                this.x = .5 * (p3.View.width - Common.STAGE_WIDTH), this._hud.resize(), this._skybox.resize()
            }, GameScene.prototype.update = function() {
                if (!Common.animator.paused) {
                    if (this._engine.update(), this._time += 1e3 * p3.Timestep.deltaTime, this.checkCollisionsAI(), this.checkCollisionsObstacles(), this.checkCollisionsPickups(), this.checkCollisionsPowerups(), Common.garage.controls == ControlTypes.CONTROLS_ROOKIE) this._player.offset.x = Math.max(-420, Math.min(420, this._player.offset.x));
                    else if (Common.garage.controls == ControlTypes.CONTROLS_EXPERT)
                        if (this._player.offset.x = Math.max(-620, Math.min(620, this._player.offset.x)), Math.abs(this._player.offset.x) > 600) {
                            if (this._offroad = !0, this._player.velocity *= .964, !this._player.nitroActive) {
                                this._player.nitroFuel -= 6 * this._player.nitroTick * p3.Timestep.deltaTime, this._engine.camera.applyShake(Number.MAX_VALUE);
                                var str = Common.copy.game_announcer_off_track[Common.language].replace("[NAME]", Common.garage.name.toUpperCase());
                                this._hud.announce(str)
                            }
                        } else this._offroad && (this._offroad = !1, this._engine.camera.applyShake(0));
                    this.updateHud(), this.updateTutorial(), this._skybox.update();
                    var pos = this.getRacePosition(this._player);
                    if (void 0 == this._player.lastPos && (this._player.lastPos = pos), pos != this._player.lastPos) {
                        var overtake = pos < this._player.lastPos;
                        this._player.lastPos = pos, 0 == pos ? (str = Common.copy.game_announcer_first[Common.language].replace("[NAME]", Common.garage.name.toUpperCase()), this._hud.announce(str)) : pos == this._ai.length ? (str = Common.copy.game_announcer_last[Common.language].replace("[NAME]", Common.garage.name.toUpperCase()), this._hud.announce(str)) : overtake && (str = Common.copy.game_announcer_overtake[Common.language], this._hud.announce(str))
                    }
                }
            }, GameScene.prototype.updateHud = function() {
                this._racing && this._hud.updateTime(this._time), this._hud.updateLap(this._player.lap, this._engine.track.meta.laps), this._hud.updateNitroFuel(this._player.nitroFuel / this._player.nitroFuelMax, this._player.nitroActive), this._hud.update(this._player.nitroActive)
            }, GameScene.prototype.updateTutorial = function() {
                if (this._isTutorial && !(this._tutorialIndex >= this._tutorialTriggers.length)) {
                    var pickup, powerup, obstacle, distance, target, i, copy = Common.copy,
                        language = Common.language,
                        current = this._tutorialTriggers[this._tutorialIndex];
                    if (Math.abs(current.distance - this._player.distance) < this._player.velocity) switch (++this._tutorialIndex, this._currentTutorial && this._currentTutorial.destroy(), current.id) {
                        case 100:
                            this._currentTutorial = new TutorialSteering, this._currentTutorial.show(copy[p3.Device.isMobile ? "tutorial_steer_mobile" : "tutorial_steer"][language]), this.addChild(this._currentTutorial);
                            break;
                        case 101:
                            this._currentTutorial = new TutorialBrake, this._currentTutorial.show(copy.tutorial_brake[language]), this.addChild(this._currentTutorial);
                            break;
                        case 102:
                            for (i = 0; i < this._powerups.length; ++i)
                                if (powerup = this._powerups[i], distance = Math.floor(powerup.distance - this._player.distance), Math.abs(distance) < 20) {
                                    target = powerup.view.position.clone();
                                    break
                                }
                            this._currentTutorial = new TutorialPoint(PIXI.Texture.EMPTY), this._currentTutorial.show(copy.tutorial_powerups[language], target), this.addChild(this._currentTutorial);
                            break;
                        case 107:
                            this._currentTutorial = new TutorialBoost, this._currentTutorial.show(copy[p3.Device.isMobile ? "tutorial_boost_mobile" : "tutorial_boost"][language]), this.addChild(this._currentTutorial);
                            break;
                        case 103:
                            this._currentTutorial = new TutorialHud, this._currentTutorial.show(copy.tutorial_hud[language]), this.addChild(this._currentTutorial);
                            break;
                        case 104:
                            for (i = 0; i < this._pickups.length; ++i)
                                if (pickup = this._pickups[i], distance = Math.floor(pickup.distance - this._player.distance), Math.abs(distance) < this._engine.view.drawDistance) {
                                    target = pickup.view.position.clone();
                                    break
                                }
                            this._currentTutorial = new TutorialPoint(PIXI.Texture.EMPTY), this._currentTutorial.show(copy.tutorial_pickups[language], target), this.addChild(this._currentTutorial);
                            break;
                        case 105:
                            for (i = 0; i < this._obstacles.length; ++i)
                                if (obstacle = this._obstacles[i], distance = Math.floor(obstacle.distance - this._player.distance), Math.abs(distance) < this._engine.view.drawDistance) {
                                    target = obstacle.view.position.clone();
                                    break
                                }
                            this._currentTutorial = new TutorialPoint(PIXI.Texture.EMPTY), this._currentTutorial.show(copy.tutorial_obstacles[language], target), this.addChild(this._currentTutorial)
                    }
                }
            }, GameScene.prototype.checkCollisionsAI = function() {
                for (var ai, collision, length = 60, i = 0; i < this._ai.length; ++i)
                    if (ai = this._ai[i], collision = this._engine.testCollision(new PIXI.Point(this._player.offset.x, this._player.distance + this._player.distanceOffset), new PIXI.Point(ai.offset.x, ai.distance), new PIXI.Point(.9 * this._player.view.width, length), new PIXI.Point(.9 * ai.view.width, length))) {
                        if (this._engine.camera.applyShake(.5), collision.top && (this._player.distance = ai.distance - this._player.distanceOffset + 2 * length / this._engine.view.segmentHeight, this._player.realDistance = ai.realDistance - this._player.distanceOffset + 2 * length / this._engine.view.segmentHeight), collision.bottom && (this._player.distance = ai.distance - this._player.distanceOffset - 2 * length / this._engine.view.segmentHeight, this._player.realDistance = ai.realDistance - this._player.distanceOffset - 2 * length / this._engine.view.segmentHeight), collision.left && (this._player.offset.x = ai.offset.x - .9 * (this._player.view.width + ai.view.width) * .5), collision.right && (this._player.offset.x = ai.offset.x + .9 * (this._player.view.width + ai.view.width) * .5), this._player.distance = (this._player.distance + this._engine.track.length) % this._engine.track.length, (collision.top || collision.bottom) && (collision.bottom && (this._player.velocity *= .99, ai.velocity *= .99), !ai.isHit)) {
                            ai.isHit = !0;
                            var dx = .32 * (ai.offset.x - this._player.offset.x);
                            this._crashRearEmitter.updateOwnerPos(.5 * Common.STAGE_WIDTH + dx, this._player.view.y + (collision.bottom ? -20 : 60)), this._crashRearEmitter.emit = !0, Common.audio.playSound("sfx_car_crash_rear_00")
                        }(collision.left || collision.right) && (this._player.velocity *= .994, this._player.turnVelocity *= .2, ai.velocity *= .994, ai.turnVelocity *= .2, ai.isHit || (ai.isHit = !0, collision.right ? (this._crashLeftEmitter.updateOwnerPos(.5 * Common.STAGE_WIDTH - 80, this._player.view.y + 60), this._crashLeftEmitter.emit = !0) : collision.left && (this._crashRightEmitter.updateOwnerPos(.5 * Common.STAGE_WIDTH + 80, this._player.view.y + 60), this._crashRightEmitter.emit = !0), Common.audio.playSound(["sfx_car_crash_side_00", "sfx_car_crash_side_01", "sfx_car_crash_side_02"]))), this._squeakyClean = !1, this._hud.announce(Common.copy.game_announcer_hits_obstacle[Common.language])
                    } else ai.isHit = !1
            }, GameScene.prototype.checkCollisionsObstacles = function() {
                for (var obstacle, collision, i = 0; i < this._obstacles.length; ++i)
                    if (obstacle = this._obstacles[i], !obstacle.smashed && (collision = this._engine.testCollision(new PIXI.Point(this._player.offset.x, this._player.distance + this._player.distanceOffset), new PIXI.Point(obstacle.offset.x, obstacle.distance), new PIXI.Point(.9 * this._player.view.width, 60), new PIXI.Point(.9 * obstacle.view.width, 30)))) {
                        switch (obstacle.smash(this._player), this._engine.camera.applyShake(.5), this._player.velocity *= obstacle.penalty, this._player.nitroActive || (this._player.nitroFuel -= .2 * this._player.nitroFuelMax), this._squeakyClean = !1, obstacle.id) {
                            case Obstacle.TYPE_OIL:
                            case Obstacle.TYPE_WATER:
                                this._hud.announce(Common.copy.game_announcer_hits_puddle[Common.language]), this._hud.showSplashEffect(obstacle.id == Obstacle.TYPE_WATER ? SplashOverlayEffect.TYPE_WATER : SplashOverlayEffect.TYPE_OIL);
                                break;
                            default:
                                this._hud.announce(Common.copy.game_announcer_hits_obstacle[Common.language])
                        }
                        switch (obstacle.id) {
                            case Obstacle.TYPE_CONE:
                                Common.audio.playSound(["sfx_object_hit_cone_01", "sfx_object_hit_cone_02", "sfx_object_hit_cone_03", "sfx_object_hit_cone_04", "sfx_object_hit_cone_05"]);
                                break;
                            case Obstacle.TYPE_PLASTIC_DRUM:
                                Common.audio.playSound(["sfx_object_hit_plasticdrum_00", "sfx_object_hit_plasticdrum_01"]);
                                break;
                            case Obstacle.TYPE_METAL:
                                Common.audio.playSound(["sfx_object_hit_metalbarrel_00", "sfx_object_hit_metalbarrel_01"]);
                                break;
                            case Obstacle.TYPE_BUSH:
                            case Obstacle.TYPE_TUMBLEWEED:
                                Common.audio.playSound(["sfx_object_tumbleweed_hit_00", "sfx_object_tumbleweed_hit_01", "sfx_object_tumbleweed_hit_02"]);
                                break;
                            case Obstacle.TYPE_WOODEN:
                                Common.audio.playSound(["sfx_object_hit_wood_barrier_00", "sfx_object_hit_wood_barrier_01", "sfx_object_hit_wood_barrier_02"]);
                                break;
                            case Obstacle.TYPE_ROCK:
                                Common.audio.playSound(["sfx_object_hit_concrete_00", "sfx_object_hit_concrete_01", "sfx_object_hit_concrete_02", "sfx_object_hit_concrete_03"]);
                                break;
                            case Obstacle.TYPE_OIL:
                                Common.audio.playSound("sfx_car_oil_splat_02");
                                break;
                            case Obstacle.TYPE_WATER:
                                Common.audio.playSound(["sfx_car_puddle_splash_00", "sfx_car_puddle_splash_01", "sfx_car_puddle_splash_02"]);
                                break;
                            default:
                                Common.audio.playSound(["sfx_car_crash_barrier_00", "sfx_car_crash_barrier_01"])
                        }
                    }
            }, GameScene.prototype.checkCollisionsPickups = function() {
                for (var pickup, collision, i = 0; i < this._pickups.length; ++i) pickup = this._pickups[i], collision = this._engine.testCollision(new PIXI.Point(this._player.offset.x, this._player.distance + this._player.distanceOffset), new PIXI.Point(pickup.offset.x, pickup.distance), new PIXI.Point(.9 * this._player.view.width, 60), new PIXI.Point(.9 * pickup.view.width, 30)), collision && pickup.collect(this._player)
            }, GameScene.prototype.checkCollisionsPowerups = function() {
                for (var powerup, collision, i = 0; i < this._powerups.length; ++i) powerup = this._powerups[i], collision = this._engine.testCollision(new PIXI.Point(this._player.offset.x, this._player.distance + this._player.distanceOffset), new PIXI.Point(powerup.offset.x, powerup.distance), new PIXI.Point(.9 * this._player.view.width, 60), new PIXI.Point(.9 * powerup.view.width, 30)), collision && powerup.collect(this._player)
            }, GameScene.prototype.start = function() {
                function go() {
                    for (var ai, i = 0; i < this._ai.length; ++i) ai = this._ai[i], ai.driving = !0;
                    this._player.driving = !0, this._racing = !0, this._time = 0;
                    var racers = this._ai.concat([this._player]);
                    this._hud.ladder.init(racers, this._player), idleSFX && idleSFX.stop(), Common.audio.playSound("sfx_car_big_skid_00"), Common.audio.playSound("sfx_car_start_tyres_04")
                }
                var sounds = ["sfx_race_start_idle_revs_00", "sfx_race_start_idle_revs_01", "sfx_race_start_idle_revs_02"],
                    params = new AudioParams;
                params.loop = !0;
                var idleSFX = Common.audio.playSound(sounds, params);
                if (this._hud.runCountdown(.8, go, this), this._isTutorial) Common.tracking.track(new p3.TrackingDataPlaydomGameAction(this._trackingContext, "tutorial_start"));
                else {
                    var car = Common.garage.myCar,
                        message = Common.garage.controls + "_" + car.kits[car.kit].name.split(" ")[0].toLowerCase();
                    Common.tracking.track(new p3.TrackingDataPlaydomGameAction(this._trackingContext, this._isRetry ? "race_start_replay" : "race_start", message))
                }
                this._isTutorial && this._isRetry && Common.tracking.track(new p3.TrackingDataPlaydomGameAction(this._trackingContext, "retry_tutorial"))
            }, GameScene.prototype.end = function() {
                Common.score = this._time, this._racing = !1, this.estimateSeriesResults();
                var tm = Common.trackManager,
                    config = Common.config,
                    garage = Common.garage,
                    position = this.getRacePosition(this._player),
                    finished = tm.completeTrack(position, this._isTutorial),
                    track = tm.currentTrack,
                    prizes = config.singles[track.country][track.difficulty],
                    trackPrize = track ? prizes[Math.min(prizes.length - 1, position)] : 0,
                    seriesPrize = 0,
                    series = tm.currentSeries;
                series && series.isFinished && (prizes = config.series[series.label], seriesPrize = series ? prizes[Math.min(prizes.length - 1, position)] : 0);
                var prizeSum = trackPrize + seriesPrize;
                garage.giveCash(prizeSum);
                var collectedSum = this.getPickupsCashTotal();
                if (garage.giveCash(collectedSum), this.signals.next.dispatch(this, position, prizeSum, this._collectedPickups.slice(), finished), Common.audio.playSound("music_cars_racefinish_sting"), this._isTutorial) Common.tracking.track(new p3.TrackingDataPlaydomGameAction(this._trackingContext, "tutorial_end"));
                else {
                    var message = Common.garage.controls + "_" + Common.garage.cash;
                    Common.tracking.track(new p3.TrackingDataPlaydomGameAction(this._trackingContext, "race_end", message))
                }
                prizeSum + collectedSum > 150 && Common.achievements.award(AchievementTypes.COLLECT_X_COINS_IN_RACE), this._squeakyClean && Common.achievements.award(AchievementTypes.WIN_CLEAN_RACE)
            }, GameScene.prototype.placeObjects = function() {
                for (var data, object, i = 0; i < this._engine.track.objects.length; ++i) switch (data = this._engine.track.objects[i], data.id) {
                    case 0:
                        object = new RoadEntity(RoadEntity.TYPE_STATIC, new PIXI.Sprite(Common.assets.getTexture(data.t))), object.offset.x = data.o.x * Common.GAME_OBJECT_SCALE, object.offset.y = 240, object.scale.x = 6, object.scale.y = 6, object.view.anchor = new PIXI.Point(.5, 1), this._engine.addEntity(object, data.d, !0);
                        break;
                    case 1:
                        object = new Powerup(Powerup.TYPE_INSTANT_BOOST, new PIXI.Sprite(Common.assets.getTexture(data.t))), object.offset.x = data.o.x * Common.GAME_OBJECT_SCALE, object.offset.y = -120, object.view.anchor = new PIXI.Point(.5, .5), object.zDepthOffset = 1, object.signals.collect.add(this.onPowerupCollect, this), object.init(), this._engine.addEntity(object, data.d), this._powerups.push(object);
                        break;
                    case 2:
                    case 4:
                    case 5:
                        object = new Obstacle(data.ty, new PIXI.Sprite(Common.assets.getTexture(data.t))), object.offset.x = data.o.x * Common.GAME_OBJECT_SCALE - 40, object.offset.y = 60, object.scale.x = 2, object.scale.y = 2, object.view.anchor = new PIXI.Point(.5, 1), this._engine.addEntity(object, data.d), this._obstacles.push(object);
                        break;
                    case 3:
                        object = new Pickup(0, new PIXI.Sprite(Common.assets.getTexture(data.t))), object.offset.x = data.o.x * Common.GAME_OBJECT_SCALE, object.view.anchor = new PIXI.Point(.5, 1), object.signals.collect.add(this.onPickupCollect, this), this._engine.addEntity(object, data.d), this._pickups.push(object);
                        break;
                    case 100:
                    case 102:
                    case 103:
                    case 104:
                    case 105:
                    case 106:
                    case 107:
                        object = new RoadEntity(RoadEntity.TYPE_STATIC, new PIXI.Sprite(PIXI.Texture.EMPTY)), object.id = data.id, this._engine.addEntity(object, data.d), this._tutorialTriggers.push(object)
                }
                this._tutorialTriggers.sort(function(a, b) {
                    return a.distance - b.distance
                })
            }, GameScene.prototype.createAI = function() {
                var ai, view, arr;
                if (this._isTutorial) ai = new AI(this, AI.FOCUS_TYPE_NORMAL, 1, new LightningView(Common.assets.getTexture("ui_hud_opponent_lightning"))), ai.id = 1, ai.offset.y = -54, ai.zDepthOffset = 1, this._engine.addEntity(ai, 2), this._ai.push(ai);
                else {
                    var count = 8,
                        track = Common.trackManager.currentTrack;
                    switch (track.country) {
                        case CountryTypes.BRAZIL:
                            arr = [new VelosoView(Common.assets.getTexture("ui_hud_opponent_veloso")), new LightningView(Common.assets.getTexture("ui_hud_opponent_lightning")), new BernoulliView(Common.assets.getTexture("ui_hud_opponent_francesco")), new GorvetteView(Common.assets.getTexture("ui_hud_opponent_gorvette")), new SchnellView(Common.assets.getTexture("ui_hud_opponent_max")), new BoostView(Common.assets.getTexture("ui_hud_opponent_boost")), new ThreatView(Common.assets.getTexture("ui_hud_opponent_threat")), new TodorokiView(Common.assets.getTexture("ui_hud_opponent_todoroki"))];
                            break;
                        case CountryTypes.GERMANY:
                            arr = [new SchnellView(Common.assets.getTexture("ui_hud_opponent_max")), new GorvetteView(Common.assets.getTexture("ui_hud_opponent_gorvette")), new LightningView(Common.assets.getTexture("ui_hud_opponent_lightning")), new BernoulliView(Common.assets.getTexture("ui_hud_opponent_francesco")), new VelosoView(Common.assets.getTexture("ui_hud_opponent_veloso")), new BoostView(Common.assets.getTexture("ui_hud_opponent_boost")), new ThreatView(Common.assets.getTexture("ui_hud_opponent_threat")), new TodorokiView(Common.assets.getTexture("ui_hud_opponent_todoroki"))];
                            break;
                        case CountryTypes.ITALY:
                            arr = [new BernoulliView(Common.assets.getTexture("ui_hud_opponent_francesco")), new LightningView(Common.assets.getTexture("ui_hud_opponent_lightning")), new TodorokiView(Common.assets.getTexture("ui_hud_opponent_todoroki")), new GorvetteView(Common.assets.getTexture("ui_hud_opponent_gorvette")), new SchnellView(Common.assets.getTexture("ui_hud_opponent_max")), new BoostView(Common.assets.getTexture("ui_hud_opponent_boost")), new VelosoView(Common.assets.getTexture("ui_hud_opponent_veloso")), new ThreatView(Common.assets.getTexture("ui_hud_opponent_threat"))];
                            break;
                        case CountryTypes.JAPAN:
                            arr = [new TodorokiView(Common.assets.getTexture("ui_hud_opponent_todoroki")), new BoostView(Common.assets.getTexture("ui_hud_opponent_boost")), new LightningView(Common.assets.getTexture("ui_hud_opponent_lightning")), new BernoulliView(Common.assets.getTexture("ui_hud_opponent_francesco")), new VelosoView(Common.assets.getTexture("ui_hud_opponent_veloso")), new GorvetteView(Common.assets.getTexture("ui_hud_opponent_gorvette")), new SchnellView(Common.assets.getTexture("ui_hud_opponent_max")), new ThreatView(Common.assets.getTexture("ui_hud_opponent_threat"))];
                            break;
                        case CountryTypes.USA:
                            arr = [new LightningView(Common.assets.getTexture("ui_hud_opponent_lightning")), new BernoulliView(Common.assets.getTexture("ui_hud_opponent_francesco")), new BoostView(Common.assets.getTexture("ui_hud_opponent_boost")), new GorvetteView(Common.assets.getTexture("ui_hud_opponent_gorvette")), new VelosoView(Common.assets.getTexture("ui_hud_opponent_veloso")), new SchnellView(Common.assets.getTexture("ui_hud_opponent_max")), new ThreatView(Common.assets.getTexture("ui_hud_opponent_threat")), new TodorokiView(Common.assets.getTexture("ui_hud_opponent_todoroki"))]
                    }
                    for (var skill, modifiers = [1, 1.04, 1.08], i = 0; count > i; ++i) view = arr[i], skill = 1 - i / (count - 1) * .5 * modifiers[track.difficulty], ai = new AI(this, 2 > i ? AI.FOCUS_TYPE_LEAD : i > count - 3 ? AI.FOCUS_TYPE_REAR : AI.FOCUS_TYPE_NORMAL, skill, view), ai.id = i + 1, ai.offset.y = -54, ai.zDepthOffset = 1, ai.signals.lap.add(this.onLap, this), this._engine.addEntity(ai, 2 + i), this._ai.push(ai);
                    if (!this._isTutorial)
                        for (i = 0; i < this._ai.length; ++i) ai = this._ai[i], ai.leadTarget = ai.focus == AI.FOCUS_TYPE_LEAD ? this._ai[2] : null
                }
            }, GameScene.prototype.prepareStartingGrid = function() {
                var distance, i, car, tm = Common.trackManager,
                    startingGrid = [-1, 1, -1, 1, -1, 1, -1, 1, -1],
                    startingSpacing = 260,
                    arr = this._ai.concat([this._player]),
                    series = tm.currentSeries;
                if (series && series.currentTrack > 0) {
                    series.results = [0, 1, 2, 3, 4, 5, 6, 7, 8];
                    var id, j;
                    for (i = 0; i < series.results.length; ++i)
                        for (id = series.results[i], j = 0; j < arr.length; ++j) car = arr[j], car.id == id && (car.offset.x = startingGrid[i] * startingSpacing, distance = car instanceof Player ? 0 : 1, distance = distance + (arr.length - 1 - i) - arr.length - 4, distance = (distance + this._engine.track.length - 1) % this._engine.track.length, this._engine.addEntity(car, distance))
                } else
                    for (i = 0; i < arr.length; ++i) car = arr[i], car.offset.x = startingGrid[i] * startingSpacing, distance = car instanceof Player ? 0 : 1, distance = distance + (arr.length - 1 - i) - arr.length - 4, distance = (distance + this._engine.track.length - 1) % this._engine.track.length, this._engine.addEntity(car, distance)
            }, GameScene.prototype.clearAI = function() {
                for (var ai, i = 0; i < this._ai.length; ++i) ai = this._ai[i], ai.destroy();
                this._ai.length = 0
            }, GameScene.prototype.estimateSeriesResults = function() {
                var trackManager = Common.trackManager;
                if (trackManager.isSeries) {
                    var series = trackManager.currentSeries,
                        arr = this._ai.concat([this._player]);
                    arr.sort(function(a, b) {
                        return b.finalDistance - a.finalDistance
                    });
                    for (var car, i = 0; i < arr.length; ++i) car = arr[i], -1 == series.results.indexOf(car.id) && series.results.push(car.id);
                    console.log("results - " + series.results.toString())
                }
            }, GameScene.prototype.resetSeriesResults = function() {
                var trackManager = Common.trackManager;
                if (trackManager.isSeries) {
                    var series = trackManager.currentSeries;
                    series.reset()
                }
            }, GameScene.prototype.playMusic = function() {
                var stingName, loopName, track = Common.trackManager.currentTrack;
                switch (track.country) {
                    case CountryTypes.BRAZIL:
                        stingName = "music_brazil_intro_sting_00", loopName = "music_brazil_raceloop_00";
                        break;
                    case CountryTypes.GERMANY:
                        stingName = "music_germany_intro_sting_00", loopName = "music_germany_raceloop_00";
                        break;
                    case CountryTypes.ITALY:
                        stingName = "music_italy_intro_sting_00", loopName = "music_italy_raceloop_00";
                        break;
                    case CountryTypes.JAPAN:
                        stingName = "music_japan_intro_sting_00", loopName = "music_japan_raceloop_00";
                        break;
                    case CountryTypes.TUTORIAL:
                    case CountryTypes.USA:
                        stingName = "music_usa_intro_sting_00", loopName = "music_usa_raceloop_00";
                        break;
                    default:
                        stingName = "music_usa_intro_sting_00", loopName = "music_usa_raceloop_00"
                }
                var params = new AudioParams;
                params.callback = function() {
                    Common.audio.playMusic(loopName)
                }, params.scope = this, Common.audio.playMusic(stingName, params)
            }, GameScene.prototype.playAmbience = function(volume) {
                this.stopAmbience();
                var name, track = Common.trackManager.currentTrack;
                switch (track.country) {
                    case CountryTypes.BRAZIL:
                        name = "sfx_ambience_brazil_00";
                        break;
                    case CountryTypes.GERMANY:
                        name = "sfx_ambience_germany_00";
                        break;
                    case CountryTypes.ITALY:
                        name = "sfx_ambience_italy_00";
                        break;
                    case CountryTypes.JAPAN:
                        name = "sfx_ambience_tokyo_00";
                        break;
                    case CountryTypes.TUTORIAL:
                    case CountryTypes.USA:
                        name = "sfx_ambience_usa_desert_00";
                        break;
                    default:
                        name = "sfx_ambience_usa_desert_00"
                }
                var params = new AudioParams;
                params.volume = volume, params.loop = !0, this._countryAmbienceSFX = Common.audio.playSound(name, params), this._raceAmbienceSFX = Common.audio.playSound("sfx_ambience_inrace_00", params)
            }, GameScene.prototype.stopAmbience = function() {
                this._countryAmbienceSFX && (this._countryAmbienceSFX.stop(), this._countryAmbienceSFX = null), this._raceAmbienceSFX && (this._raceAmbienceSFX.stop(), this._raceAmbienceSFX = null)
            }, GameScene.prototype.getPickupsCashTotal = function() {
                for (var pickup, total = 0, i = 0; i < this._collectedPickups.length; ++i) pickup = this._collectedPickups[i], total += pickup.value;
                return total
            }, GameScene.prototype.getRacePosition = function(car) {
                var arr = this._ai.concat([this._player]);
                return arr.sort(function(a, b) {
                    return b.finalDistance - a.finalDistance
                }), arr.indexOf(car)
            }, GameScene.prototype.onPickupCollect = function(pickup, collector) {
                this._collectedPickups.push({
                    id: pickup.id,
                    value: pickup.value,
                    texture: pickup.view.texture
                }), Common.audio.playSound("sfx_object_pickup_coins_00")
            }, GameScene.prototype.onPowerupCollect = function(powerup, collector) {
                collector.usePowerup(powerup.id), this._hud.turboButton.animateCharge(), Common.audio.playSound("sfx_object_pickup_turbo_01")
            }, GameScene.prototype.onPlayerNitro = function(value, superBoost) {
                if (value) {
                    var str = Common.copy.game_announcer_boost_used[Common.language].replace("[NAME]", Common.garage.name.toUpperCase());
                    this._hud.announce(str)
                } else this._hud.turboButton.stopAnimateFull()
            }, GameScene.prototype.onLap = function(car) {
                p3.Timestep.queueCall(function() {
                    if (car.lap == this._engine.track.meta.laps + 1) {
                        var trackManager = Common.trackManager;
                        if (trackManager.isSeries) {
                            var series = trackManager.currentSeries;
                            series.results.push(car.id)
                        }
                        car == this._player && this.end()
                    }
                }, null, this)
            }, Object.defineProperty(GameScene.prototype, "player", {
                get: function() {
                    return this._player
                }
            }), Object.defineProperty(GameScene.prototype, "isTutorial", {
                get: function() {
                    return this._isTutorial
                }
            })
        }, {
            "./AI": 1,
            "./AchievementTypes": 4,
            "./AudioParams": 9,
            "./BernoulliView": 11,
            "./BoostView": 12,
            "./Car": 13,
            "./Common": 23,
            "./ControlTypes": 26,
            "./CountryTypes": 27,
            "./GorvetteView": 46,
            "./Hud": 48,
            "./LightningView": 52,
            "./Obstacle": 56,
            "./Pickup": 60,
            "./Player": 61,
            "./Powerup": 63,
            "./RaceEngine": 68,
            "./RaceTrack": 72,
            "./RaceView": 73,
            "./RoadEntity": 79,
            "./Scene": 83,
            "./SchnellView": 85,
            "./Skybox": 94,
            "./SplashOverlayEffect": 95,
            "./ThreatView": 99,
            "./TodorokiView": 100,
            "./TrackData": 101,
            "./TutorialBoost": 109,
            "./TutorialBrake": 110,
            "./TutorialHud": 111,
            "./TutorialPoint": 112,
            "./TutorialSteering": 114,
            "./VelosoView": 116
        }],
        37: [function(require, module, exports) {
            function Garage() {
                this.name = "", this.cash = 0, this.spentCash = 0, this.races = 0, this.codes = [], this.controls = ControlTypes.CONTROLS_EXPERT, this.tiltEnabled = !1, this.track = 0, this.series = -1, this.decalCount = 0, this.carTypes = [], this.carTypesSeries = [], this._selected = 0, this._cars = []
            }
            var AchievementTypes = require("./AchievementTypes"),
                CarSpine = (require("./Award"), require("./CarSpine")),
                Common = require("./Common"),
                ControlTypes = require("./ControlTypes"),
                CountryTypes = require("./CountryTypes"),
                RewardTypes = require("./RewardTypes");
            module.exports = Garage, Garage.avatar = null, Garage.prototype.registerCar = function(data) {
                this._cars.push(data)
            }, Garage.prototype.resetAll = function() {
                for (var car, i = 0; i < this._cars.length; ++i) car = this._cars[i], car.reset()
            }, Garage.prototype.save = function() {
                var data = {};
                data.selected = this._selected, data.cars = [], data.codes = this.codes.slice(0), data.decalCount = this.decalCount, data.carTypes = this.carTypes, data.carTypesSeries = this.carTypesSeries;
                for (var car, saveCar, j, i = 0; i < this._cars.length; ++i) {
                    for (car = this._cars[i], saveCar = {}, saveCar.model = car.model, saveCar.color = car.color, saveCar.engine = car.engine, saveCar.kit = car.kit, saveCar.decal = car.decal, saveCar.colors = [], j = 0; j < car.colors.length; ++j) saveCar.colors.push(car.colors[j].unlocked);
                    for (saveCar.engines = [], j = 0; j < car.engines.length; ++j) saveCar.engines.push({
                        speed: car.engines[j].speedLevel,
                        boost: car.engines[j].boostLevel
                    });
                    for (saveCar.kits = [], j = 0; j < car.kits.length; ++j) saveCar.kits.push({
                        kit: car.kits[j].kitLevel,
                        tyre: car.kits[j].tyreLevel,
                        unlocked: car.kits[j].unlocked
                    });
                    for (saveCar.decals = [], j = 0; j < car.decals.length; ++j) saveCar.decals.push(car.decals[j].unlocked);
                    data.cars.push(saveCar)
                }
                return data
            }, Garage.prototype.load = function(data) {
                this._selected = data.selected, this.codes = data.codes, this.decalCount = data.decalCount, this.carTypes = data.carTypes, this.carTypesSeries = data.carTypesSeries;
                for (var car, saveCar, j, i = 0; i < data.cars.length; ++i) {
                    saveCar = data.cars[i], car = this._cars[i], car.color = saveCar.color, car.speed = saveCar.speed, car.boost = saveCar.boost, car.kit = saveCar.kit, car.decal = saveCar.decal;
                    var engine, saveEngine, kit, saveKit;
                    for (j = 0; j < saveCar.colors.length; ++j) car.colors[j].unlocked = saveCar.colors[j];
                    for (j = 0; j < saveCar.engines.length; ++j) engine = car.engines[j], saveEngine = saveCar.engines[j], engine.speedLevel = saveEngine.speed, engine.boostLevel = saveEngine.boost;
                    for (j = 0; j < saveCar.kits.length; ++j) kit = car.kits[j], saveKit = saveCar.kits[j], kit.kitLevel = saveKit.kit, kit.tyreLevel = saveKit.tyre, kit.unlocked = saveKit.unlocked;
                    for (j = 0; j < saveCar.decals.length; ++j) car.decals[j].unlocked = saveCar.decals[j]
                }
            }, Garage.prototype.createNewPlayer = function(name) {
                this.name = name, this.cash = 100, this.races = 0, this.resetAll(), Common.saveData.save(), console.log("CREATED NEW PLAYER '" + name + "'")
            }, Garage.prototype.changeName = function(name) {
                this.name = name, Common.saveData.save(), console.log("CHANGED NAME '" + name + "'")
            }, Garage.prototype.spendCash = function(value) {
                return value <= this.cash ? (this.cash -= value, this.spentCash += value, Common.audio.playSound("sfx_coins_burstout_03"), this.spentCash > 2e3 && Common.achievements.award(AchievementTypes.SPEND_X_COINS), Common.saveData.save(), !0) : !1
            }, Garage.prototype.giveCash = function(value) {
                value = Math.abs(value), this.cash += value, this.cash >= 1e3 && Common.achievements.award(AchievementTypes.EARN_X_COINS), Common.saveData.save()
            }, Garage.prototype.canAfford = function(value) {
                return value <= this.cash
            }, Garage.prototype.redeemCode = function(code) {
                var codes = Common.config.codes;
                if (-1 == this.codes.indexOf(code))
                    for (var c, i = 0; i < codes.length; ++i)
                        if (c = codes[i], c.code === code) {
                            switch (this.codes.push(code), c.reward) {
                                case RewardTypes.CASH:
                                    this.giveCash(c.value)
                            }
                            return Common.saveData.save(), c
                        }
                return {
                    error: -1 == this.codes.indexOf(code) ? 0 : 1
                }
            }, Garage.prototype.isOptimalKit = function() {
                var country = Common.trackManager.currentTrack.country,
                    kit = this.myCar.kit;
                return country == CountryTypes.USA && 0 == kit || country == CountryTypes.ITALY && 1 == kit || country == CountryTypes.GERMANY && 2 == kit || country == CountryTypes.JAPAN && 3 == kit || country == CountryTypes.BRAZIL && 4 == kit
            }, Garage.prototype.saveLicensePlate = function(name) {
                var container = new PIXI.Container,
                    license = new PIXI.Sprite(Common.assets.getTexture("ui_aaa_plate"));
                license.x = .5 * license.width, license.y = .5 * license.height, license.anchor = new PIXI.Point(.5, .5), license.scale = new PIXI.Point(.4, .4), container.addChild(license);
                var brand = new PIXI.Sprite(Common.assets.getTexture("ui_aaa_plate_rs"));
                brand.anchor = new PIXI.Point(.5, .5), license.addChild(brand), name = name.toLowerCase();
                for (var character, char, count = 3, i = 0; count > i; ++i) char = name.charAt(i), webfont ? (character = new PIXI.Text(char.toUpperCase(), {
                    font: "140px Arial",
                    fill: "#000000",
                    align: "center"
                }), character.x = 140 * i - .5 * character.width - 140 * (count - 1) * .5, character.y = .5 * -character.height + 20, license.addChild(character)) : (character = new PIXI.extras.BitmapText(char.toUpperCase(), {
                    font: "140px Great Escape Plate XL",
                    align: "center"
                }), character.x = 140 * i - .5 * character.textWidth - 140 * (count - 1) * .5, character.y = .5 * -character.textHeight + 20, license.addChild(character));
                return container.generateTexture(Common.renderer, 1, PIXI.SCALE_MODES.DEFAULT)
            }, Garage.prototype.savePhoto = function() {
                var width = 1024,
                    height = 768,
                    garage = Common.garage,
                    car = garage.myCar,
                    color = car.colors[car.color],
                    name = "car_" + p3.Utils.padNumber(car.id, 2) + "_garage",
                    animation = new PIXI.Container;
                animation.x = .5 * width, animation.y = 518, animation.scale = new PIXI.Point(.5, .5), animation.spine = new CarSpine(Common.assets.getSpineData(name)), animation.spine.id = car.id, animation.spine.skeleton.setToSetupPose(), animation.spine.autoUpdate = !1, animation.addChild(animation.spine), animation.spine.paintColor = color.color, animation.spine.decalTheme = garage.myCar.decal, animation.spine.kitTheme = garage.myCar.kit, animation.spine.update(0);
                var photo = new PIXI.Container;
                photo.addChild(animation);
                var brand = new PIXI.Sprite(Common.assets.getTexture("ui_splash_cars_logo"));
                brand.x = .5 * width - 220, brand.y = .5 * height - 126, brand.scale = new PIXI.Point(.4, .4), brand.anchor = new PIXI.Point(.5, .5), photo.addChild(brand);
                var texture = this.saveLicensePlate(this.name),
                    license = new PIXI.Sprite(texture);
                license.x = .5 * width + 220, license.y = .5 * height - 136, license.scale = new PIXI.Point(.8, .8), license.anchor = new PIXI.Point(.5, .5), photo.addChild(license);
                var bg = new PIXI.Sprite(Common.assets.getTexture("ui_bg_garage"));
                bg.scale = new PIXI.Point(2, 2), bg.x = .5 * (width - bg.width), photo.addChildAt(bg, 0);
                var renderTexture = new PIXI.RenderTexture(Common.renderer, width, height);
                return renderTexture.render(photo), renderTexture
            }, Garage.prototype.saveAvatar = function() {
                var width = 1024,
                    height = 768,
                    garage = Common.garage,
                    car = garage.myCar,
                    color = car.colors[car.color],
                    name = "car_" + p3.Utils.padNumber(car.id, 2) + "_garage",
                    animation = new PIXI.Container;
                animation.x = .5 * width, animation.y = 518, animation.scale = new PIXI.Point(.5, .5), animation.spine = new CarSpine(Common.assets.getSpineData(name)), animation.spine.id = car.id, animation.spine.skeleton.setToSetupPose(), animation.spine.autoUpdate = !1, animation.addChild(animation.spine), animation.spine.paintColor = color.color, animation.spine.decalTheme = garage.myCar.decal, animation.spine.kitTheme = garage.myCar.kit, animation.spine.update(0);
                var avatar = new PIXI.Container;
                avatar.addChild(animation);
                var renderTexture = new PIXI.RenderTexture(Common.renderer, width, height);
                return renderTexture.render(avatar), renderTexture
            }, Garage.prototype.formatTime = function(ms) {
                ms = parseInt(ms, 10);
                var minutes = Math.floor(ms / 6e4),
                    seconds = Math.floor((ms - 6e4 * minutes) / 1e3),
                    milliseconds = ms - 6e4 * minutes - 1e3 * seconds;
                return 10 > minutes && (minutes = "0" + minutes), 10 > seconds && (seconds = "0" + seconds), 10 > milliseconds && (milliseconds = "0" + milliseconds), minutes + ":" + seconds + ":" + milliseconds
            }, Object.defineProperty(Garage.prototype, "cars", {
                get: function() {
                    return this._cars.slice(0)
                }
            }), Object.defineProperty(Garage.prototype, "myCar", {
                get: function() {
                    return this._cars[this._selected]
                }
            }), Object.defineProperty(Garage.prototype, "selected", {
                get: function() {
                    return this._selected
                },
                set: function(value) {
                    this._selected = Math.max(0, Math.min(this._cars.length - 1, value))
                }
            }), Object.defineProperty(Garage.prototype, "isFirstRace", {
                get: function() {
                    return 0 == this.races
                }
            })
        }, {
            "./AchievementTypes": 4,
            "./Award": 10,
            "./CarSpine": 20,
            "./Common": 23,
            "./ControlTypes": 26,
            "./CountryTypes": 27,
            "./RewardTypes": 78
        }],
        38: [function(require, module, exports) {
            function GarageColorScene() {
                GarageScene.call(this), this.type = GarageTypes.COLOR, this.signals.purchase = new signals.Signal, this._colorIndex = 0, this._cost = null, this._nextButton = null, this._prevButton = null, this._purchaseButton = null, this._carrousel = null
            }
            var AchievementTypes = require("./AchievementTypes"),
                Common = require("./Common"),
                GarageScene = require("./GarageScene"),
                GarageTypes = require("./GarageTypes"),
                ImageCarrousel = require("./ImageCarrousel"),
                MessagePopup = require("./MessagePopup");
            require("./Scene");
            module.exports = GarageColorScene, GarageColorScene.prototype = Object.create(GarageScene.prototype), GarageColorScene.prototype.constructor = GarageColorScene, GarageColorScene.prototype.init = function() {
                GarageScene.prototype.init.call(this), webfont ? (this._titleText.text = Common.copy.garage_colors[Common.language], this._titleText.x = .5 * (Common.STAGE_WIDTH - this._titleText.width)) : (this._titleText.text = Common.copy.garage_colors[Common.language], this._titleText.validate(), this._titleText.x = .5 * (Common.STAGE_WIDTH - this._titleText.textWidth)), this._colorIndex = Common.garage.myCar.color;
                var that = this;
                this._car.animation.interactive = !0, this._car.animation.buttonMode = !0, this._car.animation.click = this._car.animation.tap = function() {
                    that.onNextButtonClick.call(that), Common.audio.playSound("sfx_ui_btn_press_00")
                }, this._nextButton = new p3.Button(Common.assets.getTexture("ui_btn_arrow_up"), Common.assets.getTexture("ui_btn_arrow_over"), Common.assets.getTexture("ui_btn_arrow_down")), this._nextButton.y = .5 * Common.STAGE_HEIGHT, this._nextButton.scale.x = this._nextButton.defaultScale.x = -1, this._nextButton.animate = !0, this._nextButton.overSoundName = "sfx_ui_btn_rollover_00", this._nextButton.downSoundName = "sfx_ui_btn_press_00", this._nextButton.clickSoundName = "sfx_ui_btn_nextcolour_01", this._nextButton.signals.click.add(r2l ? this.onPrevButtonClick : this.onNextButtonClick, this), this.addChild(this._nextButton), this._prevButton = new p3.Button(Common.assets.getTexture("ui_btn_arrow_up"), Common.assets.getTexture("ui_btn_arrow_over"), Common.assets.getTexture("ui_btn_arrow_down")), this._prevButton.y = .5 * Common.STAGE_HEIGHT, this._prevButton.animate = !0, this._prevButton.overSoundName = "sfx_ui_btn_rollover_00", this._prevButton.downSoundName = "sfx_ui_btn_press_00", this._prevButton.clickSoundName = "sfx_ui_btn_nextcolour_01", this._prevButton.signals.click.add(r2l ? this.onNextButtonClick : this.onPrevButtonClick, this), this.addChild(this._prevButton), this._purchaseButton = new p3.Button(Common.assets.getTexture("ui_btn_upgrade_up"), Common.assets.getTexture("ui_btn_upgrade_over"), Common.assets.getTexture("ui_btn_upgrade_down"), Common.assets.getTexture("ui_icon_tick"), Common.assets.getTexture("ui_btn_upgrade_inactive_up"), Common.assets.getTexture("ui_btn_upgrade_inactive_over"), Common.assets.getTexture("ui_btn_upgrade_inactive_over")), this._purchaseButton.y = .5 * Common.STAGE_HEIGHT + 260, this._purchaseButton.animate = !0, this._purchaseButton.overSoundName = "sfx_ui_btn_rollover_00", this._purchaseButton.downSoundName = "sfx_ui_btn_press_00", this._purchaseButton.clickSoundName = "sfx_ui_btn_colourconfirm_00", this._purchaseButton.signals.click.add(this.onPurchaseButtonClick, this), this.addChild(this._purchaseButton), this._cost = new PIXI.Sprite(Common.assets.getTexture("ui_cost_bg")), this._cost.anchor = new PIXI.Point(.5, .5), this.addChildAt(this._cost, this._purchaseButton.parent.getChildIndex(this._purchaseButton) - 1), this._cost.icon = new PIXI.Sprite(Common.assets.getTexture("ui_icon_coin")), this._cost.icon.x = -100, this._cost.icon.anchor = new PIXI.Point(.5, .5), this._cost.addChild(this._cost.icon), webfont ? (this._cost.text = new PIXI.Text("", {
                    font: "42px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._cost.addChild(this._cost.text)) : (this._cost.text = new PIXI.extras.BitmapText("", {
                    font: "42px Great Escape",
                    align: "center"
                }), this._cost.addChild(this._cost.text));
                var container = new PIXI.Container;
                container.interactiveChildren = !1, this.addChild(container);
                var config = Common.assets.getJSON("particle_garage_paint_swap");
                this._sprayEmitter = new cloudkid.Emitter(container, [Common.assets.getTexture("tyre_burn_rubber_00")], config), this._sprayEmitter.emit = !1, this._sprayEmitter.updateOwnerPos(.5 * Common.STAGE_WIDTH, .5 * Common.STAGE_HEIGHT), this._animator.add(this._sprayEmitter), this.updateCostText(), this.updatePurchaseButton()
            }, GarageColorScene.prototype.dispose = function() {
                this._message && (this._message.destroy(), this._message = null), GarageScene.prototype.dispose.call(this)
            }, GarageColorScene.prototype.appear = function() {
                this._message = new MessagePopup(1, MessagePopup.CHARACTER_MCQUEEN, Common.copy.garage_colors_helper[Common.language]), this._message.x = .5 * (Common.STAGE_WIDTH - p3.View.width) + 20, this._message.y = 154, this._message.animateIn(), this.addChild(this._message), this._carrousel = new ImageCarrousel([Common.assets.getTexture("ui_icon_colour_white"), Common.assets.getTexture("ui_icon_colour_red"), Common.assets.getTexture("ui_icon_colour_orange"), Common.assets.getTexture("ui_icon_colour_yellow"), Common.assets.getTexture("ui_icon_colour_limegreen"), Common.assets.getTexture("ui_icon_colour_darkgreen"), Common.assets.getTexture("ui_icon_colour_lightblue"), Common.assets.getTexture("ui_icon_colour_blue"), Common.assets.getTexture("ui_icon_colour_darkblue"), Common.assets.getTexture("ui_icon_colour_purple"), Common.assets.getTexture("ui_icon_colour_lightpink"), Common.assets.getTexture("ui_icon_colour_hotpink"), Common.assets.getTexture("ui_icon_colour_barrelgrey"), Common.assets.getTexture("ui_icon_colour_black"), Common.assets.getTexture("ui_icon_colour_lightgrey")], this._colorIndex), this._carrousel.x = .5 * Common.STAGE_WIDTH - 260, this._carrousel.y = 400, this._carrousel.animateIn(), this.addChildAt(this._carrousel, this._car.parent.getChildIndex(this._car)), this.animateIn()
            }, GarageColorScene.prototype.show = function() {
                this.updateCashText(), this.updateLicensePlate()
            }, GarageColorScene.prototype.animateIn = function(callback, scope) {
                var animation;
                animation = new TimelineMax({
                    repeat: -1,
                    yoyo: !0
                }), animation.append(TweenMax.to(this._nextButton.scale, .6, {
                    x: -1.14,
                    y: 1.14,
                    ease: Power1.easeInOut
                })), animation = new TimelineMax({
                    repeat: -1,
                    yoyo: !0
                }), animation.append(TweenMax.to(this._prevButton.scale, .6, {
                    x: 1.14,
                    y: 1.14,
                    ease: Power1.easeInOut
                }))
            }, GarageColorScene.prototype.animateOut = function(callback, scope) {}, GarageColorScene.prototype.resize = function() {
                GarageScene.prototype.resize.call(this), this._nextButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width - Math.abs(this._nextButton.width)) - 28, this._prevButton.x = .5 * (Common.STAGE_WIDTH - p3.View.width + Math.abs(this._prevButton.width)) + 28, this._purchaseButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width) - 120, this._cost.x = this._purchaseButton.x - 140, this._cost.y = this._purchaseButton.y
            }, GarageColorScene.prototype.updateCostText = function() {
                var color = Common.garage.myCar.colors[this._colorIndex],
                    cost = color.cost,
                    unlocked = color.unlocked;
                this._cost.visible = !unlocked, webfont ? (this._cost.text.text = unlocked ? Common.copy.garage_select[Common.language] : cost.toString(), this._cost.text.x = .5 * -this._cost.text.width, this._cost.text.y = .5 * -this._cost.text.height + 4, this._cost.text.tint = unlocked ? 16777215 : Common.garage.canAfford(cost) ? 16777215 : 16711680) : (this._cost.text.text = unlocked ? Common.copy.garage_select[Common.language] : cost.toString(), this._cost.text.validate(), this._cost.text.x = .5 * -this._cost.text.textWidth, this._cost.text.y = .5 * -this._cost.text.textHeight - 2, this._cost.text.tint = unlocked ? 16777215 : Common.garage.canAfford(cost) ? 16777215 : 16711680)
            }, GarageColorScene.prototype.purchaseColor = function() {
                var color = Common.garage.myCar.colors[this._colorIndex],
                    cost = color.cost;
                Common.garage.spendCash(cost) && (color.unlocked = !0, Common.saveData.save(), this.updateCostText(), this.selectColor(!0), console.log("PURCHASED COLOR - " + color.name), Common.tracking.track(new p3.TrackingDataPlaydomGameAction("garage_car_" + (Common.garage.myCar.id + 1), "buy_colour_" + color.name.toLowerCase())))
            }, GarageColorScene.prototype.selectColor = function(purchase) {
                var isNewColor = Common.garage.myCar.color != this._colorIndex;
                Common.garage.myCar.color = this._colorIndex, Common.saveData.save(), this.signals.previous.dispatch(this, purchase), isNewColor && purchase && Common.achievements.award(AchievementTypes.CHANGE_CAR_COLOR)
            }, GarageColorScene.prototype.updatePurchaseButton = function() {
                var color = Common.garage.myCar.colors[this._colorIndex],
                    cost = color.cost,
                    unlocked = color.unlocked;
                this._purchaseButton.enabled = unlocked ? !0 : Common.garage.canAfford(cost)
            }, GarageColorScene.prototype.onNextButtonClick = function(button) {
                ++this._colorIndex >= Common.garage.myCar.colors.length && (this._colorIndex = 0);
                var color = Common.garage.myCar.colors[this._colorIndex];
                this._car.animation.spine.paintColor = color.color, this.updateCostText(), this.updatePurchaseButton();
                var rgb = p3.Color.hex2rgb(color.color);
                this._sprayEmitter.startColor = this._sprayEmitter.endColor = [rgb.r, rgb.g, rgb.b], this._sprayEmitter.emit = !0, this._carrousel.nextImage()
            }, GarageColorScene.prototype.onPrevButtonClick = function(button) {
                --this._colorIndex < 0 && (this._colorIndex = Common.garage.myCar.colors.length - 1);
                var color = Common.garage.myCar.colors[this._colorIndex];
                this._car.animation.spine.paintColor = color.color, this.updateCostText(), this.updatePurchaseButton();
                var rgb = p3.Color.hex2rgb(color.color);
                this._sprayEmitter.startColor = this._sprayEmitter.endColor = [rgb.r, rgb.g, rgb.b], this._sprayEmitter.emit = !0, this._carrousel.prevImage()
            }, GarageColorScene.prototype.onPurchaseButtonClick = function(button) {
                var color = Common.garage.myCar.colors[this._colorIndex];
                if (color.unlocked) this.selectColor(!1);
                else {
                    var title = Common.copy.color[Common.language] + " " + color.name;
                    this.signals.purchase.dispatch(this, title)
                }
            }
        }, {
            "./AchievementTypes": 4,
            "./Common": 23,
            "./GarageScene": 44,
            "./GarageTypes": 45,
            "./ImageCarrousel": 49,
            "./MessagePopup": 54,
            "./Scene": 83
        }],
        39: [function(require, module, exports) {
            function GarageDecalScene() {
                GarageScene.call(this), this.type = GarageTypes.DECALS, this._decalIndex = 0, this._cost = null, this._nextButton = null, this._prevButton = null, this._purchaseButton = null, this._carrousel = null
            }
            var AchievementTypes = require("./AchievementTypes"),
                Common = require("./Common"),
                GarageScene = require("./GarageScene"),
                GarageTypes = require("./GarageTypes"),
                ImageCarrousel = require("./ImageCarrousel"),
                MessagePopup = require("./MessagePopup");
            require("./Scene");
            module.exports = GarageDecalScene, GarageDecalScene.prototype = Object.create(GarageScene.prototype), GarageDecalScene.prototype.constructor = GarageDecalScene, GarageDecalScene.prototype.init = function() {
                GarageScene.prototype.init.call(this), webfont ? (this._titleText.text = Common.copy.garage_stickers[Common.language], this._titleText.x = .5 * (Common.STAGE_WIDTH - this._titleText.width)) : (this._titleText.text = Common.copy.garage_stickers[Common.language], this._titleText.validate(), this._titleText.x = .5 * (Common.STAGE_WIDTH - this._titleText.textWidth)), this._decalIndex = Common.garage.myCar.decal;
                var that = this;
                this._car.animation.interactive = !0, this._car.animation.buttonMode = !0, this._car.animation.click = this._car.animation.tap = function() {
                    that.onNextButtonClick.call(that), Common.audio.playSound("sfx_ui_btn_press_00")
                }, this._nextButton = new p3.Button(Common.assets.getTexture("ui_btn_arrow_up"), Common.assets.getTexture("ui_btn_arrow_over"), Common.assets.getTexture("ui_btn_arrow_down")), this._nextButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width - this._nextButton.width) - 28, this._nextButton.y = .5 * Common.STAGE_HEIGHT, this._nextButton.scale.x = this._nextButton.defaultScale.x = -1, this._nextButton.animate = !0, this._nextButton.overSoundName = "sfx_ui_btn_rollover_00", this._nextButton.downSoundName = "sfx_ui_btn_press_00", this._nextButton.signals.click.add(r2l ? this.onPrevButtonClick : this.onNextButtonClick, this), this.addChild(this._nextButton), this._prevButton = new p3.Button(Common.assets.getTexture("ui_btn_arrow_up"), Common.assets.getTexture("ui_btn_arrow_over"), Common.assets.getTexture("ui_btn_arrow_down")), this._prevButton.x = .5 * (Common.STAGE_WIDTH - p3.View.width + this._prevButton.width) + 28, this._prevButton.y = .5 * Common.STAGE_HEIGHT, this._prevButton.animate = !0, this._prevButton.overSoundName = "sfx_ui_btn_rollover_00", this._prevButton.downSoundName = "sfx_ui_btn_press_00", this._prevButton.signals.click.add(r2l ? this.onNextButtonClick : this.onPrevButtonClick, this), this.addChild(this._prevButton), this._purchaseButton = new p3.Button(Common.assets.getTexture("ui_btn_upgrade_up"), Common.assets.getTexture("ui_btn_upgrade_over"), Common.assets.getTexture("ui_btn_upgrade_down"), Common.assets.getTexture("ui_icon_tick"), Common.assets.getTexture("ui_btn_upgrade_inactive_up"), Common.assets.getTexture("ui_btn_upgrade_inactive_over"), Common.assets.getTexture("ui_btn_upgrade_inactive_over")), this._purchaseButton.y = .5 * Common.STAGE_HEIGHT + 260, this._purchaseButton.animate = !0, this._purchaseButton.overSoundName = "sfx_ui_btn_rollover_00", this._purchaseButton.downSoundName = "sfx_ui_btn_press_00", this._purchaseButton.clickSoundName = "sfx_ui_btn_play_00", this._purchaseButton.signals.click.add(this.onPurchaseButtonClick, this), this.addChild(this._purchaseButton), this._cost = new PIXI.Sprite(Common.assets.getTexture("ui_cost_bg")), this._cost.anchor = new PIXI.Point(.5, .5), this.addChildAt(this._cost, this._purchaseButton.parent.getChildIndex(this._purchaseButton) - 1), this._cost.icon = new PIXI.Sprite(Common.assets.getTexture("ui_icon_coin")), this._cost.icon.x = -100, this._cost.icon.anchor = new PIXI.Point(.5, .5), this._cost.addChild(this._cost.icon), webfont ? (this._cost.text = new PIXI.Text("", {
                    font: "42px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._cost.addChild(this._cost.text)) : (this._cost.text = new PIXI.extras.BitmapText("", {
                    font: "42px Great Escape",
                    align: "center"
                }), this._cost.addChild(this._cost.text));
                var sparkleEmitterContainer = new PIXI.Container;
                this.addChild(sparkleEmitterContainer);
                var config = Common.assets.getJSON("particle_garage_decal_swap");
                this._sparkleEmitter = new cloudkid.Emitter(sparkleEmitterContainer, [Common.assets.getTexture("particle_sparkle_00"), Common.assets.getTexture("particle_sparkle_01")], config), this._sparkleEmitter.emit = !1, this._sparkleEmitter.updateOwnerPos(.5 * Common.STAGE_WIDTH, .5 * Common.STAGE_HEIGHT), this._animator.add(this._sparkleEmitter), this.updateCostText(), this.updatePurchaseButton()
            }, GarageDecalScene.prototype.dispose = function() {
                this._message && (this._message.destroy(), this._message = null), GarageScene.prototype.dispose.call(this)
            }, GarageDecalScene.prototype.appear = function() {
                this._message = new MessagePopup(2, MessagePopup.CHARACTER_LUIGI, Common.copy.garage_stickers_helper[Common.language]), this._message.x = .5 * (Common.STAGE_WIDTH - p3.View.width) + 20, this._message.y = 154, this._message.animateIn(), this.addChild(this._message), this._carrousel = new ImageCarrousel(this.getCarrouselTextures(), this._decalIndex), this._carrousel.x = .5 * Common.STAGE_WIDTH - 260, this._carrousel.y = 400, this._carrousel.animateIn(), this.addChildAt(this._carrousel, this._car.parent.getChildIndex(this._car)), this.animateIn()
            }, GarageDecalScene.prototype.animateIn = function(callback, scope) {
                var animation;
                animation = new TimelineMax({
                    repeat: -1,
                    yoyo: !0
                }), animation.append(TweenMax.to(this._nextButton.scale, .6, {
                    x: -1.14,
                    y: 1.14,
                    ease: Power1.easeInOut
                })), animation = new TimelineMax({
                    repeat: -1,
                    yoyo: !0
                }), animation.append(TweenMax.to(this._prevButton.scale, .6, {
                    x: 1.14,
                    y: 1.14,
                    ease: Power1.easeInOut
                }))
            }, GarageDecalScene.prototype.animateOut = function(callback, scope) {}, GarageDecalScene.prototype.resize = function() {
                GarageScene.prototype.resize.call(this), this._purchaseButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width) - 120, this._cost.x = this._purchaseButton.x - 140, this._cost.y = this._purchaseButton.y
            }, GarageDecalScene.prototype.updateCostText = function() {
                var decal = Common.garage.myCar.decals[this._decalIndex],
                    cost = decal.cost,
                    unlocked = decal.unlocked;
                this._cost.visible = !unlocked, webfont ? (this._cost.text.text = unlocked ? Common.copy.garage_select[Common.language] : cost.toString(), this._cost.text.x = .5 * -this._cost.text.width, this._cost.text.y = .5 * -this._cost.text.height + 4, this._cost.text.tint = unlocked ? 16777215 : Common.garage.canAfford(cost) ? 16777215 : 16711680) : (this._cost.text.text = unlocked ? Common.copy.garage_select[Common.language] : cost.toString(), this._cost.text.validate(), this._cost.text.x = .5 * -this._cost.text.textWidth, this._cost.text.y = .5 * -this._cost.text.textHeight - 2, this._cost.text.tint = unlocked ? 16777215 : Common.garage.canAfford(cost) ? 16777215 : 16711680)
            }, GarageDecalScene.prototype.updatePurchaseButton = function() {
                var decal = Common.garage.myCar.decals[this._decalIndex],
                    cost = decal.cost,
                    unlocked = decal.unlocked;
                this._purchaseButton.enabled = unlocked ? !0 : Common.garage.canAfford(cost)
            }, GarageDecalScene.prototype.purchaseDecal = function() {
                var decal = Common.garage.myCar.decals[this._decalIndex],
                    cost = decal.cost;
                Common.garage.spendCash(cost) && (decal.unlocked = !0, Common.saveData.save(), this.updateCostText(), this.selectDecal(!0), console.log("PURCHASED DECAL - " + decal.name), Common.tracking.track(new p3.TrackingDataPlaydomGameAction("garage_car_" + (Common.garage.myCar.id + 1), "buy_decal_" + decal.name.toLowerCase())))
            }, GarageDecalScene.prototype.selectDecal = function(purchase) {
                var isNewDecal = Common.garage.myCar.decal != this._decalIndex;
                Common.garage.myCar.decal = this._decalIndex, Common.saveData.save(), this.signals.previous.dispatch(this, purchase), isNewDecal && purchase && (Common.achievements.award(AchievementTypes.APPLY_STICKER), ++Common.garage.decalCount, Common.garage.decalCount >= 5 && Common.achievements.award(AchievementTypes.APPLY_X_STICKERS), Common.saveData.save())
            }, GarageDecalScene.prototype.getCarrouselTextures = function() {
                var car = Common.garage.myCar;
                switch (car.id) {
                    case 0:
                        return [Common.assets.getTexture("ui_icon_colour_none"), Common.assets.getTexture("ui_icon_decal_max1"), Common.assets.getTexture("ui_icon_decal_max2"), Common.assets.getTexture("ui_icon_decal_max3"), Common.assets.getTexture("ui_icon_decal_max4"), Common.assets.getTexture("ui_icon_decal_max5")];
                    case 1:
                        return [Common.assets.getTexture("ui_icon_colour_none"), Common.assets.getTexture("ui_icon_decal_todd1"), Common.assets.getTexture("ui_icon_decal_todd2"), Common.assets.getTexture("ui_icon_decal_todd3"), Common.assets.getTexture("ui_icon_decal_todd4"), Common.assets.getTexture("ui_icon_decal_todd5")];
                    case 2:
                        return [Common.assets.getTexture("ui_icon_colour_none"), Common.assets.getTexture("ui_icon_decal_camino1"), Common.assets.getTexture("ui_icon_decal_camino2"), Common.assets.getTexture("ui_icon_decal_camino3"), Common.assets.getTexture("ui_icon_decal_camino4"), Common.assets.getTexture("ui_icon_decal_camino5")];
                    case 3:
                        return [Common.assets.getTexture("ui_icon_colour_none"), Common.assets.getTexture("ui_icon_decal_caroule1"), Common.assets.getTexture("ui_icon_decal_caroule2"), Common.assets.getTexture("ui_icon_decal_caroule3"), Common.assets.getTexture("ui_icon_decal_caroule4"), Common.assets.getTexture("ui_icon_decal_caroule5")];
                    case 4:
                        return [Common.assets.getTexture("ui_icon_colour_none"), Common.assets.getTexture("ui_icon_decal_comodo1"), Common.assets.getTexture("ui_icon_decal_comodo2"), Common.assets.getTexture("ui_icon_decal_comodo3"), Common.assets.getTexture("ui_icon_decal_comodo4"), Common.assets.getTexture("ui_icon_decal_comodo5")]
                }
                return []
            }, GarageDecalScene.prototype.onNextButtonClick = function(button) {
                ++this._decalIndex >= Common.garage.myCar.decals.length && (this._decalIndex = 0), this._car.animation.spine.decalTheme = this._decalIndex, this.updateCostText(), this.updatePurchaseButton(), this._sparkleEmitter.emit = !0, this._carrousel.nextImage()
            }, GarageDecalScene.prototype.onPrevButtonClick = function(button) {
                --this._decalIndex < 0 && (this._decalIndex = Common.garage.myCar.decals.length - 1), this._car.animation.spine.decalTheme = this._decalIndex, this.updateCostText(), this.updatePurchaseButton(), this._sparkleEmitter.emit = !0, this._carrousel.prevImage()
            }, GarageDecalScene.prototype.onPurchaseButtonClick = function(button) {
                var decal = Common.garage.myCar.decals[this._decalIndex];
                if (decal.unlocked) this.selectDecal(!1);
                else {
                    var title = Common.copy.decal[Common.language] + " " + decal.name;
                    this.signals.purchase.dispatch(this, title)
                }
            }
        }, {
            "./AchievementTypes": 4,
            "./Common": 23,
            "./GarageScene": 44,
            "./GarageTypes": 45,
            "./ImageCarrousel": 49,
            "./MessagePopup": 54,
            "./Scene": 83
        }],
        40: [function(require, module, exports) {
            function GarageEngineScene() {
                GarageScene.call(this), this.type = GarageTypes.ENGINE, this._animator = null, this._speed = null, this._speedMeter = null, this._speedAnimationRanges = [10, 50, 80, 110, 130, 160], this._boostAnimationRanges = [0, 2, 5, 8, 12, 15], this._boost = null, this._boostMeter = null, this._message = null
            }
            var Common = require("./Common"),
                GarageScene = require("./GarageScene"),
                GarageTypes = require("./GarageTypes"),
                MessagePopup = require("./MessagePopup");
            require("./Scene");
            module.exports = GarageEngineScene, GarageEngineScene.prototype = Object.create(GarageScene.prototype), GarageEngineScene.prototype.constructor = GarageEngineScene, GarageEngineScene.prototype.init = function() {
                GarageScene.prototype.init.call(this), webfont ? (this._titleText.text = Common.copy.garage_engines[Common.language], this._titleText.x = .5 * (Common.STAGE_WIDTH - this._titleText.width)) : (this._titleText.text = Common.copy.garage_engines[Common.language], this._titleText.validate(), this._titleText.x = .5 * (Common.STAGE_WIDTH - this._titleText.textWidth)), this._animator = new p3.Animator, this._speed = new PIXI.Sprite(Common.assets.getTexture("ui_cost_bg_small")), this._speed.x = .5 * Common.STAGE_WIDTH - 300, this._speed.y = .5 * Common.STAGE_HEIGHT + 280, this._speed.anchor = new PIXI.Point(.5, .5), this.addChild(this._speed), this._speed.bar = new PIXI.Sprite(Common.assets.getTexture("ui_cost_bar_small")), this._speed.bar.x = .5 * -this._speed.bar.width, this._speed.bar.y = 0, this._speed.bar.anchor = new PIXI.Point(0, .5), this._speed.addChild(this._speed.bar), this._speed.costText = new PIXI.extras.BitmapText("", {
                        font: "42px Great Escape",
                        align: "right"
                    }), this._speed.addChild(this._speed.costText), this._speed.icon = new PIXI.Sprite(Common.assets.getTexture("ui_icon_coin")), this._speed.icon.x = -94, this._speed.icon.y = -2, this._speed.icon.scale = new PIXI.Point(.8, .8), this._speed.icon.anchor = new PIXI.Point(.5, .5), this._speed.addChild(this._speed.icon), this._speed.button = new p3.Button(Common.assets.getTexture("ui_btn_upgrade_up"), Common.assets.getTexture("ui_btn_upgrade_over"), Common.assets.getTexture("ui_btn_upgrade_down"), Common.assets.getTexture("ui_icon_plus"), Common.assets.getTexture("ui_btn_upgrade_inactive_up"), Common.assets.getTexture("ui_btn_upgrade_inactive_over"), Common.assets.getTexture("ui_btn_upgrade_inactive_over")), this._speed.button.id = 0, this._speed.button.x = 134, this._speed.button.scale.x = this._speed.button.defaultScale.x = .8, this._speed.button.scale.y = this._speed.button.defaultScale.y = .8, this._speed.button.animate = !0, this._speed.button.overSoundName = "sfx_ui_btn_rollover_00", this._speed.button.downSoundName = "sfx_ui_btn_press_00", this._speed.button.signals.click.add(this.onUpgradeButtonClick, this), this._speed.addChild(this._speed.button), this._boost = new PIXI.Sprite(Common.assets.getTexture("ui_cost_bg_small")), this._boost.x = .5 * Common.STAGE_WIDTH + 66,
                    this._boost.y = .5 * Common.STAGE_HEIGHT + 280, this._boost.anchor = new PIXI.Point(.5, .5), this.addChild(this._boost), this._boost.bar = new PIXI.Sprite(Common.assets.getTexture("ui_cost_bar_small")), this._boost.bar.x = .5 * -this._boost.bar.width, this._boost.bar.y = 0, this._boost.bar.anchor = new PIXI.Point(0, .5), this._boost.addChild(this._boost.bar), this._boost.costText = new PIXI.extras.BitmapText("", {
                        font: "42px Great Escape",
                        align: "right"
                    }), this._boost.addChild(this._boost.costText), this._boost.icon = new PIXI.Sprite(Common.assets.getTexture("ui_icon_coin")), this._boost.icon.x = -94, this._boost.icon.y = -2, this._boost.icon.scale = new PIXI.Point(.8, .8), this._boost.icon.anchor = new PIXI.Point(.5, .5), this._boost.addChild(this._boost.icon), this._boost.button = new p3.Button(Common.assets.getTexture("ui_btn_upgrade_up"), Common.assets.getTexture("ui_btn_upgrade_over"), Common.assets.getTexture("ui_btn_upgrade_down"), Common.assets.getTexture("ui_icon_plus"), Common.assets.getTexture("ui_btn_upgrade_inactive_up"), Common.assets.getTexture("ui_btn_upgrade_inactive_over"), Common.assets.getTexture("ui_btn_upgrade_inactive_over")), this._boost.button.id = 1, this._boost.button.x = 134, this._boost.button.scale.x = this._boost.button.defaultScale.x = .8, this._boost.button.scale.y = this._boost.button.defaultScale.y = .8, this._boost.button.animate = !0, this._boost.button.overSoundName = "sfx_ui_btn_rollover_00", this._boost.button.downSoundName = "sfx_ui_btn_press_00", this._boost.button.signals.click.add(this.onUpgradeButtonClick, this), this._boost.addChild(this._boost.button), this._speedMeter = new PIXI.Sprite(Common.assets.getTexture("ui_icon_engine_bg")), this._speedMeter.x = this._speed.x + 24, this._speedMeter.y = this._speed.y - this._speedMeter.texture.height + 14, this._speedMeter.anchor = new PIXI.Point(.5, .5), this.addChildAt(this._speedMeter, this._speed.parent.getChildIndex(this._speed)), this._speedMeter.dial = new PIXI.Sprite(Common.assets.getTexture("ui_icon_engine_mg")), this._speedMeter.dial.x = 0, this._speedMeter.dial.y = 54, this._speedMeter.dial.anchor = new PIXI.Point(.5, 1), this._speedMeter.addChild(this._speedMeter.dial), this._speedMeter.front = new PIXI.Sprite(Common.assets.getTexture("ui_icon_engine_fg")), this._speedMeter.front.x = 0, this._speedMeter.front.y = 0, this._speedMeter.front.anchor = new PIXI.Point(.5, .5), this._speedMeter.addChild(this._speedMeter.front);
                var config = Common.assets.getJSON("particle_upgrade_speed_burst");
                this._speedMeter.emitter = new cloudkid.Emitter(this._speedMeter, [Common.assets.getTexture("tyre_burn_rubber_00")], config), this._speedMeter.emitter.emit = !1, this._speedMeter.emitter.updateOwnerPos(0, 60), this._animator.add(this._speedMeter.emitter), this._boostMeter = new PIXI.Sprite(Common.assets.getTexture("ui_icon_boost_bg")), this._boostMeter.x = this._boost.x + 24, this._boostMeter.y = this._boost.y - this._boostMeter.texture.height + 14, this._boostMeter.anchor = new PIXI.Point(.5, .5), this._boostMeter.bars = [], this.addChildAt(this._boostMeter, this._boost.parent.getChildIndex(this._boost)), this._boostMeter.value = 0, this._boostMeter.onTexture = Common.assets.getTexture("ui_boost_unit_on"), this._boostMeter.offTexture = Common.assets.getTexture("ui_boost_unit_off");
                for (var block, angle, i = 0; 15 > i; ++i) angle = (193 + 11 * i) * PIXI.DEG_TO_RAD, block = new PIXI.Sprite(this._boostMeter.barOffTexture), block.x = 80 * Math.cos(angle), block.y = 56 + 80 * Math.sin(angle), block.rotation = angle + .5 * Math.PI, block.scale = new PIXI.Point(.8, .8), block.anchor = new PIXI.Point(.5, .5), this._boostMeter.addChild(block), this._boostMeter.bars.push(block);
                config = Common.assets.getJSON("particle_upgrade_turbo_burst"), this._boostMeter.emitter = new cloudkid.Emitter(this._boostMeter, [Common.assets.getTexture("tyre_burn_rubber_00")], config), this._boostMeter.emitter.emit = !1, this._boostMeter.emitter.updateOwnerPos(0, 60), this._animator.add(this._boostMeter.emitter), this._acceptButton = new p3.Button(Common.assets.getTexture("ui_btn_confirm_up"), Common.assets.getTexture("ui_btn_confirm_over"), Common.assets.getTexture("ui_btn_confirm_down"), Common.assets.getTexture("ui_icon_tick")), this._acceptButton.y = .5 * Common.STAGE_HEIGHT + 260, this._acceptButton.animate = !0, this._acceptButton.overSoundName = "sfx_ui_btn_rollover_00", this._acceptButton.downSoundName = "sfx_ui_btn_press_00", this._acceptButton.clickSoundName = "sfx_ui_btn_kitconfirm_00", this._acceptButton.signals.click.add(this.onAcceptButtonClick, this), this.addChild(this._acceptButton), this.updateSpeedText(), this.updateBoostText(), this.updateSpeedButton(), this.updateBoostButton(), this.updateSpeedBar(), this.updateBoostBar()
            }, GarageEngineScene.prototype.dispose = function() {
                this._animator.removeAll(), this._message && (this._message.destroy(), this._message = null), GarageScene.prototype.dispose.call(this)
            }, GarageEngineScene.prototype.appear = function() {
                this.animateIn(), this._message = new MessagePopup(3, MessagePopup.CHARACTER_MATER, Common.copy.garage_engines_helper[Common.language]), this._message.x = .5 * (Common.STAGE_WIDTH - p3.View.width) + 20, this._message.y = 154, this._message.animateIn(), this.addChild(this._message), this.animateSpeedMeter(!0), this.animateTurboMeter(!0)
            }, GarageEngineScene.prototype.animateIn = function(callback, scope) {}, GarageEngineScene.prototype.animateOut = function(callback, scope) {}, GarageEngineScene.prototype.resize = function() {
                GarageScene.prototype.resize.call(this), this._acceptButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width) - 120
            }, GarageEngineScene.prototype.update = function() {
                GarageScene.prototype.update.call(this), this._animator.update()
            }, GarageEngineScene.prototype.upgradeSpeed = function() {
                var engine = Common.garage.myCar.engines[0],
                    speed = engine.speedLevel + 1,
                    cost = engine.getSpeedCost(speed);
                Common.garage.spendCash(cost) && (++engine.speedLevel, Common.saveData.save(), this.animateCoins(), this.updateSpeedText(), this.updateSpeedButton(), this.updateSpeedBar(), this.updateBoostText(), this.updateBoostButton(), this.updateBoostBar(), this.animateSpeedMeter(), this.playEngineAnimation(), Common.audio.playSound("sfx_ui_btn_nexttyres_00"), Common.tracking.track(new p3.TrackingDataPlaydomGameAction("garage_car_" + (Common.garage.myCar.id + 1), "buy_speed_" + engine.speedLevel)))
            }, GarageEngineScene.prototype.upgradeBoost = function() {
                var engine = Common.garage.myCar.engines[0],
                    boost = engine.boostLevel + 1,
                    cost = engine.getBoostCost(boost);
                Common.garage.spendCash(cost) && (++engine.boostLevel, Common.saveData.save(), this.animateCoins(), this.updateBoostText(), this.updateBoostButton(), this.updateBoostBar(), this.updateSpeedText(), this.updateSpeedButton(), this.updateSpeedBar(), this.animateTurboMeter(), this.playEngineAnimation(), Common.audio.playSound("sfx_ui_btn_nextboost_03"), Common.tracking.track(new p3.TrackingDataPlaydomGameAction("garage_car_" + (Common.garage.myCar.id + 1), "buy_boost_" + engine.speedLevel)))
            }, GarageEngineScene.prototype.updateSpeedText = function() {
                var engine = Common.garage.myCar.engines[0],
                    speed = engine.speedLevel + 1,
                    cost = engine.isSpeedMaxed ? "" : engine.getSpeedCost(speed);
                this._speed.costText.text = cost.toString(), this._speed.costText.validate(), this._speed.costText.x = .5 * -this._speed.costText.textWidth + 4, this._speed.costText.y = .5 * -this._speed.costText.textHeight - 2, this._speed.costText.tint = Common.garage.canAfford(cost) ? 16777215 : 16711680
            }, GarageEngineScene.prototype.updateBoostText = function() {
                var engine = Common.garage.myCar.engines[0],
                    boost = engine.boostLevel + 1,
                    cost = engine.isBoostMaxed ? "" : engine.getBoostCost(boost);
                this._boost.costText.text = cost.toString(), this._boost.costText.validate(), this._boost.costText.x = .5 * -this._boost.costText.textWidth + 4, this._boost.costText.y = .5 * -this._boost.costText.textHeight - 2, this._boost.costText.tint = Common.garage.canAfford(cost) ? 16777215 : 16711680
            }, GarageEngineScene.prototype.updateSpeedButton = function() {
                var engine = Common.garage.myCar.engines[0],
                    speed = engine.speedLevel + 1;
                if (engine.isSpeedMaxed) this._speed.button.enabled = !1, this._speed.costText.visible = !1;
                else {
                    var cost = engine.getSpeedCost(speed);
                    this._speed.button.enabled = Common.garage.canAfford(cost), this._speed.costText.visible = !0
                }
            }, GarageEngineScene.prototype.updateBoostButton = function() {
                var engine = Common.garage.myCar.engines[0],
                    boost = engine.boostLevel + 1;
                if (engine.isBoostMaxed) this._boost.button.enabled = !1, this._boost.costText.visible = !1;
                else {
                    var cost = engine.getBoostCost(boost);
                    this._boost.button.enabled = Common.garage.canAfford(cost), this._boost.costText.visible = !0
                }
            }, GarageEngineScene.prototype.updateSpeedBar = function() {
                var engine = Common.garage.myCar.engines[0],
                    speed = engine.speedLevel;
                this._speed.bar.scale.x = speed / (engine.speedData.length - 1)
            }, GarageEngineScene.prototype.updateBoostBar = function() {
                var engine = Common.garage.myCar.engines[0],
                    boost = engine.boostLevel;
                this._boost.bar.scale.x = boost / (engine.speedData.length - 1)
            }, GarageEngineScene.prototype.animateSpeedMeter = function(reset) {
                var engine = Common.garage.myCar.engines[0],
                    speed = engine.speedLevel,
                    range = this._speedAnimationRanges[speed],
                    offset = -90;
                reset && (this._speedMeter.dial.rotation = (10 + offset) * PIXI.DEG_TO_RAD);
                var timeline = new TimelineMax;
                timeline.append(TweenMax.to(this._speedMeter.dial, .2, {
                    rotation: 90 * PIXI.DEG_TO_RAD,
                    ease: Power2.easeOut
                })), timeline.append(TweenMax.to(this._speedMeter.dial, .8, {
                    rotation: (range + offset) * PIXI.DEG_TO_RAD,
                    ease: Power1.easeOut
                })), !reset && (this._speedMeter.emitter.emit = !0)
            }, GarageEngineScene.prototype.animateTurboMeter = function(reset) {
                function updateBars() {
                    for (var i = 0; i < this._boostMeter.bars.length; ++i) bar = this._boostMeter.bars[i], bar.texture = i < Math.round(this._boostMeter.value) ? this._boostMeter.onTexture : this._boostMeter.offTexture
                }
                var i, engine = Common.garage.myCar.engines[0],
                    speed = engine.boostLevel,
                    range = this._boostAnimationRanges[speed];
                if (reset) {
                    var bar;
                    for (i = 0; i < this._boostMeter.bars.length; ++i) bar = this._boostMeter.bars[i], bar.texture = this._boostMeter.offTexture;
                    this._boostMeter.value = 0
                }
                var timeline = new TimelineMax({
                    onStart: updateBars,
                    onStartScope: this,
                    onUpdate: updateBars,
                    onUpdateScope: this
                });
                timeline.append(TweenMax.to(this._boostMeter, .2, {
                    value: this._boostMeter.bars.length,
                    ease: Power2.easeOut
                })), timeline.append(TweenMax.to(this._boostMeter, .8, {
                    value: range,
                    ease: Power1.easeOut
                })), !reset && (this._boostMeter.emitter.emit = !0)
            }, GarageEngineScene.prototype.onUpgradeButtonClick = function(button) {
                var engine, title;
                switch (button.id) {
                    case 0:
                        engine = Common.garage.myCar.engines[0], title = Common.copy.engine_speed_upgrade[Common.language] + " " + (engine.speedLevel + 1);
                        break;
                    case 1:
                        engine = Common.garage.myCar.engines[0], title = Common.copy.engine_boost_upgrade[Common.language] + " " + (engine.boostLevel + 1)
                }
                this.signals.purchase.dispatch(this, title, button.id)
            }, GarageEngineScene.prototype.onAcceptButtonClick = function(button) {
                this.signals.previous.dispatch()
            }
        }, {
            "./Common": 23,
            "./GarageScene": 44,
            "./GarageTypes": 45,
            "./MessagePopup": 54,
            "./Scene": 83
        }],
        41: [function(require, module, exports) {
            function GarageKitScene() {
                GarageScene.call(this), this.type = GarageTypes.KIT, this._kitIndex = 0, this._kitPanel = null, this._kitImage = null, this._cost = null, this._nextButton = null, this._prevButton = null, this._purchaseButton = null, this._kit = null, this._kitIcon = null, this._tyre = null, this._tyreIcon = null, this._message = null, this._trackingContext = "garage"
            }
            var Common = require("./Common"),
                GarageScene = require("./GarageScene"),
                GarageTypes = require("./GarageTypes"),
                MessagePopup = require("./MessagePopup");
            require("./Scene");
            module.exports = GarageKitScene, GarageKitScene.prototype = Object.create(GarageScene.prototype), GarageKitScene.prototype.constructor = GarageKitScene, GarageKitScene.prototype.init = function() {
                GarageScene.prototype.init.call(this), this._kitIndex = Math.max(0, Common.garage.myCar.kit);
                var kit = Common.garage.myCar.kits[this._kitIndex].name;
                webfont ? (this._titleText.text = Common.copy.garage_kits[Common.language], this._titleText.x = .5 * (Common.STAGE_WIDTH - this._titleText.width)) : (this._titleText.text = Common.copy.garage_kits[Common.language], this._titleText.validate(), this._titleText.x = .5 * (Common.STAGE_WIDTH - this._titleText.textWidth));
                var that = this;
                this._car.animation.interactive = !0, this._car.animation.buttonMode = !0, this._car.animation.click = this._car.animation.tap = function() {
                    that.onNextButtonClick.call(that)
                };
                var texture = this.getKitPanelTexture();
                this._kitPanel = new PIXI.Sprite(texture), this._kitPanel.x = .5 * Common.STAGE_WIDTH - 8, this._kitPanel.y = .5 * Common.STAGE_HEIGHT - 140, this._kitPanel.anchor = new PIXI.Point(.5, .5), this.addChild(this._kitPanel), webfont ? (this._kitPanel.text = new PIXI.Text(kit, {
                    font: "32px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._kitPanel.text.x = .5 * -this._kitPanel.text.width, this._kitPanel.text.y = .5 * -this._kitPanel.text.height - 8, this._kitPanel.addChild(this._kitPanel.text)) : (this._kitPanel.text = new PIXI.extras.BitmapText(kit, {
                    font: "32px Great Escape",
                    align: "center"
                }), this._kitPanel.text.x = .5 * -this._kitPanel.text.textWidth, this._kitPanel.text.y = .5 * -this._kitPanel.text.textHeight - 12, this._kitPanel.addChild(this._kitPanel.text)), texture = this.getKitImageTexture(), this._kitImage = new PIXI.Sprite(texture), this._kitImage.x = .5 * Common.STAGE_WIDTH, this._kitImage.y = .5 * Common.STAGE_HEIGHT - 20, this._kitImage.anchor = new PIXI.Point(.5, .5), this.addChildAt(this._kitImage, this._car.parent.getChildIndex(this._car)), this._purchaseButton = new p3.Button(Common.assets.getTexture("ui_btn_upgrade_up"), Common.assets.getTexture("ui_btn_upgrade_over"), Common.assets.getTexture("ui_btn_upgrade_down"), Common.assets.getTexture("ui_icon_tick")), this._purchaseButton.x = .5 * Common.STAGE_WIDTH, this._purchaseButton.y = .5 * Common.STAGE_HEIGHT + 260, this._purchaseButton.animate = !0, this._purchaseButton.visible = !1, this._purchaseButton.overSoundName = "sfx_ui_btn_rollover_00", this._purchaseButton.downSoundName = "sfx_ui_btn_press_00", this._purchaseButton.clickSoundName = "sfx_ui_btn_colourconfirm_00", this._purchaseButton.signals.click.add(this.onPurchaseButtonClick, this), this.addChild(this._purchaseButton), this._cost = new PIXI.Sprite(Common.assets.getTexture("ui_cost_bg")), this._cost.anchor = new PIXI.Point(.5, .5), this._cost.visible = !1, this.addChildAt(this._cost, this._purchaseButton.parent.getChildIndex(this._purchaseButton) - 1), this._cost.icon = new PIXI.Sprite(Common.assets.getTexture("ui_icon_coin")), this._cost.icon.x = -100, this._cost.icon.anchor = new PIXI.Point(.5, .5), this._cost.addChild(this._cost.icon), this._cost.text = new PIXI.extras.BitmapText("", {
                    font: "42px Great Escape",
                    align: "center"
                }), this._cost.addChild(this._cost.text), this._nextButton = new p3.Button(Common.assets.getTexture("ui_btn_arrow_up"), Common.assets.getTexture("ui_btn_arrow_over"), Common.assets.getTexture("ui_btn_arrow_down")), this._nextButton.y = .5 * Common.STAGE_HEIGHT, this._nextButton.scale.x = this._nextButton.defaultScale.x = -1, this._nextButton.animate = !0, this._nextButton.overSoundName = "sfx_ui_btn_rollover_00", this._nextButton.downSoundName = "sfx_ui_btn_press_00", this._nextButton.signals.click.add(r2l ? this.onPrevButtonClick : this.onNextButtonClick, this), this.addChild(this._nextButton), this._prevButton = new p3.Button(Common.assets.getTexture("ui_btn_arrow_up"), Common.assets.getTexture("ui_btn_arrow_over"), Common.assets.getTexture("ui_btn_arrow_down")), this._prevButton.y = .5 * Common.STAGE_HEIGHT, this._prevButton.animate = !0, this._prevButton.overSoundName = "sfx_ui_btn_rollover_00", this._prevButton.downSoundName = "sfx_ui_btn_press_00", this._prevButton.signals.click.add(r2l ? this.onNextButtonClick : this.onPrevButtonClick, this), this.addChild(this._prevButton), this._kit = new PIXI.Sprite(Common.assets.getTexture("ui_cost_bg_small")), this._kit.x = .5 * Common.STAGE_WIDTH - 300, this._kit.y = .5 * Common.STAGE_HEIGHT + 280, this._kit.anchor = new PIXI.Point(.5, .5), this.addChild(this._kit), this._kit.bar = new PIXI.Sprite(Common.assets.getTexture("ui_cost_bar_small")), this._kit.bar.x = .5 * -this._kit.bar.width, this._kit.bar.y = 0, this._kit.bar.anchor = new PIXI.Point(0, .5), this._kit.addChild(this._kit.bar), this._kit.costText = new PIXI.extras.BitmapText("", {
                    font: "42px Great Escape",
                    align: "right"
                }), this._kit.addChild(this._kit.costText), this._kit.icon = new PIXI.Sprite(Common.assets.getTexture("ui_icon_coin")), this._kit.icon.x = -94, this._kit.icon.y = -2, this._kit.icon.scale = new PIXI.Point(.8, .8), this._kit.icon.anchor = new PIXI.Point(.5, .5), this._kit.addChild(this._kit.icon), this._kit.button = new p3.Button(Common.assets.getTexture("ui_btn_upgrade_up"), Common.assets.getTexture("ui_btn_upgrade_over"), Common.assets.getTexture("ui_btn_upgrade_down"), Common.assets.getTexture("ui_icon_plus"), Common.assets.getTexture("ui_btn_upgrade_inactive_up"), Common.assets.getTexture("ui_btn_upgrade_inactive_over"), Common.assets.getTexture("ui_btn_upgrade_inactive_over")), this._kit.button.id = 0, this._kit.button.x = 134, this._kit.button.scale.x = this._kit.button.defaultScale.x = .8, this._kit.button.scale.y = this._kit.button.defaultScale.y = .8, this._kit.button.animate = !0, this._kit.button.overSoundName = "sfx_ui_btn_rollover_00", this._kit.button.downSoundName = "sfx_ui_btn_press_00", this._kit.button.signals.click.add(this.onUpgradeButtonClick, this), this._kit.addChild(this._kit.button), this._tyre = new PIXI.Sprite(Common.assets.getTexture("ui_cost_bg_small")), this._tyre.x = .5 * Common.STAGE_WIDTH + 66, this._tyre.y = .5 * Common.STAGE_HEIGHT + 280, this._tyre.anchor = new PIXI.Point(.5, .5), this.addChild(this._tyre), this._tyre.bar = new PIXI.Sprite(Common.assets.getTexture("ui_cost_bar_small")), this._tyre.bar.x = .5 * -this._tyre.bar.width, this._tyre.bar.y = 0, this._tyre.bar.anchor = new PIXI.Point(0, .5), this._tyre.addChild(this._tyre.bar), this._tyre.costText = new PIXI.extras.BitmapText("", {
                    font: "42px Great Escape",
                    align: "right"
                }), this._tyre.addChild(this._tyre.costText), this._tyre.icon = new PIXI.Sprite(Common.assets.getTexture("ui_icon_coin")), this._tyre.icon.x = -94, this._tyre.icon.y = -2, this._tyre.icon.scale = new PIXI.Point(.8, .8), this._tyre.icon.anchor = new PIXI.Point(.5, .5), this._tyre.addChild(this._tyre.icon), this._tyre.button = new p3.Button(Common.assets.getTexture("ui_btn_upgrade_up"), Common.assets.getTexture("ui_btn_upgrade_over"), Common.assets.getTexture("ui_btn_upgrade_down"), Common.assets.getTexture("ui_icon_plus"), Common.assets.getTexture("ui_btn_upgrade_inactive_up"), Common.assets.getTexture("ui_btn_upgrade_inactive_over"), Common.assets.getTexture("ui_btn_upgrade_inactive_over")), this._tyre.button.id = 1, this._tyre.button.x = 134, this._tyre.button.scale.x = this._tyre.button.defaultScale.x = .8, this._tyre.button.scale.y = this._tyre.button.defaultScale.y = .8, this._tyre.button.animate = !0, this._tyre.button.overSoundName = "sfx_ui_btn_rollover_00", this._tyre.button.downSoundName = "sfx_ui_btn_press_00", this._tyre.button.signals.click.add(this.onUpgradeButtonClick, this), this._tyre.addChild(this._tyre.button);
                var k, spacing = 54,
                    index = this._kit.parent.getChildIndex(this._kit);
                this._kit.levels = [];
                for (var i = 0; 4 > i; ++i) k = new PIXI.Sprite(Common.assets.getTexture("ui_icon_kit" + (i + 1))), k.x = this._kit.x + i * spacing - 3 * spacing * .5 + 8, k.y = this._kit.y + (.5 * -k.height - 20), k.anchor = new PIXI.Point(.5, .5), k.alpha = .5, this.addChildAt(k, index), this._kit.levels.push(k);
                for (spacing = 54, index = this._tyre.parent.getChildIndex(this._tyre), this._tyre.levels = [], i = 0; 4 > i; ++i) k = new PIXI.Sprite(Common.assets.getTexture("ui_icon_tyre" + (i + 1))), k.x = this._tyre.x + i * spacing - 3 * spacing * .5 + 8, k.y = this._tyre.y + (.5 * -k.height - 2), k.anchor = new PIXI.Point(.5, .5), k.alpha = .5, this.addChildAt(k, index), this._tyre.levels.push(k);
                this._acceptButton = new p3.Button(Common.assets.getTexture("ui_btn_confirm_up"), Common.assets.getTexture("ui_btn_confirm_over"), Common.assets.getTexture("ui_btn_confirm_down"), Common.assets.getTexture("ui_icon_tick")), this._acceptButton.y = .5 * Common.STAGE_HEIGHT + 260, this._acceptButton.animate = !0, this._acceptButton.overSoundName = "sfx_ui_btn_rollover_00", this._acceptButton.downSoundName = "sfx_ui_btn_press_00", this._acceptButton.clickSoundName = "sfx_ui_btn_kitconfirm_00", this._acceptButton.signals.click.add(this.onAcceptButtonClick, this), this.addChild(this._acceptButton), this.updateKitText(), this.updateTyreText(), this.updateKitButton(), this.updateTyreButton(), this.updateKitBar(), this.updateTyreBar(), this.updateKitLevels(), this.updateTyreLevels()
            }, GarageKitScene.prototype.dispose = function() {
                this._message && (this._message.destroy(), this._message = null), GarageScene.prototype.dispose.call(this)
            }, GarageKitScene.prototype.appear = function() {
                this.animateIn(), this._message = new MessagePopup(4, MessagePopup.CHARACTER_MATER, Common.copy.garage_kits_helper[Common.language]), this._message.x = .5 * (Common.STAGE_WIDTH - p3.View.width) + 20, this._message.y = 154, this._message.animateIn(), this.addChild(this._message)
            }, GarageKitScene.prototype.animateIn = function(callback, scope) {
                var animation;
                animation = new TimelineMax({
                    repeat: -1,
                    yoyo: !0
                }), animation.append(TweenMax.to(this._nextButton.scale, .6, {
                    x: -1.14,
                    y: 1.14,
                    ease: Power1.easeInOut
                })), animation = new TimelineMax({
                    repeat: -1,
                    yoyo: !0
                }), animation.append(TweenMax.to(this._prevButton.scale, .6, {
                    x: 1.14,
                    y: 1.14,
                    ease: Power1.easeInOut
                }))
            }, GarageKitScene.prototype.animateOut = function(callback, scope) {}, GarageKitScene.prototype.resize = function() {
                GarageScene.prototype.resize.call(this), this._nextButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width - Math.abs(this._nextButton.width)) - 28, this._prevButton.x = .5 * (Common.STAGE_WIDTH - p3.View.width + Math.abs(this._prevButton.width)) + 28, this._purchaseButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width) - 120, this._acceptButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width) - 120, this._cost.x = this._purchaseButton.x - 140, this._cost.y = this._purchaseButton.y
            }, GarageKitScene.prototype.upgradeKit = function() {
                var kit = Common.garage.myCar.kits[this._kitIndex],
                    level = kit.kitLevel + 1,
                    cost = kit.getKitCost(level);
                Common.garage.spendCash(cost) && (++kit.kitLevel, Common.saveData.save(), this.animateCoins(), this.updateKitText(), this.updateKitButton(), this.updateKitBar(), this.updateKitLevels(), this.updateTyreText(), this.updateTyreButton(), this.updateTyreBar(), this.updateTyreLevels(), this.playWheelsAnimation(), Common.audio.playSound("sfx_ui_btn_nexttkit_00"), Common.tracking.track(new p3.TrackingDataPlaydomGameAction(this._trackingContext + "_car_" + (Common.garage.myCar.id + 1), "buy_kit_" + kit.kitLevel)))
            }, GarageKitScene.prototype.upgradeTyre = function() {
                var kit = Common.garage.myCar.kits[this._kitIndex],
                    level = kit.tyreLevel + 1,
                    cost = kit.getTyreCost(level);
                Common.garage.spendCash(cost) && (++kit.tyreLevel, Common.saveData.save(), this.animateCoins(), this.updateTyreText(), this.updateTyreButton(), this.updateTyreBar(), this.updateTyreLevels(), this.updateKitText(), this.updateKitButton(), this.updateKitBar(), this.updateKitLevels(), this.playWheelsAnimation(), Common.audio.playSound("sfx_ui_btn_nexttkit_00"), Common.tracking.track(new p3.TrackingDataPlaydomGameAction(this._trackingContext + "_car_" + (Common.garage.myCar.id + 1), "buy_tyres_" + kit.tyreLevel)))
            }, GarageKitScene.prototype.updateKitText = function() {
                var kit = Common.garage.myCar.kits[this._kitIndex];
                if (kit.unlocked) {
                    var level = kit.kitLevel + 1,
                        cost = kit.isKitMaxed ? "" : kit.getKitCost(level);
                    this._kit.costText.text = cost.toString(), this._kit.costText.validate(), this._kit.costText.x = .5 * -this._kit.costText.textWidth + 4, this._kit.costText.y = .5 * -this._kit.costText.textHeight - 2, this._kit.costText.tint = Common.garage.canAfford(cost) ? 16777215 : 16711680
                }
            }, GarageKitScene.prototype.updateTyreText = function() {
                var kit = Common.garage.myCar.kits[this._kitIndex];
                if (kit.unlocked) {
                    var level = kit.tyreLevel + 1,
                        cost = kit.isTyreMaxed ? "" : kit.getTyreCost(level);
                    this._tyre.costText.text = cost.toString(), this._tyre.costText.validate(), this._tyre.costText.x = .5 * -this._tyre.costText.textWidth + 4, this._tyre.costText.y = .5 * -this._tyre.costText.textHeight - 2, this._tyre.costText.tint = Common.garage.canAfford(cost) ? 16777215 : 16711680
                }
            }, GarageKitScene.prototype.updateCostText = function() {
                var kit = Common.garage.myCar.kits[this._kitIndex],
                    cost = kit.cost,
                    unlocked = kit.unlocked;
                this._cost.text.text = unlocked ? Common.copy.garage_select[Common.language] : cost.toString(), this._cost.text.validate(), this._cost.text.x = .5 * -this._cost.text.textWidth, this._cost.text.y = .5 * -this._cost.text.textHeight, this._cost.text.tint = unlocked ? 16777215 : Common.garage.canAfford(cost) ? 16777215 : 16711680
            }, GarageKitScene.prototype.updateKitButton = function() {
                var kit = Common.garage.myCar.kits[this._kitIndex],
                    level = kit.kitLevel + 1;
                if (kit.isKitMaxed) this._kit.button.enabled = !1, this._kit.costText.visible = !1;
                else {
                    var cost = kit.getKitCost(level);
                    this._kit.button.enabled = Common.garage.canAfford(cost), this._kit.costText.visible = !0
                }
            }, GarageKitScene.prototype.updateTyreButton = function() {
                var kit = Common.garage.myCar.kits[this._kitIndex],
                    level = kit.tyreLevel + 1;
                if (kit.isTyreMaxed) this._tyre.button.enabled = !1, this._tyre.costText.visible = !1;
                else {
                    var cost = kit.getTyreCost(level);
                    this._tyre.button.enabled = Common.garage.canAfford(cost), this._tyre.costText.visible = !0
                }
            }, GarageKitScene.prototype.updateKitBar = function() {
                var kit = Common.garage.myCar.kits[this._kitIndex],
                    level = kit.kitLevel;
                this._kit.bar.scale.x = level / (kit.kitData.length - 1)
            }, GarageKitScene.prototype.updateTyreBar = function() {
                var kit = Common.garage.myCar.kits[this._kitIndex],
                    level = kit.tyreLevel;
                this._tyre.bar.scale.x = level / (kit.tyreData.length - 1)
            }, GarageKitScene.prototype.updateKitLevels = function() {
                for (var k, kit = Common.garage.myCar.kits[this._kitIndex], level = kit.kitLevel, i = 0; i < this._kit.levels.length; ++i) k = this._kit.levels[i], k.alpha = level > i ? 1 : .5
            }, GarageKitScene.prototype.updateTyreLevels = function() {
                for (var k, kit = Common.garage.myCar.kits[this._kitIndex], level = kit.tyreLevel, i = 0; i < this._tyre.levels.length; ++i) k = this._tyre.levels[i], k.alpha = level > i ? 1 : .5
            }, GarageKitScene.prototype.updatePurchaseButton = function() {
                var kit = Common.garage.myCar.kits[this._kitIndex],
                    cost = kit.cost,
                    unlocked = kit.unlocked;
                this._purchaseButton.enabled = unlocked ? !0 : Common.garage.canAfford(cost), this._purchaseButton.visible = !unlocked
            }, GarageKitScene.prototype.purchaseKit = function() {
                var kit = Common.garage.myCar.kits[this._kitIndex],
                    cost = kit.cost;
                if (Common.garage.spendCash(cost)) {
                    kit.unlocked = !0, Common.saveData.save();
                    var unlocked = kit.unlocked;
                    this._cost.visible = !unlocked, this._kit.visible = unlocked, this._tyre.visible = unlocked, this._acceptButton.visible = unlocked, this.animateCoins(), this.updateKitText(), this.updateTyreText(), this.updateCostText(), this.updateKitButton(), this.updateTyreButton(), this.updatePurchaseButton(), console.log("PURCHASED KIT - " + kit.name)
                }
            }, GarageKitScene.prototype.getKitPanelTexture = function() {
                var arr = ["ui_kit_bg_desert", "ui_kit_bg_carbon", "ui_kit_bg_aerodynamic", "ui_kit_bg_street", "ui_kit_bg_jungle"];
                return Common.assets.getTexture(arr[Math.min(arr.length - 1, this._kitIndex)])
            }, GarageKitScene.prototype.getKitImageTexture = function() {
                var arr = ["ui_kit_bg_desert_2", "ui_kit_bg_aerodynamic_2", "ui_kit_bg_carbon_2", "ui_kit_bg_street_2", "ui_kit_bg_jungle_2"];
                return Common.assets.getTexture(arr[Math.min(arr.length - 1, this._kitIndex)])
            }, GarageKitScene.prototype.onNextButtonClick = function(button) {
                ++this._kitIndex >= Common.garage.myCar.kits.length && (this._kitIndex = 0);
                var kit = Common.garage.myCar.kits[this._kitIndex];
                this._kitPanel.texture = this.getKitPanelTexture(), this._kitImage.texture = this.getKitImageTexture(), webfont ? (this._kitPanel.text.text = kit.name, this._kitPanel.text.x = .5 * -this._kitPanel.text.width) : (this._kitPanel.text.text = kit.name, this._kitPanel.text.validate(), this._kitPanel.text.x = .5 * -this._kitPanel.text.textWidth);
                var unlocked = kit.unlocked;
                this._cost.visible = !unlocked, this._kit.visible = unlocked, this._tyre.visible = unlocked, this._acceptButton.visible = unlocked, this._car.animation.spine.kitTheme = this._kitIndex, this.updateKitText(), this.updateTyreText(), this.updateKitBar(), this.updateTyreBar(), this.updateKitLevels(), this.updateTyreLevels(), this.updateCostText(), this.updatePurchaseButton()
            }, GarageKitScene.prototype.onPrevButtonClick = function(button) {
                --this._kitIndex < 0 && (this._kitIndex = Common.garage.myCar.kits.length - 1);
                var kit = Common.garage.myCar.kits[this._kitIndex];
                this._kitPanel.texture = this.getKitPanelTexture(), this._kitImage.texture = this.getKitImageTexture(), webfont ? (this._kitPanel.text.text = kit.name, this._kitPanel.text.x = .5 * -this._kitPanel.text.width) : (this._kitPanel.text.text = kit.name, this._kitPanel.text.validate(), this._kitPanel.text.x = .5 * -this._kitPanel.text.textWidth);
                var unlocked = kit.unlocked;
                this._cost.visible = !unlocked, this._kit.visible = unlocked, this._tyre.visible = unlocked, this._acceptButton.visible = unlocked, this._car.animation.spine.kitTheme = this._kitIndex, this.updateKitText(), this.updateTyreText(), this.updateKitBar(), this.updateTyreBar(), this.updateKitLevels(), this.updateTyreLevels(), this.updateCostText(), this.updatePurchaseButton()
            }, GarageKitScene.prototype.onPurchaseButtonClick = function(button) {
                var kit = Common.garage.myCar.kits[this._kitIndex];
                kit.unlocked ? (Common.garage.myCar.kit = this._kitIndex, Common.saveData.save(), this.signals.previous.dispatch(button)) : this.signals.purchase.dispatch(this, kit.name, -1)
            }, GarageKitScene.prototype.onUpgradeButtonClick = function(button) {
                var kit, title;
                switch (button.id) {
                    case 0:
                        kit = Common.garage.myCar.kits[this._kitIndex], title = Common.copy.kit_upgrade[Common.language] + " " + (kit.kitLevel + 1);
                        break;
                    case 1:
                        kit = Common.garage.myCar.kits[this._kitIndex], title = Common.copy.kit_tyre_upgrade[Common.language] + " " + (kit.tyreLevel + 1)
                }
                this.signals.purchase.dispatch(this, title, button.id)
            }, GarageKitScene.prototype.onAcceptButtonClick = function(button) {
                this.onPurchaseButtonClick(button)
            }
        }, {
            "./Common": 23,
            "./GarageScene": 44,
            "./GarageTypes": 45,
            "./MessagePopup": 54,
            "./Scene": 83
        }],
        42: [function(require, module, exports) {
            function GarageModelScene() {
                GarageScene.call(this), this.type = GarageTypes.MODEL, this.signals.photo = new signals.Signal, this.signals.color = new signals.Signal, this.signals.engine = new signals.Signal, this.signals.kit = new signals.Signal, this.signals.decals = new signals.Signal, this._modelIndex = 0, this._licensePlate = null, this._modelContainer = null, this._modelAnim = null, this._photoButton = null, this._nextButton = null, this._prevButton = null, this._playButton = null, this._colorButton = null, this._decalButton = null, this._engineButton = null, this._kitButton = null, this._message = null
            }
            var AudioParams = require("./AudioParams"),
                Common = require("./Common"),
                GarageScene = (require("./Garage"), require("./GarageScene")),
                GarageTypes = require("./GarageTypes"),
                MessagePopup = require("./MessagePopup");
            require("./Scene");
            module.exports = GarageModelScene, GarageModelScene.prototype = Object.create(GarageScene.prototype), GarageModelScene.prototype.constructor = GarageModelScene, GarageModelScene.prototype.init = function() {
                GarageScene.prototype.init.call(this), this._modelIndex = Common.garage.selected, this._modelContainer = new PIXI.Container, this.addChild(this._modelContainer);
                var that = this;
                this._car.animation.interactive = !0, this._car.animation.buttonMode = !0, this._car.animation.click = this._car.animation.tap = function() {
                        that.onNextButtonClick.call(that), Common.audio.playSound("sfx_ui_btn_press_00")
                    }, this._photoButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_photo")), this._photoButton.y = .5 * Common.STAGE_HEIGHT + 260, this._photoButton.visible = !p3.Device.isMobile, this._photoButton.animate = !0, this._photoButton.overSoundName = "sfx_ui_btn_rollover_00", this._photoButton.downSoundName = "sfx_ui_btn_press_00", this._photoButton.signals.click.add(this.onPhotoButtonClick, this), this.addChild(this._photoButton), this._nextButton = new p3.Button(Common.assets.getTexture("ui_btn_arrow_up"), Common.assets.getTexture("ui_btn_arrow_over"), Common.assets.getTexture("ui_btn_arrow_down")), this._nextButton.y = .5 * Common.STAGE_HEIGHT + 36, this._nextButton.scale.x = this._nextButton.defaultScale.x = -1, this._nextButton.overSoundName = "sfx_ui_btn_rollover_00", this._nextButton.downSoundName = "sfx_ui_btn_press_00", this._nextButton.clickSoundName = "sfx_ui_btn_nextcar_02", this._nextButton.signals.click.add(this.onNextButtonClick, this), this.addChild(this._nextButton), this._prevButton = new p3.Button(Common.assets.getTexture("ui_btn_arrow_up"), Common.assets.getTexture("ui_btn_arrow_over"), Common.assets.getTexture("ui_btn_arrow_down")), this._prevButton.y = .5 * Common.STAGE_HEIGHT + 36, this._prevButton.overSoundName = "sfx_ui_btn_rollover_00", this._prevButton.downSoundName = "sfx_ui_btn_press_00", this._prevButton.clickSoundName = "sfx_ui_btn_nextcar_02", this._prevButton.signals.click.add(this.onPrevButtonClick, this), this.addChild(this._prevButton),
                    this._playButton = new p3.Button(Common.assets.getTexture("ui_btn_confirm_up"), Common.assets.getTexture("ui_btn_confirm_over"), Common.assets.getTexture("ui_btn_confirm_down"), Common.assets.getTexture("ui_icon_race")), this._playButton.y = .5 * Common.STAGE_HEIGHT + 260, this._playButton.overSoundName = "sfx_ui_btn_rollover_00", this._playButton.downSoundName = "sfx_ui_btn_press_00", this._playButton.clickSoundName = "sfx_ui_btn_play_00", this._playButton.signals.click.add(this.onPlayButtonClick, this), this.addChild(this._playButton), this._colorButton = new p3.Button(Common.assets.getTexture("ui_btn_modify_up"), Common.assets.getTexture("ui_btn_modify_over"), Common.assets.getTexture("ui_btn_modify_down"), Common.assets.getTexture("ui_icon_colours")), this._colorButton.y = p3.View.height - 120, this._colorButton.animate = !0, this._colorButton.overSoundName = "sfx_ui_btn_rollover_00", this._colorButton.downSoundName = "sfx_ui_btn_press_00", this._colorButton.clickSoundName = "sfx_ui_btn_enterspraybooth_00", this._colorButton.signals.click.add(this.onColorButtonClick, this), this.addChild(this._colorButton), this._decalButton = new p3.Button(Common.assets.getTexture("ui_btn_modify_up"), Common.assets.getTexture("ui_btn_modify_over"), Common.assets.getTexture("ui_btn_modify_down"), Common.assets.getTexture("ui_icon_decals")), this._decalButton.y = p3.View.height - 120, this._decalButton.animate = !0, this._decalButton.overSoundName = "sfx_ui_btn_rollover_00", this._decalButton.downSoundName = "sfx_ui_btn_press_00", this._decalButton.signals.click.add(this.onDecalButtonClick, this), this.addChild(this._decalButton), this._engineButton = new p3.Button(Common.assets.getTexture("ui_btn_modify_up"), Common.assets.getTexture("ui_btn_modify_over"), Common.assets.getTexture("ui_btn_modify_down"), Common.assets.getTexture("ui_icon_engine")), this._engineButton.y = p3.View.height - 120, this._engineButton.animate = !0, this._engineButton.overSoundName = "sfx_ui_btn_rollover_00", this._engineButton.downSoundName = "sfx_ui_btn_press_00", this._engineButton.clickSoundName = "sfx_ui_btn_enterenginebooth_00", this._engineButton.signals.click.add(this.onEngineButtonClick, this), this.addChild(this._engineButton), this._kitButton = new p3.Button(Common.assets.getTexture("ui_btn_modify_up"), Common.assets.getTexture("ui_btn_modify_over"), Common.assets.getTexture("ui_btn_modify_down"), Common.assets.getTexture("ui_icon_kit")), this._kitButton.y = p3.View.height - 120, this._kitButton.animate = !0, this._kitButton.overSoundName = "sfx_ui_btn_rollover_00", this._kitButton.downSoundName = "sfx_ui_btn_press_00", this._kitButton.signals.click.add(this.onKitButtonClick, this), this.addChild(this._kitButton)
            }, GarageModelScene.prototype.dispose = function() {
                this.signals.color.dispose(), this.signals.color = null, this.signals.engine.dispose(), this.signals.engine = null, this.signals.kit.dispose(), this.signals.kit = null, this.signals.decals.dispose(), this.signals.decals = null, this._message && (this._message.destroy(), this._message = null), Common.audio.stopSound("sfx_ambience_garage_00"), GarageScene.prototype.dispose.call(this)
            }, GarageModelScene.prototype.appear = function() {
                GarageScene.prototype.appear.call(this), this._message = new MessagePopup(0, MessagePopup.CHARACTER_MCQUEEN, Common.copy.garage_helper[Common.language]), this._message.x = .5 * (Common.STAGE_WIDTH - p3.View.width) + 20, this._message.y = 154, this._message.animateIn(), this.addChild(this._message);
                var params = new AudioParams;
                params.loop = !0, Common.audio.playSound("sfx_ambience_garage_00", params)
            }, GarageModelScene.prototype.animateIn = function(callback, scope) {
                GarageScene.prototype.animateIn.call(this, callback, scope);
                var animation;
                animation = new TimelineMax({
                    repeat: -1,
                    yoyo: !0
                }), animation.append(TweenMax.to(this._nextButton.scale, .6, {
                    x: -1.14,
                    y: 1.14,
                    ease: Power1.easeInOut
                })), animation = new TimelineMax({
                    repeat: -1,
                    yoyo: !0
                }), animation.append(TweenMax.to(this._prevButton.scale, .6, {
                    x: 1.14,
                    y: 1.14,
                    ease: Power1.easeInOut
                })), TweenMax.to(this._playButton.scale, .6, {
                    x: 1.14,
                    y: 1.14,
                    ease: Power1.easeInOut,
                    repeat: -1,
                    yoyo: !0
                })
            }, GarageModelScene.prototype.animateOut = function(callback, scope) {}, GarageModelScene.prototype.resize = function() {
                GarageScene.prototype.resize.call(this), this._photoButton.x = this._backButton.x, this._nextButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width - Math.abs(this._nextButton.width)) - 28, this._prevButton.x = .5 * (Common.STAGE_WIDTH - p3.View.width + Math.abs(this._prevButton.width)) + 28;
                var spacing = 144;
                this._colorButton.x = .5 * Common.STAGE_WIDTH - 1.5 * spacing, this._decalButton.x = .5 * Common.STAGE_WIDTH - .5 * spacing, this._engineButton.x = .5 * Common.STAGE_WIDTH + .5 * spacing, this._kitButton.x = .5 * Common.STAGE_WIDTH + 1.5 * spacing, this._playButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width) - 120
            }, GarageModelScene.prototype.onNextButtonClick = function(button) {
                ++this._modelIndex >= Common.garage.cars.length && (this._modelIndex = 0), Common.garage.selected = this._modelIndex, Common.saveData.save(), this._car.animation.spine.state.setAnimationByName(0, "idle", !0), this.setupCar()
            }, GarageModelScene.prototype.onPrevButtonClick = function(button) {
                --this._modelIndex < 0 && (this._modelIndex = Common.garage.cars.length - 1), Common.garage.selected = this._modelIndex, Common.saveData.save(), this._car.animation.spine.state.setAnimationByName(0, "idle", !0), this.setupCar()
            }, GarageModelScene.prototype.onPlayButtonClick = function(button) {
                this.signals.next.dispatch(this)
            }, GarageModelScene.prototype.onPhotoButtonClick = function(button) {
                this.signals.photo.dispatch(this, Common.garage.savePhoto())
            }, GarageModelScene.prototype.onColorButtonClick = function(button) {
                this.signals.color.dispatch(this)
            }, GarageModelScene.prototype.onEngineButtonClick = function(button) {
                this.signals.engine.dispatch(this)
            }, GarageModelScene.prototype.onKitButtonClick = function(button) {
                this.signals.kit.dispatch(this)
            }, GarageModelScene.prototype.onDecalButtonClick = function(button) {
                this.signals.decals.dispatch(this)
            }
        }, {
            "./AudioParams": 9,
            "./Common": 23,
            "./Garage": 37,
            "./GarageScene": 44,
            "./GarageTypes": 45,
            "./MessagePopup": 54,
            "./Scene": 83
        }],
        43: [function(require, module, exports) {
            function GaragePitstopScene() {
                this._playButton = null, GarageKitScene.call(this), this._trackingContext = "kit"
            }
            var Common = require("./Common"),
                CountryTypes = require("./CountryTypes"),
                GarageKitScene = require("./GarageKitScene"),
                GarageScene = require("./GarageScene"),
                MessagePopup = (require("./GarageTypes"), require("./MessagePopup"));
            require("./Scene");
            module.exports = GaragePitstopScene, GaragePitstopScene.prototype = Object.create(GarageKitScene.prototype), GaragePitstopScene.prototype.constructor = GaragePitstopScene, GaragePitstopScene.prototype.init = function() {
                GarageKitScene.prototype.init.call(this), this._trophyButton.visible = !1, webfont ? (this._titleText.text = Common.copy.garage_pitstop[Common.language], this._titleText.x = .5 * (Common.STAGE_WIDTH - this._titleText.width)) : (this._titleText.text = Common.copy.garage_pitstop[Common.language], this._titleText.validate(), this._titleText.x = .5 * (Common.STAGE_WIDTH - this._titleText.textWidth)), this._acceptButton.visible = !1, this._playButton = new p3.Button(Common.assets.getTexture("ui_btn_confirm_up"), Common.assets.getTexture("ui_btn_confirm_over"), Common.assets.getTexture("ui_btn_confirm_down"), Common.assets.getTexture("ui_icon_race")), this._playButton.y = .5 * Common.STAGE_HEIGHT + 260, this._playButton.overSoundName = "sfx_ui_btn_rollover_00", this._playButton.downSoundName = "sfx_ui_btn_press_00", this._playButton.clickSoundName = "sfx_ui_btn_play_00", this._playButton.signals.click.add(this.onAcceptButtonClick, this), this.addChild(this._playButton);
                var country = Common.trackManager.currentTrack.country;
                switch (country) {
                    case CountryTypes.TUTORIAL:
                    case CountryTypes.USA:
                        this._kitIndex = 0;
                        break;
                    case CountryTypes.ITALY:
                        this._kitIndex = 1;
                        break;
                    case CountryTypes.GERMANY:
                        this._kitIndex = 2;
                        break;
                    case CountryTypes.JAPAN:
                        this._kitIndex = 3;
                        break;
                    case CountryTypes.BRAZIL:
                        this._kitIndex = 4
                }
                var kit = Common.garage.myCar.kits[this._kitIndex];
                this._kitPanel.texture = this.getKitPanelTexture(), this._kitImage.texture = this.getKitImageTexture(), this._car.animation.spine.kitTheme = this._kitIndex, webfont ? (this._kitPanel.text.text = kit.name, this._kitPanel.text.x = .5 * -this._kitPanel.text.width) : (this._kitPanel.text.text = kit.name, this._kitPanel.text.validate(), this._kitPanel.text.x = .5 * -this._kitPanel.text.textWidth), this.updateKitText(), this.updateTyreText(), this.updateKitBar(), this.updateTyreBar(), this.updateCostText(), this.updatePurchaseButton()
            }, GaragePitstopScene.prototype.dispose = function() {
                GarageKitScene.prototype.dispose.call(this)
            }, GaragePitstopScene.prototype.appear = function() {
                GarageScene.prototype.appear.call(this);
                var str, country = Common.trackManager.currentTrack.country;
                switch (country) {
                    case CountryTypes.TUTORIAL:
                    case CountryTypes.USA:
                        str = Common.copy.garage_pitstop_usa[Common.language];
                        break;
                    case CountryTypes.ITALY:
                        str = Common.copy.garage_pitstop_italy[Common.language];
                        break;
                    case CountryTypes.GERMANY:
                        str = Common.copy.garage_pitstop_germany[Common.language];
                        break;
                    case CountryTypes.JAPAN:
                        str = Common.copy.garage_pitstop_japan[Common.language];
                        break;
                    case CountryTypes.BRAZIL:
                        str = Common.copy.garage_pitstop_brazil[Common.language]
                }
                this._message = new MessagePopup(5, MessagePopup.CHARACTER_RAMONE, str), this._message.x = .5 * (Common.STAGE_WIDTH - p3.View.width) + 20, this._message.y = 154, this._message.auto = !0, this._message.animateIn(), this.addChild(this._message)
            }, GaragePitstopScene.prototype.animateIn = function() {
                GarageKitScene.prototype.animateIn.call(this), TweenMax.to(this._playButton.scale, .6, {
                    x: 1.14,
                    y: 1.14,
                    ease: Power1.easeInOut,
                    repeat: -1,
                    yoyo: !0
                })
            }, GaragePitstopScene.prototype.resize = function() {
                GarageKitScene.prototype.resize.call(this), this._playButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width) - 120
            }, GaragePitstopScene.prototype.onPurchaseButtonClick = function(button) {
                var kit = Common.garage.myCar.kits[this._kitIndex];
                kit.unlocked ? (Common.garage.myCar.kit = this._kitIndex, Common.saveData.save(), this.signals.next.dispatch(button)) : this.signals.purchase.dispatch(this, kit.name, -1)
            }, GaragePitstopScene.prototype.onAcceptButtonClick = function(button) {
                this.onPurchaseButtonClick(button)
            }
        }, {
            "./Common": 23,
            "./CountryTypes": 27,
            "./GarageKitScene": 41,
            "./GarageScene": 44,
            "./GarageTypes": 45,
            "./MessagePopup": 54,
            "./Scene": 83
        }],
        44: [function(require, module, exports) {
            function GarageScene() {
                Scene.call(this), this.type = "", this.signals.settings = new signals.Signal, this.signals.trophy = new signals.Signal, this.signals.purchase = new signals.Signal, this.signals.name = new signals.Signal, this._animator = null, this._header = null, this._titleText = null, this._cash = null, this._trophyButton = null, this._helpButton = null, this._settingsButton = null, this._backButton = null, this._car = null
            }
            var CarSpine = require("./CarSpine"),
                Common = require("./Common"),
                Scene = require("./Scene");
            module.exports = GarageScene, GarageScene.prototype = Object.create(Scene.prototype), GarageScene.prototype.constructor = GarageScene, GarageScene.prototype.init = function() {
                this._animator = new p3.Animator;
                var bg = new PIXI.Sprite(Common.assets.getTexture("ui_bg_garage"));
                bg.scale = new PIXI.Point(2, 2), this.addChild(bg), this._header = new PIXI.Sprite(Common.assets.getTexture("ui_top_bar")), this._header.x = .5 * Common.STAGE_WIDTH, this._header.y = 120, this._header.anchor = new PIXI.Point(.5, .5), this.addChild(this._header), webfont ? (this._titleText = new PIXI.Text(Common.copy.garage[Common.language], {
                    font: "48px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._titleText.x = .5 * (Common.STAGE_WIDTH - this._titleText.width), this._titleText.y = 96, this.addChild(this._titleText)) : (this._titleText = new PIXI.extras.BitmapText(Common.copy.garage[Common.language], {
                    font: "48px Great Escape",
                    align: "center"
                }), this._titleText.x = .5 * (Common.STAGE_WIDTH - this._titleText.textWidth), this._titleText.y = 86, this.addChild(this._titleText)), this._settingsButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_settings")), this._settingsButton.y = 120, this._settingsButton.animate = !0, this._settingsButton.overSoundName = "sfx_ui_btn_rollover_00", this._settingsButton.downSoundName = "sfx_ui_btn_press_00", this._settingsButton.signals.click.add(this.onSettingsButtonClick, this), this.addChild(this._settingsButton), this._helpButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_help")), this._helpButton.y = this._settingsButton.y, this._helpButton.animate = !0, this._helpButton.overSoundName = "sfx_ui_btn_rollover_00", this._helpButton.downSoundName = "sfx_ui_btn_press_00", this._helpButton.signals.click.add(this.onHelpButtonClick, this), this.addChild(this._helpButton), this._backButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_back")), this._backButton.y = 120, this._backButton.animate = !0, this._backButton.overSoundName = "sfx_ui_btn_rollover_00", this._backButton.downSoundName = "sfx_ui_btn_press_00", this._backButton.signals.click.add(this.onBackButtonClick, this), this.addChild(this._backButton), this._trophyButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_trophy")), this._trophyButton.y = 120, this._trophyButton.animate = !0, this._trophyButton.overSoundName = "sfx_ui_btn_rollover_00", this._trophyButton.downSoundName = "sfx_ui_btn_press_00", this._trophyButton.signals.click.add(this.onTrophyButtonClick, this), this.addChild(this._trophyButton);
                var that = this;
                this._licensePlate = new PIXI.Sprite(PIXI.Texture.EMPTY), this._licensePlate.anchor = new PIXI.Point(.5, .5), this._licensePlate.interactive = !0, this._licensePlate.buttonMode = !0, this._licensePlate.click = this._licensePlate.tap = function() {
                    that.onLicensePlateClick(that._licensePlate), Common.audio.playSound("sfx_ui_btn_press_00")
                }, this.addChild(this._licensePlate), this._cash = new PIXI.Sprite(Common.assets.getTexture("ui_coins_bg")), this._cash.y = .5 * Common.STAGE_HEIGHT - 174, this._cash.anchor = new PIXI.Point(.5, .5), this.addChild(this._cash), this._licensePlate.y = this._cash.y + 74, this._cash.icon = new p3.AdditiveSprite(Common.assets.getTexture("ui_icon_coin")), this._cash.icon.x = -76, this._cash.icon.y = 0, this._cash.icon.scale = new PIXI.Point(.9, .9), this._cash.icon.anchor = new PIXI.Point(.5, .5), this._cash.icon.blendPasses = 1, this._cash.addChild(this._cash.icon), this._cash.text = new PIXI.extras.BitmapText("9999", {
                    font: "38px Great Escape",
                    align: "left"
                }), this._cash.text.x = .5 * -this._cash.text.textWidth + 20, this._cash.text.y = .5 * -this._cash.text.textHeight - 2, this._cash.addChild(this._cash.text);
                var config = Common.assets.getJSON("particle_coins_spend_rise");
                this._cash.emitter = new cloudkid.Emitter(this, [Common.assets.getTexture("ui_icon_coin")], config), this._cash.emitter.emit = !1, this._cash.target = null, this._car = new PIXI.Container, this.addChild(this._car), this._car.animation = new PIXI.Container, this._car.animation.x = .5 * Common.STAGE_WIDTH, this._car.animation.y = .5 * Common.STAGE_HEIGHT + 134, this._car.animation.scale = new PIXI.Point(.5, .5), this._car.addChild(this._car.animation), this.setupCar(), this.updateCashText(), this.updateLicensePlate()
            }, GarageScene.prototype.dispose = function() {
                this._animator.removeAll(), this._car.animation.spine.destroy(), this.signals.settings.dispose(), this.signals.settings = null, this.signals.trophy.dispose(), this.signals.trophy = null, this.signals.purchase.dispose(), this.signals.purchase = null, this.signals.name.dispose(), this.signals.name = null, Scene.prototype.dispose.call(this)
            }, GarageScene.prototype.appear = function() {
                this.animateIn()
            }, GarageScene.prototype.show = function() {
                this.setupCar(), this.updateLicensePlate()
            }, GarageScene.prototype.animateIn = function(callback, scope) {
                this._cash.icon.blendStrength = 0, TweenMax.to(this._cash.icon, 1.4, {
                    blendStrength: .34,
                    ease: Power1.easeInOut,
                    repeat: -1,
                    yoyo: !0
                })
            }, GarageScene.prototype.animateOut = function(callback, scope) {}, GarageScene.prototype.resize = function() {
                this.x = .5 * (p3.View.width - Common.STAGE_WIDTH), this._header.width = p3.View.width, this._cash.x = .5 * (Common.STAGE_WIDTH + p3.View.width) - 160, this._licensePlate.x = this._cash.x, this._settingsButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width - this._settingsButton.width) - 28, this._helpButton.x = this._settingsButton.x - 112, this._backButton.x = .5 * (Common.STAGE_WIDTH - p3.View.width + this._backButton.width) + 28, this._trophyButton.x = this._backButton.x + 112
            }, GarageScene.prototype.update = function() {
                this._animator.update(), this._car.animation.spine && this._car.animation.spine.update(p3.Timestep.deltaTime), this._cash.emitter.update(p3.Timestep.deltaTime)
            }, GarageScene.prototype.updateCashText = function(animate) {
                function next() {
                    var cash = this._cash.value;
                    cash += (this._cash.target - cash) * ease, this._cash.value = cash, this._cash.text.text = Math.round(this._cash.value).toString(), Math.abs(Math.floor(this._cash.target - cash)) > 0 && TweenMax.delayedCall(.02, next, null, this)
                }
                if (animate) {
                    var ease = .2;
                    this._cash.target = Common.garage.cash, this._cash.value = parseInt(this._cash.text.text), next.call(this)
                } else this._cash.text.text = Common.garage.cash.toString()
            }, GarageScene.prototype.updateLicensePlate = function() {
                var name = Common.garage.name;
                this._licensePlate.texture = Common.garage.saveLicensePlate(name)
            }, GarageScene.prototype.setupCar = function() {
                var garage = Common.garage,
                    car = garage.myCar,
                    colorIndex = car.color,
                    color = car.colors[colorIndex];
                if (!this._car.animation.spine || this._car.animation.spine.id != car.id) {
                    this._car.animation.spine && this._car.animation.spine.parent.removeChild(this._car.animation.spine);
                    var name = "car_" + p3.Utils.padNumber(car.id, 2) + "_garage";
                    this._car.animation.spine = new CarSpine(Common.assets.getSpineData(name)), this._car.animation.spine.id = car.id, this._car.animation.spine.skeleton.setToSetupPose(), this._car.animation.spine.update(0), this._car.animation.spine.autoUpdate = !1, this._car.animation.addChild(this._car.animation.spine), this.playIdleAnimation()
                }
                this._car.animation.spine.paintColor = color.color, this._car.animation.spine.decalTheme = garage.myCar.decal, this._car.animation.spine.kitTheme = Math.max(0, garage.myCar.kit)
            }, GarageScene.prototype.animateCoins = function() {
                TweenMax.killTweensOf(this._cash.scale);
                var animation = new TimelineMax;
                animation.append(TweenMax.to(this._cash.scale, .4, {
                    x: 1.14,
                    y: 1.14,
                    ease: Elastic.easeOut,
                    easeParams: [1]
                })), animation.append(TweenMax.to(this._cash.scale, .4, {
                    x: 1,
                    y: 1,
                    ease: Back.easeInOut,
                    easeParams: [2]
                }));
                var localPos = this.toLocal(this._cash.icon.position, this._cash);
                this._cash.emitter.emit = !0, this._cash.emitter.updateOwnerPos(localPos.x, localPos.y), this.updateCashText(!0)
            }, GarageScene.prototype.playIdleAnimation = function() {
                var arr = ["idle", "idle2"],
                    name = arr[Math.floor(Math.random() * arr.length)];
                this._car.animation.spine.state.addAnimationByName(0, name, !0, 0)
            }, GarageScene.prototype.playColorAnimation = function() {
                this._car.animation.spine.state.setAnimationByName(0, "upgrade_paint", !1), this.playIdleAnimation()
            }, GarageScene.prototype.playDecalAnimation = function() {
                this._car.animation.spine.state.setAnimationByName(0, "upgrade_paint", !1), this.playIdleAnimation()
            }, GarageScene.prototype.playEngineAnimation = function() {
                this._car.animation.spine.state.setAnimationByName(0, "upgrade_engine", !1), this.playIdleAnimation()
            }, GarageScene.prototype.playWheelsAnimation = function() {
                this._car.animation.spine.state.setAnimationByName(0, "upgrade_wheels", !1), this.playIdleAnimation()
            }, GarageScene.prototype.onSettingsButtonClick = function(button) {
                this.signals.settings.dispatch(this)
            }, GarageScene.prototype.onHelpButtonClick = function(button) {
                this.signals.pause.dispatch(this)
            }, GarageScene.prototype.onTrophyButtonClick = function(button) {
                this.signals.trophy.dispatch(this)
            }, GarageScene.prototype.onBackButtonClick = function(button) {
                this.signals.previous.dispatch(this)
            }, GarageScene.prototype.onLicensePlateClick = function(button) {
                this.signals.name.dispatch(this)
            }
        }, {
            "./CarSpine": 20,
            "./Common": 23,
            "./Scene": 83
        }],
        45: [function(require, module, exports) {
            function GarageTypes() {}
            module.exports = GarageTypes, GarageTypes.MODEL = "model", GarageTypes.COLOR = "color", GarageTypes.ENGINE = "engine", GarageTypes.KIT = "kit", GarageTypes.DECALS = "decals"
        }, {}],
        46: [function(require, module, exports) {
            function GorvetteView(avatar) {
                CarView.call(this, 16777215, avatar);
                var chassisOffset = new PIXI.Point(0, -2);
                this._shadow.offset = new PIXI.Point(0, 26), this._wheels.front.left.offset = new PIXI.Point(-82, 14), this._wheels.front.right.offset = new PIXI.Point(82, 14), this._wheels.rear.left.offset = new PIXI.Point(-124, 78), this._wheels.rear.right.offset = new PIXI.Point(124, 78), this._front.offset = new PIXI.Point(chassisOffset.x, -4 + chassisOffset.y), this._mid.offset = new PIXI.Point(chassisOffset.x, chassisOffset.y), this._back.offset = new PIXI.Point(chassisOffset.x, chassisOffset.y)
            }
            var CarView = (require("./CarShader"), require("./CarView")),
                Common = require("./Common");
            module.exports = GorvetteView, GorvetteView.prototype = Object.create(CarView.prototype), GorvetteView.prototype.constructor = GorvetteView, GorvetteView.prototype.update = function(distance, curvature, gradient, velocity, turnVelocity) {
                var scalar = 140;
                this._curvature += .4 * (turnVelocity + curvature - this._curvature), this._curvature = Math.max(-scalar, Math.min(scalar, this._curvature)), this._front.x = .4 * this._curvature + this._front.offset.x, this._front.y = -gradient * scalar * 1.6 + this._front.offset.y, this._mid.x = .1 * this._curvature + this._mid.offset.x, this._mid.y = -gradient * scalar * 1.3 + this._mid.offset.y, this._back.x = .14 * -this._curvature + this._back.offset.x, this._back.y = gradient * scalar + this._back.offset.y, this._shadow.x = this._back.x, this._shadow.y = this._wheels.rear.left.y + this._shadow.offset.y, this._front.rotation = 8e-4 * this._curvature, this._back.rotation = 8e-4 * this._curvature, this._wheels.front.left.x = this._front.x + this._wheels.front.left.offset.x, this._wheels.front.left.y = gradient * scalar + this._wheels.front.left.offset.y, this._wheels.front.right.x = this._front.x + this._wheels.front.right.offset.x, this._wheels.front.right.y = gradient * scalar + this._wheels.front.right.offset.y, this._wheels.rear.left.x = this._back.x + this._wheels.rear.left.offset.x, this._wheels.rear.left.y = gradient * scalar + this._wheels.rear.left.offset.y, this._wheels.rear.right.x = this._back.x + this._wheels.rear.right.offset.x, this._wheels.rear.right.y = gradient * scalar + this._wheels.rear.right.offset.y;
                var theta;
                theta = .008 * turnVelocity, 0 > theta && (theta *= .112), this._wheels.front.left.rotation = theta, theta = .008 * turnVelocity, theta > 0 && (theta *= .112), this._wheels.front.right.rotation = theta, theta = .008 * turnVelocity, 0 > theta && (theta *= .112), this._wheels.rear.left.rotation = theta, theta = .008 * turnVelocity, theta > 0 && (theta *= .112), this._wheels.rear.right.rotation = theta, velocity = Math.max(0, velocity), this._wheels.front.left.animationSpeed = velocity / .2, this._wheels.front.right.animationSpeed = velocity / .2, this._wheels.rear.left.animationSpeed = velocity / .2, this._wheels.rear.right.animationSpeed = velocity / .2
            }, GorvetteView.prototype.createFrontLayer = function() {
                return new PIXI.Sprite(Common.assets.getTexture("car_gorvette_body_00"))
            }, GorvetteView.prototype.createMidLayer = function() {
                return new PIXI.Sprite(Common.assets.getTexture("car_gorvette_body_01"))
            }, GorvetteView.prototype.createBackLayer = function() {
                var back = new PIXI.Sprite(Common.assets.getTexture("car_gorvette_body_02")),
                    spoiler = this.createSpoilerLayer();
                return spoiler.y = 20, back.addChild(spoiler), back
            }, GorvetteView.prototype.createSpoilerLayer = function() {
                var spoiler = new PIXI.Sprite(Common.assets.getTexture("car_gorvette_spoiler_02"));
                return spoiler.anchor = new PIXI.Point(.5, 1), spoiler
            }, GorvetteView.prototype.createFrontWheel = function() {
                var sequence = new p3.MovieClipSequence;
                return sequence.addTextures([Common.assets.getTexture("car_gorvette_wheels_front_0"), Common.assets.getTexture("car_gorvette_wheels_front_1"), Common.assets.getTexture("car_gorvette_wheels_front_2"), Common.assets.getTexture("car_gorvette_wheels_front_3")]), new p3.MovieClip(sequence)
            }, GorvetteView.prototype.createRearWheel = function() {
                var sequence = new p3.MovieClipSequence;
                return sequence.addTextures([Common.assets.getTexture("car_gorvette_wheels_rear_0"), Common.assets.getTexture("car_gorvette_wheels_rear_1"), Common.assets.getTexture("car_gorvette_wheels_rear_2"), Common.assets.getTexture("car_gorvette_wheels_rear_3")]), new p3.MovieClip(sequence)
            }, GorvetteView.prototype.createShadow = function() {
                return new PIXI.Sprite(Common.assets.getTexture("car_gorvette_shadow"))
            }
        }, {
            "./CarShader": 19,
            "./CarView": 21,
            "./Common": 23
        }],
        47: [function(require, module, exports) {
            function HelpScene(type) {
                this._type = type || HelpScene.TYPE_GARAGE, this._overlay = null, this._panel = null, this._titleText = null, this._image = null, this._imageDark = null, this._box = null, this._nextButton = null, this._prevButton = null, this._closeButton = null, this._pageIndicator = null, this._helpIndex = 0, this._content = [], Scene.call(this)
            }
            var Common = require("./Common"),
                PageIndicator = require("./PageIndicator"),
                Scene = require("./Scene");
            module.exports = HelpScene, HelpScene.prototype = Object.create(Scene.prototype), HelpScene.prototype.constructor = HelpScene, HelpScene.TYPE_GARAGE = "type_garage", HelpScene.TYPE_GAME = "type_game", HelpScene.TYPE_TROPHIES = "type_trophies", HelpScene.TYPE_ACHIEVEMENTS = "type_achievements", HelpScene.prototype.init = function() {
                var graphics = new PIXI.Graphics;
                switch (graphics.beginFill(0, .64), graphics.drawRect(0, 0, 1, 1), graphics.endFill(), this._overlay = new PIXI.Sprite(graphics.generateTexture()), this._overlay.width = p3.View.width, this._overlay.height = p3.View.height, this._overlay.visible = !1, this.addChild(this._overlay), this._panel = new PIXI.Container, this._panel.x = .5 * Common.STAGE_WIDTH, this._panel.y = .5 * Common.STAGE_HEIGHT - 80, this._panel.visible = !1, this.addChild(this._panel), this._panel.header = new PIXI.Sprite(Common.assets.getTexture("ui_popup_top")), this._panel.header.x = .5 * -this._panel.header.width, this._panel.addChild(this._panel.header), this._panel.content = new PIXI.Sprite(Common.assets.getTexture("ui_popup_bottom_carbon_small")), this._panel.content.x = .5 * -this._panel.content.width, this._panel.content.y = this._panel.header.y + this._panel.header.height, this._panel.addChild(this._panel.content), this._panel.header.y -= .5 * (this._panel.header.height + this._panel.content.height), this._panel.content.y -= .5 * (this._panel.header.height + this._panel.content.height), webfont ? (this._titleText = new PIXI.Text(Common.copy.help[Common.language], {
                    font: "48px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._titleText.x = .5 * (this._panel.header.width - this._titleText.width), this._titleText.y = 24, this._panel.header.addChild(this._titleText)) : (this._titleText = new PIXI.extras.BitmapText(Common.copy.help[Common.language], {
                    font: "48px Great Escape",
                    align: "center"
                }), this._titleText.x = .5 * (this._panel.header.width - this._titleText.textWidth), this._titleText.y = 16, this._panel.header.addChild(this._titleText)), this._imageDark = new PIXI.Sprite(PIXI.Texture.EMPTY), this._imageDark.x = .5 * this._panel.content.texture.width, this._imageDark.y = .5 * this._panel.content.texture.height + 10, this._imageDark.anchor = new PIXI.Point(.5, .5), this._panel.content.addChild(this._imageDark), this._image = new PIXI.Sprite(PIXI.Texture.EMPTY), this._image.x = .5 * this._panel.content.texture.width, this._image.y = .5 * this._panel.content.texture.height + 10, this._image.anchor = new PIXI.Point(.5, .5), this._panel.content.addChild(this._image), this._image.group = new PIXI.Container, this._image.addChild(this._image.group), this._image.mask = new PIXI.Graphics, this._image.addChild(this._image.mask), this._box = new PIXI.Sprite(Common.assets.getTexture("ui_message_bg_help")), this._box.x = .5 * Common.STAGE_WIDTH, this._box.y = Common.STAGE_HEIGHT - .5 * this._box.height - 140, this._box.anchor = new PIXI.Point(.5, .5), this.addChild(this._box), this._nextButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_arrow")), this._nextButton.x = .5 * this._panel.content.texture.width - 20, this._nextButton.y = 18, this._nextButton.scale.x = this._nextButton.defaultScale.x = -1, this._nextButton.animate = !0, this._nextButton.signals.click.add(r2l ? this.onPrevButtonClick : this.onNextButtonClick, this), this._panel.addChild(this._nextButton), this._prevButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_arrow")), this._prevButton.x = .5 * -this._panel.content.texture.width + 20, this._prevButton.y = 18, this._prevButton.animate = !0, this._prevButton.signals.click.add(r2l ? this.onNextButtonClick : this.onPrevButtonClick, this), this._panel.addChild(this._prevButton), this._closeButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_btn_close")), this._closeButton.x = .5 * (this._panel.header.width - this._closeButton.width) - 18, this._closeButton.y = -190, this._closeButton.animate = !0, this._closeButton.overSoundName = "sfx_ui_btn_rollover_00", this._closeButton.downSoundName = "sfx_ui_btn_press_00", this._closeButton.signals.click.add(this.onCloseButtonClick, this), this._panel.addChild(this._closeButton), webfont ? (this._box.text = new PIXI.Text("", {
                    font: "28px Arial",
                    fill: "#FFFFFF",
                    align: r2l ? "center" : "left"
                }), this._box.addChild(this._box.text)) : (this._box.text = new PIXI.extras.BitmapText("", {
                    font: "28px Great Escape Italic",
                    align: r2l ? "center" : "left"
                }), this._box.addChild(this._box.text)), this._type) {
                    case HelpScene.TYPE_GARAGE:
                        this._content = [{
                            text: Common.copy.help_garage1[Common.language],
                            texture: Common.assets.getTexture("ui_help1")
                        }, {
                            text: Common.copy.help_garage2[Common.language],
                            texture: Common.assets.getTexture("ui_help1")
                        }, {
                            text: Common.copy.help_garage3[Common.language],
                            texture: Common.assets.getTexture("ui_help1")
                        }, {
                            text: Common.copy.help_garage4[Common.language],
                            texture: Common.assets.getTexture("ui_help1")
                        }, {
                            text: Common.copy.help_garage5[Common.language],
                            texture: Common.assets.getTexture("ui_help1")
                        }, {
                            text: Common.copy.help_garage6[Common.language],
                            texture: Common.assets.getTexture("ui_help1")
                        }];
                        break;
                    case HelpScene.TYPE_GAME:
                        this._content = [p3.Device.isMobile ? {
                            text: Common.copy.help_game1b[Common.language],
                            texture: Common.assets.getTexture("ui_help2")
                        } : {
                            text: Common.copy.help_game1[Common.language],
                            texture: Common.assets.getTexture("ui_help2")
                        }, {
                            text: Common.copy.help_game2[Common.language],
                            texture: Common.assets.getTexture("ui_help2")
                        }, {
                            text: Common.copy.help_game3[Common.language],
                            texture: Common.assets.getTexture("ui_help2")
                        }, {
                            text: Common.copy.help_game4[Common.language],
                            texture: Common.assets.getTexture("ui_help2")
                        }, {
                            text: Common.copy.help_game5[Common.language],
                            texture: Common.assets.getTexture("ui_help2")
                        }, {
                            text: Common.copy.help_game6[Common.language],
                            texture: Common.assets.getTexture("ui_help2")
                        }, {
                            text: Common.copy.help_game7[Common.language],
                            texture: Common.assets.getTexture("ui_help2")
                        }];
                        break;
                    case HelpScene.TYPE_TROPHIES:
                        this._content = [{
                            text: Common.copy.help_trophies1[Common.language],
                            texture: Common.assets.getTexture("ui_help3")
                        }];
                        break;
                    case HelpScene.TYPE_ACHIEVEMENTS:
                        this._content = [{
                            text: Common.copy.help_achievements1[Common.language],
                            texture: Common.assets.getTexture("ui_help4")
                        }]
                }
                this._pageIndicator = new PageIndicator(this._content.length, r2l), this._pageIndicator.x = .5 * Common.STAGE_WIDTH, this._pageIndicator.y = 708, this._pageIndicator.select(this._helpIndex), this.addChild(this._pageIndicator), this.show(this._helpIndex)
            }, HelpScene.prototype.dispose = function() {
                Common.animator.removeAll(), Scene.prototype.dispose.call(this)
            }, HelpScene.prototype.appear = function() {
                this.animateIn()
            }, HelpScene.prototype.show = function(index) {
                var content = this._content[index],
                    text = content.text;
                switch (this._image.texture = content.texture, this._image.group.removeChildren(), this._imageDark.texture = content.texture, this._imageDark.tint = 5592405, this._image.mask.clear(), webfont ? (this._box.text.text = text, this._box.text.x = .5 * -this._box.text.width, this._box.text.y = .5 * -this._box.text.height) : (this._box.text.text = text, this._box.text.validate(), this._box.text.x = .5 * -this._box.text.textWidth,
                    this._box.text.y = .5 * -this._box.text.textHeight), this._type) {
                    case HelpScene.TYPE_GARAGE:
                        switch (index) {
                            case 0:
                                this._image.mask.beginFill(16711680), this._image.mask.drawCircle(-283, -20, 40), this._image.mask.drawCircle(283, -20, 40), this._image.mask.endFill();
                                break;
                            case 1:
                                this._image.mask.beginFill(16711680), this._image.mask.drawCircle(-116, 100, 40), this._image.mask.drawCircle(-38, 100, 40), this._image.mask.endFill();
                                break;
                            case 2:
                                this._image.mask.beginFill(16711680), this._image.mask.drawCircle(39, 100, 40), this._image.mask.endFill();
                                break;
                            case 3:
                                this._image.mask.beginFill(16711680), this._image.mask.drawCircle(116, 100, 40), this._image.mask.endFill();
                                break;
                            case 4:
                                this._image.mask.beginFill(16711680), this._image.mask.drawCircle(271, 98, 48), this._image.mask.endFill();
                                break;
                            case 5:
                                this._image.mask.beginFill(16711680), this._image.mask.drawCircle(282, -176, 26), this._image.mask.endFill()
                        }
                        break;
                    case HelpScene.TYPE_GAME:
                        switch (index) {
                            case 0:
                                var keys = new PIXI.Sprite(Common.assets.getTexture("ui_icon_tutorial_steer"));
                                keys.y = -84, keys.scale = new PIXI.Point(.8, .8), keys.anchor = new PIXI.Point(.5, .5), this._image.group.addChild(keys);
                                break;
                            case 1:
                                this._image.mask.beginFill(16711680), this._image.mask.drawCircle(-72, 0, 48), this._image.mask.endFill();
                                break;
                            case 2:
                                this._image.mask.beginFill(16711680), this._image.mask.drawCircle(6, -48, 32), this._image.mask.endFill();
                                break;
                            case 3:
                                this._image.mask.beginFill(16711680), this._image.mask.drawCircle(194, -18, 48), this._image.mask.endFill();
                                break;
                            case 4:
                                this._image.mask.beginFill(16711680), this._image.mask.drawCircle(-305, -138, 80), this._image.mask.endFill();
                                break;
                            case 5:
                                this._image.mask.beginFill(16711680), this._image.mask.drawCircle(320, 91, 74), this._image.mask.endFill();
                                break;
                            case 6:
                                this._image.mask.beginFill(16711680), this._image.mask.drawCircle(329, -169, 26), this._image.mask.endFill()
                        }
                        break;
                    case HelpScene.TYPE_ACHIEVEMENTS:
                        switch (index) {
                            case 0:
                        }
                    case HelpScene.TYPE_TROPHIES:
                        switch (index) {
                            case 0:
                        }
                }
                var pages = this._content.length > 1;
                this._nextButton.visible = pages, this._prevButton.visible = pages, this._pageIndicator.visible = pages
            }, HelpScene.prototype.animateIn = function(callback, scope) {
                Scene.prototype.animateIn.call(this, callback, scope), this._overlay.alpha = 0, this._overlay.visible = !0, TweenMax.to(this._overlay, .2, {
                    alpha: 1,
                    ease: Power1.easeInOut
                });
                var x = this._panel.x;
                this._panel.x = .5 * (Common.STAGE_WIDTH - p3.View.width - this._panel.width), this._panel.visible = !0, TweenMax.to(this._panel, .3, {
                    x: x,
                    ease: Back.easeOut,
                    easeParams: [1]
                })
            }, HelpScene.prototype.animateOut = function(callback, scope) {
                Scene.prototype.animateOut.call(this, callback, scope), TweenMax.to(this._overlay, .4, {
                    alpha: 0,
                    ease: Power1.easeInOut,
                    onComplete: function() {
                        this._overlay.visible = !1
                    },
                    onCompleteScope: this
                }), TweenMax.to(this._panel, .26, {
                    x: .5 * (Common.STAGE_WIDTH + p3.View.width + this._panel.width),
                    ease: Back.easeIn,
                    easeParams: [1],
                    onComplete: function() {
                        this._panel.visible = !1, callback && callback.call(scope)
                    },
                    onCompleteScope: this
                })
            }, HelpScene.prototype.resize = function() {
                this.x = .5 * (p3.View.width - Common.STAGE_WIDTH), this._overlay.x = .5 * (Common.STAGE_WIDTH - p3.View.width), this._overlay.y = .5 * (Common.STAGE_HEIGHT - p3.View.height), this._overlay.width = p3.View.width, this._overlay.height = p3.View.height
            }, HelpScene.prototype.update = function() {}, HelpScene.prototype.onNextButtonClick = function(button) {
                ++this._helpIndex >= this._content.length && (this._helpIndex = 0), this.show(this._helpIndex), this._pageIndicator.select(this._helpIndex)
            }, HelpScene.prototype.onPrevButtonClick = function(button) {
                --this._helpIndex < 0 && (this._helpIndex = this._content.length - 1), this.show(this._helpIndex), this._pageIndicator.select(this._helpIndex)
            }, HelpScene.prototype.onCloseButtonClick = function(button) {
                this._closeButton.interactive = !1, this._closeButton.onMouseOut(), this.animateOut(function() {
                    this.signals.next.dispatch()
                }, this)
            }
        }, {
            "./Common": 23,
            "./PageIndicator": 57,
            "./Scene": 83
        }],
        48: [function(require, module, exports) {
            function Hud() {
                this.signals = {}, this.signals.pause = new signals.Signal, this.signals.boost = new signals.Signal, this._laps = null, this._time = null, this._nitro = null, this._nitroTarget = 0, this._nitroSmooth = 0, this._ladder = null, this._pauseButton = null, this._announcer = null, this._announcerTimeout = null, this._isAnnouncing = !1, this._lights = null, PIXI.Container.call(this)
            }
            var Common = require("./Common"),
                ControlTypes = require("./ControlTypes"),
                MessagePopup = require("./MessagePopup"),
                RaceLadder = require("./RaceLadder"),
                SplashOverlayEffect = require("./SplashOverlayEffect"),
                StartingLights = require("./StartingLights"),
                TurboButton = require("./TurboButton");
            module.exports = Hud, Hud.prototype = Object.create(PIXI.Container.prototype), Hud.prototype.constructor = Hud, Hud.prototype.init = function() {
                this._laps = new PIXI.Sprite(Common.assets.getTexture("ui_laps_bg")), this._laps.x = .5 * Common.STAGE_WIDTH, this._laps.y = 108, this._laps.anchor = new PIXI.Point(.5, .5), this.addChild(this._laps), this._laps.text = new PIXI.extras.BitmapText("1/3", {
                    font: "38px Great Escape",
                    align: "right"
                }), this._laps.text.y = .5 * -this._laps.text.textHeight - 2, this._laps.addChild(this._laps.text), this._time = new PIXI.Sprite(Common.assets.getTexture("ui_time_bg")), this._time.y = 108, this._time.anchor = new PIXI.Point(.5, .5), this.addChild(this._time), this._time.text = new PIXI.extras.BitmapText("00:00:00", {
                    font: "38px Great Escape",
                    align: "center"
                }), this._time.text.x = -94, this._time.text.y = .5 * -this._time.text.textHeight - 2, this._time.addChild(this._time.text), this._nitro = new PIXI.Sprite(Common.assets.getTexture("ui_gameplay_boost_bg")), this._nitro.y = Common.STAGE_HEIGHT - .5 * this._nitro.texture.height - 24, this._nitro.anchor = new PIXI.Point(.5, .5), this.addChild(this._nitro), this._nitro.units = [];
                for (var unit, angle, start = 140, spacing = 10, radius = 96, offset = new PIXI.Point(14, 10), i = 0; 18 > i; ++i) angle = (start + spacing * i) * PIXI.DEG_TO_RAD, unit = new PIXI.Sprite(Common.assets.getTexture("ui_boost_unit_off")), unit.x = offset.x + Math.cos(angle) * radius, unit.y = offset.y + Math.sin(angle) * radius, unit.rotation = angle + .5 * Math.PI, unit.anchor = new PIXI.Point(.5, .5), this._nitro.addChild(unit), this._nitro.units.push(unit);
                this._nitro.button = new TurboButton, this._nitro.button.x = 14, this._nitro.button.y = 9, this._nitro.button.animate = !0, this._nitro.button.signals.click.add(this.onBoostButtonDown, this), this._nitro.addChild(this._nitro.button), this._ladder = new RaceLadder, this._ladder.y = 74, this.addChild(this._ladder), this._pauseButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_pause")), this._pauseButton.y = 120, this._pauseButton.animate = !0, this._pauseButton.signals.click.add(this.onPauseButtonClick, this), this.addChild(this._pauseButton), this.updateLap(0, 3), this.updateNitroFuel(0), this._announcer = new MessagePopup(-1, MessagePopup.CHARACTER_DARRELL, "1"), this._announcer.y = p3.View.height - this._announcer.height - 20, this._announcer.animateIn(), this._announcer.interactiveChildren = !1, this.addChild(this._announcer)
            }, Hud.prototype.destroy = function() {
                this.signals.pause.dispose(), this.signals.boost.dispose(), this._lights.destroy(), PIXI.Container.prototype.destroy.call(this)
            }, Hud.prototype.resize = function() {
                this._time.x = .5 * (Common.STAGE_WIDTH + p3.View.width) - 296, this._nitro.x = .5 * (Common.STAGE_WIDTH + p3.View.width) - .5 * this._nitro.texture.width - 8, this._ladder.x = .5 * (Common.STAGE_WIDTH - p3.View.width) + 40, this._pauseButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width - Math.abs(this._pauseButton.width)) - 28, this._announcer.x = .5 * (Common.STAGE_WIDTH - p3.View.width) + 20
            }, Hud.prototype.update = function(nitro) {
                this._nitroSmooth += .14 * (this._nitroTarget - this._nitroSmooth);
                var i, unit, on = Common.assets.getTexture("ui_boost_unit_on"),
                    off = Common.assets.getTexture("ui_boost_unit_off"),
                    active = Common.assets.getTexture("ui_boost_unit_active");
                for (i = 0; i < this._nitro.units.length; ++i) unit = this._nitro.units[i], unit.texture = off;
                var count = Math.round(this._nitroSmooth * this._nitro.units.length);
                for (i = 0; count > i; ++i) unit = this._nitro.units[i], unit.texture = nitro ? active : on;
                this._ladder.update(), this._nitro.button.visible = Common.garage.controls == ControlTypes.CONTROLS_EXPERT
            }, Hud.prototype.runCountdown = function(delay, callback, scope) {
                scope = scope || window;
                var country = Common.trackManager.currentTrack.country;
                this._lights = new StartingLights(country), this._lights.x = .5 * Common.STAGE_WIDTH, this._lights.y = .5 * Common.STAGE_HEIGHT, this.addChild(this._lights), this._lights.animateIn(function() {
                    this._lights.start(delay, function() {
                        callback && callback.call(scope), this._lights.animateOut()
                    }, this)
                }, this)
            }, Hud.prototype.updateLap = function(lap, total) {
                this._laps.text.text = Math.max(1, Math.min(total, lap)) + "/" + total, this._laps.text.validate(), this._laps.text.x = .5 * -this._laps.text.textWidth + 2
            }, Hud.prototype.updateTime = function(time) {
                this._time.text.text = Common.garage.formatTime(time), this._time.text.validate()
            }, Hud.prototype.updateNitroFuel = function(value, boost) {
                value = Math.min(1, Math.max(0, value)), this._nitroTarget = value, 1 == value ? this._nitro.button.startAnimateFull(-1) : boost || this._nitro.button.stopAnimateFull()
            }, Hud.prototype.announce = function(message, squelch) {
                squelch = "boolean" == typeof squelch ? squelch : !0, this._isAnnouncing || squelch && this._announcerTimeout || (this._isAnnouncing = !0, squelch && (this._announcerTimeout = delay(function() {
                    this._announcerTimeout = null
                }, 8, this)), this._announcer.message = message, this._announcer.show(2, function() {
                    this._isAnnouncing = !1
                }, this))
            }, Hud.prototype.showSplashEffect = function(type) {
                var overlay = new SplashOverlayEffect(type);
                overlay.show(), this.addChild(overlay)
            }, Hud.prototype.onPauseButtonClick = function(button) {
                this.signals.pause.dispatch()
            }, Hud.prototype.onBoostButtonDown = function(button) {
                this.signals.boost.dispatch()
            }, Object.defineProperty(Hud.prototype, "ladder", {
                get: function() {
                    return this._ladder
                }
            }), Object.defineProperty(Hud.prototype, "announcer", {
                get: function() {
                    return this._announcer
                }
            }), Object.defineProperty(Hud.prototype, "turboButton", {
                get: function() {
                    return this._nitro.button
                }
            })
        }, {
            "./Common": 23,
            "./ControlTypes": 26,
            "./MessagePopup": 54,
            "./RaceLadder": 69,
            "./SplashOverlayEffect": 95,
            "./StartingLights": 97,
            "./TurboButton": 107
        }],
        49: [function(require, module, exports) {
            function ImageCarrousel(textures, startIndex) {
                PIXI.Container.call(this), this.signals = {}, this.spacing = 60, this._index = startIndex || 0, this._textures = textures.slice(), this._currentImage = new PIXI.Sprite(this._textures[this._index]), this._currentImage.anchor = new PIXI.Point(.5, .5), this.addChild(this._currentImage)
            }
            require("./Common");
            module.exports = ImageCarrousel, ImageCarrousel.prototype = Object.create(PIXI.Container.prototype), ImageCarrousel.prototype.constructor = ImageCarrousel, ImageCarrousel.prototype.nextImage = function() {
                ++this._index >= this._textures.length && (this._index = 0);
                var next = new PIXI.Sprite(this._textures[this._index]);
                next.anchor = new PIXI.Point(.5, .5), TweenMax.killTweensOf(this._currentImage), TweenMax.killTweensOf(this._currentImage.scale), TweenMax.to(this._currentImage, .4, {
                    x: this._currentImage.x - 160,
                    ease: Power1.easeOut,
                    onComplete: function(image) {
                        image.parent.removeChild(image)
                    },
                    onCompleteParams: [this._currentImage],
                    onCompleteScope: this
                }), TweenMax.to(this._currentImage, .3, {
                    delay: .04,
                    alpha: 0,
                    ease: Power1.easeIn
                }), TweenMax.to(this._currentImage.scale, .3, {
                    delay: .04,
                    x: .8,
                    y: .8,
                    ease: Power1.easeIn
                }), this._currentImage = next, this.addChild(this._currentImage), this._currentImage.x = 180, this._currentImage.scale = new PIXI.Point, this._currentImage.alpha = 0, TweenMax.to(this._currentImage, .4, {
                    x: 0,
                    ease: Power1.easeOut
                }), TweenMax.to(this._currentImage, .3, {
                    alpha: 1,
                    ease: Power1.easeOut
                }), TweenMax.to(this._currentImage.scale, .34, {
                    x: 1,
                    y: 1,
                    ease: Back.easeOut
                }), this.animateFloat(this._currentImage)
            }, ImageCarrousel.prototype.prevImage = function() {
                --this._index < 0 && (this._index = this._textures.length - 1);
                var next = new PIXI.Sprite(this._textures[this._index]);
                next.anchor = new PIXI.Point(.5, .5), TweenMax.killTweensOf(this._currentImage), TweenMax.killTweensOf(this._currentImage.scale), TweenMax.to(this._currentImage, .4, {
                    x: this._currentImage.x + 160,
                    ease: Power1.easeOut,
                    onComplete: function(image) {
                        image.parent.removeChild(image)
                    },
                    onCompleteParams: [this._currentImage],
                    onCompleteScope: this
                }), TweenMax.to(this._currentImage, .3, {
                    delay: .04,
                    alpha: 0,
                    ease: Power1.easeIn
                }), TweenMax.to(this._currentImage.scale, .3, {
                    delay: .04,
                    x: .8,
                    y: .8,
                    ease: Power1.easeIn
                }), this._currentImage = next, this.addChild(this._currentImage), this._currentImage.x = -180, this._currentImage.scale = new PIXI.Point, this._currentImage.alpha = 0, TweenMax.to(this._currentImage, .4, {
                    x: 0,
                    ease: Power1.easeOut
                }), TweenMax.to(this._currentImage, .3, {
                    alpha: 1,
                    ease: Power1.easeOut
                }), TweenMax.to(this._currentImage.scale, .34, {
                    x: 1,
                    y: 1,
                    ease: Back.easeOut
                }), this.animateFloat(this._currentImage)
            }, ImageCarrousel.prototype.animateIn = function(callback, scope) {
                this._currentImage.alpha = 0, TweenMax.to(this._currentImage, .2, {
                    alpha: 1,
                    ease: Power1.easeInOut
                }), this.animateFloat(this._currentImage)
            }, ImageCarrousel.prototype.animateFloat = function(target, frequency, amplitude) {
                frequency = frequency || 1.4, amplitude = amplitude || 8, TweenMax.to(target, .5 * frequency, {
                    y: target.y + .5 * amplitude,
                    ease: Power1.easeOut,
                    onComplete: function() {
                        TweenMax.to(target, frequency, {
                            y: target.y - amplitude,
                            ease: Power1.easeInOut,
                            repeat: -1,
                            yoyo: !0
                        })
                    },
                    onCompleteScope: this
                })
            }
        }, {
            "./Common": 23
        }],
        50: [function(require, module, exports) {
            function Input() {
                this.isKeyUp = !1, this.isKeyLeft = !1, this.isKeyRight = !1, this.isKeyDown = !1, this.isKeyFire = !1, this.isKeyUpPressed = !1, this.isKeyLeftPressed = !1, this.isKeyRightPressed = !1, this.isKeyDownPressed = !1, this.isKeyFirePressed = !1, this.touch = new PIXI.Point, this.isTouch = !1, this.isTouchPressed = !1, this.gamma = 0, this.beta = 0, this.alpha = 0, this.signals = {}, this.signals.mouseMove = new signals.Signal, this.signals.mouseDown = new signals.Signal, this.signals.mouseUp = new signals.Signal, this.signals.mouseClick = new signals.Signal, this.signals.keyDown = new signals.Signal, this.signals.keyUp = new signals.Signal, this.signals.keyPressed = new signals.Signal, this.signals.accelerometer = new signals.Signal, this._stage = null
            }
            module.exports = Input, Input.keys = {}, Input.keys.W = 87, Input.keys.A = 65, Input.keys.S = 83, Input.keys.D = 68, Input.keys.UP = 38, Input.keys.LEFT = 37, Input.keys.DOWN = 40, Input.keys.RIGHT = 39, Input.keys.ENTER = 13, Input.prototype.init = function(stage, keyListener) {
                this._stage = stage, this._stage.interactive = !0, this._stage.mousemove = this._stage.touchmove = this.onMouseMove.bind(this), this._stage.mousedown = this._stage.touchstart = this.onMouseDown.bind(this), this._stage.mouseup = this._stage.touchend = this.onMouseUp.bind(this), this._stage.click = this._stage.tap = this.onMouseClick.bind(this), keyListener.onkeydown = this.onKeyDown.bind(this), keyListener.onkeyup = this.onKeyUp.bind(this), keyListener.focus(), document.onclick = function(event) {
                    keyListener.focus()
                }, p3.Device.isMobile && window.addEventListener("deviceorientation", this.onDeviceOrientation.bind(this))
            }, Input.prototype.dispose = function() {
                this._stage.mousemove = this._stage.touchmove = null, this._stage.mousedown = this._stage.touchstart = null, this._stage.mouseup = this._stage.touchend = null, this._stage.click = this._stage.tap = null, p3.Device.isMobile && window.removeEventListener("deviceorientation", this.onDeviceOrientation), this.signals.mouseMove.dispose(), this.signals.mouseDown.dispose(), this.signals.mouseUp.dispose(), this.signals.mouseClick.dispose(), this.signals.keyDown.dispose(), this.signals.keyUp.dispose(), this.signals.keyPressed.dispose(), this.signals.accelerometer.dispose()
            }, Input.prototype.update = function() {
                this.isKeyUpPressed = !1, this.isKeyLeftPressed = !1, this.isKeyRightPressed = !1, this.isKeyDownPressed = !1, this.isKeyFirePressed = !1, this.isTouchPressed = !1
            }, Input.prototype.onMouseMove = function(event) {
                this.touch = event.data.getLocalPosition(this._stage), p3.Timestep.queueCall(function() {
                    this.signals.mouseMove.dispatch(event)
                }, [], this)
            }, Input.prototype.onMouseDown = function(event) {
                this.touch = event.data.getLocalPosition(this._stage), this.isTouch = !0, this.isTouchPressed = !0, p3.Timestep.queueCall(function() {
                    this.signals.mouseDown.dispatch(event)
                }, [], this)
            }, Input.prototype.onMouseUp = function(event) {
                this.touch = event.data.getLocalPosition(this._stage), this.isTouch = !1, p3.Timestep.queueCall(function() {
                    this.signals.mouseUp.dispatch(event)
                }, [], this)
            }, Input.prototype.onMouseClick = function(event) {
                p3.Timestep.queueCall(function() {
                    this.signals.mouseClick.dispatch(event)
                }, [], this)
            }, Input.prototype.onKeyDown = function(event) {
                switch (event.keyCode) {
                    case Input.keys.UP:
                    case Input.keys.W:
                        !this.isKeyUp && (this.isKeyUpPressed = !0), this.isKeyUp = !0;
                        break;
                    case Input.keys.LEFT:
                    case Input.keys.A:
                        !this.isKeyLeft && (this.isKeyLeftPressed = !0), this.isKeyLeft = !0;
                        break;
                    case Input.keys.DOWN:
                    case Input.keys.S:
                        !this.isKeyDown && (this.isKeyDownPressed = !0), this.isKeyDown = !0;
                        break;
                    case Input.keys.RIGHT:
                    case Input.keys.D:
                        !this.isKeyRight && (this.isKeyRightPressed = !0), this.isKeyRight = !0;
                        break;
                    case Input.keys.ENTER:
                        !this.isKeyFire && (this.isKeyFirePressed = !0), this.isKeyFire = !0
                }
                event.keyCode != Input.keys.UP && event.keyCode != Input.keys.DOWN || event.preventDefault(), p3.Timestep.queueCall(function() {
                    this.signals.keyDown.dispatch(event)
                }, [], this)
            }, Input.prototype.onKeyUp = function(event) {
                switch (event.keyCode) {
                    case Input.keys.UP:
                    case Input.keys.W:
                        this.isKeyUp = !1;
                        break;
                    case Input.keys.LEFT:
                    case Input.keys.A:
                        this.isKeyLeft = !1;
                        break;
                    case Input.keys.DOWN:
                    case Input.keys.S:
                        this.isKeyDown = !1;
                        break;
                    case Input.keys.RIGHT:
                    case Input.keys.D:
                        this.isKeyRight = !1;
                        break;
                    case Input.keys.ENTER:
                        this.isKeyFire = !1
                }
                p3.Timestep.queueCall(function() {
                    this.signals.keyUp.dispatch(event)
                }, [], this)
            }, Input.prototype.onDeviceOrientation = function(event) {
                this.gamma = event.gamma, this.beta = event.beta, this.alpha = event.alpha, p3.Timestep.queueCall(function() {
                    this.signals.accelerometer.dispatch(event)
                }, [], this)
            }
        }, {}],
        51: [function(require, module, exports) {
            function LeaderboardScene() {
                this._overlay = null, this._panel = null, this._closeButton = null, this._nextButton = null, this._prevButton = null, this._trackIcon = null, this._nameText = null, this._todayText = null, this._weekText = null, this._allText = null, this._scrollView = null, this._scroller = null, this._scoreIndex = 0, Scene.call(this)
            }
            var Common = require("./Common"),
                CountryTypes = require("./CountryTypes"),
                Scene = require("./Scene"),
                Scores = require("./Scores"),
                Scroller = require("./Scroller"),
                ScrollView = require("./ScrollView"),
                TrackData = require("./TrackData");
            module.exports = LeaderboardScene, LeaderboardScene.prototype = Object.create(Scene.prototype), LeaderboardScene.prototype.constructor = LeaderboardScene, LeaderboardScene.prototype.init = function() {
                var track = Common.trackManager.currentTrack,
                    graphics = new PIXI.Graphics;
                graphics.beginFill(0, .74), graphics.drawRect(0, 0, 1, 1), graphics.endFill(), this._overlay = new PIXI.Sprite(graphics.generateTexture()), this._overlay.width = p3.View.width, this._overlay.height = p3.View.height, this._overlay.visible = !1, this.addChild(this._overlay), this._panel = new PIXI.Container, this._panel.x = .5 * Common.STAGE_WIDTH, this._panel.y = .5 * Common.STAGE_HEIGHT, this._panel.visible = !1, this.addChild(this._panel), this._panel.header = new PIXI.Sprite(Common.assets.getTexture("ui_popup_top_high")), this._panel.header.x = .5 * -this._panel.header.width, this._panel.addChild(this._panel.header), this._panel.content = new PIXI.Sprite(Common.assets.getTexture("ui_popup_bottom_carbon")), this._panel.content.x = .5 * -this._panel.content.width, this._panel.content.y = this._panel.header.y + this._panel.header.height, this._panel.addChildAt(this._panel.content, 0), this._panel.content.top = new PIXI.Sprite(Common.assets.getTexture("ui_popup_leaderboard")), this._panel.content.addChild(this._panel.content.top), this._panel.header.y -= .5 * (this._panel.header.height + this._panel.content.height), this._panel.content.y -= .5 * (this._panel.header.height + this._panel.content.height), webfont ? (this._titleText = new PIXI.Text(Common.copy.leaderboard[Common.language], {
                    font: "48px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._titleText.x = .5 * (this._panel.header.width - this._titleText.width), this._titleText.y = 16, this._panel.header.addChild(this._titleText)) : (this._titleText = new PIXI.extras.BitmapText(Common.copy.leaderboard[Common.language], {
                    font: "48px Great Escape",
                    align: "center"
                }), this._titleText.x = .5 * (this._panel.header.width - this._titleText.textWidth), this._titleText.y = 12, this._panel.header.addChild(this._titleText)), webfont ? (this._nameText = new PIXI.Text(track.name, {
                    font: "48px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._nameText.x = .5 * (this._panel.header.width - this._nameText.width), this._nameText.y = 66, this._panel.header.addChild(this._nameText)) : (this._nameText = new PIXI.extras.BitmapText(track.name, {
                    font: "48px Great Escape",
                    align: "center"
                }), this._nameText.x = .5 * (this._panel.header.width - this._nameText.textWidth), this._nameText.y = 62, this._panel.header.addChild(this._nameText)), webfont ? (this._todayText = new PIXI.Text(Common.copy.leaderboard_today[Common.language], {
                    font: "32px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._todayText.x = .5 * -this._todayText.width - 180, this._todayText.y = -154, this._panel.addChild(this._todayText)) : (this._todayText = new PIXI.extras.BitmapText(Common.copy.leaderboard_today[Common.language], {
                    font: "32px Great Escape",
                    align: "center"
                }), this._todayText.x = .5 * -this._todayText.textWidth - 180, this._todayText.y = -158, this._panel.addChild(this._todayText)), webfont ? (this._weekText = new PIXI.Text(Common.copy.leaderboard_week[Common.language], {
                    font: "32px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._weekText.x = .5 * -this._weekText.width, this._weekText.y = -154, this._weekText.tint = 455935, this._panel.addChild(this._weekText)) : (this._weekText = new PIXI.extras.BitmapText(Common.copy.leaderboard_week[Common.language], {
                    font: "32px Great Escape",
                    align: "center"
                }), this._weekText.x = .5 * -this._weekText.textWidth, this._weekText.y = -158, this._weekText.tint = 455935, this._panel.addChild(this._weekText)), webfont ? (this._timeText = new PIXI.Text(Common.copy.leaderboard_all[Common.language], {
                    font: "32px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._timeText.x = .5 * -this._timeText.width + 180, this._timeText.y = -154, this._timeText.tint = 455935, this._panel.addChild(this._timeText)) : (this._timeText = new PIXI.extras.BitmapText(Common.copy.leaderboard_all[Common.language], {
                    font: "32px Great Escape",
                    align: "center"
                }), this._timeText.x = .5 * -this._timeText.textWidth + 180, this._timeText.y = -158, this._timeText.tint = 455935, this._panel.addChild(this._timeText)), this._nextButton = new p3.Button(Common.assets.getTexture("ui_btn_arrow_up"), Common.assets.getTexture("ui_btn_arrow_over"), Common.assets.getTexture("ui_btn_arrow_down")), this._nextButton.x = 400, this._nextButton.scale.x = this._nextButton.defaultScale.x = -1, this._nextButton.animate = !0, this._nextButton.overSoundName = "sfx_ui_btn_rollover_00", this._nextButton.downSoundName = "sfx_ui_btn_press_00", this._nextButton.clickSoundName = "sfx_ui_btn_nextcar_02", this._nextButton.signals.click.add(this.onNextButtonClick, this), this._panel.addChild(this._nextButton), this._prevButton = new p3.Button(Common.assets.getTexture("ui_btn_arrow_up"), Common.assets.getTexture("ui_btn_arrow_over"), Common.assets.getTexture("ui_btn_arrow_down")), this._prevButton.x = -400, this._prevButton.animate = !0, this._prevButton.overSoundName = "sfx_ui_btn_rollover_00", this._prevButton.downSoundName = "sfx_ui_btn_press_00", this._prevButton.clickSoundName = "sfx_ui_btn_nextcar_02", this._prevButton.signals.click.add(this.onPrevButtonClick, this), this._panel.addChild(this._prevButton), this._closeButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_btn_close")), this._closeButton.x = .5 * (this._panel.header.width - this._closeButton.width) - 24, this._closeButton.y = -238, this._closeButton.animate = !0, this._closeButton.signals.click.add(this.onCloseButtonClick, this), this._panel.addChild(this._closeButton);
                var texture;
                switch (track.country) {
                    case CountryTypes.BRAZIL:
                        texture = Common.assets.getTexture("ui_btn_track_brazil");
                        break;
                    case CountryTypes.GERMANY:
                        texture = Common.assets.getTexture("ui_btn_track_germany");
                        break;
                    case CountryTypes.ITALY:
                        texture = Common.assets.getTexture("ui_btn_track_italy");
                        break;
                    case CountryTypes.JAPAN:
                        texture = Common.assets.getTexture("ui_btn_track_japan");
                        break;
                    case CountryTypes.USA:
                        texture = Common.assets.getTexture("ui_btn_track_usa")
                }
                switch (this._trackIcon = new PIXI.Sprite(Common.assets.getTexture("ui_icon_track")), this._trackIcon.x = 120, this._trackIcon.y = 74, this._trackIcon.anchor = new PIXI.Point(.5, .5), this._panel.header.addChild(this._trackIcon), this._trackIcon.flag = new PIXI.Sprite(texture), this._trackIcon.flag.anchor = new PIXI.Point(.5, .5), this._trackIcon.addChild(this._trackIcon.flag), texture = PIXI.Texture.EMPTY, track.difficulty) {
                    case TrackData.DIFFICULTY_EASY:
                        texture = Common.assets.getTexture("ui_btn_track_loop_easy");
                        break;
                    case TrackData.DIFFICULTY_INTERMEDIATE:
                        texture = Common.assets.getTexture("ui_btn_track_loop_medium");
                        break;
                    case TrackData.DIFFICULTY_HARD:
                        texture = Common.assets.getTexture("ui_btn_track_loop_hard")
                }
                switch (this._trackIcon.map = new PIXI.Sprite(texture), this._trackIcon.map.anchor = new PIXI.Point(.5, .5), this._trackIcon.addChild(this._trackIcon.map), this._trackIcon.no = new PIXI.Sprite(Common.assets.getTexture("ui_btn_track_" + (track.id % 4 + 1))), this._trackIcon.no.anchor = new PIXI.Point(.5, .5), this._trackIcon.addChild(this._trackIcon.no), texture = PIXI.Texture.EMPTY, track.reward) {
                    case 0:
                        texture = Common.assets.getTexture("ui_btn_track_gold");
                        break;
                    case 1:
                        texture = Common.assets.getTexture("ui_btn_track_silver");
                        break;
                    case 2:
                        texture = Common.assets.getTexture("ui_btn_track_bronze")
                }
                this._trackIcon.reward = new PIXI.Sprite(texture), this._trackIcon.reward.anchor = new PIXI.Point(.5, .5), this._trackIcon.addChild(this._trackIcon.reward), this._scrollView = new ScrollView(600, 375, 0, .1), this._scrollView.x = .5 * -this._scrollView.frameWidth, this._scrollView.y = -88, this._scrollView.signals.scroll.add(this.onScrollViewScroll, this), this._panel.addChild(this._scrollView), this._scroller = new Scroller, this._scroller.x = 300, this._scroller.y = -48, this._scroller.visible = !p3.Device.isMobile, this._scroller.signals.scroll.add(this.onScrollerScroll, this), this._panel.addChild(this._scroller), Common.input.signals.mouseUp.add(this.onStageMouseUp, this)
            }, LeaderboardScene.prototype.dispose = function() {
                Common.animator.removeAll(), this._scrollView.destroy(), this._scroller.destroy(), Common.input.signals.mouseUp.remove(this.onStageMouseUp), Scene.prototype.dispose.call(this)
            }, LeaderboardScene.prototype.appear = function() {
                this.animateIn(), this.loadScores(0)
            }, LeaderboardScene.prototype.show = function() {}, LeaderboardScene.prototype.animateIn = function(callback, scope) {
                this._overlay.alpha = 0, this._overlay.visible = !0, TweenMax.to(this._overlay, .34, {
                    alpha: 1,
                    ease: Power1.easeInOut
                }), this._panel.scale = new PIXI.Point, this._panel.visible = !0, TweenMax.to(this._panel.scale, .4, {
                    x: 1,
                    y: 1,
                    ease: Back.easeOut,
                    easeParams: [2]
                })
            }, LeaderboardScene.prototype.animateOut = function(callback, scope) {
                TweenMax.to(this._overlay, .34, {
                    alpha: 0,
                    ease: Power1.easeInOut,
                    onComplete: function() {
                        this._overlay.visible = !1
                    },
                    onCompleteScope: this
                }), TweenMax.to(this._panel.scale, .4, {
                    x: 0,
                    y: 0,
                    ease: Back.easeIn,
                    easeParams: [1],
                    onComplete: function() {
                        this._panel.visible = !1, callback.call(scope)
                    },
                    onCompleteScope: this
                })
            }, LeaderboardScene.prototype.resize = function() {
                this.x = .5 * (p3.View.width - Common.STAGE_WIDTH), this._overlay.x = .5 * (Common.STAGE_WIDTH - p3.View.width), this._overlay.y = .5 * (Common.STAGE_HEIGHT - p3.View.height), this._overlay.width = p3.View.width, this._overlay.height = p3.View.height
            }, LeaderboardScene.prototype.update = function() {
                this._scrollView.update()
            }, LeaderboardScene.prototype.loadScores = function(type) {
                type = type || 0, this._scrollView.content.removeChildren(), this._todayText.tint = 455935, this._weekText.tint = 455935, this._timeText.tint = 455935;
                var d, startTime, endTime = Date.now() / 1e3;
                switch (type) {
                    case 0:
                        this._todayText.tint = 16777215, startTime = endTime - 604800, d = new Date, d.setHours(0, 0, 0, 0), startTime = d.getTime() / 1e3;
                        break;
                    case 1:
                        this._weekText.tint = 16777215, d = new Date;
                        var day = d.getDay(),
                            diff = d.getDate() - day + (0 == day ? -6 : 1);
                        d = new Date(d.setDate(diff)), d.setHours(0, 0, 0, 0), startTime = d.getTime() / 1e3;
                        break;
                    case 2:
                        this._timeText.tint = 16777215, startTime = null
                }
                console.log(startTime, endTime);
                var id = highscores + Common.garage.track.id,
                    score = new Scores;
                score.getScores(id, startTime, endTime, function(response) {
                    this.displayScores(response), console.log(response)
                }, this)
            }, LeaderboardScene.prototype.displayScores = function(data) {
                this._scrollView.content.removeChildren();
                for (var entry, texture, user, spacing = 94, i = 0; i < data.results.length; ++i) user = data.results[i], entry = new PIXI.Container, entry.y = 40 + i * spacing, this._scrollView.content.addChild(entry), entry.rankText = new PIXI.extras.BitmapText((i + 1).toString(), {
                    font: "42px Great Escape",
                    align: "center"
                }), entry.rankText.x = 28 - .5 * entry.rankText.textWidth, entry.rankText.y = 0, entry.addChild(entry.rankText), entry.timeText = new PIXI.extras.BitmapText(Common.garage.formatTime(user.score_int), {
                    font: "42px Great Escape",
                    align: "center"
                }), entry.timeText.x = 360, entry.timeText.y = 0, entry.addChild(entry.timeText), texture = Common.garage.saveLicensePlate(user.name_str), entry.plate = new PIXI.Sprite(texture), entry.plate.x = 200, entry.plate.y = .5 * entry.rankText.textHeight, entry.plate.anchor = new PIXI.Point(.5, .5), entry.addChild(entry.plate);
                this._scrollView.contentHeight = spacing * data.results.length - this._scrollView.frameHeight + 40, this.resetScores()
            }, LeaderboardScene.prototype.resetScores = function() {
                this._scrollView.scroll(0, 0, !1), this._scroller.scroll(0)
            }, LeaderboardScene.prototype.onNextButtonClick = function() {
                ++this._scoreIndex >= 3 && (this._scoreIndex = 0), this.resetScores(), this.loadScores(this._scoreIndex)
            }, LeaderboardScene.prototype.onPrevButtonClick = function() {
                --this._scoreIndex < 0 && (this._scoreIndex = 2), this.resetScores(), this.loadScores(this._scoreIndex)
            }, LeaderboardScene.prototype.onCloseButtonClick = function() {
                this._closeButton.interactive = !1, this.animateOut(function() {
                    this.signals.next.dispatch()
                }, this)
            }, LeaderboardScene.prototype.onScrollerScroll = function(scroller, fraction) {
                var value = fraction * this._scrollView.contentHeight;
                this._scrollView.scroll(0, value, !0)
            }, LeaderboardScene.prototype.onScrollViewScroll = function(scrollView, position) {
                var value = position.y / this._scrollView.contentHeight * this._scroller.innerHeight;
                this._scroller.scroll(value)
            }, LeaderboardScene.prototype.onStageMouseUp = function(event) {
                this._scroller.onMouseUp(null), this._scrollView.onMouseUp(null)
            }
        }, {
            "./Common": 23,
            "./CountryTypes": 27,
            "./Scene": 83,
            "./Scores": 86,
            "./ScrollView": 87,
            "./Scroller": 88,
            "./TrackData": 101
        }],
        52: [function(require, module, exports) {
            function LightningView(avatar) {
                CarView.call(this, 16777215, avatar);
                var chassisOffset = new PIXI.Point(0, -2);
                this._shadow.offset = new PIXI.Point(0, 26), this._wheels.front.left.offset = new PIXI.Point(-82, 14), this._wheels.front.right.offset = new PIXI.Point(82, 14), this._wheels.rear.left.offset = new PIXI.Point(-124, 78), this._wheels.rear.right.offset = new PIXI.Point(124, 78), this._front.offset = new PIXI.Point(chassisOffset.x, -4 + chassisOffset.y), this._mid.offset = new PIXI.Point(chassisOffset.x, chassisOffset.y), this._back.offset = new PIXI.Point(chassisOffset.x, chassisOffset.y)
            }
            var CarView = (require("./CarShader"), require("./CarView")),
                Common = require("./Common");
            module.exports = LightningView, LightningView.prototype = Object.create(CarView.prototype), LightningView.prototype.constructor = LightningView, LightningView.prototype.update = function(distance, curvature, gradient, velocity, turnVelocity) {
                var scalar = 140;
                this._curvature += .4 * (turnVelocity + curvature - this._curvature), this._curvature = Math.max(-scalar, Math.min(scalar, this._curvature)), this._front.x = .4 * this._curvature + this._front.offset.x, this._front.y = -gradient * scalar * 1.6 + this._front.offset.y, this._mid.x = .1 * this._curvature + this._mid.offset.x, this._mid.y = -gradient * scalar * 1.3 + this._mid.offset.y, this._back.x = .14 * -this._curvature + this._back.offset.x, this._back.y = gradient * scalar + this._back.offset.y, this._shadow.x = this._back.x, this._shadow.y = this._wheels.rear.left.y + this._shadow.offset.y, this._front.rotation = 8e-4 * this._curvature, this._back.rotation = 8e-4 * this._curvature, this._wheels.front.left.x = this._front.x + this._wheels.front.left.offset.x, this._wheels.front.left.y = gradient * scalar + this._wheels.front.left.offset.y, this._wheels.front.right.x = this._front.x + this._wheels.front.right.offset.x,
                    this._wheels.front.right.y = gradient * scalar + this._wheels.front.right.offset.y, this._wheels.rear.left.x = this._back.x + this._wheels.rear.left.offset.x, this._wheels.rear.left.y = gradient * scalar + this._wheels.rear.left.offset.y, this._wheels.rear.right.x = this._back.x + this._wheels.rear.right.offset.x, this._wheels.rear.right.y = gradient * scalar + this._wheels.rear.right.offset.y;
                var theta;
                theta = .008 * turnVelocity, 0 > theta && (theta *= .112), this._wheels.front.left.rotation = theta, theta = .008 * turnVelocity, theta > 0 && (theta *= .112), this._wheels.front.right.rotation = theta, theta = .008 * turnVelocity, 0 > theta && (theta *= .112), this._wheels.rear.left.rotation = theta, theta = .008 * turnVelocity, theta > 0 && (theta *= .112), this._wheels.rear.right.rotation = theta, velocity = Math.max(0, velocity), this._wheels.front.left.animationSpeed = velocity / .2, this._wheels.front.right.animationSpeed = velocity / .2, this._wheels.rear.left.animationSpeed = velocity / .2, this._wheels.rear.right.animationSpeed = velocity / .2
            }, LightningView.prototype.createFrontLayer = function() {
                return new PIXI.Sprite(Common.assets.getTexture("car_lightning_body_00"))
            }, LightningView.prototype.createMidLayer = function() {
                return new PIXI.Sprite(Common.assets.getTexture("car_lightning_body_01"))
            }, LightningView.prototype.createBackLayer = function() {
                var back = new PIXI.Sprite(Common.assets.getTexture("car_lightning_body_02")),
                    spoiler = this.createSpoilerLayer();
                return spoiler.y = 20, back.addChild(spoiler), back
            }, LightningView.prototype.createSpoilerLayer = function() {
                var spoiler = new PIXI.Sprite(Common.assets.getTexture("car_lightning_spoiler_02"));
                return spoiler.anchor = new PIXI.Point(.5, 1), spoiler
            }, LightningView.prototype.createFrontWheel = function() {
                var sequence = new p3.MovieClipSequence;
                return sequence.addTextures([Common.assets.getTexture("car_lightning_wheels_front_0"), Common.assets.getTexture("car_lightning_wheels_front_1"), Common.assets.getTexture("car_lightning_wheels_front_2"), Common.assets.getTexture("car_lightning_wheels_front_3")]), new p3.MovieClip(sequence)
            }, LightningView.prototype.createRearWheel = function() {
                var sequence = new p3.MovieClipSequence;
                return sequence.addTextures([Common.assets.getTexture("car_lightning_wheels_rear_0"), Common.assets.getTexture("car_lightning_wheels_rear_1"), Common.assets.getTexture("car_lightning_wheels_rear_2"), Common.assets.getTexture("car_lightning_wheels_rear_3")]), new p3.MovieClip(sequence)
            }, LightningView.prototype.createShadow = function() {
                return new PIXI.Sprite(Common.assets.getTexture("car_lightning_shadow"))
            }
        }, {
            "./CarShader": 19,
            "./CarView": 21,
            "./Common": 23
        }],
        53: [function(require, module, exports) {
            function Main(width, height) {
                this._width = width, this._height = height, this._preloader = null, this._game = null
            }
            var Application = require("./Application"),
                AudioManager = require("./AudioManager"),
                Common = require("./Common"),
                Input = require("./Input"),
                PreloaderScene = require("./PreloaderScene"),
                SceneManager = require("./SceneManager");
            window.Main = Main, Main.prototype.init = function() {
                var params = new p3.ViewParams;
                params.holderId = "game", params.width = this._width, params.height = this._height, params.rotateImageUrl = "./rotate_device.png", params.rotateImageColor = "#000000", PIXI.RETINA_PREFIX = /\_(?=[^_]*$)(.+)x/, p3.Device.init(window.bowser), TweenMax.defaultOverwrite = "none", TweenMax.ticker.fps(60), Common.assets = p3.AssetManager.instance, Common.audio = p3.Button.audio = new AudioManager;
                var view = new p3.View(params);
                view.signals.ready.addOnce(function(canvas) {
                    var options = {};
                    options.view = canvas, options.transparent = !1, options.antialias = !1, options.preserveDrawingBuffer = !1, options.resolution = 1;
                    var stage = new PIXI.Container;
                    Common.stage = stage;
                    var input = new Input;
                    input.init(stage, canvas), Common.input = input, p3.Device.isCocoonJS && (stage.scale.x = window.innerHeight / params.height, stage.scale.y = window.innerHeight / params.height);
                    var renderer = p3.Device.isCocoonJS ? new PIXI.WebGLRenderer(window.innerWidth, window.innerHeight, options) : PIXI.autoDetectRenderer(this._width, this._height, options);
                    renderer.backgroundColor = 10842, Common.renderer = renderer, Common.isWebGL = renderer instanceof PIXI.WebGLRenderer;
                    var sm = new SceneManager(renderer);
                    Common.scene = sm, Common.stage.addChild(sm.view);
                    var timestep = new p3.Timestep(p3.Timestep.FIXED);
                    timestep.init(this.update, this.render, this), Common.timestep = timestep, Common.animator = new p3.Animator, Common.animator.init(), window.delay = function(callback, delay, scope) {
                        return Common.animator.setTimeout(callback, delay, scope)
                    }, this.loadPreloader()
                }, this), view.signals.resize.add(this.onCanvasResize, this), Common.view = view
            }, Main.prototype.gameStart = Main.prototype.init, Main.prototype.loadPreloader = function() {
                var prefix = "hd/",
                    files = [{
                        name: "ui_splash_cars_logo",
                        url: "images/localized/ui_splash_cars_logo.png"
                    }, {
                        name: "ui_bg_main_menu",
                        url: "images/" + prefix + "ui_bg_main_menu.jpg"
                    }, {
                        name: "loading0",
                        url: "images/" + prefix + "loading0.json"
                    }, {
                        name: "copy",
                        url: "strings/strings.json"
                    }, {
                        name: "config",
                        url: "strings/config.json"
                    }, {
                        name: "profanity",
                        url: "data/profanity.json"
                    }, {
                        name: "ui_loader_mask",
                        url: "images/" + prefix + "ui_loader_mask.png"
                    }, {
                        name: "esper_42pt",
                        url: "fonts/esper_42pt.xml"
                    }, {
                        name: "great_escape_60pt",
                        url: "fonts/great_escape_60pt.xml"
                    }, {
                        name: "great_escape_120pt",
                        url: "fonts/great_escape_120pt.xml"
                    }, {
                        name: "great_escape_italic_56pt",
                        url: "fonts/great_escape_italic_56pt.xml"
                    }, {
                        name: "greatesc_plate_60pt",
                        url: "fonts/greatesc_plate_60pt.xml"
                    }, {
                        name: "greatesc_plate_140pt",
                        url: "fonts/greatesc_plate_140pt.xml"
                    }],
                    sounds = [];
                files.length ? (Common.assets.addFiles(files, "assets/"), Common.assets.signalCompleted.addOnce(function() {
                    Common.copy = Common.assets.getJSON("copy"), Common.config = Common.assets.getJSON("config"), Common.profanity = Common.assets.getJSON("profanity"), Common.language = Common.config.locale, window.r2l = Common.config.r2l, window.highscores = Common.config.highscores, window.webfont = Common.config.webfont;
                    var tracking = new p3.Tracking;
                    tracking.init(new p3.TrackingModulePlaydom("carsracercasual_bd_bd", Common.language, "bd", "bd", "FD 41768DE3-CCEE-4F13-8730-8DB85E21F8E6:9914F4064ACEE5EBB12C3975F07625557EDE429281DC41A9")), tracking.track(new p3.TrackingDataPlaydomDeviceInfo(null, null, null, null, null, null, null, null)), Common.tracking = tracking, this.loadAssets()
                }, this), Common.assets.load(), p3.AudioManager.instance.addSounds(sounds, [".mp3", ".ogg"], "")) : this.loadAssets()
            }, Main.prototype.loadAssets = function() {
                for (var c, prefix = "hd/", files = [{
                        name: "loading_wheel_text",
                        url: "images/localized/loading_wheel_text.png"
                    }, {
                        name: "ui_fortune_wheel_text",
                        url: "images/localized/ui_fortune_wheel_text.png"
                    }, {
                        name: "ui_aaa_plate_rs",
                        url: "images/localized/ui_aaa_plate_rs.png"
                    }, {
                        name: "ui_bg_garage",
                        url: "images/" + prefix + "ui_bg_garage.jpg"
                    }, {
                        name: "map_bg_brazil",
                        url: "images/" + prefix + "map_bg_brazil.jpg"
                    }, {
                        name: "map_bg_germany",
                        url: "images/" + prefix + "map_bg_germany.jpg"
                    }, {
                        name: "map_bg_global",
                        url: "images/" + prefix + "map_bg_global.jpg"
                    }, {
                        name: "map_bg_italy",
                        url: "images/" + prefix + "map_bg_italy.jpg"
                    }, {
                        name: "map_bg_japan",
                        url: "images/" + prefix + "map_bg_japan.jpg"
                    }, {
                        name: "map_bg_usa",
                        url: "images/" + prefix + "map_bg_usa.jpg"
                    }, {
                        name: "pickups",
                        url: "images/" + prefix + "pickups.json"
                    }, {
                        name: "ui_comms",
                        url: "images/" + prefix + "ui_comms.json"
                    }, {
                        name: "ui_loadingwheel",
                        url: "images/" + prefix + "ui_loadingwheel.json"
                    }, {
                        name: "ui_bonuswheel",
                        url: "images/" + prefix + "ui_bonuswheel.json"
                    }, {
                        name: "ui_unlockdevice",
                        url: "images/" + prefix + "ui_unlockdevice.json"
                    }, {
                        name: "ui0",
                        url: "images/" + prefix + "ui0.json"
                    }, {
                        name: "ui1",
                        url: "images/" + prefix + "ui1.json"
                    }, {
                        name: "ui_cutscene_bg_bz",
                        url: "images/" + prefix + "/cutscene_bg/ui_cutscene_bg_bz.jpg"
                    }, {
                        name: "ui_cutscene_bg_de",
                        url: "images/" + prefix + "/cutscene_bg/ui_cutscene_bg_de.jpg"
                    }, {
                        name: "ui_cutscene_bg_pc",
                        url: "images/" + prefix + "/cutscene_bg/ui_cutscene_bg_pc.jpg"
                    }, {
                        name: "ui_cutscene_bg_rs",
                        url: "images/" + prefix + "/cutscene_bg/ui_cutscene_bg_rs.jpg"
                    }, {
                        name: "ui_cutscene_bg_tk",
                        url: "images/" + prefix + "/cutscene_bg/ui_cutscene_bg_tk.jpg"
                    }, {
                        name: "cutscene0",
                        url: "images/" + prefix + "cutscene0.json"
                    }, {
                        name: "cutscene_bz0",
                        url: "images/" + prefix + "cutscene_bz0.json"
                    }, {
                        name: "cutscene_de0",
                        url: "images/" + prefix + "cutscene_de0.json"
                    }, {
                        name: "cutscene_pc0",
                        url: "images/" + prefix + "cutscene_pc0.json"
                    }, {
                        name: "cutscene_rs0",
                        url: "images/" + prefix + "cutscene_rs0.json"
                    }, {
                        name: "cutscene_tk0",
                        url: "images/" + prefix + "cutscene_tk0.json"
                    }, {
                        name: "ui_help1",
                        url: "images/" + prefix + "ui_help1.png"
                    }, {
                        name: "ui_help2",
                        url: "images/" + prefix + "ui_help2.png"
                    }, {
                        name: "ui_help3",
                        url: "images/" + prefix + "ui_help3.png"
                    }, {
                        name: "ui_help4",
                        url: "images/" + prefix + "ui_help4.png"
                    }, {
                        name: "ui_bg_popup",
                        url: "images/" + prefix + "ui_bg_popup.jpg"
                    }, {
                        name: "ui_buttons_001",
                        url: "images/" + prefix + "ui_buttons_001.json"
                    }, {
                        name: "transition_mask",
                        url: "images/" + prefix + "transition_mask.png"
                    }, {
                        name: "lightning_welcome",
                        url: "images/" + prefix + "lightning_welcome.json"
                    }, {
                        name: "car_bernoulli_layers",
                        url: "images/" + prefix + "car_characters/car_bernoulli_layers.json"
                    }, {
                        name: "car_boost_layers",
                        url: "images/" + prefix + "car_characters/car_boost_layers.json"
                    }, {
                        name: "car_gorvette_layers",
                        url: "images/" + prefix + "car_characters/car_gorvette_layers.json"
                    }, {
                        name: "car_lightning_layers",
                        url: "images/" + prefix + "car_characters/car_lightning_layers.json"
                    }, {
                        name: "car_schnell_layers",
                        url: "images/" + prefix + "car_characters/car_schnell_layers.json"
                    }, {
                        name: "car_threat_layers",
                        url: "images/" + prefix + "car_characters/car_threat_layers.json"
                    }, {
                        name: "car_todoroki_layers",
                        url: "images/" + prefix + "car_characters/car_todoroki_layers.json"
                    }, {
                        name: "car_veloso_layers",
                        url: "images/" + prefix + "car_characters/car_veloso_layers.json"
                    }, {
                        name: "car_dust",
                        url: "particles/car_dust.json"
                    }, {
                        name: "particles_coin_pop",
                        url: "particles/particles_coin_pop.json"
                    }, {
                        name: "particle_fairydust_bg",
                        url: "particles/particle_fairydust_bg.json"
                    }, {
                        name: "particle_coin_burst",
                        url: "particles/particle_coin_burst.json"
                    }, {
                        name: "particle_upgrade_speed_burst",
                        url: "particles/particle_upgrade_speed_burst.json"
                    }, {
                        name: "particle_upgrade_turbo_burst",
                        url: "particles/particle_upgrade_turbo_burst.json"
                    }, {
                        name: "particle_coins_spend_rise",
                        url: "particles/particle_coins_spend_rise.json"
                    }, {
                        name: "particle_garage_paint_swap",
                        url: "particles/particle_garage_paint_swap.json"
                    }, {
                        name: "particle_garage_decal_swap",
                        url: "particles/particle_garage_decal_swap.json"
                    }, {
                        name: "particle_garage_decal_purchased",
                        url: "particles/particle_garage_decal_purchased.json"
                    }, {
                        name: "particles_car_leftside_impact",
                        url: "particles/particles_car_leftside_impact.json"
                    }, {
                        name: "particles_car_rightside_impact",
                        url: "particles/particles_car_rightside_impact.json"
                    }, {
                        name: "particles_car_rear_impact",
                        url: "particles/particles_car_rear_impact.json"
                    }, {
                        name: "particle_turbo_tyre_left",
                        url: "particles/particle_turbo_tyre_left.json"
                    }, {
                        name: "particle_turbo_tyre_right",
                        url: "particles/particle_turbo_tyre_right.json"
                    }, {
                        name: "particle_bonus_wheel_spin",
                        url: "particles/particle_bonus_wheel_spin.json"
                    }, {
                        name: "car_00_garage",
                        url: "images/" + prefix + "car_00/car_00_garage.json"
                    }, {
                        name: "car_00_garage_decal_00",
                        url: "images/" + prefix + "car_00/car_00_garage_decal_00.png"
                    }, {
                        name: "car_00_garage_decal_01",
                        url: "images/" + prefix + "car_00/car_00_garage_decal_01.png"
                    }, {
                        name: "car_00_garage_decal_02",
                        url: "images/" + prefix + "car_00/car_00_garage_decal_02.png"
                    }, {
                        name: "car_00_garage_decal_03",
                        url: "images/" + prefix + "car_00/car_00_garage_decal_03.png"
                    }, {
                        name: "car_00_garage_decal_04",
                        url: "images/" + prefix + "car_00/car_00_garage_decal_04.png"
                    }, {
                        name: "car_01_garage",
                        url: "images/" + prefix + "car_01/car_01_garage.json"
                    }, {
                        name: "car_01_garage_decal_00",
                        url: "images/" + prefix + "car_01/car_01_garage_decal_00.png"
                    }, {
                        name: "car_01_garage_decal_01",
                        url: "images/" + prefix + "car_01/car_01_garage_decal_01.png"
                    }, {
                        name: "car_01_garage_decal_02",
                        url: "images/" + prefix + "car_01/car_01_garage_decal_02.png"
                    }, {
                        name: "car_01_garage_decal_03",
                        url: "images/" + prefix + "car_01/car_01_garage_decal_03.png"
                    }, {
                        name: "car_01_garage_decal_04",
                        url: "images/" + prefix + "car_01/car_01_garage_decal_04.png"
                    }, {
                        name: "car_02_garage",
                        url: "images/" + prefix + "car_02/car_02_garage.json"
                    }, {
                        name: "car_02_garage_decal_00",
                        url: "images/" + prefix + "car_02/car_02_garage_decal_00.png"
                    }, {
                        name: "car_02_garage_decal_01",
                        url: "images/" + prefix + "car_02/car_02_garage_decal_01.png"
                    }, {
                        name: "car_02_garage_decal_02",
                        url: "images/" + prefix + "car_02/car_02_garage_decal_02.png"
                    }, {
                        name: "car_02_garage_decal_03",
                        url: "images/" + prefix + "car_02/car_02_garage_decal_03.png"
                    }, {
                        name: "car_02_garage_decal_04",
                        url: "images/" + prefix + "car_02/car_02_garage_decal_04.png"
                    }, {
                        name: "car_03_garage",
                        url: "images/" + prefix + "car_03/car_03_garage.json"
                    }, {
                        name: "car_03_garage_decal_00",
                        url: "images/" + prefix + "car_03/car_03_garage_decal_00.png"
                    }, {
                        name: "car_03_garage_decal_01",
                        url: "images/" + prefix + "car_03/car_03_garage_decal_01.png"
                    }, {
                        name: "car_03_garage_decal_02",
                        url: "images/" + prefix + "car_03/car_03_garage_decal_02.png"
                    }, {
                        name: "car_03_garage_decal_03",
                        url: "images/" + prefix + "car_03/car_03_garage_decal_03.png"
                    }, {
                        name: "car_03_garage_decal_04",
                        url: "images/" + prefix + "car_03/car_03_garage_decal_04.png"
                    }, {
                        name: "car_04_garage",
                        url: "images/" + prefix + "car_04/car_04_garage.json"
                    }, {
                        name: "car_04_garage_decal_00",
                        url: "images/" + prefix + "car_04/car_04_garage_decal_00.png"
                    }, {
                        name: "car_04_garage_decal_01",
                        url: "images/" + prefix + "car_04/car_04_garage_decal_01.png"
                    }, {
                        name: "car_04_garage_decal_02",
                        url: "images/" + prefix + "car_04/car_04_garage_decal_02.png"
                    }, {
                        name: "car_04_garage_decal_03",
                        url: "images/" + prefix + "car_04/car_04_garage_decal_03.png"
                    }, {
                        name: "car_04_garage_decal_04",
                        url: "images/" + prefix + "car_04/car_04_garage_decal_04.png"
                    }, {
                        name: "car_00_layers",
                        url: "images/" + prefix + "car_00/car_00_layers.json"
                    }, {
                        name: "car_00_decal_00",
                        url: "images/" + prefix + "car_00/car_00_decal_00.json"
                    }, {
                        name: "car_00_decal_01",
                        url: "images/" + prefix + "car_00/car_00_decal_01.json"
                    }, {
                        name: "car_00_decal_02",
                        url: "images/" + prefix + "car_00/car_00_decal_02.json"
                    }, {
                        name: "car_00_decal_03",
                        url: "images/" + prefix + "car_00/car_00_decal_03.json"
                    }, {
                        name: "car_00_decal_04",
                        url: "images/" + prefix + "car_00/car_00_decal_04.json"
                    }, {
                        name: "car_01_layers",
                        url: "images/" + prefix + "car_01/car_01_layers.json"
                    }, {
                        name: "car_01_decal_00",
                        url: "images/" + prefix + "car_01/car_01_decal_00.json"
                    }, {
                        name: "car_01_decal_01",
                        url: "images/" + prefix + "car_01/car_01_decal_01.json"
                    }, {
                        name: "car_01_decal_02",
                        url: "images/" + prefix + "car_01/car_01_decal_02.json"
                    }, {
                        name: "car_01_decal_03",
                        url: "images/" + prefix + "car_01/car_01_decal_03.json"
                    }, {
                        name: "car_01_decal_04",
                        url: "images/" + prefix + "car_01/car_01_decal_04.json"
                    }, {
                        name: "car_02_layers",
                        url: "images/" + prefix + "car_02/car_02_layers.json"
                    }, {
                        name: "car_02_decal_00",
                        url: "images/" + prefix + "car_02/car_02_decal_00.json"
                    }, {
                        name: "car_02_decal_01",
                        url: "images/" + prefix + "car_02/car_02_decal_01.json"
                    }, {
                        name: "car_02_decal_02",
                        url: "images/" + prefix + "car_02/car_02_decal_02.json"
                    }, {
                        name: "car_02_decal_03",
                        url: "images/" + prefix + "car_02/car_02_decal_03.json"
                    }, {
                        name: "car_02_decal_04",
                        url: "images/" + prefix + "car_02/car_02_decal_04.json"
                    }, {
                        name: "car_03_layers",
                        url: "images/" + prefix + "car_03/car_03_layers.json"
                    }, {
                        name: "car_03_decal_00",
                        url: "images/" + prefix + "car_03/car_03_decal_00.json"
                    }, {
                        name: "car_03_decal_01",
                        url: "images/" + prefix + "car_03/car_03_decal_01.json"
                    }, {
                        name: "car_03_decal_02",
                        url: "images/" + prefix + "car_03/car_03_decal_02.json"
                    }, {
                        name: "car_03_decal_03",
                        url: "images/" + prefix + "car_03/car_03_decal_03.json"
                    }, {
                        name: "car_03_decal_04",
                        url: "images/" + prefix + "car_03/car_03_decal_04.json"
                    }, {
                        name: "car_04_layers",
                        url: "images/" + prefix + "car_04/car_04_layers.json"
                    }, {
                        name: "car_04_decal_00",
                        url: "images/" + prefix + "car_04/car_04_decal_00.json"
                    }, {
                        name: "car_04_decal_01",
                        url: "images/" + prefix + "car_04/car_04_decal_01.json"
                    }, {
                        name: "car_04_decal_02",
                        url: "images/" + prefix + "car_04/car_04_decal_02.json"
                    }, {
                        name: "car_04_decal_03",
                        url: "images/" + prefix + "car_04/car_04_decal_03.json"
                    }, {
                        name: "car_04_decal_04",
                        url: "images/" + prefix + "car_04/car_04_decal_04.json"
                    }, {
                        name: "tutorial1",
                        url: "data/tutorial1.json"
                    }], comms = Common.config.comms, i = 0; i < comms.length; ++i) c = comms[i], files.push({
                    name: c.name,
                    url: "images/localized/" + c.name + ".png"
                });
                var sounds = ["music_cars_splashmenu", "music_cars_preracesetup", "music_cars_raceresults", "music_cars_racefinish_sting", "sfx_ui_btn_play_00", "sfx_ui_btn_press_00", "sfx_ui_btn_press_inactive_00", "sfx_ui_btn_press_pause_03", "sfx_ui_btn_rollover_00", "sfx_ui_btn_nextcar_02", "sfx_ui_btn_nextcolour_01", "sfx_ui_btn_colourconfirm_00", "sfx_ui_btn_enterenginebooth_00", "sfx_ui_btn_enterspraybooth_00", "sfx_ui_btn_entertyrebooth_00", "sfx_ui_btn_kitconfirm_00", "sfx_ui_btn_nexttyres_00", "sfx_ui_btn_nextboost_03", "sfx_ui_btn_nexttkit_00", "sfx_race_start_idle_revs_00", "sfx_race_start_idle_revs_01", "sfx_race_start_idle_revs_02", "sfx_car_big_skid_00", "sfx_car_start_tyres_04", "sfx_car_crash_rear_00", "sfx_car_crash_side_00", "sfx_car_crash_side_01", "sfx_car_crash_side_02", "sfx_car_crash_barrier_00", "sfx_car_crash_barrier_01", "sfx_car_accelerate_00", "sfx_car_deccelerate_00", "sfx_camera", "sfx_ambience_splashandprerace_00", "sfx_ambience_garage_00", "sfx_ambience_inrace_00", "sfx_coins_burstout_03", "sfx_counter_loop_00", "sfx_coins_rewarded_00", "sfx_race_lights_count_00", "sfx_race_lights_go_00", "sfx_object_pickup_coins_00", "sfx_object_pickup_turbo_01", "sfx_car_turbo_burn_00", "sfx_car_turbo_end_01", "sfx_car_skid_long", "sfx_car_skid_loop_slow", "sfx_car_skid_short", "sfx_car_skid_vshort", "sfx_car_puddle_splash_00", "sfx_car_puddle_splash_01", "sfx_car_puddle_splash_02", "sfx_car_oil_splat_02", "sfx_object_hit_concrete_00", "sfx_object_hit_concrete_01", "sfx_object_hit_concrete_02", "sfx_object_hit_concrete_03", "sfx_object_hit_cone_01", "sfx_object_hit_cone_02", "sfx_object_hit_cone_03", "sfx_object_hit_cone_04", "sfx_object_hit_cone_05", "sfx_object_hit_metalbarrel_00", "sfx_object_hit_metalbarrel_01", "sfx_object_hit_plasticdrum_00", "sfx_object_hit_plasticdrum_01", "sfx_object_hit_wood_barrier_00", "sfx_object_hit_wood_barrier_01", "sfx_object_hit_wood_barrier_02", "sfx_object_tumbleweed_hit_00", "sfx_object_tumbleweed_hit_01", "sfx_object_tumbleweed_hit_02"];
                files.length ? (this._preloader = new PreloaderScene, Common.scene.add(this._preloader), Common.assets.addFiles(files, "assets/"), Common.assets.signalProgress.add(this.onLoadingProgress, this), Common.assets.signalCompleted.addOnce(this.onLoadingCompleted, this), Common.assets.load(), Common.audio.addSounds(sounds, [".mp3", ".ogg"], "assets/audio/")) : (this.startGame(), Common.tracking.track(new p3.TrackingDataPlaydomGameAction("main", "game_load")))
            }, Main.prototype.startGame = function() {
                this._game = new Application, this._game.init()
            }, Main.prototype.update = function() {
                Common.view.isCorrectOrientation && (Common.scene.update(), Common.animator.update(), Common.input.update())
            }, Main.prototype.render = function() {
                Common.renderer.render(Common.stage)
            }, Main.prototype.onLoadingProgress = function(event) {
                this._preloader.loaded = event.progress / 100
            }, Main.prototype.onLoadingCompleted = function() {
                Common.assets.signalProgress.removeAll(), Common.assets.signalCompleted.removeAll(), this._preloader.loaded = 1, delay(function() {
                    this.startGame()
                }, 1.2, this)
            }, Main.prototype.onCanvasResize = function(correct) {
                correct && (Common.renderer.resize(p3.View.width, p3.View.height), Common.scene && Common.scene.resize())
            }
        }, {
            "./Application": 7,
            "./AudioManager": 8,
            "./Common": 23,
            "./Input": 50,
            "./PreloaderScene": 64,
            "./SceneManager": 84
        }],
        54: [function(require, module, exports) {
            function MessagePopup(id, character, message) {
                PIXI.Container.call(this), this.auto = !1, this._id = id, this._message = message || null, this._button = null, this._character = null, this._box = null, this._boxStartX = -528, this._boxEndX = 128, this._shown = !1, this._timeout = null, this._id > -1 && (this.auto = !0), this._button = new p3.Button(Common.assets.getTexture("ui_helper_bg")), this._button.x = .5 * this._button.width, this._button.y = .5 * this._button.height, this._button.animate = !0, this._button.overSoundName = "sfx_ui_btn_rollover_00", this._button.downSoundName = "sfx_ui_btn_press_00", this._button.signals.click.add(this.onButtonClick, this), this.addChild(this._button);
                var texture;
                switch (character) {
                    case MessagePopup.CHARACTER_CARLA:
                        texture = Common.assets.getTexture("ui_helper_carla");
                        break;
                    case MessagePopup.CHARACTER_DARRELL:
                        texture = Common.assets.getTexture("ui_helper_darrell");
                        break;
                    case MessagePopup.CHARACTER_FRANCESCO:
                        texture = Common.assets.getTexture("ui_helper_francesco");
                        break;
                    case MessagePopup.CHARACTER_LUIGI:
                        texture = Common.assets.getTexture("ui_helper_luigi");
                        break;
                    case MessagePopup.CHARACTER_MAX:
                        texture = Common.assets.getTexture("ui_helper_max");
                        break;
                    case MessagePopup.CHARACTER_RAMONE:
                    case MessagePopup.CHARACTER_MCQUEEN:
                        texture = Common.assets.getTexture("ui_helper_mcqueen");
                        break;
                    case MessagePopup.CHARACTER_SHU:
                        texture = Common.assets.getTexture("ui_helper_shu");
                        break;
                    case MessagePopup.CHARACTER_MATER:
                        texture = Common.assets.getTexture("ui_helper_matter")
                }
                this._character = new PIXI.Sprite(texture), this._character.x = 8, this._character.y = 2, this._character.anchor = new PIXI.Point(.5, .5), this._character.hitArea = new PIXI.Rectangle, this._button.addChild(this._character), this._box = new PIXI.Sprite(Common.assets.getTexture("ui_helper_speech_box")), this._box.x = -548, this._box.visible = !1, this.addChildAt(this._box, 0), this._box.mask = new PIXI.Graphics, this._box.mask.hitArea = new PIXI.Rectangle, this._box.mask.beginFill(16711680, .5), this._box.mask.drawRect(this._button.x - 88, this._button.y - 40, p3.View.width, 122), this._box.mask.endFill(), this.addChild(this._box.mask);
                var bubble = new PIXI.Sprite(Common.assets.getTexture("ui_helper_speech_bubble"));
                bubble.x = 74, bubble.y = -28, bubble.anchor = new PIXI.Point(.5, .5), this._button.addChild(bubble), webfont ? (this._text = new PIXI.Text(this._message, {
                    font: "24px Arial",
                    fill: "#FFFFFF",
                    align: r2l ? "center" : "left"
                }), this._text.x = .5 * (this._box.texture.width - this._text.width), this._text.y = .5 * (this._box.texture.height - this._text.height) + 18, this._box.addChild(this._text)) : (this._text = new PIXI.extras.BitmapText(this._message, {
                    font: "24px Great Escape Italic",
                    align: r2l ? "center" : "left"
                }), this._text.x = .5 * (this._box.texture.width - this._text.textWidth), this._text.y = .5 * (this._box.texture.height - this._text.textHeight) + 18, this._box.addChild(this._text))
            }
            var Common = require("./Common");
            module.exports = MessagePopup, MessagePopup.prototype = Object.create(PIXI.Container.prototype), MessagePopup.prototype.constructor = MessagePopup, MessagePopup.CHARACTER_CARLA = "carla", MessagePopup.CHARACTER_DARRELL = "darrell", MessagePopup.CHARACTER_FRANCESCO = "francesco", MessagePopup.CHARACTER_LUIGI = "luigi", MessagePopup.CHARACTER_MAX = "max", MessagePopup.CHARACTER_MCQUEEN = "mcqueen", MessagePopup.CHARACTER_RAMONE = "ramone", MessagePopup.CHARACTER_SHU = "shu", MessagePopup.CHARACTER_MATER = "mater", MessagePopup.firstTimeHelpers = [], MessagePopup.prototype.destroy = function() {
                TweenMax.killTweensOf(this._character), TweenMax.killTweensOf(this._box), this.parent && this.parent.removeChild(this)
            }, MessagePopup.prototype.animateIn = function(callback, scope) {
                var x = this._button.x;
                this._button.x = this._button.x - 240, TweenMax.to(this._button, .6, {
                    x: x,
                    ease: Back.easeOut,
                    easeParams: [1]
                }), this._button.alpha = 0, TweenMax.to(this._button, .4, {
                    alpha: 1,
                    ease: Power1.easeInOut
                }), this._timeout = TweenMax.delayedCall(.6, function() {
                    callback && callback.call(scope), this.auto && this.show(10)
                }, null, this)
            }, MessagePopup.prototype.animateOut = function(callback, scope) {
                TweenMax.to(this._button, .6, {
                    x: this._button.x - 240,
                    ease: Back.easeIn,
                    easeParams: [1]
                }), TweenMax.to(this._button, .2, {
                    delay: .4,
                    alpha: 0,
                    ease: Power1.easeInOut
                }), TweenMax.to(this._box, .2, {
                    alpha: 0,
                    ease: Power1.easeInOut
                }), TweenMax.delayedCall(.6, function() {
                    this.parent && this.parent.removeChild(this), callback && callback.call(scope)
                }, null, this)
            }, MessagePopup.prototype.show = function(delay, callback, scope) {
                delay = delay || 0, this._shown = !0, this._box.x = this._boxStartX, this._box.visible = !0, TweenMax.killTweensOf(this), TweenMax.to(this._box, .6, {
                    x: this._boxEndX,
                    ease: Back.easeOut,
                    easeParams: [1],
                    onComplete: function() {
                        delay > 0 ? TweenMax.delayedCall(delay, this.hide, [callback, scope], this) : callback && callback.call(scope)
                    },
                    onCompleteScope: this
                })
            }, MessagePopup.prototype.hide = function(callback, scope) {
                this._shown = !1, this._timeout && this._timeout.kill(), TweenMax.killTweensOf(this), TweenMax.to(this._box, .4, {
                    x: this._boxStartX,
                    ease: Back.easeIn,
                    easeParams: [1],
                    onComplete: function() {
                        this._box.visible = !1, callback && callback.call(scope)
                    },
                    onCompleteScope: this
                })
            }, MessagePopup.prototype.onButtonClick = function(button) {
                this._shown ? this.hide() : this.show()
            }, Object.defineProperty(MessagePopup.prototype, "id", {
                get: function() {
                    return this._id
                }
            }), Object.defineProperty(MessagePopup.prototype, "message", {
                get: function() {
                    return this._message
                },
                set: function(value) {
                    this._message = value, webfont ? (this._text.text = this._message, this._text.x = .5 * (this._box.texture.width - this._text.width), this._text.y = .5 * (this._box.texture.height - this._text.height) + 18) : (this._text.text = this._message, this._text.validate(), this._text.x = .5 * (this._box.texture.width - this._text.textWidth), this._text.y = .5 * (this._box.texture.height - this._text.textHeight) + 18)
                }
            })
        }, {
            "./Common": 23
        }],
        55: [function(require, module, exports) {
            function NameScene() {
                Scene.call(this), this.selectorX = 0, this.selectorY = 20, this._header = null, this._panel = null, this._titleText = null, this._infoText = null, this._alphabet = [], this._characters = [], this._charNextButtons = [], this._charPreviousButtons = [], this._backButton = null, this._acceptButton = null, this._message = null
            }
            var Common = require("./Common"),
                MessagePopup = require("./MessagePopup"),
                Scene = require("./Scene");
            module.exports = NameScene, NameScene.prototype = Object.create(Scene.prototype), NameScene.prototype.constructor = NameScene, NameScene.prototype.init = function() {
                this._alphabet = Common.config.alphabet.slice();
                var bg = new PIXI.Sprite(Common.assets.getTexture("ui_bg_main_menu"));
                this.addChild(bg), this._header = new PIXI.Sprite(Common.assets.getTexture("ui_top_bar")), this._header.x = .5 * Common.STAGE_WIDTH, this._header.y = 120, this._header.anchor = new PIXI.Point(.5, .5), this.addChild(this._header), webfont ? (this._titleText = new PIXI.Text(Common.copy.name[Common.language], {
                    font: "48px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._titleText.x = .5 * (Common.STAGE_WIDTH - this._titleText.width), this._titleText.y = 96, this.addChild(this._titleText)) : (this._titleText = new PIXI.extras.BitmapText(Common.copy.name[Common.language], {
                    font: "48px Great Escape",
                    align: "center"
                }), this._titleText.x = .5 * (Common.STAGE_WIDTH - this._titleText.textWidth), this._titleText.y = 86, this.addChild(this._titleText)), this._acceptButton = new p3.Button(Common.assets.getTexture("ui_btn_confirm_up"), Common.assets.getTexture("ui_btn_confirm_over"), Common.assets.getTexture("ui_btn_confirm_down"), Common.assets.getTexture("ui_icon_tick"), Common.assets.getTexture("ui_btn_confirm_inactive_up"), Common.assets.getTexture("ui_btn_confirm_inactive_over"), Common.assets.getTexture("ui_btn_confirm_inactive_over")), this._acceptButton.y = .5 * Common.STAGE_HEIGHT + 260, this._acceptButton.animate = !0, this._acceptButton.visible = !1, this._acceptButton.overSoundName = "sfx_ui_btn_rollover_00", this._acceptButton.downSoundName = "sfx_ui_btn_press_00", this._acceptButton.clickSoundName = "sfx_ui_btn_play_00", this._acceptButton.signals.click.add(this.onAcceptButtonClick, this), this.addChild(this._acceptButton), this._panel = new PIXI.Sprite(Common.assets.getTexture("ui_aaa_plate")), this._panel.x = .5 * Common.STAGE_WIDTH + this.selectorX, this._panel.y = .5 * p3.View.height + this.selectorY, this._panel.anchor = new PIXI.Point(.5, .5), this.addChild(this._panel);
                var brand = new PIXI.Sprite(Common.assets.getTexture("ui_aaa_plate_rs"));
                brand.anchor = new PIXI.Point(.5, .5), this._panel.addChild(brand);
                for (var button, character, char, animation, name = Common.garage.name.toLowerCase() || this._alphabet[0] + this._alphabet[0] + this._alphabet[0], count = 3, i = 0; count > i; ++i) button = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_arrow")), button.x = 160 * i - 160 * (count - 1) * .5, button.y = -156, button.rotation = .5 * Math.PI, button.id = i, button.overSoundName = "sfx_ui_btn_rollover_00", button.downSoundName = "sfx_ui_btn_press_00", button.signals.click.add(this.onCharPrevButtonClick, this), this._panel.addChild(button), this._charNextButtons.push(button), animation = new TimelineMax({
                    repeat: -1,
                    yoyo: !0
                }), animation.append(TweenMax.to(button.scale, .6, {
                    x: 1.14,
                    y: 1.14,
                    ease: Power1.easeInOut
                })), button = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_arrow")), button.x = 160 * i - 160 * (count - 1) * .5, button.y = 156, button.rotation = .5 * Math.PI, button.scale.x = button.defaultScale.x = -1, button.id = i, button.overSoundName = "sfx_ui_btn_rollover_00", button.downSoundName = "sfx_ui_btn_press_00", button.signals.click.add(this.onCharNextButtonClick, this), this._panel.addChild(button), this._charPreviousButtons.push(button), animation = new TimelineMax({
                    repeat: -1,
                    yoyo: !0
                }), animation.append(TweenMax.to(button.scale, .6, {
                    x: -1.14,
                    y: 1.14,
                    ease: Power1.easeInOut
                })), char = name.charAt(i), webfont ? (character = new PIXI.Text(char.toUpperCase(), {
                    font: "140px Arial",
                    fill: "#000000",
                    align: "center"
                }), character.x = 140 * i - .5 * character.width - 140 * (count - 1) * .5, character.y = .5 * -character.height + 20, character.id = i, character["char"] = this._alphabet.indexOf(char), this._panel.addChild(character)) : (character = new PIXI.extras.BitmapText(char.toUpperCase(), {
                    font: "140px Great Escape Plate XL",
                    align: "center"
                }), character.x = 140 * i - .5 * character.textWidth - 140 * (count - 1) * .5, character.y = .5 * -character.textHeight + 20, character.id = i, character["char"] = this._alphabet.indexOf(char), this._panel.addChild(character)), this._characters.push(character)
            }, NameScene.prototype.dispose = function() {
                Common.animator.removeAll(), this._message.destroy(), Scene.prototype.dispose.call(this)
            }, NameScene.prototype.appear = function() {
                this.animateIn(), this._message = new MessagePopup(9, MessagePopup.CHARACTER_MCQUEEN, Common.copy.name_helper[Common.language]), this._message.x = .5 * (Common.STAGE_WIDTH - p3.View.width) + 20, this._message.y = p3.View.height - this._message.height - 20, this._message.animateIn(), this.addChild(this._message)
            }, NameScene.prototype.show = function() {
                this._closeButton.interactive = !0, this._acceptButton.interactive = !0;
                for (var i = 0; i < this._charNextButtons.length; ++i) this._charNextButtons[i].interactive = !1, this._charPreviousButtons[i].interactive = !1
            }, NameScene.prototype.animateIn = function(callback, scope) {
                this._acceptButton.scale = new PIXI.Point, this._acceptButton.visible = !0, TweenMax.to(this._acceptButton.scale, .4, {
                    delay: .2,
                    x: 1,
                    y: 1,
                    ease: Back.easeOut,
                    easeParams: [3]
                })
            }, NameScene.prototype.animateOut = function(callback, scope) {}, NameScene.prototype.resize = function() {
                this.x = .5 * (p3.View.width - Common.STAGE_WIDTH), this._header.width = p3.View.width, this._acceptButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width - Math.abs(this._acceptButton.width)) - 28
            }, NameScene.prototype.update = function() {}, NameScene.prototype.validateName = function(name) {
                var list = Common.profanity.list;
                return -1 == list.indexOf(name.toLowerCase())
            }, NameScene.prototype.onCharNextButtonClick = function(button) {
                var character = this._characters[button.id];
                character["char"] ++, character["char"] >= this._alphabet.length && (character["char"] = 0), webfont ? (character.text = this._alphabet[character["char"]].toUpperCase(), character.x = 140 * character.id - 140 * (this._characters.length - 1) * .5 - .5 * character.width, character.y = .5 * -character.height + 20) : (character.text = this._alphabet[character["char"]].toUpperCase(), character.validate(), character.x = 140 * character.id - 140 * (this._characters.length - 1) * .5 - .5 * character.textWidth, character.y = .5 * -character.textHeight + 20);
                var name = this.getName();
                this._acceptButton.enabled = this.validateName(name)
            }, NameScene.prototype.onCharPrevButtonClick = function(button) {
                var character = this._characters[button.id];
                character["char"] --, character["char"] < 0 && (character["char"] = 25), webfont ? (character.text = this._alphabet[character["char"]].toUpperCase(), character.x = 140 * character.id - 140 * (this._characters.length - 1) * .5 - .5 * character.width, character.y = .5 * -character.height + 20) : (character.text = this._alphabet[character["char"]].toUpperCase(), character.validate(), character.x = 140 * character.id - 140 * (this._characters.length - 1) * .5 - .5 * character.textWidth, character.y = .5 * -character.textHeight + 20);
                var name = this.getName();
                this._acceptButton.enabled = this.validateName(name)
            }, NameScene.prototype.onHelpButtonClick = function(button) {
                this.signals.pause.dispatch(this)
            }, NameScene.prototype.onAcceptButtonClick = function(button) {
                var i, name = this.getName();
                if (this.validateName(name)) {
                    var garage = Common.garage;
                    for (Common.saveData.isNewPlayer ? garage.createNewPlayer(name) : garage.changeName(name), this._acceptButton.interactive = !1, i = 0; i < this._charNextButtons.length; ++i) this._charNextButtons[i].interactive = !1, this._charPreviousButtons[i].interactive = !1;
                    this.signals.next.dispatch()
                }
            }, NameScene.prototype.getName = function() {
                for (var name = "", i = 0; i < this._characters.length; ++i) name += this._alphabet[this._characters[i]["char"]].toUpperCase();
                return name
            }
        }, {
            "./Common": 23,
            "./MessagePopup": 54,
            "./Scene": 83
        }],
        56: [function(require, module, exports) {
            function Obstacle(id, view) {
                this.penalty = .74, this.signals = {}, this._id = id, this._smashed = !1, view.anchor = new PIXI.Point(.5, .5), RoadEntity.call(this, RoadEntity.TYPE_STATIC, view)
            }
            var RoadEntity = (require("./Common"), require("./RoadEntity"));
            module.exports = Obstacle, Obstacle.prototype = Object.create(RoadEntity.prototype), Obstacle.prototype.constructor = Obstacle, Obstacle.TYPE_DEFAULT = 0, Obstacle.TYPE_CONE = 1, Obstacle.TYPE_OIL = 2, Obstacle.TYPE_WATER = 3, Obstacle.TYPE_PLASTIC_DRUM = 4, Obstacle.TYPE_METAL = 5, Obstacle.TYPE_BUSH = 6, Obstacle.TYPE_WOODEN = 7, Obstacle.TYPE_TUMBLEWEED = 8, Obstacle.TYPE_ROCK = 9, Obstacle.prototype.destroy = function() {
                this.engine.removeEntity(this), RoadEntity.prototype.destroy.call(this)
            }, Obstacle.prototype.smash = function(smashee) {
                switch (this._smashed = !0, this._id) {
                    case Obstacle.TYPE_OIL:
                    case Obstacle.TYPE_WATER:
                        TweenMax.to(this, 1, {
                            alpha: 0,
                            ease: Power1.easeInOut,
                            onComplete: function() {
                                this.destroy()
                            },
                            onCompleteScope: this
                        });
                        break;
                    default:
                        var dx = this.offset.x - smashee.offset.x,
                            sign = dx / Math.abs(dx),
                            to = new PIXI.Point(-1 == sign ? this.offset.x - 240 : this.offset.x + 240, this.offset.y - 120);
                        TweenMax.to(this.offset, .24, {
                            x: to.x,
                            y: to.y,
                            ease: Power0.easeNone,
                            onComplete: function() {
                                this.destroy()
                            },
                            onCompleteScope: this
                        }), TweenMax.to(this, .1, {
                            delay: .14,
                            alpha: 0,
                            ease: Power1.easeInOut
                        }), TweenMax.to(this.view, .24, {
                            rotation: -1 == sign ? .1 * -Math.PI : .1 * Math.PI,
                            ease: Power0.easeNone
                        })
                }
            }, Object.defineProperty(Obstacle.prototype, "id", {
                get: function() {
                    return this._id
                }
            }), Object.defineProperty(Obstacle.prototype, "smashed", {
                get: function() {
                    return this._smashed
                }
            })
        }, {
            "./Common": 23,
            "./RoadEntity": 79
        }],
        57: [function(require, module, exports) {
            function PageIndicator(pages, reverse) {
                PIXI.Container.call(this);
                var page, i, spacing = 46;
                if (reverse)
                    for (i = pages - 1; i >= 0; --i) page = new PIXI.Sprite(Common.assets.getTexture("ui_pagination_off")), page.x = i * spacing - (pages - 1) * spacing * .5, page.anchor = new PIXI.Point(.5, .5), this.addChild(page);
                else
                    for (i = 0; pages > i; ++i) page = new PIXI.Sprite(Common.assets.getTexture("ui_pagination_off")), page.x = i * spacing - (pages - 1) * spacing * .5, page.anchor = new PIXI.Point(.5, .5), this.addChild(page);
                this.select(0)
            }
            var Common = require("./Common");
            module.exports = PageIndicator, PageIndicator.prototype = Object.create(PIXI.Container.prototype), PageIndicator.prototype.constructor = PageIndicator, PageIndicator.prototype.select = function(index) {
                for (var page, i = 0; i < this.children.length; ++i) page = this.children[i], page.texture = Common.assets.getTexture("ui_pagination_off");
                page = this.children[index], page.texture = Common.assets.getTexture("ui_pagination_on")
            }
        }, {
            "./Common": 23
        }],
        58: [function(require, module, exports) {
            function PauseScene() {
                Scene.call(this), this.signals.restart = new signals.Signal, this._overlay = null, this._panel = null, this._titleText = null, this._closeButton = null, this._homeButton = null, this._helpButton = null, this._muteButton = null, this._restartButton = null, this._playButton = null, this._controlsSwitch = null, this._message = null
            }
            var Common = require("./Common"),
                MessagePopup = require("./MessagePopup"),
                ControlTypes = require("./ControlTypes"),
                Scene = require("./Scene"),
                SettingsSwitch = require("./SettingsSwitch");
            module.exports = PauseScene, PauseScene.prototype = Object.create(Scene.prototype), PauseScene.prototype.constructor = PauseScene, PauseScene.prototype.init = function() {
                var graphics = new PIXI.Graphics;
                graphics.beginFill(0, .64), graphics.drawRect(0, 0, 1, 1), graphics.endFill(), this._overlay = new PIXI.Sprite(graphics.generateTexture()), this._overlay.width = p3.View.width, this._overlay.height = p3.View.height, this._overlay.visible = !1, this.addChild(this._overlay), this._panel = new PIXI.Container, this._panel.x = .5 * Common.STAGE_WIDTH, this._panel.y = .5 * Common.STAGE_HEIGHT - 80, this._panel.visible = !1, this.addChild(this._panel), this._panel.header = new PIXI.Sprite(Common.assets.getTexture("ui_popup_top")), this._panel.header.x = .5 * -this._panel.header.width, this._panel.addChild(this._panel.header), this._panel.content = new PIXI.Sprite(Common.assets.getTexture("ui_popup_bottom_carbon_small")), this._panel.content.x = .5 * -this._panel.content.width, this._panel.content.y = this._panel.header.y + this._panel.header.height, this._panel.addChild(this._panel.content), this._panel.header.y -= .5 * (this._panel.header.height + this._panel.content.height), this._panel.content.y -= .5 * (this._panel.header.height + this._panel.content.height), webfont ? (this._titleText = new PIXI.Text("Pause", {
                    font: "48px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._titleText.x = .5 * (this._panel.header.width - this._titleText.width), this._titleText.y = 24, this._panel.header.addChild(this._titleText)) : (this._titleText = new PIXI.extras.BitmapText("Pause", {
                    font: "48px Great Escape",
                    align: "center"
                }), this._titleText.x = .5 * (this._panel.header.width - this._titleText.textWidth), this._titleText.y = 16, this._panel.header.addChild(this._titleText)), this._playButton = new p3.Button(Common.assets.getTexture("ui_btn_confirm_up"), Common.assets.getTexture("ui_btn_confirm_over"), Common.assets.getTexture("ui_btn_confirm_down"), Common.assets.getTexture("ui_icon_play")), this._playButton.x = .5 * this._panel.content.width, this._playButton.y = .5 * this._panel.content.height + 70, this._playButton.animate = !0, this._playButton.signals.click.add(this.onCloseButtonClick, this), this._panel.content.addChild(this._playButton), this._closeButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_btn_close")), this._closeButton.x = .5 * (this._panel.header.width - this._closeButton.width) - 18, this._closeButton.y = -190, this._closeButton.animate = !0, this._closeButton.signals.click.add(this.onCloseButtonClick, this), this._panel.addChild(this._closeButton);
                var spacing = 134.4;
                this._helpButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_big_up"), Common.assets.getTexture("ui_btn_navigation_big_over"), Common.assets.getTexture("ui_btn_navigation_big_down"), Common.assets.getTexture("ui_icon_help")), this._helpButton.x = .5 * this._panel.content.width - .5 * spacing - 90, this._helpButton.y = this._playButton.y, this._helpButton.animate = !0, this._helpButton.signals.click.add(this.onHelpButtonClick, this), this._panel.content.addChild(this._helpButton), this._homeButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_big_up"), Common.assets.getTexture("ui_btn_navigation_big_over"), Common.assets.getTexture("ui_btn_navigation_big_down"), Common.assets.getTexture("ui_icon_home")), this._homeButton.x = this._helpButton.x - spacing, this._homeButton.y = this._playButton.y, this._homeButton.animate = !0, this._homeButton.signals.click.add(this.onHomeButtonClick, this), this._panel.content.addChild(this._homeButton), this._muteButton = new p3.MuteButton(Common.assets.getTexture("ui_btn_navigation_big_up"), Common.assets.getTexture("ui_btn_navigation_big_over"), Common.assets.getTexture("ui_btn_navigation_big_down"), Common.assets.getTexture("ui_icon_sound_on"), Common.assets.getTexture("ui_icon_sound_off")), this._muteButton.x = .5 * this._panel.content.width + .5 * spacing + 90, this._muteButton.y = this._playButton.y, this._muteButton.animate = !0, this._panel.content.addChild(this._muteButton), this._restartButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_big_up"), Common.assets.getTexture("ui_btn_navigation_big_over"), Common.assets.getTexture("ui_btn_navigation_big_down"), Common.assets.getTexture("ui_icon_replay")), this._restartButton.x = this._muteButton.x + spacing, this._restartButton.y = this._playButton.y, this._restartButton.animate = !0, this._restartButton.signals.click.add(this.onRestartButtonClick, this), this._panel.content.addChild(this._restartButton), this._controlsSwitch = new SettingsSwitch(Common.garage.controls == ControlTypes.CONTROLS_EXPERT, 0), this._controlsSwitch.y = -36, this._controlsSwitch.animate = !0, this._controlsSwitch.signals.click.add(this.onControlsSwitchClick, this), this._panel.addChild(this._controlsSwitch), webfont ? (this._controlsSwitch.nameLabel = new PIXI.Text(Common.copy.options_difficulty[Common.language], {
                    font: "32px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._controlsSwitch.nameLabel.x = .5 * -this._controlsSwitch.nameLabel.width, this._controlsSwitch.nameLabel.y = this._controlsSwitch.y - .5 * this._controlsSwitch.nameLabel.height - 64, this._panel.addChild(this._controlsSwitch.nameLabel)) : (this._controlsSwitch.nameLabel = new PIXI.extras.BitmapText(Common.copy.options_difficulty[Common.language], {
                    font: "32px Great Escape",
                    align: "center"
                }), this._controlsSwitch.nameLabel.x = .5 * -this._controlsSwitch.nameLabel.textWidth, this._controlsSwitch.nameLabel.y = this._controlsSwitch.y - .5 * this._controlsSwitch.nameLabel.textHeight - 64, this._panel.addChild(this._controlsSwitch.nameLabel)), webfont ? (this._controlsSwitch.onLabel = new PIXI.Text(Common.copy.options_difficulty_pro[Common.language], {
                    font: "32px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._controlsSwitch.onLabel.x = this._controlsSwitch.x + 148, this._controlsSwitch.onLabel.y = this._controlsSwitch.y - .5 * this._controlsSwitch.onLabel.height, this._panel.addChild(this._controlsSwitch.onLabel)) : (this._controlsSwitch.onLabel = new PIXI.extras.BitmapText(Common.copy.options_difficulty_pro[Common.language], {
                    font: "32px Great Escape",
                    align: "center"
                }), this._controlsSwitch.onLabel.x = this._controlsSwitch.x + 148, this._controlsSwitch.onLabel.y = this._controlsSwitch.y - .5 * this._controlsSwitch.onLabel.textHeight, this._panel.addChild(this._controlsSwitch.onLabel)), webfont ? (this._controlsSwitch.offLabel = new PIXI.Text(Common.copy.options_difficulty_rookie[Common.language], {
                    font: "32px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._controlsSwitch.offLabel.x = this._controlsSwitch.x - 148 - this._controlsSwitch.offLabel.width, this._controlsSwitch.offLabel.y = this._controlsSwitch.y - .5 * this._controlsSwitch.offLabel.height, this._panel.addChild(this._controlsSwitch.offLabel)) : (this._controlsSwitch.offLabel = new PIXI.extras.BitmapText(Common.copy.options_difficulty_rookie[Common.language], {
                    font: "32px Great Escape",
                    align: "center"
                }), this._controlsSwitch.offLabel.x = this._controlsSwitch.x - 148 - this._controlsSwitch.offLabel.textWidth, this._controlsSwitch.offLabel.y = this._controlsSwitch.y - .5 * this._controlsSwitch.offLabel.textHeight, this._panel.addChild(this._controlsSwitch.offLabel))
            }, PauseScene.prototype.dispose = function() {
                this.signals.restart.dispose(), this._message && (this._message.destroy(), this._message = null), Scene.prototype.dispose.call(this)
            }, PauseScene.prototype.appear = function() {
                this.animateIn(), this._message = new MessagePopup(10, MessagePopup.CHARACTER_MCQUEEN, Common.copy.pause_helper[Common.language]), this._message.x = .5 * (Common.STAGE_WIDTH - p3.View.width) + 20, this._message.y = 560, this._message.animateIn(), this.addChild(this._message)
            }, PauseScene.prototype.show = function() {
                this._closeButton.interactive = !0, this.animateIn()
            }, PauseScene.prototype.hide = function() {
                this._closeButton.interactive = !1
            }, PauseScene.prototype.animateIn = function(callback, scope) {
                Scene.prototype.animateIn.call(this, callback, scope), this._overlay.alpha = 0, this._overlay.visible = !0, TweenMax.to(this._overlay, .2, {
                    alpha: 1,
                    ease: Power1.easeInOut
                });
                var x = .5 * Common.STAGE_WIDTH;
                this._panel.x = .5 * (Common.STAGE_WIDTH - p3.View.width - this._panel.width), this._panel.visible = !0, TweenMax.to(this._panel, .3, {
                    x: x,
                    ease: Back.easeOut,
                    easeParams: [1]
                })
            }, PauseScene.prototype.animateOut = function(callback, scope) {
                Scene.prototype.animateOut.call(this, callback, scope), TweenMax.to(this._overlay, .4, {
                    alpha: 0,
                    ease: Power1.easeInOut,
                    onComplete: function() {
                        this._overlay.visible = !1
                    },
                    onCompleteScope: this
                }), TweenMax.to(this._panel, .26, {
                    x: .5 * (Common.STAGE_WIDTH + p3.View.width + this._panel.width),
                    ease: Back.easeIn,
                    easeParams: [1],
                    onComplete: function() {
                        this._panel.visible = !1, callback && callback.call(scope)
                    },
                    onCompleteScope: this
                })
            }, PauseScene.prototype.resize = function() {
                this.x = .5 * (p3.View.width - Common.STAGE_WIDTH), this._overlay.x = .5 * (Common.STAGE_WIDTH - p3.View.width), this._overlay.y = .5 * (Common.STAGE_HEIGHT - p3.View.height), this._overlay.width = p3.View.width, this._overlay.height = p3.View.height
            }, PauseScene.prototype.update = function() {}, PauseScene.prototype.onHelpButtonClick = function(button) {
                this.animateOut(function() {
                    this.signals.pause.dispatch()
                }, this)
            }, PauseScene.prototype.onRestartButtonClick = function(button) {
                this.animateOut(function() {
                    this.signals.restart.dispatch()
                }, this)
            }, PauseScene.prototype.onHomeButtonClick = function(button) {
                this.animateOut(function() {
                    this.signals.previous.dispatch()
                }, this)
            }, PauseScene.prototype.onCloseButtonClick = function(button) {
                this.animateOut(function() {
                    this.signals.next.dispatch()
                }, this)
            }, PauseScene.prototype.onControlsSwitchClick = function(button, value) {
                Common.garage.controls = value ? ControlTypes.CONTROLS_EXPERT : ControlTypes.CONTROLS_ROOKIE, Common.saveData.save(), Common.tracking.track(new p3.TrackingDataPlaydomGameAction("settings", value ? "set_pro" : "set_rookie"))
            }
        }, {
            "./Common": 23,
            "./ControlTypes": 26,
            "./MessagePopup": 54,
            "./Scene": 83,
            "./SettingsSwitch": 92
        }],
        59: [function(require, module, exports) {
            function PhotoScene(texture) {
                this._texture = texture, this._overlay = null, this._panel = null, this._photo = null, this._titleText = null, this._nameText = null, this._closeButton = null, Scene.call(this)
            }
            var Common = require("./Common"),
                Scene = require("./Scene");
            module.exports = PhotoScene, PhotoScene.prototype = Object.create(Scene.prototype), PhotoScene.prototype.constructor = PhotoScene, PhotoScene.prototype.init = function() {
                var graphics = new PIXI.Graphics;
                graphics.beginFill(0, .64), graphics.drawRect(0, 0, 1, 1), graphics.endFill(), this._overlay = new PIXI.Sprite(graphics.generateTexture()), this._overlay.width = p3.View.width, this._overlay.height = p3.View.height, this._overlay.visible = !1, this.addChild(this._overlay), this._panel = new PIXI.Container, this._panel.x = .5 * Common.STAGE_WIDTH, this._panel.y = .5 * Common.STAGE_HEIGHT, this._panel.visible = !1, this.addChild(this._panel), this._panel.header = new PIXI.Sprite(Common.assets.getTexture("ui_popup_top")), this._panel.header.x = .5 * -this._panel.header.width, this._panel.addChild(this._panel.header), this._panel.content = new PIXI.Sprite(Common.assets.getTexture("ui_popup_bottom_carbon")), this._panel.content.x = .5 * -this._panel.content.width, this._panel.content.y = this._panel.header.y + this._panel.header.height, this._panel.addChild(this._panel.content), this._panel.header.y -= .5 * (this._panel.header.height + this._panel.content.height), this._panel.content.y -= .5 * (this._panel.header.height + this._panel.content.height), webfont ? (this._titleText = new PIXI.Text(Common.copy.garage_photo[Common.language], {
                    font: "48px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._titleText.x = .5 * (this._panel.header.width - this._titleText.width), this._titleText.y = 24, this._panel.header.addChild(this._titleText)) : (this._titleText = new PIXI.extras.BitmapText(Common.copy.garage_photo[Common.language], {
                    font: "48px Great Escape",
                    align: "center"
                }), this._titleText.x = .5 * (this._panel.header.width - this._titleText.textWidth), this._titleText.y = 16, this._panel.header.addChild(this._titleText)), this._photo = new PIXI.Sprite(Common.assets.getTexture("ui_photo")), this._photo.x = 2, this._photo.y = 40, this._photo.rotation = -.08, this._photo.scale = new PIXI.Point(1.6, 1.6), this._photo.anchor = new PIXI.Point(.5, .5), this._panel.addChild(this._photo), this._photo.car = new PIXI.Sprite(this._texture), this._photo.car.y = 0, this._photo.car.scale = new PIXI.Point(1 / this._photo.scale.x, 1 / this._photo.scale.y), this._photo.car.anchor = new PIXI.Point(.5, .5), this._photo.addChild(this._photo.car);
                var width = 428,
                    height = 256;
                this._photo.car.mask = new PIXI.Graphics, this._photo.car.mask.beginFill(16711680), this._photo.car.mask.drawRect(.5 * -width - 2, .5 * -height - 2, width, height), this._photo.car.mask.endFill(), this._photo.addChild(this._photo.car.mask), this._closeButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_btn_close")), this._closeButton.x = .5 * (this._panel.header.width - this._closeButton.width) - 18, this._closeButton.y = -240, this._closeButton.animate = !0, this._closeButton.overSoundName = "sfx_ui_btn_rollover_00", this._closeButton.downSoundName = "sfx_ui_btn_press_00", this._closeButton.signals.click.add(this.onCloseButtonClick, this), this._panel.addChild(this._closeButton)
            }, PhotoScene.prototype.dispose = function() {
                Common.animator.removeAll(), Scene.prototype.dispose.call(this)
            }, PhotoScene.prototype.appear = function() {
                this.animateIn(), this.savePhoto(), Common.audio.playSound("sfx_camera")
            }, PhotoScene.prototype.show = function() {}, PhotoScene.prototype.animateIn = function(callback, scope) {
                Scene.prototype.animateIn.call(this, callback, scope);
                var flash = new PIXI.Graphics;
                flash.beginFill(16777215), flash.drawRect(.5 * (Common.STAGE_WIDTH - p3.View.width), .5 * (Common.STAGE_HEIGHT - p3.View.height), p3.View.width, p3.View.height), flash.endFill(), this.addChild(flash), TweenMax.to(flash, 2, {
                    delay: .2,
                    alpha: 0,
                    ease: Power4.easeOut,
                    onComplete: function() {
                        flash.parent.removeChild(flash)
                    },
                    onCompleteScope: this
                }), this._overlay.alpha = 0, this._overlay.visible = !0, TweenMax.to(this._overlay, .2, {
                    delay: 1,
                    alpha: 1,
                    ease: Power1.easeInOut
                });
                var x = this._panel.x;
                this._panel.x = .5 * (Common.STAGE_WIDTH - p3.View.width - this._panel.width), this._panel.visible = !0, TweenMax.to(this._panel, .3, {
                    delay: 1,
                    x: x,
                    ease: Back.easeOut,
                    easeParams: [1]
                })
            }, PhotoScene.prototype.animateOut = function(callback, scope) {
                Scene.prototype.animateOut.call(this, callback, scope), TweenMax.to(this._overlay, .4, {
                    alpha: 0,
                    ease: Power1.easeInOut,
                    onComplete: function() {
                        this._overlay.visible = !1
                    },
                    onCompleteScope: this
                }), TweenMax.to(this._panel, .26, {
                    x: .5 * (Common.STAGE_WIDTH + p3.View.width + this._panel.width),
                    ease: Back.easeIn,
                    easeParams: [1],
                    onComplete: function() {
                        this._panel.visible = !1, callback && callback.call(scope)
                    },
                    onCompleteScope: this
                })
            }, PhotoScene.prototype.resize = function() {
                this.x = .5 * (p3.View.width - Common.STAGE_WIDTH), this._overlay.x = .5 * (Common.STAGE_WIDTH - p3.View.width), this._overlay.y = .5 * (Common.STAGE_HEIGHT - p3.View.height), this._overlay.width = p3.View.width, this._overlay.height = p3.View.height
            }, PhotoScene.prototype.update = function() {}, PhotoScene.prototype.savePhoto = function() {
                var canvas = this._texture.getCanvas();
                canvas.toBlob && canvas.toBlob(function(blob) {
                    saveAs(blob, "mycar.jpg")
                }, "image/jpeg")
            }, PhotoScene.prototype.onSaveButtonClick = function(button) {
                this.savePhoto()
            }, PhotoScene.prototype.onCloseButtonClick = function(button) {
                this._closeButton.onMouseOut(), this.animateOut(function() {
                    this.signals.next.dispatch()
                }, this)
            }
        }, {
            "./Common": 23,
            "./Scene": 83
        }],
        60: [function(require, module, exports) {
            function Pickup(id, view) {
                this.signals = {}, this.signals.collect = new signals.Signal, this._id = id, this._value = 0, this._collected = !1, this._timelines = [];
                var config = Common.config.pickups;
                switch (id) {
                    case 0:
                        this._value = config.toolbox.value;
                        break;
                    case 1:
                        this._value = config.lugnuts.value;
                        break;
                    case 2:
                        this._value = config["package"].value
                }
                view.anchor = new PIXI.Point(.5, .5), RoadEntity.call(this, RoadEntity.TYPE_STATIC, view)
            }
            var Common = require("./Common"),
                RoadEntity = require("./RoadEntity");
            module.exports = Pickup, Pickup.prototype = Object.create(RoadEntity.prototype), Pickup.prototype.constructor = Pickup, Pickup.prototype.init = function() {
                TweenMax.to(this.offset, .8, {
                    y: this.offset.y + 40,
                    ease: Power1.easeInOut,
                    yoyo: !0,
                    repeat: -1
                })
            }, Pickup.prototype.destroy = function() {
                TweenMax.killTweensOf(this.offset)
            }, Pickup.prototype.reset = function() {
                this._collected = !1, this.renderInWorld = !0, this.view.alpha = 1;
                for (var tl, i = 0; i < this._timelines.length; ++i) tl = this._timelines[i], tl.kill();
                this._timelines.length = 0
            }, Pickup.prototype.collect = function(collector, callback, scope) {
                if (!this._collected) {
                    this._collected = !0, this.renderInWorld = !1, this.signals.collect.dispatch(this, collector);
                    for (var tl, scale = this.view.scale.clone(), i = 0; i < this._timelines.length; ++i) tl = this._timelines[i], tl.kill();
                    this._timelines.length = 0, tl = new TimelineMax, this._timelines.push(tl), tl.append(TweenMax.to(this.view.scale, .1, {
                        x: scale.x + .2,
                        y: scale.y + .2,
                        ease: Back.easeOut
                    })), tl.append(TweenMax.to(this._view.scale, .2, {
                        x: scale.x,
                        y: scale.y,
                        ease: Power2.easeOut
                    })), tl = new TimelineMax, this._timelines.push(tl), tl.append(TweenMax.to(this.view, .2, {
                        x: collector.view.x,
                        y: collector.view.y - 80,
                        ease: Power1.easeOut
                    })), tl.append(TweenMax.to(this._view, .4, {
                        y: collector.view.y - 140,
                        ease: Power2.easeInOut,
                        onStart: function() {
                            TweenMax.to(this._view, .1, {
                                delay: .62,
                                alpha: 0,
                                ease: Power1.easeInOut
                            }), TweenMax.to(this._view.scale, .2, {
                                delay: .5,
                                x: 0,
                                y: 0,
                                ease: Back.easeIn,
                                easeParams: [2]
                            })
                        },
                        onStartScope: this,
                        onComplete: callback,
                        onCompleteScope: scope
                    }))
                }
            }, Object.defineProperty(Pickup.prototype, "id", {
                get: function() {
                    return this._id
                }
            }), Object.defineProperty(Pickup.prototype, "collected", {
                get: function() {
                    return this._collected
                }
            }), Object.defineProperty(Pickup.prototype, "value", {
                get: function() {
                    return this._value
                }
            })
        }, {
            "./Common": 23,
            "./RoadEntity": 79
        }],
        61: [function(require, module, exports) {
            function Player(color, avatar) {
                this.tiltSensitivity = 20, this.laneRecover = !1, this.laneRecoverDelay = .6, this._lastVelocity = 0;
                var params = new AudioParams;
                params.loop = !0, params.volume = 0, this._accelerateSFX = Common.audio.playSound("sfx_car_accelerate_00", params), this._deccelerateSFX = Common.audio.playSound("sfx_car_deccelerate_00", params), this._turboStartSFX = null, this._turboEndSFX = null, this._skidSFX = null, this._skidLoopSFX = null, this._engineMuted = !1, this._didSuddenSkid = !1, this._leftBoostEmitter = null, this._rightBoostEmitter = null;
                var view;
                switch (Common.garage.myCar.id) {
                    case 0:
                        view = new V8View(color, avatar);
                        break;
                    case 1:
                        view = new StockView(color, avatar);
                        break;
                    case 2:
                        view = new SaloonView(color, avatar);
                        break;
                    case 3:
                        view = new RallyView(color, avatar);
                        break;
                    case 4:
                        view = new DriftView(color, avatar);
                        break;
                    default:
                        view = new V8View(color, avatar)
                }
                Car.call(this, view, color), this.applyEngineUpgrades(), this.applyKitUpgrades()
            }
            var AudioParams = require("./AudioParams"),
                Car = require("./Car"),
                Common = require("./Common"),
                ControlTypes = require("./ControlTypes"),
                V8View = (require("./Point4"), require("./V8View")),
                StockView = require("./StockView"),
                SaloonView = require("./SaloonView"),
                RallyView = require("./RallyView"),
                DriftView = require("./DriftView");
            module.exports = Player, Player.prototype = Object.create(Car.prototype), Player.prototype.constructor = Player, Player.prototype.destroy = function() {
                this._accelerateSFX.stop(), this._deccelerateSFX.stop(), this._turboStartSFX && (this._turboStartSFX.stop(), this._turboStartSFX = null), this._turboEndSFX && (this._turboEndSFX.stop(), this._turboEndSFX = null), this._skidSFX && (this._skidSFX.stop(), this._skidSFX = null), this._skidLoopSFX && (this._skidLoopSFX.stop(), this._skidLoopSFX = null), Car.prototype.destroy.call(this)
            }, Player.prototype.update = function() {
                if (this.turnSpeed = 0, p3.Device.isMobile ? Common.garage.tiltEnabled ? this.turnSpeed = this.turnAccel * Math.min(1, Common.input.beta / this.tiltSensitivity) : (Common.input.isTouch && Common.input.touch.x < .5 * p3.View.width && (this.turnSpeed = -this.turnAccel), Common.input.isTouch && Common.input.touch.x > .5 * p3.View.width && (Common.input.touch.x > p3.View.width - 300 && Common.input.touch.y > 500 || (this.turnSpeed = this.turnAccel))) : (Common.input.isKeyLeft && (this.turnSpeed = -this.turnAccel), Common.input.isKeyRight && (this.turnSpeed = this.turnAccel)), Common.garage.controls == ControlTypes.CONTROLS_EXPERT) {
                    Common.input.isKeyFire && this.startNitro(), Common.input.isKeyDown;
                    var coef = this.velocity / 6;
                    this.offset.x -= 6200 * this.engine.getTrackCurvature(this.distance) * coef * p3.Timestep.deltaTime
                } else this.nitroFuel >= this.nitroFuelMax && this.startNitro();
                Car.prototype.update.call(this);
                var delta = this.velocity - this._lastVelocity;
                if (0 != delta && !this._engineMuted) {
                    var sign = delta / Math.abs(delta);
                    1 == sign ? (this._accelerateSFX.volume(1), this._deccelerateSFX.volume(0)) : (this._accelerateSFX.volume(0), this._deccelerateSFX.volume(1))
                } - .2 > delta && !this._didSuddenSkid ? (this._skidSFX && this._skidSFX.stop(), this._skidSFX = Common.audio.playSound("sfx_car_skid_vshort"), this._didSuddenSkid = !0) : delta > 0 && (this._didSuddenSkid = !1);
                var skid = Math.abs(this.engine.getTrackCurvature(this.distance) * this.velocity * 1.2) > .4;
                if (skid && !this._skidLoopSFX) {
                    var params = new AudioParams;
                    params.volume = .5, params.loop = !0, this._skidLoopSFX = Common.audio.playSound("sfx_car_skid_long", params)
                } else !skid && this._skidLoopSFX && (this._skidLoopSFX.stop(), this._skidLoopSFX = null);
                this._lastVelocity = this.velocity
            }, Player.prototype.applyEngineUpgrades = function() {
                var car = Common.garage.myCar,
                    engine = car.engines[car.engine];
                this.acceleration *= engine.getSpeedValue(engine.speedLevel), this.nitroMultiplier *= engine.getBoostValue(engine.boostLevel)
            }, Player.prototype.applyKitUpgrades = function() {
                if (Common.garage.isOptimalKit()) {
                    var car = Common.garage.myCar,
                        kit = car.kits[car.kit];
                    this.linearDamping = kit.getKitValue(kit.kitLevel), console.log("DAMPING - " + this.linearDamping), this.turnSpeed *= kit.getTyreValue(kit.tyreLevel)
                }
            }, Player.prototype.startNitro = function() {
                Car.prototype.startNitro.call(this) && (this._turboStartSFX = Common.audio.playSound("sfx_car_turbo_burn_00"), this._turboEndSFX && (this._turboEndSFX.stop(), this._turboEndSFX = null))
            }, Player.prototype.stopNitro = function() {
                Car.prototype.stopNitro.call(this) && (this._turboEndSFX = Common.audio.playSound("sfx_car_turbo_end_01"), this._turboStartSFX && (this._turboStartSFX.stop(), this._turboStartSFX = null))
            }, Player.prototype.muteEngine = function(value) {
                this._engineMuted = value, this._engineMuted ? (this._accelerateSFX.volume(0), this._deccelerateSFX.volume(0), this._turboStartSFX && this._turboStartSFX.pause(), this._turboEndSFX && this._turboEndSFX.pause(), this._skidLoopSFX && this._skidLoopSFX.pause()) : (this._turboStartSFX && this._turboStartSFX.play(), this._turboEndSFX && this._turboEndSFX.play(), this._skidLoopSFX && this._skidLoopSFX.play())
            }, Player.prototype.getEmitterPosition = function() {
                return new PIXI.Point(this.offset.x + 4 * this.view.back.x, 4 * this.view.back.y - 14)
            }, Player.prototype.updateEmitters = function() {
                Car.prototype.updateEmitters.call(this), this._leftBoostEmitter || (this._leftBoostEmitter = new cloudkid.Emitter(this.view.parent, [Common.assets.getTexture("particle_car_dust1"), Common.assets.getTexture("particle_car_dust2"), Common.assets.getTexture("particle_car_dust3"), Common.assets.getTexture("particle_car_dust4")], Common.assets.getJSON("particle_turbo_tyre_left")), this._leftBoostEmitter.updateOwnerPos(this.view.x - 94, this.view.y + 80)), this._leftBoostEmitter.emit = this.nitroActive, this._leftBoostEmitter.update(p3.Timestep.deltaTime), this._rightBoostEmitter || (this._rightBoostEmitter = new cloudkid.Emitter(this.view.parent, [Common.assets.getTexture("particle_car_dust1"), Common.assets.getTexture("particle_car_dust2"), Common.assets.getTexture("particle_car_dust3"), Common.assets.getTexture("particle_car_dust4")], Common.assets.getJSON("particle_turbo_tyre_right")), this._rightBoostEmitter.updateOwnerPos(this.view.x + 94, this.view.y + 80)), this._rightBoostEmitter.emit = this.nitroActive, this._rightBoostEmitter.update(p3.Timestep.deltaTime)
            }
        }, {
            "./AudioParams": 9,
            "./Car": 13,
            "./Common": 23,
            "./ControlTypes": 26,
            "./DriftView": 33,
            "./Point4": 62,
            "./RallyView": 74,
            "./SaloonView": 81,
            "./StockView": 98,
            "./V8View": 115
        }],
        62: [function(require, module, exports) {
            function Point4(x, y, z, w) {
                this.x = x || 0, this.y = y || 0, this.z = z || 0, this.w = w || 0
            }
            module.exports = Point4, Point4.prototype.normalize = function(length) {
                length = length || 1;
                var l = this.length;
                l && (this.x /= l, this.y /= l, this.z /= l)
            }, Object.defineProperty(Point4.prototype, "length", {
                get: function() {
                    return Math.sqrt(this.lengthSq)
                }
            }), Object.defineProperty(Point4.prototype, "lengthSq", {
                get: function() {
                    return this.x * this.x + this.y * this.y + this.z * this.z
                }
            }), Point4.prototype.clone = function() {
                return new Point4(this.x, this.y, this.z, this.w)
            }
        }, {}],
        63: [function(require, module, exports) {
            function Powerup(id, view) {
                Pickup.call(this, id, view), this._value = 0, this.respawnDelay = 4
            }
            var Pickup = (require("./Common"), require("./Pickup"));
            module.exports = Powerup, Powerup.prototype = Object.create(Pickup.prototype), Powerup.prototype.constructor = Powerup, Powerup.TYPE_INSTANT_BOOST = 0, Powerup.prototype.collect = function(collector) {
                Pickup.prototype.collect.call(this, collector, function() {
                    delay(this.reset, this.respawnDelay, this)
                }, this)
            }
        }, {
            "./Common": 23,
            "./Pickup": 60
        }],
        64: [function(require, module, exports) {
            function PreloaderScene() {
                this.loaded = 0, this._brand = null, this._characters = null, this._loadingText = null, this._loadingBar = null, this._loadedSmooth = 0, Scene.call(this)
            }
            var Common = require("./Common"),
                Scene = require("./Scene");
            module.exports = PreloaderScene, PreloaderScene.prototype = Object.create(Scene.prototype), PreloaderScene.prototype.constructor = PreloaderScene, PreloaderScene.prototype.init = function() {
                var bg = new PIXI.Sprite(Common.assets.getTexture("ui_bg_main_menu"));
                this.addChild(bg), this._brand = new PIXI.Sprite(Common.assets.getTexture("ui_splash_cars_logo")), this._brand.x = .5 * Common.STAGE_WIDTH, this._brand.y = 220, this._brand.anchor = new PIXI.Point(.5, .5), this._brand.visible = !1, this.addChild(this._brand), this._characters = new PIXI.Sprite(Common.assets.getTexture("ui_splash_cars")), this._characters.x = .5 * Common.STAGE_WIDTH, this._characters.y = 480, this._characters.anchor = new PIXI.Point(.5, .5), this._characters.visible = !1, this.addChild(this._characters), this._loadingBar = new PIXI.Sprite(Common.assets.getTexture("ui_loader_bg")), this._loadingBar.x = .5 * Common.STAGE_WIDTH, this._loadingBar.y = 638, this._loadingBar.anchor = new PIXI.Point(.5, .5), this.addChild(this._loadingBar), this._loadingBar.fill = new PIXI.Sprite(Common.assets.getTexture("ui_loader_bar")), this._loadingBar.fill.anchor = new PIXI.Point(.5, .5), this._loadingBar.addChild(this._loadingBar.fill), this._loadingBar.fill.mask = new PIXI.Sprite(Common.assets.getTexture("ui_loader_mask")), this._loadingBar.fill.mask.x = -6, this._loadingBar.fill.mask.anchor = new PIXI.Point(.5, .5), this._loadingBar.fill.addChild(this._loadingBar.fill.mask), webfont ? (this._loadingText = new PIXI.Text(Common.copy.loading[Common.language], {
                    font: "34px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._loadingText.x = .5 * (Common.STAGE_WIDTH - this._loadingText.width), this._loadingText.y = 680, this.addChild(this._loadingText)) : (this._loadingText = new PIXI.extras.BitmapText(Common.copy.loading[Common.language], {
                    font: "34px Great Escape",
                    align: "center"
                }), this._loadingText.x = .5 * (Common.STAGE_WIDTH - this._loadingText.textWidth), this._loadingText.y = 680, this.addChild(this._loadingText))
            }, PreloaderScene.prototype.dispose = function() {
                Common.animator.removeAll(), Scene.prototype.dispose.call(this)
            }, PreloaderScene.prototype.appear = function() {
                this.animateIn()
            }, PreloaderScene.prototype.show = function() {}, PreloaderScene.prototype.animateIn = function(callback, scope) {
                this._brand.scale = new PIXI.Point, this._brand.visible = !0, TweenMax.to(this._brand.scale, .4, {
                    delay: .28,
                    x: 1,
                    y: 1,
                    ease: Back.easeOut,
                    easeParams: [2]
                }), this._characters.scale = new PIXI.Point, this._characters.alpha = 0, this._characters.visible = !0, TweenMax.to(this._characters, .7, {
                    delay: .24,
                    alpha: 1,
                    ease: Power1.easeInOut
                }), TweenMax.to(this._characters.scale, .8, {
                    delay: .24,
                    x: 1,
                    y: 1,
                    ease: Power4.easeInOut
                })
            }, PreloaderScene.prototype.animateOut = function(callback, scope) {}, PreloaderScene.prototype.resize = function() {
                this.x = .5 * (p3.View.width - Common.STAGE_WIDTH)
            }, PreloaderScene.prototype.update = function() {
                this._loadedSmooth += .2 * (this.loaded - this._loadedSmooth), this._loadingBar.fill.mask.x = -364 + 364 * this._loadedSmooth;
                var dot = Math.floor(.005 * window.performance.now()) % 4;
                this._loadingText.text = Common.copy.loading[Common.language];
                for (var i = 0; dot > i; ++i) this._loadingText.text = this._loadingText.text + "."
            }
        }, {
            "./Common": 23,
            "./Scene": 83
        }],
        65: [function(require, module, exports) {
            function PurchasePopupScene(itemName) {
                Scene.call(this), this._overlay = null, this._itemName = itemName || "", this._panel = null, this._titleText = null, this._yesButton = null, this._noButton = null
            }
            var Common = require("./Common"),
                Scene = require("./Scene");
            module.exports = PurchasePopupScene, PurchasePopupScene.prototype = Object.create(Scene.prototype),
                PurchasePopupScene.prototype.constructor = PurchasePopupScene, PurchasePopupScene.prototype.init = function() {
                    var graphics = new PIXI.Graphics;
                    graphics.beginFill(0, .74), graphics.drawRect(0, 0, 1, 1), graphics.endFill(), this._overlay = new PIXI.Sprite(graphics.generateTexture()), this._overlay.width = p3.View.width, this._overlay.height = p3.View.height, this._overlay.visible = !1, this.addChild(this._overlay), this._panel = new PIXI.Container, this._panel.x = .5 * Common.STAGE_WIDTH, this._panel.y = .5 * Common.STAGE_HEIGHT, this._panel.visible = !1, this.addChild(this._panel), this._panel.header = new PIXI.Sprite(Common.assets.getTexture("ui_popup_top")), this._panel.header.x = .5 * -this._panel.header.width, this._panel.addChild(this._panel.header), this._panel.content = new PIXI.Sprite(Common.assets.getTexture("ui_popup_bottom_carbon_super_small")), this._panel.content.x = .5 * -this._panel.content.width, this._panel.content.y = this._panel.header.y + this._panel.header.height, this._panel.addChild(this._panel.content), this._panel.header.y -= .5 * (this._panel.header.height + this._panel.content.height), this._panel.content.y -= .5 * (this._panel.header.height + this._panel.content.height), webfont ? (this._titleText = new PIXI.Text(Common.copy.purchase_confirm[Common.language], {
                        font: "48px Arial",
                        fill: "#FFFFFF",
                        align: "center"
                    }), this._titleText.x = .5 * (this._panel.header.width - this._titleText.width), this._titleText.y = 24, this._panel.header.addChild(this._titleText)) : (this._titleText = new PIXI.extras.BitmapText(Common.copy.purchase_confirm[Common.language], {
                        font: "48px Great Escape",
                        align: "center"
                    }), this._titleText.x = .5 * (this._panel.header.width - this._titleText.textWidth), this._titleText.y = 16, this._panel.header.addChild(this._titleText)), this._yesButton = new p3.Button(Common.assets.getTexture("ui_btn_confirm_up"), Common.assets.getTexture("ui_btn_confirm_over"), Common.assets.getTexture("ui_btn_confirm_down"), Common.assets.getTexture("ui_icon_tick")), this._yesButton.x = 140, this._yesButton.y = 30, this._yesButton.animate = !0, this._yesButton.overSoundName = "sfx_ui_btn_rollover_00", this._yesButton.downSoundName = "sfx_ui_btn_press_00", this._yesButton.signals.click.add(this.onYesButtonClick, this), this._panel.addChild(this._yesButton), this._noButton = new p3.Button(Common.assets.getTexture("ui_btn_decline_up"), Common.assets.getTexture("ui_btn_decline_over"), Common.assets.getTexture("ui_btn_decline_down"), Common.assets.getTexture("ui_icon_close_big")), this._noButton.x = -140, this._noButton.y = 30, this._noButton.animate = !0, this._noButton.overSoundName = "sfx_ui_btn_rollover_00", this._noButton.downSoundName = "sfx_ui_btn_press_00", this._noButton.signals.click.add(this.onNoButtonClick, this), this._panel.addChild(this._noButton)
                }, PurchasePopupScene.prototype.dispose = function() {
                    Common.animator.removeAll(), Scene.prototype.dispose.call(this)
                }, PurchasePopupScene.prototype.appear = function() {
                    this.animateIn()
                }, PurchasePopupScene.prototype.show = function() {
                    this.interactiveChildren = !0
                }, PurchasePopupScene.prototype.animateIn = function(callback, scope) {
                    Scene.prototype.animateIn.call(this, callback, scope), this._overlay.alpha = 0, this._overlay.visible = !0, TweenMax.to(this._overlay, .2, {
                        alpha: 1,
                        ease: Power1.easeInOut
                    });
                    var x = this._panel.x;
                    this._panel.x = .5 * (Common.STAGE_WIDTH - p3.View.width - this._panel.width), this._panel.visible = !0, TweenMax.to(this._panel, .3, {
                        x: x,
                        ease: Back.easeOut,
                        easeParams: [1]
                    })
                }, PurchasePopupScene.prototype.animateOut = function(callback, scope) {
                    Scene.prototype.animateOut.call(this, callback, scope), TweenMax.to(this._overlay, .4, {
                        alpha: 0,
                        ease: Power1.easeInOut,
                        onComplete: function() {
                            this._overlay.visible = !1
                        },
                        onCompleteScope: this
                    }), TweenMax.to(this._panel, .26, {
                        x: .5 * (Common.STAGE_WIDTH + p3.View.width + this._panel.width),
                        ease: Back.easeIn,
                        easeParams: [1],
                        onComplete: function() {
                            this._panel.visible = !1, callback && callback.call(scope)
                        },
                        onCompleteScope: this
                    })
                }, PurchasePopupScene.prototype.resize = function() {
                    this.x = .5 * (p3.View.width - Common.STAGE_WIDTH), this._overlay.x = .5 * (Common.STAGE_WIDTH - p3.View.width), this._overlay.y = .5 * (Common.STAGE_HEIGHT - p3.View.height), this._overlay.width = p3.View.width, this._overlay.height = p3.View.height
                }, PurchasePopupScene.prototype.update = function() {}, PurchasePopupScene.prototype.onYesButtonClick = function(button) {
                    this.interactiveChildren = !1, this._yesButton.onMouseOut(), this.animateOut(function() {
                        this.signals.next.dispatch()
                    }, this)
                }, PurchasePopupScene.prototype.onNoButtonClick = function(button) {
                    this.interactiveChildren = !1, this._noButton.onMouseOut(), this.animateOut(function() {
                        this.signals.previous.dispatch()
                    }, this)
                }
        }, {
            "./Common": 23,
            "./Scene": 83
        }],
        66: [function(require, module, exports) {
            function RaceCamera(position, angle) {
                this.target = null, this.position = position || new Point4, this.angle = angle || 0, this.vanishingPoint = new PIXI.Point, this.fieldOfView = 90, this.focus = 2.5, this.zoom = 30, this.height = -2, this.offset = new PIXI.Point, this.distance = 1, this.tilt = 1.6, this.tiltEase = .03, this.shake = {}, this.shake.offset = new PIXI.Point, this.shake.ease = .14, this.shake.magnitude = 14, this.shake.elapsed = 0, this.shake.duration = 0
            }
            var Point4 = require("./Point4");
            module.exports = RaceCamera, RaceCamera.prototype.applyShake = function(duration, magnitude) {
                this.shake.duration = duration, this.shake.magnitude = magnitude || 14, this.shake.elapsed = 0
            }
        }, {
            "./Point4": 62
        }],
        67: [function(require, module, exports) {
            function RaceEmitter(engine, textures, config) {
                this.distance = 0, this.offset = new PIXI.Point, this.textures = null, this.startAlpha = 1, this.endAlpha = 1, this.startSpeed = 0, this.endSpeed = 0, this.zSpeed = 0, this.acceleration = null, this.startScale = 1, this.endScale = 1, this.minimumScaleMultiplier = 1, this.startColor = null, this.endColor = null, this.minLifetime = 0, this.maxLifetime = 0, this.minStartRotation = 0, this.maxStartRotation = 0, this.minRotationSpeed = 0, this.maxRotationSpeed = 0, this.particleBlendMode = 0, this.customEase = null, this.extraData = null, this.maxParticles = 1e3, this.emitterLifetime = -1, this.spawnPos = null, this.spawnType = null, this.particlesPerWave = 1, this.particleSpacing = 0, this.angleStart = 0, this.rotation = 0, this.ownerPos = null, this.particleCount = 0, this.zDepthOffset = 0, this._engine = engine, this._frequency = 1, this._spawnFunc = null, this._prevEmitterPos = null, this._prevPosIsValid = !1, this._posChanged = !1, this._parentIsPC = !1, this._parent = engine.view, this._emit = !1, this._spawnTimer = 0, this._emitterLife = -1, this._activeParticlesFirst = null, this._activeParticlesLast = null, this._poolFirst = null, textures && config && this.init(textures, config), this.recycle = this.recycle, this.update = this.update, this.rotate = this.rotate, this.updateSpawnPos = this.updateSpawnPos, this.updateOwnerPos = this.updateOwnerPos
            }
            var Point4 = require("./Point4"),
                RaceParticle = (require("./RaceEngine"), require("./RaceParticle"));
            module.exports = RaceEmitter, RaceEmitter.prototype.init = function(textures, config) {
                if (textures && config) {
                    this.cleanup(), textures = Array.isArray(textures) ? textures.slice() : [textures], this.particleImages = cloudkid.Particle.parseArt ? cloudkid.Particle.parseArt(textures) : textures, config.alpha ? (this.startAlpha = config.alpha.start, this.endAlpha = config.alpha.end) : this.startAlpha = this.endAlpha = 1, config.speed ? (this.startSpeed = config.speed.start, this.endSpeed = config.speed.end) : this.startSpeed = this.endSpeed = 0;
                    var acceleration = config.acceleration;
                    switch (acceleration && (acceleration.x || acceleration.y) ? (this.endSpeed = this.startSpeed, this.acceleration = new Point4(acceleration.x, acceleration.y, acceleration.z)) : this.acceleration = null, config.scale ? (this.startScale = config.scale.start, this.endScale = config.scale.end, this.minimumScaleMultiplier = config.scale.minimumScaleMultiplier || 1) : this.startScale = this.endScale = this.minimumScaleMultiplier = 1, config.color && (this.startColor = cloudkid.ParticleUtils.hexToRGB(config.color.start), config.color.start != config.color.end ? this.endColor = cloudkid.ParticleUtils.hexToRGB(config.color.end) : this.endColor = null), config.startRotation ? (this.minStartRotation = config.startRotation.min, this.maxStartRotation = config.startRotation.max) : this.minStartRotation = this.maxStartRotation = 0, config.rotationSpeed ? (this.minRotationSpeed = config.rotationSpeed.min, this.maxRotationSpeed = config.rotationSpeed.max) : this.minRotationSpeed = this.maxRotationSpeed = 0, this.minLifetime = config.lifetime.min, this.maxLifetime = config.lifetime.max, this.particleBlendMode = cloudkid.ParticleUtils.getBlendMode(config.blendMode), config.ease ? this.customEase = "function" == typeof config.ease ? config.ease : cloudkid.ParticleUtils.generateEase(config.ease) : this.customEase = null, cloudkid.Particle.parseData ? this.extraData = cloudkid.Particle.parseData(config.extraData) : this.extraData = config.extraData || null, this.particlesPerWave = 1, this.particleSpacing = 0, this.angleStart = 0, config.spawnType) {
                        case "point":
                            this.spawnType = "point", this._spawnFunc = this._spawnPoint;
                            break;
                        default:
                            this.spawnType = "point", this._spawnFunc = this._spawnPoint
                    }
                    this.frequency = config.frequency, this.emitterLifetime = config.emitterLifetime || -1, this.maxParticles = config.maxParticles > 0 ? config.maxParticles : 1e3, this.rotation = 0, this.ownerPos = new Point4, this.spawnPos = new Point4(config.pos.x, config.pos.y), this._prevEmitterPos = this.spawnPos.clone(), this._prevPosIsValid = !1, this._spawnTimer = 0, this.emit = !0
                }
            }, RaceEmitter.prototype.recycle = function(particle) {
                particle.next && (particle.next.prev = particle.prev), particle.prev && (particle.prev.next = particle.next), particle == this._activeParticlesLast && (this._activeParticlesLast = particle.prev), particle == this._activeParticlesFirst && (this._activeParticlesFirst = particle.next), particle.prev = null, particle.next = this._poolFirst, this._poolFirst = particle, this._parentIsPC ? (particle.alpha = 0, particle.view.visible = !1) : particle.engine && particle.engine.removeEntity(particle), --this.particleCount
            }, RaceEmitter.prototype.rotate = function(angle) {
                if (this.rotation != angle) {
                    var diff = angle - this.rotation;
                    this.rotation = angle, cloudkid.ParticleUtils.rotatePoint(diff, this.spawnPos), this._posChanged = !0
                }
            }, RaceEmitter.prototype.updateSpawnPos = function(distance, offset) {
                this._posChanged = !0, this.spawnPos.x = offset.x, this.spawnPos.y = offset.y, this.spawnPos.z = distance
            }, RaceEmitter.prototype.updateOwnerPos = function(distance, offset) {
                this._posChanged = !0, this.ownerPos.x = offset.x, this.ownerPos.y = offset.y, this.ownerPos.z = distance
            }, RaceEmitter.prototype.resetPositionTracking = function() {
                this._prevPosIsValid = !1
            }, RaceEmitter.prototype.update = function(delta) {
                var i, particle, next;
                for (particle = this._activeParticlesFirst; particle; particle = next) next = particle.next, particle.update(delta);
                var prevX, prevY, prevZ;
                this._prevPosIsValid && (prevX = this._prevEmitterPos.x, prevY = this._prevEmitterPos.y, prevZ = this._prevEmitterPos.z);
                var curX = this.ownerPos.x + this.spawnPos.x,
                    curY = this.ownerPos.y + this.spawnPos.y,
                    curZ = this.ownerPos.z + this.spawnPos.z;
                if (this.emit)
                    for (this._spawnTimer -= delta; this._spawnTimer <= 0;) {
                        if (this._emitterLife > 0 && (this._emitterLife -= this._frequency, this._emitterLife <= 0)) {
                            this._spawnTimer = 0, this._emitterLife = 0, this.emit = !1;
                            break
                        }
                        if (this.particleCount >= this.maxParticles) this._spawnTimer += this._frequency;
                        else {
                            var lifetime;
                            if (lifetime = this.minLifetime == this.maxLifetime ? this.minLifetime : Math.random() * (this.maxLifetime - this.minLifetime) + this.minLifetime, -this._spawnTimer < lifetime) {
                                var emitPosX, emitPosY, emitPosZ;
                                if (this._prevPosIsValid && this._posChanged) {
                                    var lerp = 1 + this._spawnTimer / delta;
                                    emitPosX = (curX - prevX) * lerp + prevX, emitPosY = (curY - prevY) * lerp + prevY, emitPosZ = (curZ - prevZ) * lerp + prevZ
                                } else emitPosX = curX, emitPosY = curY, emitPosZ = curZ;
                                i = 0;
                                for (var len = Math.min(this.particlesPerWave, this.maxParticles - this.particleCount); len > i; ++i) {
                                    var p;
                                    if (this._poolFirst ? (p = this._poolFirst, this._poolFirst = this._poolFirst.next, p.next = null) : p = new RaceParticle(this), this.particleImages.length > 1 ? p.applyArt(this.particleImages.random()) : p.applyArt(this.particleImages[0]), p.startAlpha = this.startAlpha, p.endAlpha = this.endAlpha, p.startSpeed = this.startSpeed, p.endSpeed = this.endSpeed, p.zSpeed = this.zSpeed, p.acceleration = this.acceleration, 1 != this.minimumScaleMultiplier) {
                                        var rand = Math.random() * (1 - this.minimumScaleMultiplier) + this.minimumScaleMultiplier;
                                        p.startScale = this.startScale * rand, p.endScale = this.endScale * rand
                                    } else p.startScale = this.startScale, p.endScale = this.endScale;
                                    if (p.startColor = this.startColor, p.endColor = this.endColor, this.minRotationSpeed == this.maxRotationSpeed ? p.rotationSpeed = this.minRotationSpeed : p.rotationSpeed = Math.random() * (this.maxRotationSpeed - this.minRotationSpeed) + this.minRotationSpeed, p.maxLife = lifetime, p.blendMode = this.particleBlendMode, p.ease = this.customEase, p.extraData = this.extraData, p.zDepthOffset = this.zDepthOffset, this._spawnFunc(p, emitPosX, emitPosY, i), p.init(), p.update(-this._spawnTimer), this._parentIsPC && p.parent) {
                                        var children = this._parent.children,
                                            index = children.indexOf(p);
                                        1 > index ? children.shift() : index == children.length - 1 ? children.pop() : children.splice(index, 1), this.addAtBack ? children.unshift(p) : children.push(p)
                                    } else this._parent.addChild(p.view), this._engine.addEntity(p, curZ);
                                    this._activeParticlesLast ? (this._activeParticlesLast.next = p, p.prev = this._activeParticlesLast, this._activeParticlesLast = p) : this._activeParticlesLast = this._activeParticlesFirst = p, ++this.particleCount
                                }
                            }
                            this._spawnTimer += this._frequency
                        }
                    }
                this._posChanged && (this._prevEmitterPos.x = curX, this._prevEmitterPos.y = curY, this._prevEmitterPos.z = curZ, this._prevPosIsValid = !0, this._posChanged = !1)
            }, RaceEmitter.prototype.cleanup = function() {
                var particle, next;
                for (particle = this._activeParticlesFirst; particle; particle = next) next = particle.next, this.recycle(particle);
                this._activeParticlesFirst = this._activeParticlesLast = null, this.particleCount = 0
            }, RaceEmitter.prototype.destroy = function() {
                this.cleanup();
                for (var particle = this._poolFirst; particle; particle = particle.next) particle.destroy();
                this._poolFirst = this._parent = this.particleImages = this.spawnPos = this.ownerPos = this.startColor = this.endColor = this.customEase = null
            }, RaceEmitter.prototype._spawnPoint = function(particle, emitPosX, emitPosY, emitPosZ, i) {
                this.minStartRotation == this.maxStartRotation ? particle.view.rotation = this.minStartRotation + this.rotation : particle.view.rotation = Math.random() * (this.maxStartRotation - this.minStartRotation) + this.minStartRotation + this.rotation, particle.offset.x = emitPosX, particle.offset.y = emitPosY, particle.distance = emitPosZ
            }, RaceEmitter.prototype._spawnBurst = function() {}, Object.defineProperty(RaceEmitter.prototype, "engine", {
                get: function() {
                    return this._engine
                }
            }), Object.defineProperty(RaceEmitter.prototype, "emit", {
                get: function() {
                    return this._emit
                },
                set: function(value) {
                    this._emit = !!value, this._emitterLife = this.emitterLifetime
                }
            }), Object.defineProperty(RaceEmitter.prototype, "frequency", {
                get: function() {
                    return this._frequency
                },
                set: function(value) {
                    "number" == typeof value && value > 0 ? this._frequency = value : this._frequency = 1
                }
            })
        }, {
            "./Point4": 62,
            "./RaceEngine": 68,
            "./RaceParticle": 71
        }],
        68: [function(require, module, exports) {
            function RaceEngine(track, view, options) {
                this.roadWidth = 600, this._camera = null, this._track = track, this._view = view, this._trackSegments = [], this._trackGradients = [], this._trackCells = [], this._entities = [], this._tempCache = []
            }
            var Common = require("./Common"),
                Point4 = require("./Point4"),
                RaceCamera = require("./RaceCamera"),
                RoadEntity = (require("./RaceTrack"), require("./RaceView"), require("./RoadEntity")),
                RoadSegment = require("./RoadSegment");
            module.exports = RaceEngine, RaceEngine.prototype.init = function() {
                this._camera = new RaceCamera;
                for (var segment, data, i = 0; i < this.track.length; ++i) data = this.track.textures[i], segment = new RoadSegment(Common.assets.getTexture(data.rM), Common.assets.getTexture(data.rL), Common.assets.getTexture(data.rR), Common.assets.getTexture(data.sL), Common.assets.getTexture(data.sR)), segment.global3d = new Point4(this.track.track[i].x, this.track.track[i].y, this.track.track[i].h), segment.distance = i, segment.view.visible = !1, this._view.addChildAt(segment.view, 0), this._trackSegments.push(segment), this._trackCells.push([]);
                for (i = 0; i < this._trackSegments.length; ++i) segment = this._trackSegments[i], segment.next = i < this._trackSegments.length - 1 ? this._trackSegments[i + 1] : this._trackSegments[0], segment.previous = i > 0 ? this._trackSegments[i - 1] : this._trackSegments[this._trackSegments.length - 1];
                this.calculateTrackGradients()
            }, RaceEngine.prototype.addEntity = function(entity, distance, cached) {
                -1 != this._entities.indexOf(entity) && this.removeEntity(entity), entity.engine = this, entity.distance = distance || 0, entity.global3d = this.getPointAt(distance, 0), entity.view.visible = !cached, this._view.addChild(entity.view), cached ? this._trackCells[Math.floor(entity.distance)].push(entity) : this._entities.push(entity)
            }, RaceEngine.prototype.removeEntity = function(entity) {
                for (var i = 0; i < this._entities.length; ++i) this._entities[i] == entity && (entity.engine = null, this._view.removeChild(entity.view), this._entities.splice(i, 1))
            }, RaceEngine.prototype.update = function() {
                var i, j, temp;
                for (i = 0; i < this._tempCache.length; ++i) temp = this._tempCache[i], temp.view.visible = !1;
                this._tempCache.length = 0;
                var entity;
                for (i = 0; i < this._entities.length; ++i) entity = this._entities[i], entity.type == RoadEntity.TYPE_MOVING && entity.update(), entity.distance %= this.track.length, entity.global3d = this.getPointAt(entity.distance, 0), entity.pos3d = this.shiftAndRotate(entity.global3d, this.camera.position.x, this.camera.position.y, -this.camera.angle), entity.pos2d = this.getProjectionFrom3d(entity.pos3d), 0 != entity.zDepth && (entity.pos2d.x += entity.offset.x / entity.zDepth, entity.pos2d.y += entity.offset.y / entity.zDepth);
                this.updateCamera();
                var d = Math.floor(this.camera.target.distance),
                    start = d - 1;
                start = 0 > start ? start + this._track.length : start;
                var cell, end = start + 2 * this._view.drawDistance;
                for (i = start; end > i; ++i)
                    for (cell = this._trackCells[i % this._track.length], j = 0; j < cell.length; ++j) entity = cell[j], entity.type == RoadEntity.TYPE_MOVING && entity.update(), entity.distance %= this.track.length, entity.global3d = this.getPointAt(entity.distance, 0), entity.pos3d = this.shiftAndRotate(entity.global3d, this.camera.position.x, this.camera.position.y, -this.camera.angle), entity.pos2d = this.getProjectionFrom3d(entity.pos3d), 0 != entity.zDepth && (entity.pos2d.x += entity.offset.x / entity.zDepth, entity.pos2d.y += entity.offset.y / entity.zDepth), this._tempCache.push(entity);
                var segment;
                for (i = start; end > i; ++i) segment = this._trackSegments[i % this._track.length], segment.pos3d = this.shiftAndRotate(segment.global3d, this.camera.position.x, this.camera.position.y, -this.camera.angle), segment.pos2d = this.getProjectionFrom3d(segment.pos3d), segment.width = this.roadWidth / segment.zDepth, this._tempCache.push(segment);
                for (this.sortDepths(), i = 0; i < this._entities.length; ++i) entity = this._entities[i], this._view.updateRoadEntity(entity);
                for (i = start; end > i; ++i)
                    for (cell = this._trackCells[i % this._track.length], j = 0; j < cell.length; ++j) entity = cell[j], this._view.updateRoadEntity(entity);
                for (i = start; end > i; ++i) segment = this._trackSegments[i % this._track.length], this._view.updateRoadSegment(segment, this._camera.target.getHeading())
            }, RaceEngine.prototype.updateCamera = function() {
                if (this.camera.target) {
                    var position = this.getPointAt(this.camera.target.distance - this.camera.distance, 0);
                    if (position.z = this.camera.target.global3d.z - this.camera.height, this.camera.offset.x = -this.camera.target.offset.x / 30, this.camera.position.x = position.x, this.camera.position.y = position.y, this.camera.position.z = position.z, this.camera.angle = position.w, this.camera.shake.duration > 0)
                        if (this.camera.shake.elapsed < this.camera.shake.duration) {
                            this.camera.shake.elapsed += p3.Timestep.deltaTime;
                            var magnitude = this.camera.shake.magnitude;
                            this.camera.shake.offset = new PIXI.Point(.5 * Common.STAGE_WIDTH + Math.random() * (magnitude - -magnitude) + -magnitude, Math.random() * (magnitude - -magnitude) + -magnitude), this.view.x += (this.camera.shake.offset.x - this.view.x) * this.camera.shake.ease, this.view.y += (this.camera.shake.offset.y - this.view.y) * this.camera.shake.ease
                        } else this.camera.shake.duration = 0;
                    var curve = this.getTrackCurvature(this.camera.target.distance),
                        coef = this.camera.target.velocity / 16,
                        ease = curve * this.camera.tilt - this.view.rotation;
                    this.view.rotation += ease * this.camera.tiltEase * coef
                }
            }, RaceEngine.prototype.sortDepths = function() {
                var depth = this._entities.concat(this._tempCache);
                depth.sort(function(a, b) {
                    return b.zDepth - b.zDepthOffset - (a.zDepth - a.zDepthOffset)
                });
                for (var i = depth.length - 1; i >= 0; --i) this.view.addChildAt(depth[i].view, 0)
            }, RaceEngine.prototype.calculateTrackGradients = function() {
                this._trackGradients = [];
                for (var h1, h2, i = 0; i < this.track.length; ++i) h1 = this.track.track[i].h, h2 = i == this.track.length - 1 ? this.track.track[0].h : this.track.track[i + 1].h, this._trackGradients.push(h1 - h2)
            }, RaceEngine.prototype.rotateAboutOrigin = function(point, angle) {
                var x = point.x * Math.cos(angle) - point.y * Math.sin(angle),
                    y = point.y * Math.cos(angle) + point.x * Math.sin(angle);
                point.x = x, point.y = y, point.w = point.w + angle
            }, RaceEngine.prototype.shiftAndRotate = function(point, x, y, angle) {
                return point = point.clone(), point.x -= x, point.y -= y, this.rotateAboutOrigin(point, angle), point
            }, RaceEngine.prototype.getPointAt = function(l, focus) {
                focus = focus || 0, 0 > l && (l += this.track.length);
                var index = Math.floor(l),
                    w2 = l % 1,
                    w1 = 1 - w2,
                    i1 = index,
                    i2 = index + 1;
                i1 %= this.track.length, i2 %= this.track.length;
                var w3 = (l + focus) % 1,
                    w4 = 1 - w3;
                index = Math.floor(l + focus);
                var i3 = index,
                    i4 = index + 1;
                i3 %= this.track.length, i4 %= this.track.length;
                var p1 = this.track.track[i1],
                    p2 = this.track.track[i2],
                    p3 = this.track.track[i3],
                    p4 = this.track.track[i4];
                return new Point4(w1 * p1.x + w2 * p2.x, w1 * p1.y + w2 * p2.y, w4 * p3.h + w3 * p4.h, this.angleAverage(p1.a, p2.a, w1, w2))
            }, RaceEngine.prototype.angleAverage = function(theta1, theta2, w1, w2) {
                var x = w1 * Math.cos(theta1) + w2 * Math.cos(theta2),
                    y = w1 * Math.sin(theta1) + w2 * Math.sin(theta2);
                return Math.atan2(y, x)
            }, RaceEngine.prototype.getProjectionFrom3d = function(point) {
                var z = point.x,
                    y = 40 * -point.z,
                    x = point.y,
                    fov = 40 * -this.camera.position.z + this.camera.fieldOfView;
                return new PIXI.Point(this.camera.zoom * (20 * x + this.camera.offset.x) / z + this.camera.vanishingPoint.x, -this.camera.zoom * (y - fov) / z + this.camera.vanishingPoint.y)
            }, RaceEngine.prototype.getTrackCurvature = function(distance) {
                var a1 = this.track.track[Math.floor(distance) % this.track.length].a,
                    a2 = this.track.track[Math.floor(distance + 1) % this.track.length].a,
                    diff = a2 - a1;
                return diff = Math.max(2 * -Math.PI, Math.min(2 * Math.PI, diff)), diff > Math.PI ? diff -= 2 * Math.PI : diff < -Math.PI && (diff += 2 * Math.PI), diff
            }, RaceEngine.prototype.getAverageTrackCurvature = function(distance, samples) {
                samples = samples || 3, 0 > distance && (distance += this.track.length);
                for (var average = 0, i = 0; samples > i; ++i) average += this.getTrackCurvature(distance + i);
                return average / samples
            }, RaceEngine.prototype.getTrackGradient = function(distance) {
                var g1 = this._trackGradients[Math.floor(distance) % this.track.length],
                    g2 = this._trackGradients[Math.ceil(distance) % this.track.length],
                    w1 = distance % 1,
                    w2 = 1 - w1;
                return w2 * g1 + w1 * g2
            }, RaceEngine.prototype.testCollision = function(p1, p2, size1, size2) {
                var collision, w = .5 * (size1.x + size2.x),
                    h = size1.y + size2.y,
                    dx = p1.x - p2.x,
                    dy = (p1.y - p2.y) * this._view.segmentHeight;
                if (Math.abs(dx) < w && Math.abs(dy) < h) {
                    collision = {};
                    var wy = w * dy,
                        hx = h * dx;
                    wy > hx ? wy > -hx ? collision.top = !0 : collision.left = !0 : wy > -hx ? collision.right = !0 : collision.bottom = !0
                }
                return collision
            }, Object.defineProperty(RaceEngine.prototype, "camera", {
                get: function() {
                    return this._camera
                }
            }), Object.defineProperty(RaceEngine.prototype, "track", {
                get: function() {
                    return this._track
                }
            }), Object.defineProperty(RaceEngine.prototype, "view", {
                get: function() {
                    return this._view
                }
            })
        }, {
            "./Common": 23,
            "./Point4": 62,
            "./RaceCamera": 66,
            "./RaceTrack": 72,
            "./RaceView": 73,
            "./RoadEntity": 79,
            "./RoadSegment": 80
        }],
        69: [function(require, module, exports) {
            function RaceLadder() {
                this._racers = [], this._player = null, this._current = null, this._next = null, this._previous = null, this._spacing = 80, PIXI.Container.call(this)
            }
            var Common = (require("./Car"), require("./Common"));
            module.exports = RaceLadder, RaceLadder.prototype = Object.create(PIXI.Container.prototype), RaceLadder.prototype.constructor = RaceLadder, RaceLadder.prototype.init = function(racers, player) {
                this._player = player, this._racers = racers.slice(), this._me = new PIXI.Sprite(Common.assets.getTexture("ui_coins_bg")), this._me.racePos = this.getRacerIndex(this._player), this.addChild(this._me), this._me.avatar = new PIXI.Sprite(this._player.view.avatar), this._me.avatar.x = 160, this._me.avatar.y = 26, this._me.avatar.scale = new PIXI.Point(-.28, .28), this._me.avatar.anchor = new PIXI.Point(.5, .5), this._me.addChild(this._me.avatar), this._me.text = new PIXI.extras.BitmapText("", {
                    font: "40px Great Escape",
                    align: "center"
                }), this._me.text.y = 6, this._me.addChild(this._me.text), this._next = new PIXI.Sprite(Common.assets.getTexture("ui_coins_bg")), this._next.avatar = new PIXI.Sprite(PIXI.Texture.EMPTY), this._next.avatar.x = 160, this._next.avatar.y = 30, this._next.avatar.anchor = new PIXI.Point(.5, .5), this._next.addChild(this._next.avatar), this._next.text = new PIXI.extras.BitmapText("", {
                    font: "40px Great Escape",
                    align: "center"
                }), this._next.text.y = 6, this._next.addChild(this._next.text), this._prev = new PIXI.Sprite(Common.assets.getTexture("ui_coins_bg")), this._prev.avatar = new PIXI.Sprite(PIXI.Texture.EMPTY), this._prev.avatar.x = 160, this._prev.avatar.y = 30, this._prev.avatar.anchor = new PIXI.Point(.5, .5), this._prev.addChild(this._prev.avatar), this._prev.text = new PIXI.extras.BitmapText("", {
                    font: "40px Great Escape",
                    align: "center"
                }), this._prev.text.y = 6, this._prev.addChild(this._prev.text), this.update(), this.updatePosition(!1)
            }, RaceLadder.prototype.update = function() {
                this._racers.length && (this._racers.sort(function(a, b) {
                    return b.finalDistance - a.finalDistance
                }), (this._me.racePos != this.getRacerIndex(this._player) || this._next && this._next.racePos != this.getRacerIndex(this._next.racer) || this._previous && this._previous.racePos != this.getRacerIndex(this._previous.racer)) && this.updatePosition(!0))
            }, RaceLadder.prototype.updatePosition = function(animate) {
                var newPos = this.getRacerIndex(this._player),
                    position = (this._me.racePos < newPos, this._me.racePos = newPos);
                this._me.text.text = (this._me.racePos + 1).toString(), this._me.text.validate(), this._me.text.x = -this._me.text.textWidth + 58;
                var order = 0 == position ? 0 : position == this._racers.length - 1 && this._racers.length >= 3 ? 2 : 1;
                this._me.y = order * this._spacing;
                var racer;
                racer = 0 == position ? this._racers[position + 1] : position == this._racers.length - 1 && this._racers.length >= 3 ? this._racers[position - 2] : this._racers[position - 1], order = 0 == position ? 1 : 0, this._next.avatar.texture = racer.view.avatar, this._next.y = order * this._spacing, this._next.racePos = this.getRacerIndex(racer), this.addChildAt(this._next, 0), this._next.text.text = (this._next.racePos + 1).toString(), this._next.text.validate(), this._next.text.x = -this._next.text.textWidth + 58, this._racers.length >= 3 && (racer = 0 == position ? this._racers[position + 2] : position == this._racers.length - 1 ? this._racers[position - 1] : this._racers[position + 1], order = position == this._racers.length - 1 ? 1 : 2, this._prev.avatar.texture = racer.view.avatar, this._prev.y = order * this._spacing, this._prev.racePos = this.getRacerIndex(racer), this.addChildAt(this._prev, 0), this._prev.text.text = (this._prev.racePos + 1).toString(), this._prev.text.validate(), this._prev.text.x = -this._prev.text.textWidth + 58)
            }, RaceLadder.prototype.animateIn = function() {
                return
            }, RaceLadder.prototype.getRacerIndex = function(racer) {
                for (var i = 0; i < this._racers.length; ++i)
                    if (this._racers[i] == racer) return i;
                return -1
            }
        }, {
            "./Car": 13,
            "./Common": 23
        }],
        70: [function(require, module, exports) {
            function RaceModeScene() {
                Scene.call(this), this.signals.settings = new signals.Signal, this._header = null, this._titleText = null, this._settingsButton = null, this._backButton = null, this._single = null, this._series = null
            }
            var Common = require("./Common"),
                Scene = require("./Scene");
            module.exports = RaceModeScene, RaceModeScene.prototype = Object.create(Scene.prototype), RaceModeScene.prototype.constructor = RaceModeScene, RaceModeScene.prototype.init = function() {
                var bg = new PIXI.Sprite(Common.assets.getTexture("ui_bg_main_menu"));
                this.addChild(bg), this._header = new PIXI.Sprite(Common.assets.getTexture("ui_top_bar")), this._header.x = .5 * Common.STAGE_WIDTH, this._header.y = 120, this._header.anchor = new PIXI.Point(.5, .5), this.addChild(this._header), webfont ? (this._titleText = new PIXI.Text(Common.copy.race_mode[Common.language], {
                    font: "48px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._titleText.x = .5 * (Common.STAGE_WIDTH - this._titleText.width), this._titleText.y = 96, this.addChild(this._titleText)) : (this._titleText = new PIXI.extras.BitmapText(Common.copy.race_mode[Common.language], {
                    font: "48px Great Escape",
                    align: "center"
                }), this._titleText.x = .5 * (Common.STAGE_WIDTH - this._titleText.textWidth), this._titleText.y = 86, this.addChild(this._titleText)), this._settingsButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_settings")), this._settingsButton.y = 120, this._settingsButton.animate = !0, this._settingsButton.overSoundName = "sfx_ui_btn_rollover_00", this._settingsButton.downSoundName = "sfx_ui_btn_press_00", this._settingsButton.signals.click.add(this.onSettingsButtonClick, this), this.addChild(this._settingsButton), this._backButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_back")), this._backButton.y = 120, this._backButton.animate = !0, this._backButton.overSoundName = "sfx_ui_btn_rollover_00", this._backButton.downSoundName = "sfx_ui_btn_press_00", this._backButton.signals.click.add(this.onBackButtonClick, this), this.addChild(this._backButton), this._single = new PIXI.Sprite(Common.assets.getTexture("ui_race_mode_single")), this._single.x = .5 * Common.STAGE_WIDTH - 220, this._single.y = .5 * Common.STAGE_HEIGHT + 40, this._single.anchor = new PIXI.Point(.5, .5), this._single.visible = !1, this.addChild(this._single), this._series = new PIXI.Sprite(Common.assets.getTexture("ui_race_mode_series")), this._series.x = .5 * Common.STAGE_WIDTH + 220, this._series.y = .5 * Common.STAGE_HEIGHT + 40, this._series.anchor = new PIXI.Point(.5, .5), this._series.visible = !1, this.addChild(this._series), webfont ? (this._single.text = new PIXI.Text(Common.copy.race_mode_single[Common.language], {
                    font: "48px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._single.text.x = .5 * -this._single.text.width + 4, this._single.text.y = 46, this._single.addChild(this._single.text)) : (this._single.text = new PIXI.extras.BitmapText(Common.copy.race_mode_single[Common.language], {
                    font: "48px Great Escape XL",
                    align: "center"
                }), this._single.text.x = .5 * -this._single.text.textWidth + 4, this._single.text.y = 46, this._single.addChild(this._single.text)), webfont ? (this._series.text = new PIXI.Text(Common.copy.race_mode_series[Common.language], {
                    font: "48px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._series.text.x = .5 * -this._series.text.width + 4, this._series.text.y = 46, this._series.addChild(this._series.text)) : (this._series.text = new PIXI.extras.BitmapText(Common.copy.race_mode_series[Common.language], {
                    font: "48px Great Escape XL",
                    align: "center"
                }), this._series.text.x = .5 * -this._series.text.textWidth + 4, this._series.text.y = 46, this._series.addChild(this._series.text)), this._single.button = new p3.Button(Common.assets.getTexture("ui_btn_confirm_up"), Common.assets.getTexture("ui_btn_confirm_over"), Common.assets.getTexture("ui_btn_confirm_down"), Common.assets.getTexture("ui_icon_play")), this._single.button.y = 200, this._single.button.animate = !0, this._single.button.overSoundName = "sfx_ui_btn_rollover_00", this._single.button.downSoundName = "sfx_ui_btn_press_00", this._single.button.signals.click.add(this.onSingleButtonClick, this), this._single.addChild(this._single.button), this._series.button = new p3.Button(Common.assets.getTexture("ui_btn_confirm_up"), Common.assets.getTexture("ui_btn_confirm_over"), Common.assets.getTexture("ui_btn_confirm_down"), Common.assets.getTexture("ui_icon_play")), this._series.button.y = 200, this._series.button.animate = !0, this._series.button.overSoundName = "sfx_ui_btn_rollover_00", this._series.button.downSoundName = "sfx_ui_btn_press_00", this._series.button.signals.click.add(this.onSeriesButtonClick, this), this._series.addChild(this._series.button)
            }, RaceModeScene.prototype.dispose = function() {
                Common.animator.removeAll(), this._single.button.dispose(), this._series.button.dispose(), this.signals.settings.dispose(), Scene.prototype.dispose.call(this)
            }, RaceModeScene.prototype.appear = function() {
                this.animateIn()
            }, RaceModeScene.prototype.show = function() {}, RaceModeScene.prototype.animateIn = function(callback, scope) {
                this._single.scale = new PIXI.Point, this._single.visible = !0,
                    TweenMax.to(this._single.scale, .4, {
                        x: 1,
                        y: 1,
                        ease: Back.easeOut,
                        easeParams: [1]
                    }), this._series.scale = new PIXI.Point, this._series.visible = !0, TweenMax.to(this._series.scale, .4, {
                        x: 1,
                        y: 1,
                        ease: Back.easeOut,
                        easeParams: [1]
                    })
            }, RaceModeScene.prototype.animateOut = function(callback, scope) {}, RaceModeScene.prototype.resize = function() {
                this.x = .5 * (p3.View.width - Common.STAGE_WIDTH), this._header.width = p3.View.width, this._settingsButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width - Math.abs(this._settingsButton.width)) - 28, this._backButton.x = .5 * (Common.STAGE_WIDTH - p3.View.width + Math.abs(this._backButton.width)) + 28
            }, RaceModeScene.prototype.update = function() {}, RaceModeScene.prototype.onSettingsButtonClick = function(button) {
                this.signals.settings.dispatch(this)
            }, RaceModeScene.prototype.onBackButtonClick = function(button) {
                this.signals.previous.dispatch(this)
            }, RaceModeScene.prototype.onSingleButtonClick = function(button) {
                this.signals.next.dispatch(this, 0)
            }, RaceModeScene.prototype.onSeriesButtonClick = function(button) {
                this.signals.next.dispatch(this, 1)
            }
        }, {
            "./Common": 23,
            "./Scene": 83
        }],
        71: [function(require, module, exports) {
            function RaceParticle(emitter) {
                this.emitter = emitter, this.velocity = new Point4, this.maxLife = 0, this.age = 0, this.ease = null, this.extraData = null, this.startAlpha = 0, this.endAlpha = 0, this.startSpeed = 0, this.endSpeed = 0, this.zSpeed = 0, this.acceleration = null, this.startScale = 0, this.endScale = 0, this.startColor = null, this.endColor = null, this.next = null, this.prev = null, this._sR = 0, this._sG = 0, this._sB = 0, this._eR = 0, this._eG = 0, this._eB = 0, this._doAlpha = !1, this._doScale = !1, this._doSpeed = !1, this._doColor = !1, this._doNormalMovement = !1, this._oneOverLife = 0;
                var view = new PIXI.Sprite;
                view.anchor = new PIXI.Point(.5, .5), RoadEntity.call(this, RoadEntity.TYPE_STATIC, view), this.init = this.init, this.update = this.update, this.applyArt = this.applyArt, this.kill = this.kill
            }
            var Point4 = require("./Point4"),
                RoadEntity = require("./RoadEntity");
            module.exports = RaceParticle, RaceParticle.prototype = Object.create(RoadEntity.prototype), RaceParticle.prototype.constructor = RaceParticle, RaceParticle.prototype.init = function() {
                this.age = 0, this.velocity.x = this.startSpeed, this.velocity.y = 0, this.velocity.z = this.zSpeed, cloudkid.ParticleUtils.rotatePoint(this.view.rotation, this.velocity), this.view.rotation *= cloudkid.ParticleUtils.DEG_TO_RADS, this.rotationSpeed *= cloudkid.ParticleUtils.DEG_TO_RADS, this.alpha = this.startAlpha, this.scale.x = this.scale.y = this.startScale, this.startColor && (this._sR = this.startColor[0], this._sG = this.startColor[1], this._sB = this.startColor[2], this.endColor && (this._eR = this.endColor[0], this._eG = this.endColor[1], this._eB = this.endColor[2])), this._doAlpha = this.startAlpha != this.endAlpha, this._doSpeed = this.startSpeed != this.endSpeed, this._doScale = this.startScale != this.endScale, this._doColor = !!this.endColor, this._doNormalMovement = this._doSpeed || 0 !== this.startSpeed || this.acceleration, this._oneOverLife = 1 / this.maxLife, this.view.tint = cloudkid.ParticleUtils.combineRGBComponents(this._sR, this._sG, this._sB), this.view.visible = !0
            }, RaceParticle.prototype.applyArt = function(texture) {
                this.view.texture = texture
            }, RaceParticle.prototype.update = function(delta) {
                if (this.age += delta, this.age >= this.maxLife) return this.kill(), -1;
                var lerp = this.age * this._oneOverLife;
                if (this.ease && (lerp = 4 == this.ease.length ? this.ease(lerp, 0, 1, 1) : this.ease(lerp)), this._doAlpha && (this.alpha = (this.endAlpha - this.startAlpha) * lerp + this.startAlpha), this._doScale) {
                    var scale = (this.endScale - this.startScale) * lerp + this.startScale;
                    this.scale.x = this.scale.y = scale
                }
                if (this._doNormalMovement) {
                    if (this._doSpeed) {
                        var speed = (this.endSpeed - this.startSpeed) * lerp + this.startSpeed;
                        cloudkid.ParticleUtils.normalize(this.velocity), cloudkid.ParticleUtils.scaleBy(this.velocity, speed)
                    } else this.acceleration && (this.velocity.x += this.acceleration.x * delta, this.velocity.y += this.acceleration.y * delta, this.velocity.z += this.acceleration.z * delta);
                    this.offset.x += this.velocity.x * delta, this.offset.y += this.velocity.y * delta, this.distance += this.velocity.z * delta
                }
                if (this._doColor) {
                    var r = (this._eR - this._sR) * lerp + this._sR,
                        g = (this._eG - this._sG) * lerp + this._sG,
                        b = (this._eB - this._sB) * lerp + this._sB;
                    this.view.tint = cloudkid.ParticleUtils.combineRGBComponents(r, g, b)
                }
                return 0 !== this.rotationSpeed ? this.view.rotation += this.rotationSpeed * delta : this.acceleration && (this.view.rotation = Math.atan2(this.velocity.y, this.velocity.x)), lerp
            }, RaceParticle.prototype.kill = function() {
                this.emitter.recycle(this)
            }, RaceParticle.prototype.destroy = function() {
                this.emitter = this.velocity = this.startColor = this.endColor = this.ease = this.next = this.prev = null
            }
        }, {
            "./Point4": 62,
            "./RoadEntity": 79
        }],
        72: [function(require, module, exports) {
            function RaceTrack(name) {
                console.log(name);
                var data = Common.assets.getJSON(name);
                this.meta = data.meta, this.objects = data.objects, this.track = data.track, this.textures = data.textures
            }
            var Common = require("./Common");
            module.exports = RaceTrack, Object.defineProperty(RaceTrack.prototype, "length", {
                get: function() {
                    return this.track.length
                }
            })
        }, {
            "./Common": 23
        }],
        73: [function(require, module, exports) {
            function RaceView() {
                this.segmentWidth = 830, this.segmentHeight = 136, this.drawDistance = 14, PIXI.Container.call(this)
            }
            require("./Common"), require("./RoadEntity"), require("./RoadSegment");
            module.exports = RaceView, RaceView.prototype = Object.create(PIXI.Container.prototype), RaceView.prototype.constructor = RaceView, RaceView.prototype.updateRoadEntity = function(entity) {
                if (entity.renderInWorld) {
                    if (entity.zDepth > this.drawDistance) return void(entity.view.visible = !1);
                    entity.view.x = entity.pos2d.x, entity.view.y = entity.pos2d.y, entity.view.scale.x = 1 / entity.zDepth * entity.scale.x, entity.view.scale.y = 1 / entity.zDepth * entity.scale.y, entity.view.visible = (entity.view.scale.x * (1 / entity.scale.x) > 0 && entity.view.scale.y * (1 / entity.scale.y)) > 0;
                    var frac = (this.drawDistance - entity.zDepth) / (.05 * this.drawDistance);
                    entity.view.alpha = Math.max(0, Math.min(1, frac)) * entity.alpha
                }
            }, RaceView.prototype.updateRoadSegment = function(segment, heading) {
                if (segment.zDepth < .7 || segment.zDepth > this.drawDistance) return void(segment.view.visible = !1);
                if (heading) {
                    var h = segment.getHeading(),
                        dot = h.x * heading.x + h.y * heading.y + h.z * heading.z;
                    if (.1 > dot) return void(segment.view.visible = !1)
                }
                var quad = segment.getQuad();
                segment.view.x = quad.tl.x, segment.view.y = quad.tl.y;
                var sx = (quad.tr.x - quad.tl.x) / this.segmentWidth,
                    sy = (quad.bl.y - quad.tl.y) / this.segmentHeight;
                sx *= 1, sy *= 1, segment.view.scale.x = 2 * sx, segment.view.scale.y = 2 * sy;
                var frac = (this.drawDistance - segment.zDepth) / (.05 * this.drawDistance);
                segment.view.alpha = Math.max(0, Math.min(1, frac)), segment.view.visible = !0;
                var sxl = (quad.tl.x - quad.bl.x) / 170,
                    sxr = -(quad.tr.x - quad.br.x) / 170;
                sxl *= 1 / sx, sxr *= 1 / sx, segment.view.left.scale.x = Math.abs(sxl), segment.view.left.scale.y = sxl / Math.abs(sxl), segment.view.right.scale.x = Math.abs(sxr), segment.view.right.scale.y = sxr / Math.abs(sxr), segment.view.grassLeft.x = segment.view.left.x, segment.view.grassRight.x = segment.view.right.x, frac = 1 - (this.drawDistance - segment.zDepth) / (1.04 * this.drawDistance), segment.view.grassLeft.scale.x = 24 * frac, segment.view.grassRight.scale.x = 24 * frac
            }
        }, {
            "./Common": 23,
            "./RoadEntity": 79,
            "./RoadSegment": 80
        }],
        74: [function(require, module, exports) {
            function RallyView(color, avatar) {
                CarView.call(this, color, avatar);
                var chassisOffset = new PIXI.Point(0, -2);
                this._shadow.offset = new PIXI.Point(0, 20), this._wheels.front.left.visible = !1, this._wheels.front.right.visible = !1, this._wheels.rear.left.offset = new PIXI.Point(-124, 78), this._wheels.rear.right.offset = new PIXI.Point(124, 78), this._front.offset = new PIXI.Point(chassisOffset.x, -4 + chassisOffset.y), this._mid.offset = new PIXI.Point(chassisOffset.x, chassisOffset.y), this._back.offset = new PIXI.Point(chassisOffset.x, chassisOffset.y)
            }
            var CarShader = require("./CarShader"),
                CarView = require("./CarView"),
                Common = require("./Common");
            module.exports = RallyView, RallyView.prototype = Object.create(CarView.prototype), RallyView.prototype.constructor = RallyView, RallyView.prototype.update = function(distance, curvature, gradient, velocity, turnVelocity) {
                var scalar = 140;
                this._curvature += .4 * (turnVelocity + curvature - this._curvature), this._curvature = Math.max(-scalar, Math.min(scalar, this._curvature)), this._front.x = .3 * this._curvature + this._front.offset.x, this._front.y = -gradient * scalar * 1.6 + this._front.offset.y, this._mid.x = .1 * this._curvature + this._mid.offset.x, this._mid.y = -gradient * scalar * 1.3 + this._mid.offset.y, this._back.x = .2 * -this._curvature + this._back.offset.x, this._back.y = gradient * scalar + this._back.offset.y, this._shadow.x = this._back.x, this._shadow.y = this._wheels.rear.left.y + this._shadow.offset.y, this._front.rotation = 8e-4 * this._curvature, this._back.rotation = 8e-4 * this._curvature, this._wheels.front.left.x = this._front.x + this._wheels.front.left.offset.x, this._wheels.front.left.y = gradient * scalar + this._wheels.front.left.offset.y, this._wheels.front.right.x = this._front.x + this._wheels.front.right.offset.x, this._wheels.front.right.y = gradient * scalar + this._wheels.front.right.offset.y, this._wheels.rear.left.x = this._back.x + this._wheels.rear.left.offset.x, this._wheels.rear.left.y = gradient * scalar + this._wheels.rear.left.offset.y, this._wheels.rear.right.x = this._back.x + this._wheels.rear.right.offset.x, this._wheels.rear.right.y = gradient * scalar + this._wheels.rear.right.offset.y;
                var theta;
                theta = .008 * turnVelocity, 0 > theta && (theta *= .112), this._wheels.front.left.rotation = theta, theta = .008 * turnVelocity, theta > 0 && (theta *= .112), this._wheels.front.right.rotation = theta, theta = .008 * turnVelocity, 0 > theta && (theta *= .112), this._wheels.rear.left.rotation = theta, theta = .008 * turnVelocity, theta > 0 && (theta *= .112), this._wheels.rear.right.rotation = theta, velocity = Math.max(0, velocity), this._wheels.front.left.animationSpeed = velocity / .2, this._wheels.front.right.animationSpeed = velocity / .2, this._wheels.rear.left.animationSpeed = velocity / .2, this._wheels.rear.right.animationSpeed = velocity / .2
            }, RallyView.prototype.createFrontLayer = function() {
                var bodyTexture = Common.assets.getTexture("car_03_body_00"),
                    maskTexture = Common.assets.getTexture("car_03_mask_00"),
                    shineTexture = Common.assets.getTexture("car_03_shine_00"),
                    maskOffset = new PIXI.Point(maskTexture._uvs.x0 - bodyTexture._uvs.x0, maskTexture._uvs.y0 - bodyTexture._uvs.y0),
                    shineOffset = new PIXI.Point(shineTexture._uvs.x0 - bodyTexture._uvs.x0, shineTexture._uvs.y0 - bodyTexture._uvs.y0),
                    front = new PIXI.Sprite(bodyTexture);
                front.shader = new CarShader(this._color, maskOffset, this._shininess, shineOffset);
                var decal = new PIXI.Sprite(this.getDecalTexture(0));
                return front.addChild(decal), new PIXI.Sprite(front.generateTexture(Common.renderer, 1, PIXI.SCALE_MODES.DEFAULT))
            }, RallyView.prototype.createMidLayer = function() {
                var bodyTexture = Common.assets.getTexture("car_03_body_01"),
                    maskTexture = Common.assets.getTexture("car_03_mask_01"),
                    shineTexture = Common.assets.getTexture("car_03_shine_01"),
                    maskOffset = new PIXI.Point(maskTexture._uvs.x0 - bodyTexture._uvs.x0, maskTexture._uvs.y0 - bodyTexture._uvs.y0),
                    shineOffset = new PIXI.Point(shineTexture._uvs.x0 - bodyTexture._uvs.x0, shineTexture._uvs.y0 - bodyTexture._uvs.y0),
                    mid = new PIXI.Sprite(bodyTexture);
                mid.shader = new CarShader(this._color, maskOffset, this._shininess, shineOffset);
                var decal = new PIXI.Sprite(this.getDecalTexture(1));
                mid.addChild(decal);
                var kit = Common.garage.myCar.kit;
                if (0 == kit || 4 == kit) {
                    var topLights = new PIXI.Sprite(Common.assets.getTexture("car_03_specialkit_00"));
                    mid.addChild(topLights)
                }
                if (0 == kit) {
                    var spareTyre = new PIXI.Sprite(Common.assets.getTexture("car_03_specialkit_01"));
                    mid.addChild(spareTyre)
                }
                if (3 == kit) {
                    var neonLights = new PIXI.Sprite(Common.assets.getTexture("car_03_specialkit_02"));
                    mid.addChild(neonLights)
                }
                return new PIXI.Sprite(mid.generateTexture(Common.renderer, 1, PIXI.SCALE_MODES.DEFAULT))
            }, RallyView.prototype.createBackLayer = function() {
                var bodyTexture = Common.assets.getTexture("car_03_body_02"),
                    maskTexture = Common.assets.getTexture("car_03_mask_02"),
                    shineTexture = Common.assets.getTexture("car_03_shine_02"),
                    maskOffset = new PIXI.Point(maskTexture._uvs.x0 - bodyTexture._uvs.x0, maskTexture._uvs.y0 - bodyTexture._uvs.y0),
                    shineOffset = new PIXI.Point(shineTexture._uvs.x0 - bodyTexture._uvs.x0, shineTexture._uvs.y0 - bodyTexture._uvs.y0),
                    back = new PIXI.Sprite(bodyTexture);
                back.shader = new CarShader(this._color, maskOffset, this._shininess, shineOffset);
                var decal = new PIXI.Sprite(this.getDecalTexture(2));
                back.addChild(decal);
                var name = Common.garage.name,
                    plate = new PIXI.Sprite(Common.garage.saveLicensePlate(name));
                plate.x = .5 * back.width, plate.y = 178, plate.scale = new PIXI.Point(.5, .5), plate.anchor.x = .5, back.addChild(plate);
                var spoiler = this.createSpoilerLayer();
                return spoiler.y = 5, back.addChild(spoiler), new PIXI.Sprite(back.generateTexture(Common.renderer, 1, PIXI.SCALE_MODES.DEFAULT))
            }, RallyView.prototype.createSpoilerLayer = function() {
                var bodyTexture = Common.assets.getTexture("car_03_spoiler_02"),
                    maskTexture = Common.assets.getTexture("car_03_maskspoiler_02"),
                    maskOffset = new PIXI.Point(maskTexture._uvs.x0 - bodyTexture._uvs.x0, maskTexture._uvs.y0 - bodyTexture._uvs.y0),
                    spoiler = new PIXI.Sprite(bodyTexture);
                return spoiler.shader = new CarShader(this._color, maskOffset, 0), new PIXI.Sprite(spoiler.generateTexture(Common.renderer, 1, PIXI.SCALE_MODES.DEFAULT))
            }, RallyView.prototype.createRearWheel = function() {
                var sequence = new p3.MovieClipSequence;
                return sequence.addTextures([Common.assets.getTexture("car_03_wheels_rear_0"), Common.assets.getTexture("car_03_wheels_rear_1"), Common.assets.getTexture("car_03_wheels_rear_2"), Common.assets.getTexture("car_03_wheels_rear_3")]), new p3.MovieClip(sequence)
            }, RallyView.prototype.createShadow = function() {
                return new PIXI.Sprite(Common.assets.getTexture("car_03_shadow"))
            }
        }, {
            "./CarShader": 19,
            "./CarView": 21,
            "./Common": 23
        }],
        75: [function(require, module, exports) {
            function RedeemCodeScene() {
                Scene.call(this), this.signals.error = new signals.Signal, this.signals.reward = new signals.Signal, this._header = null, this._titleText = null, this._panel = null, this._backButton = null, this._muteButton = null, this._redeemButton = null, this._clearButton = null, this._numericButtons = [], this._numericCode = "", this._outputText = null
            }
            var Common = require("./Common"),
                Scene = (require("./MessagePopup"), require("./Scene"));
            module.exports = RedeemCodeScene, RedeemCodeScene.prototype = Object.create(Scene.prototype), RedeemCodeScene.prototype.constructor = RedeemCodeScene, RedeemCodeScene.NUMERIC_CODE_LENGTH = 4, RedeemCodeScene.prototype.init = function() {
                var bg = new PIXI.Sprite(Common.assets.getTexture("ui_bg_main_menu"));
                this.addChild(bg), this._header = new PIXI.Sprite(Common.assets.getTexture("ui_top_bar")), this._header.x = .5 * Common.STAGE_WIDTH, this._header.y = 120, this._header.anchor = new PIXI.Point(.5, .5), this.addChild(this._header), webfont ? (this._titleText = new PIXI.Text(Common.copy.code_entry[Common.language], {
                    font: "48px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._titleText.x = .5 * (Common.STAGE_WIDTH - this._titleText.width), this._titleText.y = 96, this.addChild(this._titleText)) : (this._titleText = new PIXI.extras.BitmapText(Common.copy.code_entry[Common.language], {
                    font: "48px Great Escape",
                    align: "center"
                }), this._titleText.x = .5 * (Common.STAGE_WIDTH - this._titleText.textWidth), this._titleText.y = 86, this.addChild(this._titleText)), this._muteButton = new p3.MuteButton(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_sound_on"), Common.assets.getTexture("ui_icon_sound_off")), this._muteButton.y = 120, this._muteButton.animate = !0, this._muteButton.visible = !1, this._muteButton.overSoundName = "sfx_ui_btn_rollover_00", this._muteButton.downSoundName = "sfx_ui_btn_press_00", this.addChild(this._muteButton), this._backButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_home")), this._backButton.y = 120, this._backButton.animate = !0, this._backButton.overSoundName = "sfx_ui_btn_rollover_00", this._backButton.downSoundName = "sfx_ui_btn_press_00", this._backButton.signals.click.add(this.onBackButtonClick, this), this.addChild(this._backButton), this._panel = new PIXI.Sprite(Common.assets.getTexture("ui_unlock_device_bg")), this._panel.x = .5 * Common.STAGE_WIDTH, this._panel.y = .5 * Common.STAGE_HEIGHT + 80, this._panel.anchor = new PIXI.Point(.5, .5), this.addChild(this._panel);
                for (var button, origin = new PIXI.Point(-58, 46), spacing = 118, offsets = [new PIXI.Point(-1, -1), new PIXI.Point(0, -1), new PIXI.Point(1, -1), new PIXI.Point(-1, 0), new PIXI.Point(0, 0), new PIXI.Point(1, 0), new PIXI.Point(-1, 1), new PIXI.Point(0, 1), new PIXI.Point(1, 1)], i = 0; 9 > i; ++i) button = new p3.Button(Common.assets.getTexture("ui_btn_unlock_number_up"), Common.assets.getTexture("ui_btn_unlock_number_over"), Common.assets.getTexture("ui_btn_unlock_number_down"), Common.assets.getTexture("ui_icon_calculator_" + (i + 1))), button.id = i + 1, button.x = origin.x + offsets[i].x * spacing, button.y = origin.y + offsets[i].y * spacing, button.overSoundName = "sfx_ui_btn_rollover_00", button.downSoundName = "sfx_ui_btn_press_00", button.signals.click.add(this.onNumericButtonClick, this), this._panel.addChild(button), this._numericButtons.push(button);
                this._clearButton = new p3.Button(Common.assets.getTexture("ui_btn_unlock_delete_up"), Common.assets.getTexture("ui_btn_unlock_delete_over"), Common.assets.getTexture("ui_btn_unlock_delete_down"), Common.assets.getTexture("ui_icon_delete")), this._clearButton.x = origin.x + 2 * spacing, this._clearButton.y = origin.y + -1 * spacing, this._clearButton.overSoundName = "sfx_ui_btn_rollover_00", this._clearButton.downSoundName = "sfx_ui_btn_press_00", this._clearButton.signals.click.add(this.onClearButtonClick, this), this._panel.addChildAt(this._clearButton, 1), this._redeemButton = new p3.Button(Common.assets.getTexture("ui_btn_unlock_enter_up"), Common.assets.getTexture("ui_btn_unlock_enter_over"), Common.assets.getTexture("ui_btn_unlock_enter_down"), Common.assets.getTexture("ui_icon_tick")), this._redeemButton.x = origin.x + 2 * spacing, this._redeemButton.y = origin.y + .5 * spacing, this._redeemButton.overSoundName = "sfx_ui_btn_rollover_00", this._redeemButton.downSoundName = "sfx_ui_btn_press_00", this._redeemButton.clickSoundName = "sfx_ui_btn_play_00", this._redeemButton.signals.click.add(this.onRedeemButtonClick, this), this._panel.addChildAt(this._redeemButton, 1), this._outputText = new PIXI.extras.BitmapText("", {
                    font: "48px Esper",
                    align: "center"
                }), this._outputText.y = -188 - .5 * this._outputText.textHeight, this._panel.addChild(this._outputText), this.updateOutputText(), Common.tracking.track(new p3.TrackingDataPlaydomGameAction("main", "code_redeem"))
            }, RedeemCodeScene.prototype.dispose = function() {
                Common.animator.removeAll(), Scene.prototype.dispose.call(this)
            }, RedeemCodeScene.prototype.appear = function() {
                this.animateIn()
            }, RedeemCodeScene.prototype.show = function() {}, RedeemCodeScene.prototype.animateIn = function(callback, scope) {
                this._muteButton.scale = new PIXI.Point, this._muteButton.visible = !0, TweenMax.to(this._muteButton.scale, .4, {
                    delay: .3,
                    x: 1,
                    y: 1,
                    ease: Back.easeOut,
                    easeParams: [2]
                })
            }, RedeemCodeScene.prototype.animateOut = function(callback, scope) {}, RedeemCodeScene.prototype.resize = function() {
                this.x = .5 * (p3.View.width - Common.STAGE_WIDTH), this._header.width = p3.View.width, this._muteButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width - Math.abs(this._muteButton.width)) - 28, this._backButton.x = .5 * (Common.STAGE_WIDTH - p3.View.width + Math.abs(this._backButton.width)) + 28
            }, RedeemCodeScene.prototype.update = function() {}, RedeemCodeScene.prototype.updateOutputText = function() {
                this._outputText.text = this._numericCode, this._outputText.validate(), this._outputText.x = .5 * -this._outputText.textWidth
            }, RedeemCodeScene.prototype.onRedeemButtonClick = function(button) {
                var garage = Common.garage,
                    result = garage.redeemCode(this._numericCode);
                void 0 == result.error ? (this.signals.reward.dispatch(result.value), Common.tracking.track(new p3.TrackingDataPlaydomGameAction("code_screen", "code_success", result.code.toString()))) : this.signals.error.dispatch(result.error), this.onClearButtonClick()
            }, RedeemCodeScene.prototype.onNumericButtonClick = function(button) {
                var num = button.id;
                this._numericCode.length < RedeemCodeScene.NUMERIC_CODE_LENGTH && (this._numericCode += num.toString(), this.updateOutputText())
            }, RedeemCodeScene.prototype.onBackButtonClick = function(button) {
                this.signals.previous.dispatch()
            }, RedeemCodeScene.prototype.onClearButtonClick = function(button) {
                this._numericCode = "", this.updateOutputText()
            }
        }, {
            "./Common": 23,
            "./MessagePopup": 54,
            "./Scene": 83
        }],
        76: [function(require, module, exports) {
            function ResultScene(place, prize, pickups, seriesFinished) {
                Scene.call(this), this.signals.retry = new signals.Signal, this.signals.leader = new signals.Signal, this.signals.settings = new signals.Signal, this._place = place || 0, this._prize = prize || 0, this._pickups = pickups || [], this._seriesFinished = seriesFinished, this._header = null, this._titleText = null, this._position = null, this._trophy = null, this._particles = null, this._cash = null, this._helpButton = null, this._homeButton = null, this._leaderButton = null, this._nextButton = null, this._retryButton = null, this._car = null, this._bursts = [], this._fairyDustEmitter = null
            }
            var CarSpine = require("./CarSpine"),
                CoinBurst = require("./CoinBurst"),
                Common = require("./Common"),
                CountryTypes = require("./CountryTypes"),
                MessagePopup = require("./MessagePopup"),
                Scene = require("./Scene"),
                Scores = require("./Scores");
            module.exports = ResultScene, ResultScene.prototype = Object.create(Scene.prototype), ResultScene.prototype.constructor = ResultScene, ResultScene.animator = new p3.Animator, ResultScene.prototype.init = function() {
                var bg = new PIXI.Sprite(Common.assets.getTexture("ui_bg_main_menu"));
                this.addChild(bg), this._header = new PIXI.Sprite(Common.assets.getTexture("ui_top_bar")), this._header.x = .5 * Common.STAGE_WIDTH, this._header.y = 120, this._header.anchor = new PIXI.Point(.5, .5), this.addChild(this._header), webfont ? (this._titleText = new PIXI.Text(Common.copy.results[Common.language], {
                    font: "48px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._titleText.x = .5 * (Common.STAGE_WIDTH - this._titleText.width), this._titleText.y = 96, this.addChild(this._titleText)) : (this._titleText = new PIXI.extras.BitmapText(Common.copy.results[Common.language], {
                    font: "48px Great Escape",
                    align: "center"
                }), this._titleText.x = .5 * (Common.STAGE_WIDTH - this._titleText.textWidth), this._titleText.y = 86, this.addChild(this._titleText)), this._position = new PIXI.Sprite(Common.assets.getTexture("ui_message_bg_tutorial")), this._position.x = .5 * Common.STAGE_WIDTH - 160, this._position.y = .5 * Common.STAGE_HEIGHT - 60, this._position.anchor = new PIXI.Point(.5, .5), this._position.visible = !1, this.addChild(this._position), webfont ? (this._position.text = new PIXI.Text(Common.copy["ordinal_number" + (this._place + 1)][Common.language], {
                    font: "120px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._position.text.x = .5 * -this._position.text.width - 40, this._position.text.y = .5 * -this._position.text.height + 8, this._position.addChild(this._position.text)) : (this._position.text = new PIXI.extras.BitmapText(Common.copy["ordinal_number" + (this._place + 1)][Common.language], {
                    font: "120px Great Escape XL",
                    align: "center"
                }), this._position.text.x = .5 * -this._position.text.textWidth - 40, this._position.text.y = .5 * -this._position.text.textHeight + 8, this._position.addChild(this._position.text)), this._car = new PIXI.Container, this.addChild(this._car), this._particles = new PIXI.Container, this.addChild(this._particles);
                var texture = PIXI.Texture.EMPTY,
                    series = Common.trackManager.currentSeries;
                if (series && -1 != series.reward && this._seriesFinished) switch (series.reward) {
                    case 0:
                        texture = Common.assets.getTexture("ui_trophy_gold_big");
                        break;
                    case 1:
                        texture = Common.assets.getTexture("ui_trophy_silver_big");
                        break;
                    case 2:
                        texture = Common.assets.getTexture("ui_trophy_bronze_big")
                } else switch (this._place) {
                    case 0:
                        texture = Common.assets.getTexture("ui_trophies_star_gold_big");
                        break;
                    case 1:
                        texture = Common.assets.getTexture("ui_trophies_star_silver_big");
                        break;
                    case 2:
                        texture = Common.assets.getTexture("ui_trophies_star_bronze_big")
                }
                if (this._trophy = new PIXI.Sprite(texture), this._trophy.x = .5 * Common.STAGE_WIDTH + 300, this._trophy.y = 460, this._trophy.anchor = new PIXI.Point(.5, .5), this._trophy.visible = !1, this.addChild(this._trophy), series && -1 != series.reward && this._seriesFinished) {
                    texture = PIXI.Texture.EMPTY;
                    var name = series.type.toLowerCase();
                    switch (series.reward) {
                        case 0:
                            texture = Common.assets.getTexture("ui_trophy_" + name + "_gold_big");
                            break;
                        case 1:
                            texture = Common.assets.getTexture("ui_trophy_" + name + "_silver_big");
                            break;
                        case 2:
                            texture = Common.assets.getTexture("ui_trophy_" + name + "_bronze_big")
                    }
                }
                this._trophy.icon = new PIXI.Sprite(texture), this._trophy.icon.anchor = new PIXI.Point(.5, .5), this._trophy.addChild(this._trophy.icon);
                var config = Common.assets.getJSON("particle_fairydust_bg");
                this._trophy.emitter = new cloudkid.Emitter(this._particles, [Common.assets.getTexture("particle_standard")], config), this._trophy.emitter.emit = !1, this._trophy.emitter.updateOwnerPos(this._trophy.x, this._trophy.y), ResultScene.animator.add(this._trophy.emitter), this._car.animation = new PIXI.Container, this._car.animation.x = .5 * Common.STAGE_WIDTH, this._car.animation.y = .5 * Common.STAGE_HEIGHT + 134 + 60, this._car.animation.scale = new PIXI.Point(.5, .5), this._car.addChild(this._car.animation), this._car.animation.spine = new CarSpine(Common.assets.getSpineData("car_00_garage")), this._car.animation.spine.skeleton.setToSetupPose(), this._car.animation.spine.update(0), this._car.animation.spine.autoUpdate = !1, this._car.animation.spine.state.setAnimationByName(0, "idle", !0), this._car.animation.addChild(this._car.animation.spine), this.setupCar(), this.animateCar(), this._cash = new PIXI.Sprite(Common.assets.getTexture("ui_coins_bg")), this._cash.y = .5 * Common.STAGE_HEIGHT - 174, this._cash.anchor = new PIXI.Point(.5, .5), this._cash.visible = !1, this.addChild(this._cash), this._cash.icon = new p3.AdditiveSprite(Common.assets.getTexture("ui_icon_coin")), this._cash.icon.x = -76, this._cash.icon.y = 0, this._cash.icon.scale = new PIXI.Point(.9, .9), this._cash.icon.anchor = new PIXI.Point(.5, .5), this._cash.icon.blendPasses = 1, this._cash.addChild(this._cash.icon);
                var sum = Common.garage.cash - (this._prize + this.getPickupsCashTotal());
                this._cash.target = sum, this._cash.text = new PIXI.extras.BitmapText(sum.toString(), {
                    font: "38px Great Escape",
                    align: "left"
                }), this._cash.text.x = .5 * -this._cash.text.textWidth + 20, this._cash.text.y = .5 * -this._cash.text.textHeight - 2, this._cash.addChild(this._cash.text), this._helpButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_help")), this._helpButton.y = 120, this._helpButton.animate = !0, this._helpButton.signals.click.add(this.onHelpButtonClick, this), this.addChild(this._helpButton), this._settingsButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_settings")), this._settingsButton.y = 120, this._settingsButton.animate = !0, this._settingsButton.overSoundName = "sfx_ui_btn_rollover_00", this._settingsButton.downSoundName = "sfx_ui_btn_press_00", this._settingsButton.signals.click.add(this.onSettingsButtonClick, this), this.addChild(this._settingsButton), this._homeButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_home")), this._homeButton.y = 120, this._homeButton.animate = !0, this._homeButton.signals.click.add(this.onHomeButtonClick, this), this.addChild(this._homeButton), this._leaderButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_leaderboard")), this._leaderButton.y = 120, this._leaderButton.visible = Common.trackManager.currentTrack.country != CountryTypes.TUTORIAL, this._leaderButton.signals.click.add(this.onLeaderButtonClick, this), this.addChild(this._leaderButton), this._retryButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_replay")), this._retryButton.y = 120, this._retryButton.animate = !0, this._retryButton.signals.click.add(this.onRetryButtonClick, this), this.addChild(this._retryButton), this._nextButton = new p3.Button(Common.assets.getTexture("ui_btn_confirm_up"), Common.assets.getTexture("ui_btn_confirm_over"), Common.assets.getTexture("ui_btn_confirm_down"), Common.assets.getTexture("ui_icon_play")), this._nextButton.y = .5 * Common.STAGE_HEIGHT + 260, this._nextButton.animate = !0, this._nextButton.signals.click.add(this.onNextButtonClick, this), this.addChild(this._nextButton), config = Common.assets.getJSON("particle_coin_burst"), this._fairyDustEmitter = new cloudkid.Emitter(this._particles, [Common.assets.getTexture("particle_standard")], config), this._fairyDustEmitter.emit = !1, this._fairyDustEmitter.updateOwnerPos(.5 * Common.STAGE_WIDTH, .5 * Common.STAGE_HEIGHT), ResultScene.animator.add(this._fairyDustEmitter)
            }, ResultScene.prototype.dispose = function() {
                ResultScene.animator.removeAllTweens(!0), this.signals.retry.dispose(), this.signals.leader.dispose(), this.signals.settings.dispose(), this._message.destroy(), this._car.animation.spine.destroy(), Scene.prototype.dispose.call(this)
            }, ResultScene.prototype.appear = function() {
                this.animateIn();
                var str = Common.copy.results_helper[Common.language].replace("[POSITION]", Common.copy["ordinal_number" + (this._place + 1)][Common.language]);
                this._message = new MessagePopup(8, MessagePopup.CHARACTER_MCQUEEN, str), this._message.x = .5 * (Common.STAGE_WIDTH - p3.View.width) + 20, this._message.y = p3.View.height - this._message.height - 20, this._message.auto = !0, this._message.animateIn(), this.addChild(this._message);
                var score = new Scores;
                score.sendScore(1, Common.garage.name, Common.score)
            }, ResultScene.prototype.show = function() {}, ResultScene.prototype.animateIn = function(callback, scope) {
                var to, timeline = new TimelineMax({
                    delay: .4,
                    onComplete: this.animateTrophy,
                    onCompleteScope: this
                });
                ResultScene.animator.add(timeline), this._position.alpha = 0, this._position.visible = !0, timeline.insert(TweenMax.to(this._position, .2, {
                    alpha: 1,
                    ease: Power1.easeInOut
                })), to = this._position.position.clone(), this._position.y = this._position.y + 80, timeline.insert(TweenMax.to(this._position, .4, {
                    y: to.y,
                    ease: Back.easeOut,
                    easeParams: [2]
                })), this._cash.alpha = 0, this._cash.visible = !0, timeline.insert(TweenMax.to(this._cash, .4, {
                    alpha: 1,
                    ease: Power1.easeInOut
                })), ResultScene.animator.add(TweenMax.to(this._leaderButton.scale, .6, {
                    x: 1.14,
                    y: 1.14,
                    ease: Power1.easeInOut,
                    repeat: -1,
                    yoyo: !0
                })), this._cash.icon.blendStrength = 0, ResultScene.animator.add(TweenMax.to(this._cash.icon, 1.4, {
                    blendStrength: .34,
                    ease: Power1.easeInOut,
                    repeat: -1,
                    yoyo: !0
                }))
            }, ResultScene.prototype.animateOut = function(callback, scope) {}, ResultScene.prototype.resize = function() {
                this.x = .5 * (p3.View.width - Common.STAGE_WIDTH), this._header.width = p3.View.width, this._settingsButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width - this._settingsButton.width) - 28, this._helpButton.x = this._settingsButton.x - 112, this._homeButton.x = .5 * (Common.STAGE_WIDTH - p3.View.width + this._homeButton.width) + 28, this._leaderButton.x = this._homeButton.x + 112, this._retryButton.x = Common.trackManager.currentTrack.country != CountryTypes.TUTORIAL ? this._leaderButton.x + 112 : this._homeButton.x + 112, this._cash.x = .5 * (Common.STAGE_WIDTH + p3.View.width) - 160, this._nextButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width - this._nextButton.width) - 28
            }, ResultScene.prototype.update = function() {
                ResultScene.animator.update(), this._car.animation.spine && this._car.animation.spine.update(p3.Timestep.deltaTime), this._trophy.emitter.updateOwnerPos(this._trophy.x, this._trophy.y - 60);
                for (var burst, i = 0; i < this._bursts.length; ++i) burst = this._bursts[i], burst.update()
            }, ResultScene.prototype.animateTrophy = function(callback, scope) {
                var to, timeline = new TimelineMax({
                    onComplete: this.animateAwards,
                    onCompleteScope: this
                });
                if (ResultScene.animator.add(timeline), this._place < 3 || this._seriesFinished) to = this._trophy.position.clone(), this._trophy.position = new PIXI.Point(.5 * Common.STAGE_WIDTH, .5 * Common.STAGE_HEIGHT + 60), this._trophy.scale = new PIXI.Point, this._trophy.visible = !0, timeline.insert(TweenMax.to(this._trophy.scale, .34, {
                    delay: .4,
                    x: 1.34,
                    y: 1.34,
                    ease: Back.easeOut,
                    onStart: function() {
                        this._trophy.emitter.emit = !0, Common.audio.playSound("sfx_race_lights_go_00")
                    },
                    onStartScope: this
                })), this._trophy.rotation = -.07, timeline.insert(TweenMax.to(this._trophy, .28, {
                    delay: .6,
                    rotation: .14,
                    ease: Power1.easeInOut,
                    yoyo: !0,
                    repeat: 1,
                    onComplete: function(timeline) {
                        this.createCoinBurst(this._trophy.position, this._prize), ResultScene.animator.add(TweenMax.to(this._trophy, .28, {
                            rotation: 0,
                            ease: Power1.easeInOut
                        })), ResultScene.animator.add(TweenMax.to(this._trophy, .6, {
                            ease: Power1.easeInOut,
                            bezier: [{
                                x: this._trophy.x + 160,
                                y: this._trophy.y - 20
                            }, {
                                x: to.x,
                                y: to.y
                            }]
                        })), ResultScene.animator.add(TweenMax.to(this._trophy.scale, .6, {
                            x: 1,
                            y: 1,
                            ease: Power1.easeInOut,
                            easeParams: [1],
                            onComplete: function() {},
                            onCompleteScope: this
                        }))
                    },
                    onCompleteScope: this
                }));
                else {
                    var center = new PIXI.Point(.5 * Common.STAGE_WIDTH, .5 * Common.STAGE_HEIGHT);
                    this.createCoinBurst(center, this._prize), this.animateAwards()
                }
            }, ResultScene.prototype.animateAwards = function(callback, scope) {
                var to, timeline = new TimelineMax({
                    delay: 1.2
                });
                ResultScene.animator.add(timeline);
                for (var pickup, reward, delay = .5, i = 0; i < this._pickups.length; ++i) pickup = this._pickups[i], reward = new PIXI.Sprite(pickup.texture), reward.x = .5 * Common.STAGE_WIDTH, reward.y = .5 * Common.STAGE_HEIGHT, reward.anchor = new PIXI.Point(.5, .5), this.addChild(reward), reward.scale = new PIXI.Point, timeline.insert(TweenMax.to(reward.scale, .34, {
                    delay: i * delay,
                    x: 1,
                    y: 1,
                    ease: Back.easeOut,
                    easeParams: [2]
                })), to = reward.position.clone(), reward.y = reward.y + 40, timeline.insert(TweenMax.to(reward, .34, {
                    delay: i * delay,
                    y: to.y,
                    ease: Power1.easeInOut,
                    onComplete: this.createCoinBurst,
                    onCompleteParams: [reward.position, pickup.value],
                    onCompleteScope: this
                })), timeline.insert(TweenMax.to(reward.scale, .2, {
                    delay: .34 + i * delay,
                    x: 0,
                    y: 0,
                    ease: Back.easeIn,
                    easeParams: [1]
                }))
            }, ResultScene.prototype.createCoinBurst = function(position, value) {
                var localPos = this._cash.parent.toLocal(this._cash.icon.position, this._cash),
                    burst = new CoinBurst(position, localPos, value, ResultScene.animator);
                burst.signals.coin.add(this.onCoinAdded, this), this.addChild(burst), this._bursts.push(burst), this._fairyDustEmitter.emit = !0, Common.audio.playSound("sfx_coins_burstout_03")
            }, ResultScene.prototype.updateCashText = function(animate) {
                function next() {
                    var cash = this._cash.value;
                    cash += (this._cash.target - cash) * ease, this._cash.value = cash, this._cash.text.text = Math.ceil(this._cash.value).toString(), Math.abs(Math.floor(this._cash.target - cash)) > 0 && ResultScene.animator.add(TweenMax.delayedCall(.02, next, null, this)), Common.audio.playSound("sfx_counter_loop_00")
                }
                if (animate) {
                    var ease = .2;
                    this._cash.value = parseInt(this._cash.text.text), next.call(this)
                } else this._cash.text.text = Common.garage.cash.toString()
            }, ResultScene.prototype.animateCoins = function() {
                var timeline = new TimelineMax;
                ResultScene.animator.add(timeline), timeline.append(TweenMax.to(this._cash.scale, .2, {
                    x: 1.14,
                    y: 1.14,
                    ease: Elastic.easeOut,
                    easeParams: [1]
                })), timeline.append(TweenMax.to(this._cash.scale, .2, {
                    x: 1,
                    y: 1,
                    ease: Back.easeInOut,
                    easeParams: [2]
                })), this.updateCashText(!0)
            }, ResultScene.prototype.setupCar = function() {
                var garage = Common.garage,
                    car = garage.myCar,
                    colorIndex = car.color,
                    color = car.colors[colorIndex];
                if (!this._car.animation.spine || this._car.animation.spine.id != car.id) {
                    this._car.animation.spine && this._car.animation.spine.parent.removeChild(this._car.animation.spine);
                    var name = "car_" + p3.Utils.padNumber(car.id, 2) + "_garage";
                    this._car.animation.spine = new CarSpine(Common.assets.getSpineData(name)), this._car.animation.spine.id = car.id, this._car.animation.spine.skeleton.setToSetupPose(), this._car.animation.spine.update(0), this._car.animation.spine.autoUpdate = !1, this._car.animation.addChild(this._car.animation.spine)
                }
                this._car.animation.spine.paintColor = color.color, this._car.animation.spine.decalTheme = garage.myCar.decal, this._car.animation.spine.kitTheme = Math.max(0, garage.myCar.kit)
            }, ResultScene.prototype.animateCar = function() {
                if (0 == this._place) this._car.animation.spine.state.setAnimationByName(0, "upgrade_wheels", !0);
                else if (1 == this._place) this._car.animation.spine.state.setAnimationByName(0, "upgrade_paint", !0);
                else if (2 == this._place) this._car.animation.spine.state.setAnimationByName(0, "upgrade_engine", !0);
                else {
                    var arr = ["idle", "idle2"],
                        name = arr[Math.floor(Math.random() * arr.length)];
                    this._car.animation.spine.state.addAnimationByName(0, name, !0, 0)
                }
            }, ResultScene.prototype.getPickupsCashTotal = function() {
                for (var pickup, total = 0, i = 0; i < this._pickups.length; ++i) pickup = this._pickups[i], total += pickup.value;
                return total
            }, ResultScene.prototype.onSettingsButtonClick = function(button) {
                this.signals.settings.dispatch(this)
            }, ResultScene.prototype.onHelpButtonClick = function(button) {
                this.signals.pause.dispatch(this)
            }, ResultScene.prototype.onHomeButtonClick = function(button) {
                this.signals.previous.dispatch(this)
            }, ResultScene.prototype.onNextButtonClick = function(button) {
                this.signals.next.dispatch(this)
            }, ResultScene.prototype.onRetryButtonClick = function(button) {
                this.signals.retry.dispatch(this)
            }, ResultScene.prototype.onLeaderButtonClick = function(button) {
                this.signals.leader.dispatch(this)
            }, ResultScene.prototype.onCoinAdded = function(burst, coin, count) {
                1 == count && (this._cash.target += burst.count), this.animateCoins()
            }
        }, {
            "./CarSpine": 20,
            "./CoinBurst": 22,
            "./Common": 23,
            "./CountryTypes": 27,
            "./MessagePopup": 54,
            "./Scene": 83,
            "./Scores": 86
        }],
        77: [function(require, module, exports) {
            function RewardPopupScene(cash) {
                Scene.call(this), this._panel = null, this._titleText = null, this._coinsIcon = null, this._cash = cash || 0, this._cashSmooth = 0, this._infoText = null, this._closeButton = null, this._acceptButton = null
            }
            var Common = require("./Common"),
                Scene = require("./Scene");
            module.exports = RewardPopupScene, RewardPopupScene.prototype = Object.create(Scene.prototype), RewardPopupScene.prototype.constructor = RewardPopupScene, RewardPopupScene.prototype.init = function() {
                var graphics = new PIXI.Graphics;
                graphics.beginFill(0, .74), graphics.drawRect(0, 0, 1, 1), graphics.endFill(), this._overlay = new PIXI.Sprite(graphics.generateTexture()), this._overlay.width = p3.View.width, this._overlay.height = p3.View.height, this._overlay.visible = !1, this.addChild(this._overlay), graphics = new PIXI.Graphics, graphics.beginFill(16711680), graphics.drawRect(0, 0, 900, 520), graphics.endFill(), this._panel = new PIXI.Container, this._panel.x = .5 * Common.STAGE_WIDTH, this._panel.y = .5 * Common.STAGE_HEIGHT, this._panel.visible = !1, this.addChild(this._panel), this._panel.header = new PIXI.Sprite(Common.assets.getTexture("ui_popup_top")), this._panel.header.x = .5 * -this._panel.header.width, this._panel.addChild(this._panel.header), this._panel.content = new PIXI.Sprite(Common.assets.getTexture("ui_popup_bottom_gold")), this._panel.content.x = .5 * -this._panel.content.width, this._panel.content.y = this._panel.header.y + this._panel.header.height, this._panel.addChildAt(this._panel.content, 0), this._panel.header.y -= .5 * (this._panel.header.height + this._panel.content.height), this._panel.content.y -= .5 * (this._panel.header.height + this._panel.content.height), webfont ? (this._titleText = new PIXI.Text(Common.copy.reward_popup[Common.language], {
                    font: "48px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._titleText.x = .5 * (this._panel.header.width - this._titleText.width), this._titleText.y = 28, this._panel.header.addChild(this._titleText)) : (this._titleText = new PIXI.extras.BitmapText(Common.copy.reward_popup[Common.language], {
                    font: "48px Great Escape",
                    align: "center"
                }), this._titleText.x = .5 * (this._panel.header.width - this._titleText.textWidth), this._titleText.y = 16, this._panel.header.addChild(this._titleText)), this._coinsIcon = new PIXI.Sprite(Common.assets.getTexture("ui_icon_coins")), this._coinsIcon.y = 20, this._coinsIcon.anchor = new PIXI.Point(.5, .5), this._panel.addChild(this._coinsIcon);
                var str = Common.copy.reward_message_coins[Common.language].replace("[VALUE]", this._cash.toString());
                webfont ? (this._infoText = new PIXI.Text(str, {
                    font: "38px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._infoText.x = .5 * -this._infoText.width, this._infoText.y = 160, this._panel.addChild(this._infoText)) : (this._infoText = new PIXI.extras.BitmapText(str, {
                    font: "38px Great Escape",
                    align: "center"
                }), this._infoText.x = .5 * -this._infoText.textWidth, this._infoText.y = 160, this._panel.addChild(this._infoText)), this._closeButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_btn_close")), this._closeButton.x = .5 * (this._panel.header.width - this._closeButton.width) - 18, this._closeButton.y = -240, this._closeButton.animate = !0, this._closeButton.overSoundName = "sfx_ui_btn_rollover_00", this._closeButton.downSoundName = "sfx_ui_btn_press_00", this._closeButton.signals.click.add(this.onCloseButtonClick, this), this._panel.addChild(this._closeButton), this._acceptButton = new p3.Button(Common.assets.getTexture("ui_btn_confirm_up"), Common.assets.getTexture("ui_btn_confirm_over"), Common.assets.getTexture("ui_btn_confirm_down"), Common.assets.getTexture("ui_icon_tick")), this._acceptButton.y = 240, this._acceptButton.animate = !0, this._acceptButton.overSoundName = "sfx_ui_btn_rollover_00", this._acceptButton.downSoundName = "sfx_ui_btn_press_00", this._acceptButton.clickSoundName = "sfx_ui_btn_play_00", this._acceptButton.signals.click.add(this.onCloseButtonClick, this)
            }, RewardPopupScene.prototype.dispose = function() {
                Common.animator.removeAll(), Scene.prototype.dispose.call(this)
            }, RewardPopupScene.prototype.appear = function() {
                this.animateIn()
            }, RewardPopupScene.prototype.show = function() {}, RewardPopupScene.prototype.animateIn = function(callback, scope) {
                this._overlay.alpha = 0, this._overlay.visible = !0, TweenMax.to(this._overlay, .34, {
                    alpha: 1,
                    ease: Power1.easeInOut
                }), this._panel.scale = new PIXI.Point, this._panel.visible = !0, TweenMax.to(this._panel.scale, .4, {
                    x: 1,
                    y: 1,
                    ease: Back.easeOut,
                    easeParams: [2],
                    onComplete: function() {},
                    onCompleteScope: this
                })
            }, RewardPopupScene.prototype.animateOut = function(callback, scope) {
                TweenMax.to(this._overlay, .34, {
                    alpha: 0,
                    ease: Power1.easeInOut,
                    onComplete: function() {
                        this._overlay.visible = !1
                    },
                    onCompleteScope: this
                }), TweenMax.to(this._panel.scale, .4, {
                    x: 0,
                    y: 0,
                    ease: Back.easeIn,
                    easeParams: [1],
                    onComplete: function() {
                        this._panel.visible = !1, callback.call(scope)
                    },
                    onCompleteScope: this
                })
            }, RewardPopupScene.prototype.resize = function() {
                this.x = .5 * (p3.View.width - Common.STAGE_WIDTH), this._overlay.x = .5 * (Common.STAGE_WIDTH - p3.View.width), this._overlay.y = .5 * (Common.STAGE_HEIGHT - p3.View.height), this._overlay.width = p3.View.width, this._overlay.height = p3.View.height
            }, RewardPopupScene.prototype.update = function() {}, RewardPopupScene.prototype.animateInfoText = function() {
                function next() {
                    this._cashSmooth += (this._cash - this._cashSmooth) * ease, this._infoText.text = Math.floor(Math.ceil(this._cashSmooth)), this._infoText.validate(), this._infoText.x = .5 * -this._infoText.textWidth, Math.abs(Math.floor(this._cash - this._cashSmooth)) > 0 && TweenMax.delayedCall(.02, next, null, this)
                }
                var ease = .2;
                this._cashSmooth = 0, this._infoText.text = 0..toString(), this._infoText.validate(), this._infoText.x = .5 * -this._infoText.textWidth, next.call(this)
            }, RewardPopupScene.prototype.onCloseButtonClick = function(button) {
                this._closeButton.interactive = !1, this.animateOut(function() {
                    this.signals.next.dispatch()
                }, this)
            }
        }, {
            "./Common": 23,
            "./Scene": 83
        }],
        78: [function(require, module, exports) {
            function RewardTypes() {}
            module.exports = RewardTypes, RewardTypes.CASH = 0
        }, {}],
        79: [function(require, module, exports) {
            function RoadEntity(type, view) {
                this.engine = null, this.pos2d = new PIXI.Point, this.pos3d = new Point4, this.global3d = new Point4, this.distance = 0, this.offset = new PIXI.Point, this.scale = new PIXI.Point(1, 1), this.alpha = 1, this.renderInWorld = !0, this.zDepthOffset = 0, this._type = type, this._view = view
            }
            var Point4 = (require("./Common"), require("./Point4"));
            module.exports = RoadEntity, RoadEntity.TYPE_STATIC = 0, RoadEntity.TYPE_MOVING = 1, RoadEntity.TYPE_SEGMENT = 2, RoadEntity.prototype.init = function() {}, RoadEntity.prototype.destroy = function() {
                this.view.parent && this.view.parent.removeChild(this.view), this.engine && this.engine.removeEntity(this)
            }, RoadEntity.prototype.update = function() {}, Object.defineProperty(RoadEntity.prototype, "type", {
                get: function() {
                    return this._type
                }
            }), Object.defineProperty(RoadEntity.prototype, "view", {
                get: function() {
                    return this._view
                }
            }), Object.defineProperty(RoadEntity.prototype, "zDepth", {
                get: function() {
                    return this.pos3d.x
                }
            })
        }, {
            "./Common": 23,
            "./Point4": 62
        }],
        80: [function(require, module, exports) {
            function RoadSegment(roadMiddleTexture, roadLeftTexture, roadRightTexture, grassLeftTexture, grassRightTexture) {
                this.next = null, this.previous = null, this.width = 0;
                var view = new PIXI.Sprite(roadMiddleTexture);
                view.grassLeft = new PIXI.Sprite(grassLeftTexture), view.grassLeft.anchor.x = 1, view.addChild(view.grassLeft), view.grassRight = new PIXI.Sprite(grassRightTexture), view.addChild(view.grassRight), view.left = new PIXI.Sprite(roadLeftTexture), view.left.y = .5 * view.left.height, view.left.anchor.x = 1, view.left.anchor.y = .5, view.addChild(view.left), view.right = new PIXI.Sprite(roadRightTexture), view.right.x = view.width, view.right.y = .5 * view.right.height, view.right.anchor.y = .5, view.addChild(view.right), RoadEntity.call(this, RoadEntity.TYPE_SEGMENT, view)
            }
            var Point4 = (require("./Common"), require("./Point4")),
                RoadEntity = require("./RoadEntity");
            module.exports = RoadSegment, RoadSegment.prototype = Object.create(RoadEntity.prototype), RoadSegment.prototype.constructor = RoadSegment, RoadSegment.prototype.getQuad = function() {
                return {
                    tl: new PIXI.Point(this.pos2d.x - this.width, this.pos2d.y),
                    tr: new PIXI.Point(this.pos2d.x + this.width, this.pos2d.y),
                    bl: new PIXI.Point(this.previous.pos2d.x - this.previous.width, this.previous.pos2d.y),
                    br: new PIXI.Point(this.previous.pos2d.x + this.previous.width, this.previous.pos2d.y)
                }
            }, RoadSegment.prototype.getHeading = function() {
                var heading = new Point4(this.next.global3d.x - this.global3d.x, this.next.global3d.y - this.global3d.y, this.next.global3d.z - this.global3d.z, 1);
                return heading.normalize(), heading
            }
        }, {
            "./Common": 23,
            "./Point4": 62,
            "./RoadEntity": 79
        }],
        81: [function(require, module, exports) {
            function SaloonView(color, avatar) {
                CarView.call(this, color, avatar);
                var chassisOffset = new PIXI.Point(0, -2);
                this._shadow.offset = new PIXI.Point(0, 20), this._wheels.front.left.visible = !1, this._wheels.front.right.visible = !1, this._wheels.rear.left.offset = new PIXI.Point(-120, 78), this._wheels.rear.right.offset = new PIXI.Point(122, 78), this._front.offset = new PIXI.Point(chassisOffset.x, -4 + chassisOffset.y), this._mid.offset = new PIXI.Point(chassisOffset.x, chassisOffset.y), this._back.offset = new PIXI.Point(chassisOffset.x, chassisOffset.y)
            }
            var CarShader = require("./CarShader"),
                CarView = require("./CarView"),
                Common = require("./Common");
            module.exports = SaloonView, SaloonView.prototype = Object.create(CarView.prototype), SaloonView.prototype.constructor = SaloonView, SaloonView.prototype.update = function(distance, curvature, gradient, velocity, turnVelocity) {
                var scalar = 140;
                this._curvature += .4 * (turnVelocity + curvature - this._curvature), this._curvature = Math.max(-scalar, Math.min(scalar, this._curvature)), this._front.x = .3 * this._curvature + this._front.offset.x, this._front.y = -gradient * scalar * 1.6 + this._front.offset.y, this._mid.x = .1 * this._curvature + this._mid.offset.x, this._mid.y = -gradient * scalar * 1.3 + this._mid.offset.y, this._back.x = .1 * -this._curvature + this._back.offset.x, this._back.y = gradient * scalar + this._back.offset.y, this._shadow.x = this._back.x, this._shadow.y = this._wheels.rear.left.y + this._shadow.offset.y, this._front.rotation = 8e-4 * this._curvature, this._back.rotation = 8e-4 * this._curvature, this._wheels.front.left.x = this._front.x + this._wheels.front.left.offset.x, this._wheels.front.left.y = gradient * scalar + this._wheels.front.left.offset.y, this._wheels.front.right.x = this._front.x + this._wheels.front.right.offset.x, this._wheels.front.right.y = gradient * scalar + this._wheels.front.right.offset.y, this._wheels.rear.left.x = this._back.x + this._wheels.rear.left.offset.x, this._wheels.rear.left.y = gradient * scalar + this._wheels.rear.left.offset.y, this._wheels.rear.right.x = this._back.x + this._wheels.rear.right.offset.x, this._wheels.rear.right.y = gradient * scalar + this._wheels.rear.right.offset.y;
                var theta;
                theta = .008 * turnVelocity, 0 > theta && (theta *= .112), this._wheels.front.left.rotation = theta, theta = .008 * turnVelocity, theta > 0 && (theta *= .112), this._wheels.front.right.rotation = theta, theta = .008 * turnVelocity, 0 > theta && (theta *= .112), this._wheels.rear.left.rotation = theta, theta = .008 * turnVelocity, theta > 0 && (theta *= .112), this._wheels.rear.right.rotation = theta, velocity = Math.max(0, velocity), this._wheels.front.left.animationSpeed = velocity / .2, this._wheels.front.right.animationSpeed = velocity / .2, this._wheels.rear.left.animationSpeed = velocity / .2, this._wheels.rear.right.animationSpeed = velocity / .2
            }, SaloonView.prototype.createFrontLayer = function() {
                var bodyTexture = Common.assets.getTexture("car_02_body_00"),
                    maskTexture = Common.assets.getTexture("car_02_mask_00"),
                    shineTexture = Common.assets.getTexture("car_02_shine_00"),
                    maskOffset = new PIXI.Point(maskTexture._uvs.x0 - bodyTexture._uvs.x0, maskTexture._uvs.y0 - bodyTexture._uvs.y0),
                    shineOffset = new PIXI.Point(shineTexture._uvs.x0 - bodyTexture._uvs.x0, shineTexture._uvs.y0 - bodyTexture._uvs.y0),
                    front = new PIXI.Sprite(bodyTexture);
                front.shader = new CarShader(this._color, maskOffset, this._shininess, shineOffset);
                var decal = new PIXI.Sprite(this.getDecalTexture(0));
                return front.addChild(decal), new PIXI.Sprite(front.generateTexture(Common.renderer, 1, PIXI.SCALE_MODES.DEFAULT))
            }, SaloonView.prototype.createMidLayer = function() {
                var bodyTexture = Common.assets.getTexture("car_02_body_01"),
                    maskTexture = Common.assets.getTexture("car_02_mask_01"),
                    shineTexture = Common.assets.getTexture("car_02_shine_01"),
                    maskOffset = new PIXI.Point(maskTexture._uvs.x0 - bodyTexture._uvs.x0, maskTexture._uvs.y0 - bodyTexture._uvs.y0),
                    shineOffset = new PIXI.Point(shineTexture._uvs.x0 - bodyTexture._uvs.x0, shineTexture._uvs.y0 - bodyTexture._uvs.y0),
                    mid = new PIXI.Sprite(bodyTexture);
                mid.shader = new CarShader(this._color, maskOffset, this._shininess, shineOffset);
                var decal = new PIXI.Sprite(this.getDecalTexture(1));
                mid.addChild(decal);
                var kit = Common.garage.myCar.kit;
                if (0 == kit || 4 == kit) {
                    var topLights = new PIXI.Sprite(Common.assets.getTexture("car_02_specialkit_00"));
                    mid.addChild(topLights)
                }
                if (0 == kit) {
                    var spareTyre = new PIXI.Sprite(Common.assets.getTexture("car_02_specialkit_01"));
                    mid.addChild(spareTyre)
                }
                if (3 == kit) {
                    var neonLights = new PIXI.Sprite(Common.assets.getTexture("car_02_specialkit_02"));
                    mid.addChild(neonLights)
                }
                return new PIXI.Sprite(mid.generateTexture(Common.renderer, 1, PIXI.SCALE_MODES.DEFAULT))
            }, SaloonView.prototype.createBackLayer = function() {
                var bodyTexture = Common.assets.getTexture("car_02_body_02"),
                    maskTexture = Common.assets.getTexture("car_02_mask_02"),
                    shineTexture = Common.assets.getTexture("car_02_shine_02"),
                    maskOffset = new PIXI.Point(maskTexture._uvs.x0 - bodyTexture._uvs.x0, maskTexture._uvs.y0 - bodyTexture._uvs.y0),
                    shineOffset = new PIXI.Point(shineTexture._uvs.x0 - bodyTexture._uvs.x0, shineTexture._uvs.y0 - bodyTexture._uvs.y0),
                    back = new PIXI.Sprite(bodyTexture);
                back.shader = new CarShader(this._color, maskOffset, this._shininess, shineOffset);
                var decal = new PIXI.Sprite(this.getDecalTexture(2));
                back.addChild(decal);
                var name = Common.garage.name,
                    plate = new PIXI.Sprite(Common.garage.saveLicensePlate(name));
                plate.x = .5 * back.width, plate.y = 178, plate.scale = new PIXI.Point(.5, .5), plate.anchor.x = .5, back.addChild(plate);
                var spoiler = this.createSpoilerLayer();
                return spoiler.y = 22, back.addChild(spoiler), new PIXI.Sprite(back.generateTexture(Common.renderer, 1, PIXI.SCALE_MODES.DEFAULT))
            }, SaloonView.prototype.createSpoilerLayer = function() {
                var bodyTexture = Common.assets.getTexture("car_02_spoiler_02"),
                    maskTexture = Common.assets.getTexture("car_02_maskspoiler_02"),
                    maskOffset = new PIXI.Point(maskTexture._uvs.x0 - bodyTexture._uvs.x0, maskTexture._uvs.y0 - bodyTexture._uvs.y0),
                    spoiler = new PIXI.Sprite(bodyTexture);
                return spoiler.shader = new CarShader(this._color, maskOffset, 0), new PIXI.Sprite(spoiler.generateTexture(Common.renderer, 1, PIXI.SCALE_MODES.DEFAULT))
            }, SaloonView.prototype.createRearWheel = function() {
                var sequence = new p3.MovieClipSequence;
                return sequence.addTextures([Common.assets.getTexture("car_02_wheels_rear_0"), Common.assets.getTexture("car_02_wheels_rear_1"), Common.assets.getTexture("car_02_wheels_rear_2"), Common.assets.getTexture("car_02_wheels_rear_3")]), new p3.MovieClip(sequence)
            }, SaloonView.prototype.createShadow = function() {
                return new PIXI.Sprite(Common.assets.getTexture("car_02_shadow"))
            }
        }, {
            "./CarShader": 19,
            "./CarView": 21,
            "./Common": 23
        }],
        82: [function(require, module, exports) {
            function SaveData() {}
            var Common = require("./Common"),
                MessagePopup = (require("./Garage"), require("./MessagePopup"));
            module.exports = SaveData, SaveData.SAVE_NAME = "carsgame", SaveData.SAVE_VERSION = "1.0", SaveData.prototype.load = function() {
                var data = window.localStorage[SaveData.SAVE_NAME];
                if (data && (data = JSON.parse(data), data.version == SaveData.SAVE_VERSION)) {
                    var valid = data.hash == this.generateHash(data);
                    if (valid) {
                        var garage = Common.garage;
                        return garage.name = data.name, garage.cash = data.cash, garage.races = data.races, garage.controls = data.controls, garage.series = data.series, garage.track = data.track, garage.carTypes = data.carTypes || [], garage.carTypesSeries = data.carTypesSeries || [], garage.decalCount = data.decalCount || 0, MessagePopup.firstTimeHelpers = data.helpers, garage.load(data.garage), Common.achievements.load(data.achievements), Common.trackManager.load(data.tracks), !0
                    }
                }
                return !1
            }, SaveData.prototype.save = function() {
                var garage = Common.garage,
                    data = {};
                data.version = SaveData.SAVE_VERSION, data.name = garage.name, data.cash = garage.cash, data.races = garage.races, data.controls = garage.controls, data.series = garage.series, data.track = garage.track, data.garage = garage.save(), data.achievements = Common.achievements.save(), data.tracks = Common.trackManager.save(), data.helpers = MessagePopup.firstTimeHelpers.slice(), data.carTypes = garage.carTypes, data.carTypesSeries = garage.carTypesSeries, data.decalCount = garage.decalCount, data.timestamp = (new Date).getTime(), data.hash = this.generateHash(data), window.localStorage[SaveData.SAVE_NAME] = JSON.stringify(data), console.log(data)
            }, SaveData.prototype.generateHash = function(data) {
                return md5(JSON.stringify(data.version + data.name + data.cash + data.races + data.series + data.track + data.garage + data.achievements + data.tracks + data.helpers + data.timestamp + "akalegman"))
            }, SaveData.prototype.getReward = function() {
                var reward = {};
                reward.value = 0, reward.index = -1;
                var data = window.localStorage[SaveData.SAVE_NAME];
                if (data && (data = JSON.parse(data), (new Date).getTime() - data.timestamp >= 864e5)) {
                    var arr = Common.config.bonus;
                    reward.index = Math.floor(Math.random() * (arr.length - 1)), reward.value = arr[reward.index], Common.garage.cash += reward.value, this.save()
                }
                return reward
            }, Object.defineProperty(SaveData.prototype, "isNewPlayer", {
                get: function() {
                    return null == window.localStorage[SaveData.SAVE_NAME]
                }
            })
        }, {
            "./Common": 23,
            "./Garage": 37,
            "./MessagePopup": 54
        }],
        83: [function(require, module, exports) {
            function Scene() {
                this.signals = {}, this.signals.next = new signals.Signal, this.signals.previous = new signals.Signal, this.signals.home = new signals.Signal, this.signals.pause = new signals.Signal, this.signals["in"] = new signals.Signal, this.signals.out = new signals.Signal, PIXI.Container.call(this)
            }
            module.exports = Scene, Scene.prototype = Object.create(PIXI.Container.prototype), Scene.prototype.constructor = Scene, Scene.prototype.init = function() {}, Scene.prototype.dispose = function() {
                this.signals.next.dispose(), this.signals.previous.dispose(), this.signals.home.dispose(), this.signals.pause.dispose(), this.signals["in"].dispose(), this.signals.out.dispose(), this.removeChildren()
            }, Scene.prototype.resize = function() {}, Scene.prototype.update = function() {}, Scene.prototype.appear = function() {
                this.animateIn()
            }, Scene.prototype.show = function() {
                this.animateIn()
            }, Scene.prototype.hide = function() {}, Scene.prototype.animateIn = function(callback, scope) {
                scope = scope || window, this.signals["in"].dispatch(this)
            }, Scene.prototype.animateOut = function(callback, scope) {
                scope = scope || window, this.signals.out.dispatch(this)
            }
        }, {}],
        84: [function(require, module, exports) {
            function SceneManager(renderer) {
                this.updateAll = !1, this.signals = {}, this.signals.add = new signals.Signal, this.signals.remove = new signals.Signal, this._view = new PIXI.Container, this._renderer = renderer, this._stack = [], this._transition = null
            }
            var Transition = (require("./Scene"), require("./Transition"));
            module.exports = SceneManager, SceneManager.prototype.update = function() {
                if (this._stack.length)
                    if (this.updateAll)
                        for (var scene, i = this._stack.length - 1; i >= 0; --i) scene = this._stack[i], scene.update();
                    else this.top.update()
            }, SceneManager.prototype.add = function(scene, transition) {
                function swap(scene) {
                    if (this.top)
                        if (this.top.hide(), this._transition.push) {
                            if (this._transition.replace)
                                for (var temp, i = 0; i < this._stack.length; ++i) temp = this._stack[i], temp.parent && temp.parent.removeChild(temp)
                        } else
                            for (; this.top;) this.top.parent && this.top.parent.removeChild(this.top), this.top.dispose(), this._stack.pop();
                    scene.init(), scene.resize(), scene.parent || this._view.addChildAt(scene, this._transition.parent.getChildIndex(this._transition)), this._stack.push(scene), this._transition.wait || p3.Timestep.queueCall(scene.appear, null, scene), this._transition.out(), console.log(this._stack)
                }
                this.transitionInProgress || (this._transition = transition || new Transition, this._transition.requiresWebGL && (this._transition = transition.fallback(), this._transition.push = transition.push, this._transition.replace = transition.replace, this._transition.wait = transition.wait, this._transition.update = transition.update), this._transition.init(), this._view.addChild(this._transition), this._transition.signals["in"].addOnce(function(transition) {
                    p3.Timestep.queueCall(swap, [scene], this)
                }, this), this._transition.signals.out.addOnce(function(transition) {
                    this._transition = null, transition.parent.removeChild(transition), transition.dispose(), transition.wait && p3.Timestep.queueCall(scene.appear, null, scene), this.signals.add.dispatch()
                }, this), this._transition["in"]())
            }, SceneManager.prototype.remove = function(transition, count) {
                function swap(count) {
                    for (var i = 0; count > i; ++i) this.top.hide(), this.top.parent && this.top.parent.removeChild(this.top), this.top.dispose(), this._stack.pop();
                    var scene = this.top;
                    scene.resize(), scene.parent || this._view.addChildAt(scene, this._transition.parent.getChildIndex(this._transition)), this._transition.wait || scene.show(), this._transition.out(), console.log(this._stack)
                }
                this.transitionInProgress || (this._transition = transition || new Transition, count = Math.max(1, count) || 1, this._transition.requiresWebGL && (this._transition = transition.fallback(), this._transition.push = transition.push, this._transition.replace = transition.replace, this._transition.wait = transition.wait), this._transition.init(), this._view.addChild(this._transition), this._transition.signals["in"].addOnce(function(transition) {
                    p3.Timestep.queueCall(swap, [count], this)
                }, this), this._transition.signals.out.addOnce(function(transition) {
                    this._transition = null, transition.parent.removeChild(transition), transition.dispose(), transition.wait && this.top.show(), this.signals.remove.dispatch()
                }, this), this._transition["in"]())
            }, SceneManager.prototype.clear = function() {
                if (!this.transitionInProgress) {
                    for (var scene, i = 0; i < this._stack.length; ++i) scene = this._stack[i], scene.hide(), scene.parent.removeChild(scene), scene.dispose();
                    this._stack.length = 0
                }
            }, SceneManager.prototype.resize = function() {
                for (var scene, i = 0; i < this._stack.length; ++i) scene = this._stack[i], scene.resize();
                this._transition && this._transition.resize()
            }, Object.defineProperty(SceneManager.prototype, "view", {
                get: function() {
                    return this._view
                }
            }), Object.defineProperty(SceneManager.prototype, "renderer", {
                get: function() {
                    return this._renderer
                }
            }), Object.defineProperty(SceneManager.prototype, "top", {
                get: function() {
                    return this._stack.length ? this._stack[this._stack.length - 1] : null
                }
            }), Object.defineProperty(SceneManager.prototype, "transitionInProgress", {
                get: function() {
                    return null != this._transition
                }
            })
        }, {
            "./Scene": 83,
            "./Transition": 105
        }],
        85: [function(require, module, exports) {
            function SchnellView(avatar) {
                CarView.call(this, 16777215, avatar);
                var chassisOffset = new PIXI.Point(0, 12);
                this._shadow.offset = new PIXI.Point(0, 26), this._wheels.front.left.offset = new PIXI.Point(-104, 32), this._wheels.front.right.offset = new PIXI.Point(104, 32), this._wheels.rear.left.offset = new PIXI.Point(-118, 78), this._wheels.rear.right.offset = new PIXI.Point(118, 78), this._front.offset = new PIXI.Point(chassisOffset.x, -4 + chassisOffset.y), this._mid.offset = new PIXI.Point(chassisOffset.x, chassisOffset.y), this._back.offset = new PIXI.Point(chassisOffset.x, chassisOffset.y)
            }
            var CarView = (require("./CarShader"), require("./CarView")),
                Common = require("./Common");
            module.exports = SchnellView, SchnellView.prototype = Object.create(CarView.prototype), SchnellView.prototype.constructor = SchnellView, SchnellView.prototype.update = function(distance, curvature, gradient, velocity, turnVelocity) {
                var scalar = 140;
                this._curvature += .4 * (turnVelocity + curvature - this._curvature), this._curvature = Math.max(-scalar, Math.min(scalar, this._curvature)), this._front.x = .4 * this._curvature + this._front.offset.x, this._front.y = -gradient * scalar * 1.6 + this._front.offset.y, this._mid.x = .1 * this._curvature + this._mid.offset.x, this._mid.y = -gradient * scalar * 1.3 + this._mid.offset.y, this._back.x = .14 * -this._curvature + this._back.offset.x, this._back.y = gradient * scalar + this._back.offset.y, this._shadow.x = this._back.x, this._shadow.y = this._wheels.rear.left.y + this._shadow.offset.y, this._front.rotation = 8e-4 * this._curvature, this._back.rotation = 8e-4 * this._curvature, this._wheels.front.left.x = this._front.x + this._wheels.front.left.offset.x, this._wheels.front.left.y = gradient * scalar + this._wheels.front.left.offset.y, this._wheels.front.right.x = this._front.x + this._wheels.front.right.offset.x, this._wheels.front.right.y = gradient * scalar + this._wheels.front.right.offset.y, this._wheels.rear.left.x = this._back.x + this._wheels.rear.left.offset.x, this._wheels.rear.left.y = gradient * scalar + this._wheels.rear.left.offset.y, this._wheels.rear.right.x = this._back.x + this._wheels.rear.right.offset.x, this._wheels.rear.right.y = gradient * scalar + this._wheels.rear.right.offset.y;
                var theta;
                theta = .008 * turnVelocity, 0 > theta && (theta *= .112), this._wheels.front.left.rotation = theta, theta = .008 * turnVelocity, theta > 0 && (theta *= .112), this._wheels.front.right.rotation = theta, theta = .008 * turnVelocity, 0 > theta && (theta *= .112), this._wheels.rear.left.rotation = theta, theta = .008 * turnVelocity, theta > 0 && (theta *= .112), this._wheels.rear.right.rotation = theta, velocity = Math.max(0, velocity), this._wheels.front.left.animationSpeed = velocity / .2, this._wheels.front.right.animationSpeed = velocity / .2, this._wheels.rear.left.animationSpeed = velocity / .2, this._wheels.rear.right.animationSpeed = velocity / .2
            }, SchnellView.prototype.createFrontLayer = function() {
                return new PIXI.Sprite(Common.assets.getTexture("car_schnell_body_00"))
            }, SchnellView.prototype.createMidLayer = function() {
                return new PIXI.Sprite(Common.assets.getTexture("car_schnell_body_01"))
            }, SchnellView.prototype.createBackLayer = function() {
                var back = new PIXI.Sprite(Common.assets.getTexture("car_schnell_body_02")),
                    spoiler = this.createSpoilerLayer();
                return spoiler.y = 20, back.addChild(spoiler), back
            }, SchnellView.prototype.createSpoilerLayer = function() {
                var spoiler = new PIXI.Sprite(Common.assets.getTexture("car_schnell_spoiler_02"));
                return spoiler.anchor = new PIXI.Point(.5, 1), spoiler
            }, SchnellView.prototype.createFrontWheel = function() {
                var sequence = new p3.MovieClipSequence;
                return sequence.addTextures([Common.assets.getTexture("car_schnell_wheels_front_0"), Common.assets.getTexture("car_schnell_wheels_front_1"), Common.assets.getTexture("car_schnell_wheels_front_2"), Common.assets.getTexture("car_schnell_wheels_front_3")]), new p3.MovieClip(sequence)
            }, SchnellView.prototype.createRearWheel = function() {
                var sequence = new p3.MovieClipSequence;
                return sequence.addTextures([Common.assets.getTexture("car_schnell_wheels_rear_0"), Common.assets.getTexture("car_schnell_wheels_rear_1"), Common.assets.getTexture("car_schnell_wheels_rear_2"), Common.assets.getTexture("car_schnell_wheels_rear_3")]), new p3.MovieClip(sequence)
            }, SchnellView.prototype.createShadow = function() {
                return new PIXI.Sprite(Common.assets.getTexture("car_schnell_shadow"))
            }
        }, {
            "./CarShader": 19,
            "./CarView": 21,
            "./Common": 23
        }],
        86: [function(require, module, exports) {
            function Scores() {
                this._api = new GBAPI
            }
            require("./Common");
            module.exports = Scores,
                Scores.prototype.sendScore = function(id, name, score, callback, scope) {
                    scope = scope || window;
                    var payload = {};
                    payload.game = id, payload.name = name, payload.score = score, this._api.setSharedKey("1234"), this._api.sendScore(payload, function(response) {
                        callback && callback.call(scope, response)
                    })
                }, Scores.prototype.getScores = function(id, startTime, endTime, callback, scope) {
                    scope = scope || window;
                    var payload = {
                        game: id,
                        orderAsc: 1,
                        perPage: 20,
                        pageNumber: 1,
                        startTimestamp: startTime,
                        endTimestamp: endTime
                    };
                    this._api.getScores(payload, function(response) {
                        callback && callback.call(scope, response)
                    })
                }
        }, {
            "./Common": 23
        }],
        87: [function(require, module, exports) {
            function ScrollView(frameWidth, frameHeight, contentWidth, contentHeight) {
                this.signals = {}, this.signals.scroll = new signals.Signal, this.contentWidth = contentWidth, this.contentHeight = contentHeight, this._reference = new PIXI.Point, this._velocity = new PIXI.Point, this._amplitude = new PIXI.Point, this._target = new PIXI.Point, this._offset = new PIXI.Point, this._frame = new PIXI.Point, this._timestamp = Date.now(), this._content = null, this._frameWidth = frameWidth, this._frameHeight = frameHeight, this._pressed = !1, PIXI.Container.call(this), this.init()
            }
            module.exports = ScrollView, ScrollView.prototype = Object.create(PIXI.Container.prototype), ScrollView.prototype.constructor = ScrollView, ScrollView.DECELERATION_RATE = 325, ScrollView.prototype.init = function() {
                var mask = new PIXI.Graphics;
                mask.beginFill(16711680, 1), mask.drawRect(0, 0, this._frameWidth, this._frameHeight), mask.endFill(), this.addChild(mask), this._content = new PIXI.Container, this._content.mask = mask, this.addChild(this._content), this.hitArea = new PIXI.Rectangle(0, 0, this._frameWidth, this._frameHeight), this.interactive = !0, this.mousedown = this.touchstart = this.onMouseDown.bind(this), this.mouseup = this.touchend = this.onMouseUp.bind(this), this.mousemove = this.touchmove = this.onMouseMove.bind(this)
            }, ScrollView.prototype.destroy = function() {
                this.signals.scroll.dispose(), this.mousedown = this.touchstart = null, this.mouseup = this.touchend = null, this.mousemove = this.touchmove = null
            }, ScrollView.prototype.update = function() {
                this._pressed ? this.track() : this.autoScroll()
            }, ScrollView.prototype.scroll = function(x, y, force) {
                this._offset.x = x > this.contentWidth ? this.contentWidth : 0 > x ? 0 : x, this._offset.y = y > this.contentHeight ? this.contentHeight : 0 > y ? 0 : y, this.content.x = -this._offset.x, this.content.y = -this._offset.y, force && (this._amplitude = new PIXI.Point, this._target = new PIXI.Point, this._velocity = new PIXI.Point)
            }, ScrollView.prototype.track = function() {
                var now, elapsed, delta, v;
                now = Date.now(), elapsed = now - this._timestamp, this._timestamp = now, delta = new PIXI.Point(this._offset.x - this._frame.x, this._offset.y - this._frame.y), this._frame = this._offset.clone(), v = new PIXI.Point(1e3 * delta.x / (1 + elapsed), 1e3 * delta.y / (1 + elapsed)), this._velocity = new PIXI.Point(.8 * v.x + .2 * this._velocity.x, .8 * v.y + .2 * this._velocity.y)
            }, ScrollView.prototype.autoScroll = function() {
                var elapsed, delta;
                (this._amplitude.x || this._amplitude.y) && (elapsed = Date.now() - this._timestamp, delta = new PIXI.Point(-this._amplitude.x * Math.exp(-elapsed / ScrollView.DECELERATION_RATE), -this._amplitude.y * Math.exp(-elapsed / ScrollView.DECELERATION_RATE)), delta.x > .5 || delta.x < -.5 || delta.y > .5 || delta.y < -.5 ? this.scroll(this._target.x + delta.x, this._target.y + delta.y) : this.scroll(this._target.x, this._target.y), this.signals.scroll.dispatch(this, new PIXI.Point(Math.abs(this._content.x), Math.abs(this._content.y))))
            }, ScrollView.prototype.onMouseDown = function(event) {
                this._pressed = !0, this._reference = event.data.getLocalPosition(this), this._velocity = new PIXI.Point, this._amplitude = new PIXI.Point, this._frame = this._offset.clone(), this._timestamp = Date.now()
            }, ScrollView.prototype.onMouseUp = function(event) {
                this._pressed = !1, event && ((this._velocity.x > 10 || this._velocity.x < -10 || this._velocity.y > 10 || this._velocity.y < -10) && (this._amplitude = new PIXI.Point(.6 * this._velocity.x, .6 * this._velocity.y), this._target = new PIXI.Point(Math.round(this._offset.x + this._amplitude.x), Math.round(this._offset.y + this._amplitude.y)), this._timestamp = Date.now()), this._reference = event.data.getLocalPosition(this))
            }, ScrollView.prototype.onMouseMove = function(event) {
                var position, delta;
                this.pressed && (position = event.data.getLocalPosition(this), delta = new PIXI.Point(this._reference.x - position.x, this._reference.y - position.y), (delta.x > 2 || delta.x < 2 || delta.y > 2 || delta.y < -2) && (this._reference = position.clone(), this.scroll(this._offset.x + delta.x, this._offset.y + delta.y), this.signals.scroll.dispatch(this, new PIXI.Point(Math.abs(this._content.x), Math.abs(this._content.y)))))
            }, Object.defineProperty(ScrollView.prototype, "content", {
                get: function() {
                    return this._content
                }
            }), Object.defineProperty(ScrollView.prototype, "frameWidth", {
                get: function() {
                    return this._frameWidth
                }
            }), Object.defineProperty(ScrollView.prototype, "frameHeight", {
                get: function() {
                    return this._frameHeight
                }
            }), Object.defineProperty(ScrollView.prototype, "pressed", {
                get: function() {
                    return this._pressed
                }
            })
        }, {}],
        88: [function(require, module, exports) {
            function Scroller(style) {
                style = style || 0;
                var texture;
                switch (style) {
                    case 0:
                        texture = Common.assets.getTexture("ui_scroll_bg_short");
                        break;
                    case 1:
                        texture = Common.assets.getTexture("ui_scroll_bg_long")
                }
                PIXI.Sprite.call(this, texture), this.interactive = !0, this.signals = {}, this.signals.scroll = new signals.Signal, this._offset = new PIXI.Point, this._pressed = !1, this._handle = new PIXI.Sprite(Common.assets.getTexture("ui_scroll_btn")), this._handle.x = .5 * this.width + 1, this._handle.y = .5 * this.height, this._handle.anchor = new PIXI.Point(.5, .5), this._handle.interactive = !0, this._handle.mousedown = this.touchstart = this.onMouseDown.bind(this), this._handle.mouseup = this.touchend = this.onMouseUp.bind(this), this._handle.mousemove = this.touchmove = this.onMouseMove.bind(this), this.addChild(this._handle), this.scroll(0)
            }
            var Common = require("./Common");
            module.exports = Scroller, Scroller.prototype = Object.create(PIXI.Sprite.prototype), Scroller.prototype.constructor = Scroller, Scroller.prototype.destroy = function() {
                this.signals.scroll.dispose(), this._handle.mousedown = this.touchstart = null, this._handle.mouseup = this.touchend = null, this._handle.mousemove = this.touchmove = null
            }, Scroller.prototype.scroll = function(y) {
                y += .5 * this._handle.height, y = y < .5 * this._handle.height ? .5 * this._handle.height : y, y = y > this.texture.height - .5 * this._handle.height ? this.texture.height - .5 * this._handle.height : y, this._handle.y = y
            }, Scroller.prototype.onMouseDown = function(event) {
                this._pressed = !0, this._offset = event.data.getLocalPosition(this._handle)
            }, Scroller.prototype.onMouseUp = function(event) {
                this._pressed = !1
            }, Scroller.prototype.onMouseMove = function(event) {
                if (this._pressed) {
                    var point = event.data.getLocalPosition(this),
                        y = point.y - this._offset.y - .5 * this._handle.height;
                    this.scroll(y);
                    var h = .5 * this._handle.height,
                        frac = y / (this.texture.height - h - h);
                    this.signals.scroll.dispatch(this, frac)
                }
            }, Object.defineProperty(Scroller.prototype, "pressed", {
                get: function() {
                    return this._pressed
                }
            }), Object.defineProperty(Scroller.prototype, "innerHeight", {
                get: function() {
                    return this.texture.height - this._handle.height
                }
            })
        }, {
            "./Common": 23
        }],
        89: [function(require, module, exports) {
            function SeriesRaceScene(nextRace) {
                Scene.call(this), this.signals["continue"] = new signals.Signal, this.signals.settings = new signals.Signal, this._animator = null, this._header = null, this._titleText = null, this._seriesText = null, this._settingsButton = null, this._backButton = null, this._nextButton = null, this._prevButton = null, this._playButton = null, this._seriesIndex = 0, this._series = [], this._trackButtons = [], this._trackLinks = [], this._pageIndicator = null, this._nextRace = nextRace, this._isContinued = !1
            }
            var Common = require("./Common"),
                DesaturationShader = require("./DesaturationShader"),
                MessagePopup = require("./MessagePopup"),
                PageIndicator = require("./PageIndicator"),
                Scene = require("./Scene"),
                TrackData = require("./TrackData");
            module.exports = SeriesRaceScene, SeriesRaceScene.prototype = Object.create(Scene.prototype), SeriesRaceScene.prototype.constructor = SeriesRaceScene, SeriesRaceScene.prototype.init = function() {
                this._seriesIndex = -1 != Common.garage.series ? Common.garage.series : 0, this._series = Common.trackManager.allSeries;
                var series = this._series[this._seriesIndex];
                this._isContinued = !this._nextRace && -1 != Common.garage.series && this._series[Common.garage.series].currentTrack > 0 && series.unlocked, this._trackButtons = [], Common.trackManager.selectSeries(this._seriesIndex), this._animator = new p3.Animator, this._bg = new PIXI.Sprite(PIXI.Texture.EMPTY), this._bg.scale = new PIXI.Point(2, 2), this.addChild(this._bg), this._header = new PIXI.Sprite(Common.assets.getTexture("ui_top_bar")), this._header.x = .5 * Common.STAGE_WIDTH, this._header.y = 120, this._header.anchor = new PIXI.Point(.5, .5), this.addChild(this._header), webfont ? (this._titleText = new PIXI.Text(Common.copy.series_race[Common.language], {
                    font: "48px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._titleText.x = .5 * (Common.STAGE_WIDTH - this._titleText.width), this._titleText.y = 96, this.addChild(this._titleText)) : (this._titleText = new PIXI.extras.BitmapText(Common.copy.series_race[Common.language], {
                    font: "48px Great Escape",
                    align: "center"
                }), this._titleText.x = .5 * (Common.STAGE_WIDTH - this._titleText.textWidth), this._titleText.y = 86, this.addChild(this._titleText)), this._settingsButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_settings")), this._settingsButton.y = 120, this._settingsButton.animate = !0, this._settingsButton.overSoundName = "sfx_ui_btn_rollover_00", this._settingsButton.downSoundName = "sfx_ui_btn_press_00", this._settingsButton.signals.click.add(this.onSettingsButtonClick, this), this.addChild(this._settingsButton), this.addChild(this._settingsButton), this._backButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_back")), this._backButton.y = 120, this._backButton.animate = !0, this._backButton.overSoundName = "sfx_ui_btn_rollover_00", this._backButton.downSoundName = "sfx_ui_btn_press_00", this._backButton.signals.click.add(this.onBackButtonClick, this), this.addChild(this._backButton), this._panel = new PIXI.Container, this._panel.x = .5 * Common.STAGE_WIDTH, this._panel.y = .5 * Common.STAGE_HEIGHT, this.addChild(this._panel), this._panel.header = new PIXI.Sprite(Common.assets.getTexture("ui_popup_top")), this._panel.header.x = .5 * -this._panel.header.width, this._panel.addChild(this._panel.header), this._panel.content = new PIXI.Sprite(Common.assets.getTexture("ui_popup_bottom_carbon_super_small")), this._panel.content.x = .5 * -this._panel.content.width, this._panel.content.y = this._panel.header.y + this._panel.header.height, this._panel.addChild(this._panel.content), this._panel.header.y -= .5 * (this._panel.header.height + this._panel.content.height), this._panel.content.y -= .5 * (this._panel.header.height + this._panel.content.height), webfont ? (this._seriesText = new PIXI.Text("", {
                    font: "48px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._seriesText.y = -158, this._panel.addChild(this._seriesText)) : (this._seriesText = new PIXI.extras.BitmapText("", {
                    font: "48px Great Escape",
                    align: "center"
                }), this._seriesText.y = -168, this._panel.addChild(this._seriesText)), this._reward = new PIXI.Sprite(PIXI.Texture.EMPTY), this._reward.x = 300, this._reward.y = -132, this._reward.anchor = new PIXI.Point(.5, .5), this._panel.addChild(this._reward), this._reward.icon = new PIXI.Sprite(PIXI.Texture.EMPTY), this._reward.icon.anchor = new PIXI.Point(.5, .5), this._reward.addChild(this._reward.icon), this._nextButton = new p3.Button(Common.assets.getTexture("ui_btn_arrow_up"), Common.assets.getTexture("ui_btn_arrow_over"), Common.assets.getTexture("ui_btn_arrow_down")), this._nextButton.x = .5 * this._panel.content.texture.width - 20, this._nextButton.y = 26, this._nextButton.scale.x = this._nextButton.defaultScale.x = -1, this._nextButton.animate = !0, this._nextButton.overSoundName = "sfx_ui_btn_rollover_00", this._nextButton.downSoundName = "sfx_ui_btn_press_00", this._nextButton.signals.click.add(r2l ? this.onPrevButtonClick : this.onNextButtonClick, this), this._panel.addChild(this._nextButton), this._prevButton = new p3.Button(Common.assets.getTexture("ui_btn_arrow_up"), Common.assets.getTexture("ui_btn_arrow_over"), Common.assets.getTexture("ui_btn_arrow_down")), this._prevButton.x = .5 * -this._panel.content.texture.width + 20, this._prevButton.y = 26, this._prevButton.animate = !0, this._prevButton.overSoundName = "sfx_ui_btn_rollover_00", this._prevButton.downSoundName = "sfx_ui_btn_press_00", this._prevButton.signals.click.add(r2l ? this.onNextButtonClick : this.onPrevButtonClick, this), this._panel.addChild(this._prevButton), this._pageIndicator = new PageIndicator(this._series.length, r2l), this._pageIndicator.x = .5 * Common.STAGE_WIDTH, this._pageIndicator.y = 720, this._pageIndicator.select(this._seriesIndex), this.addChild(this._pageIndicator), this.updateSeriesText(), this.loadTracks(this._seriesIndex), this.swapBackgroundImage()
            }, SeriesRaceScene.prototype.dispose = function() {
                this._animator.removeAll(), this.signals["continue"].dispose(), this.signals.settings.dispose(), Scene.prototype.dispose.call(this)
            }, SeriesRaceScene.prototype.appear = function() {
                this.animateIn(), this._message = new MessagePopup(7, MessagePopup.CHARACTER_MCQUEEN, Common.copy.series_race_helper[Common.language]), this._message.x = .5 * (Common.STAGE_WIDTH - p3.View.width) + 20, this._message.y = 560, this._message.animateIn(), this.addChild(this._message)
            }, SeriesRaceScene.prototype.show = function() {
                this._settingsButton.interactive = !0, this._backButton.interactive = !0, this._nextButton.interactive = !0, this._prevButton.interactive = !0
            }, SeriesRaceScene.prototype.hide = function() {
                this._settingsButton.interactive = !1, this._backButton.interactive = !1, this._nextButton.interactive = !1, this._prevButton.interactive = !1
            }, SeriesRaceScene.prototype.animateIn = function(callback, scope) {
                this.animateTracks()
            }, SeriesRaceScene.prototype.animateOut = function(callback, scope) {}, SeriesRaceScene.prototype.resize = function() {
                this.x = .5 * (p3.View.width - Common.STAGE_WIDTH), this._header.width = p3.View.width, this._backButton.x = .5 * (Common.STAGE_WIDTH - p3.View.width + Math.abs(this._backButton.width)) + 28, this._settingsButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width - Math.abs(this._settingsButton.width)) - 28
            }, SeriesRaceScene.prototype.update = function() {
                this._animator.update(p3.Timestep.deltaTime)
            }, SeriesRaceScene.prototype.loadTracks = function(id) {
                this.clearTracks();
                var series = Common.trackManager.getSeries(id);
                Common.trackManager.currentSeries = id, Common.trackManager.currentTrack = series.tracks[series.currentTrack];
                for (var data, track, unlocked, texture, prev, link, textureNamePrefix, shader = new DesaturationShader(1), origin = new PIXI.Point(0, 32), spacing = 168, i = 0; i < series.tracks.length; ++i) {
                    switch (data = Common.trackManager.getTrack(series.tracks[i]), unlocked = i == series.currentTrack && series.unlocked, texture = unlocked ? Common.assets.getTexture("ui_icon_track") : Common.assets.getTexture("ui_icon_track"), textureNamePrefix = unlocked ? "ui_btn_track_play" : "ui_btn_track", track = new p3.Button(Common.assets.getTexture(textureNamePrefix + "_up"), Common.assets.getTexture(textureNamePrefix + "_over"), Common.assets.getTexture(textureNamePrefix + "_down")), track.x = origin.x + i * spacing - (series.tracks.length - 1) * spacing * .5, track.y = origin.y, track.anchor = new PIXI.Point(.5, .5), track.animate = !0, track.filters = unlocked ? null : [shader], track.overSoundName = "sfx_ui_btn_rollover_00", track.downSoundName = "sfx_ui_btn_press_00", this._panel.addChild(track), this._trackButtons.push(track), unlocked && track.signals.click.add(this.onPlayButtonClick, this), track.flag = new PIXI.Sprite(Common.assets.getTexture("ui_btn_track_" + data.country.toLowerCase())), track.flag.anchor = new PIXI.Point(.5, .5), track.addChild(track.flag), texture = PIXI.Texture.EMPTY, data.difficulty) {
                        case TrackData.DIFFICULTY_EASY:
                            texture = Common.assets.getTexture("ui_btn_track_loop_easy");
                            break;
                        case TrackData.DIFFICULTY_INTERMEDIATE:
                            texture = Common.assets.getTexture("ui_btn_track_loop_medium");
                            break;
                        case TrackData.DIFFICULTY_HARD:
                            texture = Common.assets.getTexture("ui_btn_track_loop_hard")
                    }
                    switch (track.map = new PIXI.Sprite(texture), track.map.anchor = new PIXI.Point(.5, .5), track.addChild(track.map), track.no = new PIXI.Sprite(Common.assets.getTexture("ui_btn_track_" + (i + 1))), track.no.anchor = new PIXI.Point(.5, .5), track.addChild(track.no), texture = PIXI.Texture.EMPTY, series.rewards[i]) {
                        case 0:
                            texture = Common.assets.getTexture("ui_btn_track_gold");
                            break;
                        case 1:
                            texture = Common.assets.getTexture("ui_btn_track_silver");
                            break;
                        case 2:
                            texture = Common.assets.getTexture("ui_btn_track_bronze")
                    }
                    track.reward = new PIXI.Sprite(texture), track.reward.anchor = new PIXI.Point(.5, .5), track.addChild(track.reward), i > 0 && (prev = this._trackButtons[i - 1], link = new PIXI.Sprite(Common.assets.getTexture(i < series.currentTrack ? "ui_map_path_straight_on" : "ui_map_path_straight_off")), link.x = .5 * prev.x + .5 * track.x, link.y = .5 * prev.y + .5 * track.y, link.anchor = new PIXI.Point(.5, .5), this._panel.addChildAt(link, 2), this._trackLinks.push(link))
                }
                if (series.reward > -1) {
                    var arr = ["gold", "silver", "bronze"],
                        name = series.type.toLowerCase();
                    texture = Common.assets.getTexture("ui_trophy_" + arr[series.reward]), this._reward.texture = texture, texture = Common.assets.getTexture("ui_trophy_" + name + "_" + arr[series.reward]), this._reward.icon.texture = texture
                } else this._reward.texture = PIXI.Texture.EMPTY, this._reward.icon.texture = PIXI.Texture.EMPTY
            }, SeriesRaceScene.prototype.animateTracks = function() {
                for (var track, config, emitter, tm = Common.trackManager, series = tm.currentSeries, i = 0; i < this._trackButtons.length; ++i) track = this._trackButtons[i], series.animate && (series.animate = !1, config = Common.assets.getJSON("particle_coin_burst"), emitter = new cloudkid.Emitter(this, [Common.assets.getTexture("particle_standard")], config), emitter.emit = !1, emitter.updateOwnerPos(track.x, track.y + 40), this._animator.add(emitter), track.reward.alpha = 0, this._animator.add(TweenMax.to(track.reward, .4, {
                    delay: .2 * i,
                    alpha: 1,
                    ease: Power1.easeInOut,
                    onStart: function(emitter) {
                        emitter.emit = !0, Common.audio.playSound("sfx_race_lights_go_00")
                    },
                    onStartParams: [emitter],
                    onStartScope: this
                })));
                Common.saveData.save()
            }, SeriesRaceScene.prototype.clearTracks = function() {
                for (var track, i = 0; i < this._trackButtons.length; ++i) track = this._trackButtons[i], track.parent.removeChild(track);
                this._trackButtons.length = 0;
                var link;
                for (i = 0; i < this._trackLinks.length; ++i) link = this._trackLinks[i], link.parent.removeChild(link);
                this._trackLinks.length = 0
            }, SeriesRaceScene.prototype.updateSeriesText = function() {
                var series = this._series[this._seriesIndex];
                this._seriesText.text = series.name, webfont ? this._seriesText.x = .5 * -this._seriesText.width : (this._seriesText.validate(), this._seriesText.x = .5 * -this._seriesText.textWidth)
            }, SeriesRaceScene.prototype.swapBackgroundImage = function(animate) {
                var texture, tm = Common.trackManager,
                    id = tm.currentSeries.id,
                    country = tm.currentTrack.country;
                switch (id) {
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                    case 6:
                        texture = Common.assets.getTexture("map_bg_" + country);
                        break;
                    default:
                        texture = Common.assets.getTexture("map_bg_global")
                }
                this._bg.next && (TweenMax.killTweensOf(this._bg.next), this._bg.next.alpha = 1, this._bg.parent.removeChild(this._bg), this._bg = this._bg.next), animate ? (this._bg.next = new PIXI.Sprite(texture), this._bg.next.scale = new PIXI.Point(2, 2), this._bg.parent.addChildAt(this._bg.next, this._bg.parent.getChildIndex(this._bg) + 1), this._bg.next.alpha = 0, this._animator.add(TweenMax.to(this._bg.next, .4, {
                    alpha: 1,
                    ease: Power1.easeInOut,
                    onComplete: function() {
                        this._bg.parent.removeChild(this._bg), this._bg = this._bg.next
                    },
                    onCompleteScope: this
                }))) : this._bg.texture = texture
            }, SeriesRaceScene.prototype.onSettingsButtonClick = function(button) {
                this.signals.settings.dispatch(this)
            }, SeriesRaceScene.prototype.onBackButtonClick = function(button) {
                this.signals.previous.dispatch(this)
            }, SeriesRaceScene.prototype.onNextButtonClick = function(button) {
                ++this._seriesIndex >= this._series.length && (this._seriesIndex = 0), Common.trackManager.selectSeries(this._seriesIndex), this.loadTracks(this._seriesIndex), this.updateSeriesText(), this._pageIndicator.select(this._seriesIndex), this.swapBackgroundImage(!0)
            }, SeriesRaceScene.prototype.onPrevButtonClick = function(button) {
                --this._seriesIndex < 0 && (this._seriesIndex = this._series.length - 1), Common.trackManager.selectSeries(this._seriesIndex), this.loadTracks(this._seriesIndex), this.updateSeriesText(), this._pageIndicator.select(this._seriesIndex), this.swapBackgroundImage(!0)
            }, SeriesRaceScene.prototype.onPlayButtonClick = function(button) {
                var tm = Common.trackManager;
                tm.selectSeries(this._seriesIndex), this.signals.next.dispatch(this)
            }
        }, {
            "./Common": 23,
            "./DesaturationShader": 32,
            "./MessagePopup": 54,
            "./PageIndicator": 57,
            "./Scene": 83,
            "./TrackData": 101
        }],
        90: [function(require, module, exports) {
            function SeriesTypes() {}
            module.exports = SeriesTypes, SeriesTypes.BEGINNER = "beginner", SeriesTypes.WORLD = "world", SeriesTypes.USA = "usa", SeriesTypes.ITALY = "italy", SeriesTypes.GERMANY = "germany", SeriesTypes.JAPAN = "japan", SeriesTypes.BRAZIL = "brazil", SeriesTypes.ADVANCED = "advanced"
        }, {}],
        91: [function(require, module, exports) {
            function SettingsScene() {
                Scene.call(this), this.signals.name = new signals.Signal, this.signals.tutorial = new signals.Signal, this.signals.difficulty = new signals.Signal, this._overlay = null, this._panel = null, this._titleText = null, this._closeButton = null, this._nameButton = null, this._muteButton = null, this._tutorialButton = null, this._tiltSwitch = null, this._controlsSwitch = null, this._message = null
            }
            var Common = require("./Common"),
                ControlTypes = require("./ControlTypes"),
                MessagePopup = require("./MessagePopup"),
                SettingsSwitch = require("./SettingsSwitch"),
                Scene = require("./Scene");
            module.exports = SettingsScene, SettingsScene.prototype = Object.create(Scene.prototype), SettingsScene.prototype.constructor = SettingsScene, SettingsScene.prototype.init = function() {
                var graphics = new PIXI.Graphics;
                graphics.beginFill(0, .64), graphics.drawRect(0, 0, 1, 1), graphics.endFill(), this._overlay = new PIXI.Sprite(graphics.generateTexture()), this._overlay.width = p3.View.width, this._overlay.height = p3.View.height, this._overlay.visible = !1, this.addChild(this._overlay), this._panel = new PIXI.Container, this._panel.x = .5 * Common.STAGE_WIDTH, this._panel.y = .5 * Common.STAGE_HEIGHT - 20, this._panel.visible = !1, this.addChild(this._panel), this._panel.header = new PIXI.Sprite(Common.assets.getTexture("ui_popup_top")), this._panel.header.x = .5 * -this._panel.header.width, this._panel.addChild(this._panel.header), this._panel.content = new PIXI.Sprite(Common.assets.getTexture("ui_popup_bottom_carbon")), this._panel.content.x = .5 * -this._panel.content.width, this._panel.content.y = this._panel.header.y + this._panel.header.height, this._panel.addChild(this._panel.content), this._panel.header.y -= .5 * (this._panel.header.height + this._panel.content.height), this._panel.content.y -= .5 * (this._panel.header.height + this._panel.content.height), webfont ? (this._titleText = new PIXI.Text(Common.copy.options[Common.language], {
                    font: "48px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._titleText.x = .5 * (this._panel.header.width - this._titleText.width), this._titleText.y = 24, this._panel.header.addChild(this._titleText)) : (this._titleText = new PIXI.extras.BitmapText(Common.copy.options[Common.language], {
                    font: "48px Great Escape",
                    align: "center"
                }), this._titleText.x = .5 * (this._panel.header.width - this._titleText.textWidth), this._titleText.y = 16, this._panel.header.addChild(this._titleText)), this._closeButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_btn_close")), this._closeButton.x = .5 * (this._panel.header.width - this._closeButton.width) - 18, this._closeButton.y = -240, this._closeButton.animate = !0, this._closeButton.overSoundName = "sfx_ui_btn_rollover_00", this._closeButton.downSoundName = "sfx_ui_btn_press_00", this._closeButton.signals.click.add(this.onCloseButtonClick, this), this._panel.addChild(this._closeButton), this._nameButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_big_up"), Common.assets.getTexture("ui_btn_navigation_big_over"), Common.assets.getTexture("ui_btn_navigation_big_down"), Common.assets.getTexture("ui_icon_aaa")), this._nameButton.x = -160, this._nameButton.y = p3.Device.isMobile ? -110 : -70, this._nameButton.animate = !0, this._nameButton.overSoundName = "sfx_ui_btn_rollover_00", this._nameButton.downSoundName = "sfx_ui_btn_press_00", this._nameButton.signals.click.add(this.onNameButtonClick, this), this._panel.addChild(this._nameButton), this._muteButton = new p3.MuteButton(Common.assets.getTexture("ui_btn_navigation_big_up"), Common.assets.getTexture("ui_btn_navigation_big_over"), Common.assets.getTexture("ui_btn_navigation_big_down"), Common.assets.getTexture("ui_icon_sound_on"), Common.assets.getTexture("ui_icon_sound_off")), this._muteButton.x = 0, this._muteButton.y = p3.Device.isMobile ? -110 : -70, this._muteButton.animate = !0, this._muteButton.overSoundName = "sfx_ui_btn_rollover_00", this._muteButton.downSoundName = "sfx_ui_btn_press_00", this._panel.addChild(this._muteButton), this._tutorialButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_big_up"), Common.assets.getTexture("ui_btn_navigation_big_over"), Common.assets.getTexture("ui_btn_navigation_big_down"), Common.assets.getTexture("ui_icon_tutorial")), this._tutorialButton.x = 160, this._tutorialButton.y = p3.Device.isMobile ? -110 : -70, this._tutorialButton.animate = !0, this._tutorialButton.overSoundName = "sfx_ui_btn_rollover_00", this._tutorialButton.downSoundName = "sfx_ui_btn_press_00", this._tutorialButton.signals.click.add(this.onTutorialButtonClick, this), this._panel.addChild(this._tutorialButton), this._controlsSwitch = new SettingsSwitch(Common.garage.controls == ControlTypes.CONTROLS_EXPERT, 0), this._controlsSwitch.y = p3.Device.isMobile ? 44 : 114, this._controlsSwitch.animate = !0, this._controlsSwitch.signals.click.add(this.onControlsSwitchClick, this), this._panel.addChild(this._controlsSwitch), webfont ? (this._controlsSwitch.nameLabel = new PIXI.Text(Common.copy.options_difficulty[Common.language], {
                    font: "32px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._controlsSwitch.nameLabel.x = .5 * -this._controlsSwitch.nameLabel.width, this._controlsSwitch.nameLabel.y = this._controlsSwitch.y - .5 * this._controlsSwitch.nameLabel.height - 64, this._panel.addChild(this._controlsSwitch.nameLabel)) : (this._controlsSwitch.nameLabel = new PIXI.extras.BitmapText(Common.copy.options_difficulty[Common.language], {
                    font: "32px Great Escape",
                    align: "center"
                }), this._controlsSwitch.nameLabel.x = .5 * -this._controlsSwitch.nameLabel.textWidth, this._controlsSwitch.nameLabel.y = this._controlsSwitch.y - .5 * this._controlsSwitch.nameLabel.textHeight - 64, this._panel.addChild(this._controlsSwitch.nameLabel)), webfont ? (this._controlsSwitch.onLabel = new PIXI.Text(Common.copy.options_difficulty_pro[Common.language], {
                    font: "32px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._controlsSwitch.onLabel.x = this._controlsSwitch.x + 148, this._controlsSwitch.onLabel.y = this._controlsSwitch.y - .5 * this._controlsSwitch.onLabel.height, this._panel.addChild(this._controlsSwitch.onLabel)) : (this._controlsSwitch.onLabel = new PIXI.extras.BitmapText(Common.copy.options_difficulty_pro[Common.language], {
                    font: "32px Great Escape",
                    align: "center"
                }), this._controlsSwitch.onLabel.x = this._controlsSwitch.x + 148, this._controlsSwitch.onLabel.y = this._controlsSwitch.y - .5 * this._controlsSwitch.onLabel.textHeight, this._panel.addChild(this._controlsSwitch.onLabel)), webfont ? (this._controlsSwitch.offLabel = new PIXI.Text(Common.copy.options_difficulty_rookie[Common.language], {
                    font: "32px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._controlsSwitch.offLabel.x = this._controlsSwitch.x - 148 - this._controlsSwitch.offLabel.width, this._controlsSwitch.offLabel.y = this._controlsSwitch.y - .5 * this._controlsSwitch.offLabel.height, this._panel.addChild(this._controlsSwitch.offLabel)) : (this._controlsSwitch.offLabel = new PIXI.extras.BitmapText(Common.copy.options_difficulty_rookie[Common.language], {
                    font: "32px Great Escape",
                    align: "center"
                }), this._controlsSwitch.offLabel.x = this._controlsSwitch.x - 148 - this._controlsSwitch.offLabel.textWidth, this._controlsSwitch.offLabel.y = this._controlsSwitch.y - .5 * this._controlsSwitch.offLabel.textHeight, this._panel.addChild(this._controlsSwitch.offLabel)), this._tiltSwitch = new SettingsSwitch(!1, 1), this._tiltSwitch.y = 190, this._tiltSwitch.animate = !0, this._tiltSwitch.visible = p3.Device.isMobile, this._tiltSwitch.signals.click.add(this.onTiltSwitchClick, this), this._panel.addChild(this._tiltSwitch), webfont ? (this._tiltSwitch.nameLabel = new PIXI.Text(Common.copy.options_tilt[Common.language], {
                    font: "32px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._tiltSwitch.nameLabel.x = .5 * -this._tiltSwitch.nameLabel.width, this._tiltSwitch.nameLabel.y = this._tiltSwitch.y - .5 * this._controlsSwitch.nameLabel.height - 64, this._tiltSwitch.nameLabel.visible = p3.Device.isMobile, this._panel.addChild(this._tiltSwitch.nameLabel)) : (this._tiltSwitch.nameLabel = new PIXI.extras.BitmapText(Common.copy.options_tilt[Common.language], {
                    font: "32px Great Escape",
                    align: "center"
                }), this._tiltSwitch.nameLabel.x = .5 * -this._tiltSwitch.nameLabel.textWidth, this._tiltSwitch.nameLabel.y = this._tiltSwitch.y - .5 * this._controlsSwitch.nameLabel.textHeight - 64, this._tiltSwitch.nameLabel.visible = p3.Device.isMobile, this._panel.addChild(this._tiltSwitch.nameLabel)), webfont ? (this._tiltSwitch.onLabel = new PIXI.Text(Common.copy.options_tilt_on[Common.language], {
                    font: "32px Great Escape",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._tiltSwitch.onLabel.x = this._tiltSwitch.x + 148, this._tiltSwitch.onLabel.y = this._tiltSwitch.y - .5 * this._tiltSwitch.onLabel.height, this._tiltSwitch.onLabel.visible = p3.Device.isMobile, this._panel.addChild(this._tiltSwitch.onLabel)) : (this._tiltSwitch.onLabel = new PIXI.extras.BitmapText(Common.copy.options_tilt_on[Common.language], {
                    font: "32px Great Escape",
                    align: "center"
                }), this._tiltSwitch.onLabel.x = this._tiltSwitch.x + 148, this._tiltSwitch.onLabel.y = this._tiltSwitch.y - .5 * this._tiltSwitch.onLabel.textHeight, this._tiltSwitch.onLabel.visible = p3.Device.isMobile, this._panel.addChild(this._tiltSwitch.onLabel)), webfont ? (this._tiltSwitch.offLabel = new PIXI.Text(Common.copy.options_tilt_off[Common.language], {
                    font: "32px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._tiltSwitch.offLabel.x = this._tiltSwitch.x - 148 - this._tiltSwitch.offLabel.width, this._tiltSwitch.offLabel.y = this._tiltSwitch.y - .5 * this._tiltSwitch.offLabel.height, this._tiltSwitch.offLabel.visible = p3.Device.isMobile, this._panel.addChild(this._tiltSwitch.offLabel)) : (this._tiltSwitch.offLabel = new PIXI.extras.BitmapText(Common.copy.options_tilt_off[Common.language], {
                    font: "32px Great Escape",
                    align: "center"
                }), this._tiltSwitch.offLabel.x = this._tiltSwitch.x - 148 - this._tiltSwitch.offLabel.textWidth, this._tiltSwitch.offLabel.y = this._tiltSwitch.y - .5 * this._tiltSwitch.offLabel.textHeight, this._tiltSwitch.offLabel.visible = p3.Device.isMobile, this._panel.addChild(this._tiltSwitch.offLabel))
            }, SettingsScene.prototype.dispose = function() {
                Common.animator.removeAll(), Scene.prototype.dispose.call(this)
            }, SettingsScene.prototype.appear = function() {
                this.animateIn(), this._message = new MessagePopup(8, MessagePopup.CHARACTER_MCQUEEN, Common.copy.options_helper[Common.language]), this._message.x = .5 * (Common.STAGE_WIDTH - p3.View.width) + 20, this._message.y = p3.View.height - this._message.height - 20, this._message.animateIn(), this.addChild(this._message)
            }, SettingsScene.prototype.show = function() {
                this._closeButton.interactive = !0, this._nameButton.interactive = !0, this._muteButton.interactive = !0, this._controlsSwitch.interactive = !0
            }, SettingsScene.prototype.animateIn = function(callback, scope) {
                Scene.prototype.animateIn.call(this, callback, scope), this._overlay.alpha = 0, this._overlay.visible = !0, TweenMax.to(this._overlay, .2, {
                    alpha: 1,
                    ease: Power1.easeInOut
                });
                var x = this._panel.x;
                this._panel.x = .5 * (Common.STAGE_WIDTH - p3.View.width - this._panel.width), this._panel.visible = !0, TweenMax.to(this._panel, .3, {
                    x: x,
                    ease: Back.easeOut,
                    easeParams: [1]
                })
            }, SettingsScene.prototype.animateOut = function(callback, scope) {
                Scene.prototype.animateOut.call(this, callback, scope), TweenMax.to(this._overlay, .4, {
                    alpha: 0,
                    ease: Power1.easeInOut,
                    onComplete: function() {
                        this._overlay.visible = !1
                    },
                    onCompleteScope: this
                }), TweenMax.to(this._panel, .26, {
                    x: .5 * (Common.STAGE_WIDTH + p3.View.width + this._panel.width),
                    ease: Back.easeIn,
                    easeParams: [1],
                    onComplete: function() {
                        this._panel.visible = !1,
                            callback && callback.call(scope)
                    },
                    onCompleteScope: this
                })
            }, SettingsScene.prototype.resize = function() {
                this.x = .5 * (p3.View.width - Common.STAGE_WIDTH), this._overlay.x = .5 * (Common.STAGE_WIDTH - p3.View.width), this._overlay.y = .5 * (Common.STAGE_HEIGHT - p3.View.height), this._overlay.width = p3.View.width, this._overlay.height = p3.View.height
            }, SettingsScene.prototype.update = function() {}, SettingsScene.prototype.onCloseButtonClick = function(button) {
                this._closeButton.interactive = !1, this._nameButton.interactive = !1, this._muteButton.interactive = !1, this._tiltSwitch.interactive = !1, this._controlsSwitch.interactive = !1, this._closeButton.onMouseOut(), this.animateOut(function() {
                    this.signals.next.dispatch()
                }, this)
            }, SettingsScene.prototype.onNameButtonClick = function(button) {
                this._closeButton.interactive = !1, this._nameButton.interactive = !1, this._muteButton.interactive = !1, this._tiltSwitch.interactive = !1, this._controlsSwitch.interactive = !1, this.signals.name.dispatch()
            }, SettingsScene.prototype.onTutorialButtonClick = function(button) {
                this._closeButton.onMouseOut(), this.animateOut(function() {
                    this.signals.tutorial.dispatch()
                }, this)
            }, SettingsScene.prototype.onTiltSwitchClick = function(button, value) {}, SettingsScene.prototype.onControlsSwitchClick = function(button, value) {
                Common.garage.controls = value ? ControlTypes.CONTROLS_EXPERT : ControlTypes.CONTROLS_ROOKIE, Common.saveData.save(), Common.tracking.track(new p3.TrackingDataPlaydomGameAction("settings", value ? "set_pro" : "set_rookie"))
            }
        }, {
            "./Common": 23,
            "./ControlTypes": 26,
            "./MessagePopup": 54,
            "./Scene": 83,
            "./SettingsSwitch": 92
        }],
        92: [function(require, module, exports) {
            function SettingsSwitch(value, style) {
                style = style || 0, this.signals = {}, this.signals.click = new signals.Signal, this._value = value, PIXI.Container.call(this);
                var texture;
                switch (style) {
                    case 0:
                        texture = Common.assets.getTexture("ui_btn_switch_diff_bg");
                        break;
                    case 1:
                        texture = Common.assets.getTexture("ui_btn_switch_tilt_bg")
                }
                var bg = new PIXI.Sprite(texture);
                bg.anchor = new PIXI.Point(.5, .5), bg.interactive = !0, bg.buttonMode = !0, this.addChild(bg);
                var that = this;
                bg.click = this.tap = function() {
                    that.onButtonClick.call(that)
                }, this.button = new p3.Button(Common.assets.getTexture("ui_btn_switch"), Common.assets.getTexture("ui_btn_switch"), Common.assets.getTexture("ui_btn_switch")), this.button.x = .5 * -texture.width + 40, this.button.animate = !0, this.button.overSoundName = "sfx_ui_btn_rollover_00", this.button.downSoundName = "sfx_ui_btn_press_00", this.button.signals.click.add(this.onButtonClick, this), this.addChild(this.button), this["switch"](value, !1)
            }
            var Common = require("./Common");
            module.exports = SettingsSwitch, SettingsSwitch.prototype = Object.create(PIXI.Container.prototype), SettingsSwitch.prototype.constructor = SettingsSwitch, SettingsSwitch.prototype["switch"] = function(value, animate) {
                this._value = value;
                var x = value ? .5 * this.children[0].texture.width - 40 : .5 * -this.children[0].texture.width + 40;
                animate ? (TweenMax.killTweensOf(this.button), TweenMax.to(this.button, .3, {
                    x: x,
                    ease: Power3.easeInOut
                })) : this.button.x = x
            }, SettingsSwitch.prototype.onButtonClick = function(button) {
                this["switch"](!this._value, !0), this.signals.click.dispatch(this, this._value)
            }, Object.defineProperty(SettingsSwitch.prototype, "value", {
                get: function() {
                    return this._value
                }
            })
        }, {
            "./Common": 23
        }],
        93: [function(require, module, exports) {
            function SingleRaceScene() {
                Scene.call(this), this.signals.settings = new signals.Signal, this._animator = null, this._bg = null, this._header = null, this._titleText = null, this._countryText = null, this._settingsButton = null, this._backButton = null, this._nextButton = null, this._prevButton = null, this._playButton = null, this._countryIndex = 0, this._countries = [], this._trackButtons = [], this._trackLinks = [], this._pageIndicator = null, this._message = null
            }
            var Common = require("./Common"),
                CountryTypes = require("./CountryTypes"),
                DesaturationShader = require("./DesaturationShader"),
                MessagePopup = require("./MessagePopup"),
                PageIndicator = require("./PageIndicator"),
                Scene = require("./Scene"),
                TrackData = require("./TrackData");
            module.exports = SingleRaceScene, SingleRaceScene.prototype = Object.create(Scene.prototype), SingleRaceScene.prototype.constructor = SingleRaceScene, SingleRaceScene.prototype.init = function() {
                var track = Common.trackManager.getTrack(Common.garage.track);
                this._countries = Common.trackManager.countries, this._countryIndex = Math.max(0, this._countries.indexOf(track.country)), Common.trackManager.selectTrack(track.id), this._animator = new p3.Animator, this._animator.init();
                var name = this._countries[this._countryIndex];
                this._bg = new PIXI.Sprite(PIXI.Texture.EMPTY), this._bg.scale = new PIXI.Point(2, 2), this.addChild(this._bg), this._header = new PIXI.Sprite(Common.assets.getTexture("ui_top_bar")), this._header.x = .5 * Common.STAGE_WIDTH, this._header.y = 120, this._header.anchor = new PIXI.Point(.5, .5), this.addChild(this._header), webfont ? (this._titleText = new PIXI.Text(Common.copy.single_race[Common.language], {
                    font: "48px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._titleText.x = .5 * (Common.STAGE_WIDTH - this._titleText.width), this._titleText.y = 96, this.addChild(this._titleText)) : (this._titleText = new PIXI.extras.BitmapText(Common.copy.single_race[Common.language], {
                    font: "48px Great Escape",
                    align: "center"
                }), this._titleText.x = .5 * (Common.STAGE_WIDTH - this._titleText.textWidth), this._titleText.y = 86, this.addChild(this._titleText)), this._countryText = new PIXI.extras.BitmapText("", {
                    font: "48px Great Escape",
                    align: "center"
                }), this._countryText.y = 200, this.addChild(this._countryText), this._settingsButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_settings")), this._settingsButton.y = 120, this._settingsButton.animate = !0, this._settingsButton.overSoundName = "sfx_ui_btn_rollover_00", this._settingsButton.downSoundName = "sfx_ui_btn_press_00", this._settingsButton.signals.click.add(this.onSettingsButtonClick, this), this.addChild(this._settingsButton), this.addChild(this._settingsButton), this._backButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_back")), this._backButton.y = 120, this._backButton.animate = !0, this._backButton.overSoundName = "sfx_ui_btn_rollover_00", this._backButton.downSoundName = "sfx_ui_btn_press_00", this._backButton.signals.click.add(this.onBackButtonClick, this), this.addChild(this._backButton), this._nextButton = new p3.Button(Common.assets.getTexture("ui_btn_arrow_up"), Common.assets.getTexture("ui_btn_arrow_over"), Common.assets.getTexture("ui_btn_arrow_down")), this._nextButton.y = .5 * Common.STAGE_HEIGHT, this._nextButton.scale.x = this._nextButton.defaultScale.x = -1, this._nextButton.animate = !0, this._nextButton.overSoundName = "sfx_ui_btn_rollover_00", this._nextButton.downSoundName = "sfx_ui_btn_press_00", this._nextButton.signals.click.add(r2l ? this.onPrevButtonClick : this.onNextButtonClick, this), this.addChild(this._nextButton), this._prevButton = new p3.Button(Common.assets.getTexture("ui_btn_arrow_up"), Common.assets.getTexture("ui_btn_arrow_over"), Common.assets.getTexture("ui_btn_arrow_down")), this._prevButton.y = .5 * Common.STAGE_HEIGHT, this._prevButton.animate = !0, this._prevButton.overSoundName = "sfx_ui_btn_rollover_00", this._prevButton.downSoundName = "sfx_ui_btn_press_00", this._prevButton.signals.click.add(r2l ? this.onNextButtonClick : this.onPrevButtonClick, this), this.addChild(this._prevButton), this._pageIndicator = new PageIndicator(this._countries.length, r2l), this._pageIndicator.x = .5 * Common.STAGE_WIDTH, this._pageIndicator.y = 720, this._pageIndicator.select(this._countryIndex), this.addChild(this._pageIndicator), this.updateCountryText(), this.loadTracks(name), this.swapBackgroundImage()
            }, SingleRaceScene.prototype.dispose = function() {
                this._animator.removeAll(), this._message && (this._message.destroy(), this._message = null), Scene.prototype.dispose.call(this)
            }, SingleRaceScene.prototype.appear = function() {
                this.animateIn(), this._message = new MessagePopup(6, MessagePopup.CHARACTER_MCQUEEN, Common.copy.single_race_helper[Common.language]), this._message.x = .5 * (Common.STAGE_WIDTH - p3.View.width) + 20, this._message.y = 560, this._message.animateIn(), this.addChild(this._message)
            }, SingleRaceScene.prototype.show = function() {}, SingleRaceScene.prototype.animateIn = function(callback, scope) {
                this.animateTracks()
            }, SingleRaceScene.prototype.animateOut = function(callback, scope) {}, SingleRaceScene.prototype.resize = function() {
                this.x = .5 * (p3.View.width - Common.STAGE_WIDTH), this._header.width = p3.View.width, this._backButton.x = .5 * (Common.STAGE_WIDTH - p3.View.width + Math.abs(this._backButton.width)) + 28, this._settingsButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width - Math.abs(this._settingsButton.width)) - 28, this._nextButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width - Math.abs(this._nextButton.width)) - 28, this._prevButton.x = .5 * (Common.STAGE_WIDTH - p3.View.width + Math.abs(this._prevButton.width)) + 28
            }, SingleRaceScene.prototype.update = function() {
                this._animator.update(p3.Timestep.deltaTime)
            }, SingleRaceScene.prototype.loadTracks = function(country) {
                this.clearTracks();
                var tracks = Common.trackManager.getTracks(country);
                Common.trackManager.currentTrack = tracks[0].id;
                for (var textureNamePrefix, data, track, unlocked, texture, child, link, j, shader = new DesaturationShader(1), positions = [new PIXI.Point(-1.8, 0), new PIXI.Point(0, -.84), new PIXI.Point(0, .84), new PIXI.Point(1.8, 0)], spacing = 120, i = 0; i < tracks.length; ++i) {
                    switch (data = tracks[i], unlocked = data.unlocked, texture = unlocked ? Common.assets.getTexture("ui_icon_track") : Common.assets.getTexture("ui_icon_track"), textureNamePrefix = unlocked ? "ui_btn_track_play" : "ui_btn_track", track = new p3.Button(Common.assets.getTexture(textureNamePrefix + "_up"), Common.assets.getTexture(textureNamePrefix + "_over"), Common.assets.getTexture(textureNamePrefix + "_down")), track.id = data.id, track.x = .5 * Common.STAGE_WIDTH + positions[i].x * spacing, track.y = .5 * Common.STAGE_HEIGHT + positions[i].y * spacing, track.anchor = new PIXI.Point(.5, .5), track.filters = unlocked ? null : [shader], track.animate = !0, track.overSoundName = "sfx_ui_btn_rollover_00", track.downSoundName = "sfx_ui_btn_press_00", this.addChild(track), this._trackButtons.push(track), unlocked && track.signals.click.add(this.onTrackButtonClick, this), track.flag = new PIXI.Sprite(Common.assets.getTexture("ui_btn_track_" + data.country.toLowerCase())), track.flag.anchor = new PIXI.Point(.5, .5), track.addChild(track.flag), track.no = new PIXI.Sprite(Common.assets.getTexture("ui_btn_track_" + (i + 1))), track.no.anchor = new PIXI.Point(.5, .5), track.addChild(track.no), texture = PIXI.Texture.EMPTY, data.difficulty) {
                        case TrackData.DIFFICULTY_EASY:
                            texture = Common.assets.getTexture("ui_btn_track_loop_easy");
                            break;
                        case TrackData.DIFFICULTY_INTERMEDIATE:
                            texture = Common.assets.getTexture("ui_btn_track_loop_medium");
                            break;
                        case TrackData.DIFFICULTY_HARD:
                            texture = Common.assets.getTexture("ui_btn_track_loop_hard")
                    }
                    switch (track.map = new PIXI.Sprite(texture), track.map.anchor = new PIXI.Point(.5, .5), track.addChild(track.map), webfont ? (track.newText = new PIXI.Text(Common.copy.single_race_new[Common.language], {
                        font: "24px Arial",
                        fill: "#FFFFFF",
                        align: "center"
                    }), track.newText.x = .5 * -track.newText.width - 4, track.newText.y = -94, track.newText.visible = 0 == data.races && unlocked, track.addChild(track.newText)) : (track.newText = new PIXI.extras.BitmapText(Common.copy.single_race_new[Common.language], {
                        font: "24px Great Escape",
                        align: "center"
                    }), track.newText.x = .5 * -track.newText.textWidth - 4, track.newText.y = -94, track.newText.visible = 0 == data.races && unlocked, track.addChild(track.newText)), texture = PIXI.Texture.EMPTY, data.reward) {
                        case 0:
                            texture = Common.assets.getTexture("ui_btn_track_gold");
                            break;
                        case 1:
                            texture = Common.assets.getTexture("ui_btn_track_silver");
                            break;
                        case 2:
                            texture = Common.assets.getTexture("ui_btn_track_bronze")
                    }
                    for (track.reward = new PIXI.Sprite(texture), track.reward.anchor = new PIXI.Point(.5, .5), track.addChild(track.reward), j = 0; j < data.requiredTracks.length; ++j) child = this._trackButtons[data.requiredTracks[j].id % 4], link = new PIXI.Sprite(Common.assets.getTexture(data.unlocked ? "ui_map_path_curvy_on" : "ui_map_path_curvy_off")), link.x = .5 * child.x + .5 * track.x, link.y = .5 * child.y + .5 * track.y, link.anchor = new PIXI.Point(.5, .5), link.rotation = Math.atan2(child.y - track.y, child.x - track.x) + .5 * Math.PI, this.addChildAt(link, 2), this._trackLinks.push(link)
                }
            }, SingleRaceScene.prototype.animateTracks = function() {
                for (var data, track, config, emitter, tm = Common.trackManager, country = this._countries[this._countryIndex], tracks = tm.getTracks(country), i = 0; i < this._trackButtons.length; ++i) data = tracks[i], track = this._trackButtons[i], data.animate && (data.animate = !1, config = Common.assets.getJSON("particle_coin_burst"), emitter = new cloudkid.Emitter(this, [Common.assets.getTexture("particle_standard")], config), emitter.emit = !1, emitter.updateOwnerPos(track.x, track.y + 40), this._animator.add(emitter), track.animate = !1, this._animator.add(TweenMax.to(track.scale, .24, {
                    delay: .2 * i,
                    x: 1.32,
                    y: 1.32,
                    ease: Power1.easeInOut,
                    yoyo: !0,
                    repeat: 1,
                    onComplete: function(track) {
                        track.animate = !0
                    },
                    onCompleteParams: [track],
                    onCompleteScope: this
                })), track.reward.alpha = 0, this._animator.add(TweenMax.to(track.reward, .4, {
                    delay: .2 * i,
                    alpha: 1,
                    ease: Power1.easeInOut,
                    onStart: function(emitter) {
                        emitter.emit = !0, Common.audio.playSound("sfx_race_lights_go_00")
                    },
                    onStartParams: [emitter],
                    onStartScope: this
                })));
                Common.saveData.save()
            }, SingleRaceScene.prototype.clearTracks = function() {
                for (var track, i = 0; i < this._trackButtons.length; ++i) track = this._trackButtons[i], track.parent.removeChild(track);
                this._trackButtons.length = 0;
                var link;
                for (i = 0; i < this._trackLinks.length; ++i) link = this._trackLinks[i], link.parent.removeChild(link);
                this._trackLinks.length = 0
            }, SingleRaceScene.prototype.updateCountryText = function() {
                var country = this._countries[this._countryIndex],
                    track = Common.trackManager.getTracks(country)[0];
                webfont ? (this._titleText.text = track.countryName, this._titleText.x = .5 * (Common.STAGE_WIDTH - this._titleText.width)) : (this._titleText.text = track.countryName, this._titleText.validate(), this._titleText.x = .5 * (Common.STAGE_WIDTH - this._titleText.textWidth))
            }, SingleRaceScene.prototype.swapBackgroundImage = function(animate) {
                var tm = Common.trackManager,
                    country = tm.currentTrack.country;
                country == CountryTypes.TUTORIAL && (country = CountryTypes.USA);
                var texture = Common.assets.getTexture("map_bg_" + country);
                this._bg.next && (TweenMax.killTweensOf(this._bg.next), this._bg.next.alpha = 1, this._bg.parent.removeChild(this._bg), this._bg = this._bg.next), animate ? (this._bg.next = new PIXI.Sprite(texture), this._bg.next.scale = new PIXI.Point(2, 2), this._bg.parent.addChildAt(this._bg.next, this._bg.parent.getChildIndex(this._bg) + 1), this._bg.next.alpha = 0, this._animator.add(TweenMax.to(this._bg.next, .4, {
                    alpha: 1,
                    ease: Power1.easeInOut,
                    onComplete: function() {
                        this._bg.parent.removeChild(this._bg), this._bg = this._bg.next
                    },
                    onCompleteScope: this
                }))) : this._bg.texture = texture
            }, SingleRaceScene.prototype.onSettingsButtonClick = function(button) {
                this.signals.settings.dispatch(this)
            }, SingleRaceScene.prototype.onBackButtonClick = function(button) {
                this.signals.previous.dispatch(this)
            }, SingleRaceScene.prototype.onNextButtonClick = function(button) {
                ++this._countryIndex >= this._countries.length && (this._countryIndex = 0);
                var name = this._countries[this._countryIndex];
                this.loadTracks(name), this.animateTracks(), this.updateCountryText();
                var tm = Common.trackManager,
                    tracks = tm.getTracks(name);
                tm.selectTrack(tracks[0].id), this._pageIndicator.select(this._countryIndex), this.swapBackgroundImage(!0)
            }, SingleRaceScene.prototype.onPrevButtonClick = function(button) {
                --this._countryIndex < 0 && (this._countryIndex = this._countries.length - 1);
                var name = this._countries[this._countryIndex];
                this.loadTracks(name), this.animateTracks(), this.updateCountryText();
                var tm = Common.trackManager,
                    tracks = tm.getTracks(name);
                tm.selectTrack(tracks[0].id), this._pageIndicator.select(this._countryIndex), this.swapBackgroundImage(!0)
            }, SingleRaceScene.prototype.onTrackButtonClick = function(button) {
                var tm = Common.trackManager;
                tm.selectTrack(button.id), this.signals.next.dispatch(this)
            }
        }, {
            "./Common": 23,
            "./CountryTypes": 27,
            "./DesaturationShader": 32,
            "./MessagePopup": 54,
            "./PageIndicator": 57,
            "./Scene": 83,
            "./TrackData": 101
        }],
        94: [function(require, module, exports) {
            function Skybox(theme) {
                PIXI.Container.call(this), this._theme = theme, this._sky = null, this._near = null, this._far = null, this.createSkyLayer(), this.createFarLayer(), this.createNearLayer(), this.update(1), this.a = 0
            }
            var Common = require("./Common");
            module.exports = Skybox, Skybox.prototype = Object.create(PIXI.Container.prototype), Skybox.prototype.constructor = Skybox, Skybox.prototype.createSkyLayer = function() {
                var texture;
                switch (this._theme) {
                    case "brazil":
                        texture = Common.assets.getTexture("bz_bg_sky_gradient");
                        break;
                    case "germany":
                        texture = Common.assets.getTexture("de_bg_sky_gradient");
                        break;
                    case "italy":
                        texture = Common.assets.getTexture("pc_bg_sky_gradient");
                        break;
                    case "japan":
                        texture = Common.assets.getTexture("tk_bg_sky_gradient");
                        break;
                    case "tutorial":
                    case "usa":
                        texture = Common.assets.getTexture("rs_bg_sky_gradient")
                }
                this._sky = new PIXI.Sprite(texture), this._sky.x = .5 * (Common.STAGE_WIDTH - p3.View.width), this._sky.width = p3.View.width, this._sky.height = 1.4 * p3.View.height, this.addChild(this._sky)
            }, Skybox.prototype.createNearLayer = function() {
                this._near = new PIXI.Container, this.addChild(this._near);
                var a, b, textures, color;
                switch (this._theme) {
                    case "brazil":
                        a = Common.assets.getTexture("bg_bz_01"), b = Common.assets.getTexture("bg_bz_01b"), textures = [a, b, a, b, a, b, a], color = 994841;
                        break;
                    case "germany":
                        a = Common.assets.getTexture("bg_de_01"), b = Common.assets.getTexture("bg_de_01b"), textures = [a, b, a, b, a, b, a], color = 4736551;
                        break;
                    case "italy":
                        a = Common.assets.getTexture("bg_pc_01"), b = Common.assets.getTexture("bg_pc_01b"), textures = [a, b, a, b, a, b, a], color = 1063763;
                        break;
                    case "japan":
                        a = Common.assets.getTexture("bg_tk_01"), textures = [a, a, a, a, a, a, a], color = 1381428;
                        break;
                    case "tutorial":
                    case "usa":
                        a = Common.assets.getTexture("bg_rs_01"), textures = [a, a, a, a, a, a, a], color = 16770240
                }
                for (var tile, i = 0; i < textures.length; ++i) tile = new PIXI.Sprite(textures[i]), tile.scale = new PIXI.Point(2, 2), tile.x = i * tile.width, tile.y = 40, this._near.addChild(tile);
                this._near.tileWidth = tile.width, this._near.tileCount = 6;
                var graphics = new PIXI.Graphics;
                graphics.beginFill(color), graphics.drawRect(0, 0, 1, 1), graphics.endFill();
                var padding = new PIXI.Sprite(graphics.generateTexture());
                padding.y = tile.y + tile.height, padding.width = textures.length * tile.width, padding.height = 140, this._near.addChild(padding), this.addFeatures()
            }, Skybox.prototype.createFarLayer = function() {
                this._far = new PIXI.Container, this.addChild(this._far);
                var a, b;
                switch (this._theme) {
                    case "brazil":
                        a = Common.assets.getTexture("bg_bz_02"), b = Common.assets.getTexture("bg_bz_02b");
                        break;
                    case "germany":
                        a = Common.assets.getTexture("bg_de_02"), b = Common.assets.getTexture("bg_de_02b");
                        break;
                    case "italy":
                        a = Common.assets.getTexture("bg_pc_02"), b = Common.assets.getTexture("bg_pc_02b");
                        break;
                    case "japan":
                        a = Common.assets.getTexture("bg_tk_02"), b = Common.assets.getTexture("bg_tk_02b");
                        break;
                    case "tutorial":
                    case "usa":
                        a = Common.assets.getTexture("bg_rs_02"), b = Common.assets.getTexture("bg_rs_02b")
                }
                for (var tile, textures = [b, a, b, a, b], i = 0; i < textures.length; ++i) tile = new PIXI.Sprite(textures[i]), tile.scale = new PIXI.Point(2, 2), tile.x = i * tile.width, tile.y = 120, this._far.addChild(tile);
                this._far.tileWidth = tile.width, this._far.tileCount = 4, this.addClouds()
            }, Skybox.prototype.addFeatures = function() {
                var feature;
                switch (this._theme) {
                    case "brazil":
                        feature = new PIXI.Sprite(Common.assets.getTexture("bg_bz_feature_00")), feature.x = 2400, feature.y = 450, feature.scale = new PIXI.Point(2, 2), feature.anchor = new PIXI.Point(.5, 1), this._near.addChildAt(feature, 0), feature = new PIXI.Sprite(Common.assets.getTexture("bg_bz_feature_01")), feature.x = 4800, feature.y = 450, feature.scale = new PIXI.Point(2, 2), feature.anchor = new PIXI.Point(.5, 1), this._near.addChildAt(feature, 0);
                        break;
                    case "germany":
                        feature = new PIXI.Sprite(Common.assets.getTexture("bg_de_feature_00")), feature.x = 2400, feature.y = 450, feature.scale = new PIXI.Point(2, 2), feature.anchor = new PIXI.Point(.5, 1), this._near.addChildAt(feature, 0), feature = new PIXI.Sprite(Common.assets.getTexture("bg_de_feature_01")), feature.x = 4800, feature.y = 450, feature.scale = new PIXI.Point(2, 2), feature.anchor = new PIXI.Point(.5, 1), this._near.addChildAt(feature, 0);
                        break;
                    case "tutorial":
                    case "usa":
                        feature = new PIXI.Sprite(Common.assets.getTexture("bg_rs_feature_00")), feature.x = 2400, feature.y = 450, feature.scale = new PIXI.Point(2, 2), feature.anchor = new PIXI.Point(.5, 1), this._near.addChildAt(feature, 0), feature = new PIXI.Sprite(Common.assets.getTexture("bg_rs_feature_01")), feature.x = 4800, feature.y = 450, feature.scale = new PIXI.Point(2, 2), feature.anchor = new PIXI.Point(.5, 1), this._near.addChildAt(feature, 0)
                }
            }, Skybox.prototype.addClouds = function() {
                var names, clouds = [
                    [{
                        position: new PIXI.Point(40, 124),
                        type: 1
                    }, {
                        position: new PIXI.Point(440, 90),
                        type: 0
                    }, {
                        position: new PIXI.Point(240, 20),
                        type: 2
                    }, {
                        position: new PIXI.Point(760, 160),
                        type: 1
                    }],
                    [{
                        position: new PIXI.Point(80, 100),
                        type: 2
                    }, {
                        position: new PIXI.Point(330, 46),
                        type: 1
                    }, {
                        position: new PIXI.Point(470, 60),
                        type: 0
                    }, {
                        position: new PIXI.Point(720, 170),
                        type: 0
                    }],
                    [{
                        position: new PIXI.Point(270, 170),
                        type: 0
                    }, {
                        position: new PIXI.Point(530, 100),
                        type: 1
                    }, {
                        position: new PIXI.Point(790, 44),
                        type: 0
                    }, {
                        position: new PIXI.Point(720, 170),
                        type: 2
                    }]
                ];
                switch (this._theme) {
                    case "brazil":
                        names = ["bg_bz_cloud_00", "bg_bz_cloud_01", "bg_bz_cloud_02"];
                        break;
                    case "germany":
                        names = ["bg_de_cloud_00", "bg_de_cloud_01", "bg_de_cloud_02"];
                        break;
                    case "italy":
                        names = ["bg_pc_cloud_00", "bg_pc_cloud_01", "bg_pc_cloud_02"];
                        break;
                    case "japan":
                        names = [];
                        break;
                    case "tutorial":
                    case "usa":
                        names = ["bg_rs_cloud_00", "bg_rs_cloud_01", "bg_rs_cloud_02"]
                }
                if (names.length)
                    for (var cloud, texture, index, first, i = 0; i < this._far.tileCount + 1; ++i) {
                        index = Math.floor(Math.random() * clouds.length), 0 == i ? first = index : i == this._far.tileCount && (index = first);
                        for (var j = 0; j < clouds[index].length * (this._far.tileCount + 1); ++j) texture = Common.assets.getTexture(names[clouds[index][j % clouds[index].length].type]), cloud = new PIXI.Sprite(texture), cloud.position = new PIXI.Point(2 * clouds[index][j % clouds[index].length].position.x + i * this._far.tileWidth, 2 * clouds[index][j % clouds[index].length].position.y), cloud.anchor = new PIXI.Point(.5, .5), this._far.addChildAt(cloud, 0)
                    }
            }, Skybox.prototype.resize = function() {
                this._sky.x = .5 * (Common.STAGE_WIDTH - p3.View.width), this._sky.width = p3.View.width
            }, Skybox.prototype.update = function(ease) {
                var engine = Common.engine,
                    camera = engine.camera,
                    target = camera.target,
                    angle = camera.angle;
                0 > angle && (angle += 2 * Math.PI), angle > 2 * Math.PI && (angle -= 2 * Math.PI), angle /= 2 * Math.PI, this._near.x = -angle * (this._near.tileWidth * this._near.tileCount), this._far.x = -angle * (this._far.tileWidth * this._far.tileCount);
                var diff;
                ease = ease || .04, diff = 420 * engine.getTrackGradient(target.distance) - this._near.y, this._near.y += diff * ease, diff = -200 + 420 * engine.getTrackGradient(target.distance) * 2 - this._sky.y, this._sky.y += diff * ease, diff = -40 + 420 * engine.getTrackGradient(target.distance) * 2 - this._far.y, this._far.y += diff * ease
            }, Object.defineProperty(Skybox.prototype, "theme", {
                get: function() {
                    return this._theme
                }
            })
        }, {
            "./Common": 23
        }],
        95: [function(require, module, exports) {
            function SplashOverlayEffect(type) {
                this._type = type || SplashOverlayEffect.TYPE_OIL, PIXI.Container.call(this)
            }
            var Common = require("./Common");
            module.exports = SplashOverlayEffect, SplashOverlayEffect.prototype = Object.create(PIXI.Container.prototype), SplashOverlayEffect.prototype.constructor = SplashOverlayEffect, SplashOverlayEffect.TYPE_OIL = "oil", SplashOverlayEffect.TYPE_WATER = "water", SplashOverlayEffect.prototype.show = function() {
                var names;
                switch (this._type) {
                    case SplashOverlayEffect.TYPE_OIL:
                        names = ["splat_oil1", "splat_oil2"];
                        break;
                    case SplashOverlayEffect.TYPE_WATER:
                        names = ["splat_water1", "splat_water2"]
                }
                for (var angle, radius, splat, tl, params, count = 3, i = 0; count > i; ++i) angle = Math.random() * (2 * Math.PI), radius = 320 * Math.random(), splat = new PIXI.Sprite(Common.assets.getTexture(names[Math.floor(Math.random() * names.length)])), splat.x = .5 * Common.STAGE_WIDTH + Math.cos(angle) * radius, splat.y = .5 * Common.STAGE_HEIGHT + 120 + Math.sin(angle) * radius, splat.scale.x = splat.scale.y = .8 + .2 * Math.random(), splat.scale.x *= 2, splat.scale.y *= 2, splat.rotation = Math.random() * Math.PI, splat.alpha = 0, splat.anchor = new PIXI.Point(.5, .5), this.addChild(splat), params = i == count - 1 ? {
                    onComplete: function() {
                        this.parent.removeChild(this)
                    },
                    onCompleteScope: this
                } : {}, tl = new TimelineMax(params), tl.append(TweenMax.to(splat, .2, {
                    delay: .034 * i,
                    alpha: 1,
                    ease: Power1.easeOut
                })), tl.append(TweenMax.to(splat, 1, {
                    delay: 1,
                    alpha: 0,
                    ease: Power1.easeInOut
                }))
            }, SplashOverlayEffect.prototype.destroy = function() {
                PIXI.Container.prototype.call(this)
            }, Object.defineProperty(SplashOverlayEffect.prototype, "type", {
                get: function() {
                    return this._type
                }
            })
        }, {
            "./Common": 23
        }],
        96: [function(require, module, exports) {
            function SplashScene() {
                Scene.call(this), this.signals.play = new signals.Signal, this.signals.name = new signals.Signal, this._playButton = null, this._helpButton = null, this._muteButton = null, this._disneyButton = null, this._redeemButton = null
            }
            var AudioParams = require("./AudioParams"),
                Common = require("./Common"),
                Scene = (require("./MessagePopup"), require("./Scene"));
            module.exports = SplashScene, SplashScene.prototype = Object.create(Scene.prototype), SplashScene.prototype.constructor = SplashScene, SplashScene.prototype.init = function() {
                var bg = new PIXI.Sprite(Common.assets.getTexture("ui_bg_main_menu"));
                this.addChild(bg), this._brand = new PIXI.Sprite(Common.assets.getTexture("ui_splash_cars_logo")), this._brand.x = .5 * Common.STAGE_WIDTH, this._brand.y = 220, this._brand.anchor = new PIXI.Point(.5, .5), this.addChild(this._brand), this._characters = new PIXI.Sprite(Common.assets.getTexture("ui_splash_cars")), this._characters.x = .5 * Common.STAGE_WIDTH, this._characters.y = 480, this._characters.anchor = new PIXI.Point(.5, .5), this.addChild(this._characters), this._playButton = new p3.Button(Common.assets.getTexture("ui_btn_play_up"), Common.assets.getTexture("ui_btn_play_over"), Common.assets.getTexture("ui_btn_play_down"), Common.assets.getTexture("ui_icon_play")), this._playButton.x = .5 * Common.STAGE_WIDTH, this._playButton.y = 620, this._playButton.animate = !0, this._playButton.visible = !1, this._playButton.overSoundName = "sfx_ui_btn_rollover_00", this._playButton.downSoundName = "sfx_ui_btn_press_00", this._playButton.clickSoundName = "sfx_ui_btn_play_00", this._playButton.signals.click.add(this.onPlayButtonClick, this), this.addChild(this._playButton), this._muteButton = new p3.MuteButton(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_sound_on"), Common.assets.getTexture("ui_icon_sound_off")), this._muteButton.y = 120, this._muteButton.animate = !0, this._muteButton.overSoundName = "sfx_ui_btn_rollover_00", this._muteButton.downSoundName = "sfx_ui_btn_press_00", this.addChild(this._muteButton), this._disneyButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_comms")), this._disneyButton.y = 640, this._disneyButton.animate = !0, this._disneyButton.visible = !1, this._disneyButton.overSoundName = "sfx_ui_btn_rollover_00", this._disneyButton.downSoundName = "sfx_ui_btn_press_00", this._disneyButton.signals.click.add(this.onDisneyButtonClick, this), this.addChild(this._disneyButton), this._redeemButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_unlock")), this._redeemButton.y = 640, this._redeemButton.animate = !0, this._redeemButton.visible = !1, this._redeemButton.overSoundName = "sfx_ui_btn_rollover_00", this._redeemButton.downSoundName = "sfx_ui_btn_press_00", this._redeemButton.signals.click.add(this.onRedeemButtonClick, this), this.addChild(this._redeemButton)
            }, SplashScene.prototype.dispose = function() {
                Common.animator.removeAll(), this.signals.play.dispose(), this.signals.name.dispose(), Common.audio.stopSound("sfx_ambience_splashandprerace_00"), Scene.prototype.dispose.call(this)
            }, SplashScene.prototype.appear = function() {
                this.animateIn();
                var params = new AudioParams;
                params.loop = !0, Common.audio.playSound("sfx_ambience_splashandprerace_00", params)
            }, SplashScene.prototype.show = function() {
                this._playButton.interactive = !0, this._muteButton.interactive = !0, this._nextButton.interactive = !0, this._prevButton.interactive = !0
            }, SplashScene.prototype.animateIn = function(callback, scope) {
                this._playButton.scale = new PIXI.Point, this._playButton.visible = !0, TweenMax.to(this._playButton.scale, .4, {
                    x: 1,
                    y: 1,
                    ease: Back.easeOut,
                    easeParams: [3]
                }), this._redeemButton.scale = new PIXI.Point, this._redeemButton.visible = !0, TweenMax.to(this._redeemButton.scale, .4, {
                    delay: .1,
                    x: 1,
                    y: 1,
                    ease: Back.easeOut,
                    easeParams: [2]
                })
            }, SplashScene.prototype.animateOut = function(callback, scope) {}, SplashScene.prototype.resize = function() {
                this.x = .5 * (p3.View.width - Common.STAGE_WIDTH), this._muteButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width - Math.abs(this._muteButton.width)) - 28, this._disneyButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width - Math.abs(this._disneyButton.width)) - 28, this._redeemButton.x = .5 * (Common.STAGE_WIDTH - p3.View.width + Math.abs(this._redeemButton.width)) + 28
            }, SplashScene.prototype.update = function() {}, SplashScene.prototype.onPlayButtonClick = function(button) {
                this._playButton.interactive = !1, this._muteButton.interactive = !1, this._disneyButton.interactive = !1, this._redeemButton.interactive = !1, this._playButton.onMouseOut(), delay(function() {
                    this.signals.play.dispatch(this)
                }, .4, this)
            }, SplashScene.prototype.onDisneyButtonClick = function(button) {
                this.signals.next.dispatch()
            }, SplashScene.prototype.onRedeemButtonClick = function(button) {
                this.signals.previous.dispatch()
            }
        }, {
            "./AudioParams": 9,
            "./Common": 23,
            "./MessagePopup": 54,
            "./Scene": 83
        }],
        97: [function(require, module, exports) {
            function StartingLights(country) {
                PIXI.Container.call(this), this._lights = [], this._tweens = [];
                var texture;
                switch (country) {
                    case CountryTypes.BRAZIL:
                        texture = Common.assets.getTexture("bz_race_lights_bg");
                        break;
                    case CountryTypes.GERMANY:
                        texture = Common.assets.getTexture("de_race_lights_bg");
                        break;
                    case CountryTypes.ITALY:
                        texture = Common.assets.getTexture("pc_race_lights_bg");
                        break;
                    case CountryTypes.JAPAN:
                        texture = Common.assets.getTexture("tk_race_lights_bg");
                        break;
                    case CountryTypes.TUTORIAL:
                    case CountryTypes.USA:
                        texture = Common.assets.getTexture("rs_race_lights_bg")
                }
                var bg = new PIXI.Sprite(texture);
                bg.anchor = new PIXI.Point(.5, .5), this.addChild(bg);
                var light, i, spacing = 44.5;
                for (i = 0; 5 > i; ++i) {
                    switch (country) {
                        case CountryTypes.BRAZIL:
                            texture = Common.assets.getTexture("bz_race_lights_red");
                            break;
                        case CountryTypes.GERMANY:
                            texture = Common.assets.getTexture("de_race_lights_red");
                            break;
                        case CountryTypes.ITALY:
                            texture = Common.assets.getTexture("pc_race_lights_red");
                            break;
                        case CountryTypes.JAPAN:
                            texture = Common.assets.getTexture("tk_race_lights_red");
                            break;
                        case CountryTypes.TUTORIAL:
                        case CountryTypes.USA:
                            texture = Common.assets.getTexture("rs_race_lights_red")
                    }
                    light = new PIXI.Sprite(texture), light.x = 3 + (i * spacing - 4 * spacing * .5), light.y = -46, light.anchor = new PIXI.Point(.5, .5), light.visible = !1, this.addChild(light), this._lights.push(light)
                }
                for (i = 0; 5 > i; ++i) {
                    switch (country) {
                        case CountryTypes.BRAZIL:
                            texture = Common.assets.getTexture("bz_race_lights_green");
                            break;
                        case CountryTypes.GERMANY:
                            texture = Common.assets.getTexture("de_race_lights_green");
                            break;
                        case CountryTypes.ITALY:
                            texture = Common.assets.getTexture("pc_race_lights_green");
                            break;
                        case CountryTypes.JAPAN:
                            texture = Common.assets.getTexture("tk_race_lights_green");
                            break;
                        case CountryTypes.TUTORIAL:
                        case CountryTypes.USA:
                            texture = Common.assets.getTexture("rs_race_lights_green")
                    }
                    light = new PIXI.Sprite(texture), light.x = 3 + (i * spacing - 4 * spacing * .5), light.y = 0, light.anchor = new PIXI.Point(.5, .5), light.visible = !1, this.addChild(light), this._lights.push(light)
                }
            }
            var Common = require("./Common"),
                CountryTypes = require("./CountryTypes");
            module.exports = StartingLights, StartingLights.prototype = Object.create(PIXI.Container.prototype), StartingLights.prototype.constructor = StartingLights, StartingLights.prototype.destroy = function() {
                for (var tween, i = 0; i < this._tweens.length; ++i) tween = this._tweens[i], tween.kill(), Common.animator.remove(tween);
                this._tweens.length = 0;
            }, StartingLights.prototype.animateIn = function(callback, scope) {
                var to = this.y;
                this.y = this.y - 140, this.alpha = 0, this._tweens.push(Common.animator.add(TweenMax.to(this, .4, {
                    y: to,
                    ease: Back.easeOut,
                    easeParams: [1],
                    onComplete: callback,
                    onCompleteScope: scope
                }))), this._tweens.push(Common.animator.add(TweenMax.to(this, .2, {
                    alpha: 1,
                    ease: Power1.easeInOut
                })))
            }, StartingLights.prototype.animateOut = function(callback, scope) {
                var to = this.y - 140;
                this._tweens.push(Common.animator.add(TweenMax.to(this, .2, {
                    delay: .6,
                    y: to,
                    ease: Back.easeIn,
                    onComplete: callback,
                    onCompleteScope: scope
                }))), this._tweens.push(Common.animator.add(TweenMax.to(this, .2, {
                    delay: .6,
                    alpha: 0,
                    ease: Power1.easeInOut
                })))
            }, StartingLights.prototype.start = function(delay, callback, scope) {
                function red() {
                    var light = this._lights[index];
                    light.alpha = 0, light.visible = !0, this._tweens.push(Common.animator.add(TweenMax.to(light, .04, {
                        delay: delay,
                        alpha: 1,
                        ease: Power2.easeInOut,
                        onComplete: function() {
                            if (++index < 5) red.call(this);
                            else {
                                var random = 1 + 2 * Math.random();
                                Common.animator.add(TweenMax.delayedCall(random, green, null, this))
                            }
                            Common.audio.playSound("sfx_race_lights_count_00")
                        },
                        onCompleteScope: this
                    })))
                }

                function green() {
                    Common.audio.playSound("sfx_race_lights_go_00");
                    for (var light, i = 5; i < this._lights.length; ++i) light = this._lights[i], light.alpha = 0, light.visible = !0, this._tweens.push(Common.animator.add(TweenMax.to(light, .04, {
                        alpha: 1,
                        ease: Power2.easeInOut
                    })));
                    callback && callback.call(scope)
                }
                var index = 0;
                red.call(this)
            }
        }, {
            "./Common": 23,
            "./CountryTypes": 27
        }],
        98: [function(require, module, exports) {
            function StockView(color, avatar) {
                CarView.call(this, color, avatar);
                var chassisOffset = new PIXI.Point(0, -2);
                this._shadow.offset = new PIXI.Point(0, 20), this._wheels.front.left.visible = !1, this._wheels.front.right.visible = !1, this._wheels.rear.left.offset = new PIXI.Point(-124, 78), this._wheels.rear.right.offset = new PIXI.Point(124, 78), this._front.offset = new PIXI.Point(chassisOffset.x, -4 + chassisOffset.y), this._mid.offset = new PIXI.Point(chassisOffset.x, chassisOffset.y), this._back.offset = new PIXI.Point(chassisOffset.x, chassisOffset.y)
            }
            var CarShader = require("./CarShader"),
                CarView = require("./CarView"),
                Common = require("./Common");
            module.exports = StockView, StockView.prototype = Object.create(CarView.prototype), StockView.prototype.constructor = StockView, StockView.prototype.update = function(distance, curvature, gradient, velocity, turnVelocity) {
                var scalar = 140;
                this._curvature += .4 * (turnVelocity + curvature - this._curvature), this._curvature = Math.max(-scalar, Math.min(scalar, this._curvature)), this._front.x = .3 * this._curvature + this._front.offset.x, this._front.y = -gradient * scalar * 1.6 + this._front.offset.y, this._mid.x = .1 * this._curvature + this._mid.offset.x, this._mid.y = -gradient * scalar * 1.3 + this._mid.offset.y, this._back.x = .2 * -this._curvature + this._back.offset.x, this._back.y = gradient * scalar + this._back.offset.y, this._shadow.x = this._back.x, this._shadow.y = this._wheels.rear.left.y + this._shadow.offset.y, this._front.rotation = 8e-4 * this._curvature, this._back.rotation = 8e-4 * this._curvature, this._wheels.front.left.x = this._front.x + this._wheels.front.left.offset.x, this._wheels.front.left.y = gradient * scalar + this._wheels.front.left.offset.y, this._wheels.front.right.x = this._front.x + this._wheels.front.right.offset.x, this._wheels.front.right.y = gradient * scalar + this._wheels.front.right.offset.y, this._wheels.rear.left.x = this._back.x + this._wheels.rear.left.offset.x, this._wheels.rear.left.y = gradient * scalar + this._wheels.rear.left.offset.y, this._wheels.rear.right.x = this._back.x + this._wheels.rear.right.offset.x, this._wheels.rear.right.y = gradient * scalar + this._wheels.rear.right.offset.y;
                var theta;
                theta = .008 * turnVelocity, 0 > theta && (theta *= .112), this._wheels.front.left.rotation = theta, theta = .008 * turnVelocity, theta > 0 && (theta *= .112), this._wheels.front.right.rotation = theta, theta = .008 * turnVelocity, 0 > theta && (theta *= .112), this._wheels.rear.left.rotation = theta, theta = .008 * turnVelocity, theta > 0 && (theta *= .112), this._wheels.rear.right.rotation = theta, velocity = Math.max(0, velocity), this._wheels.front.left.animationSpeed = velocity / .2, this._wheels.front.right.animationSpeed = velocity / .2, this._wheels.rear.left.animationSpeed = velocity / .2, this._wheels.rear.right.animationSpeed = velocity / .2
            }, StockView.prototype.createFrontLayer = function() {
                var bodyTexture = Common.assets.getTexture("car_01_body_00"),
                    maskTexture = Common.assets.getTexture("car_01_mask_00"),
                    shineTexture = Common.assets.getTexture("car_01_shine_00"),
                    maskOffset = new PIXI.Point(maskTexture._uvs.x0 - bodyTexture._uvs.x0, maskTexture._uvs.y0 - bodyTexture._uvs.y0),
                    shineOffset = new PIXI.Point(shineTexture._uvs.x0 - bodyTexture._uvs.x0, shineTexture._uvs.y0 - bodyTexture._uvs.y0),
                    front = new PIXI.Sprite(bodyTexture);
                front.shader = new CarShader(this._color, maskOffset, this._shininess, shineOffset);
                var decal = new PIXI.Sprite(this.getDecalTexture(0));
                return front.addChild(decal), new PIXI.Sprite(front.generateTexture(Common.renderer, 1, PIXI.SCALE_MODES.DEFAULT))
            }, StockView.prototype.createMidLayer = function() {
                var bodyTexture = Common.assets.getTexture("car_01_body_01"),
                    maskTexture = Common.assets.getTexture("car_01_mask_01"),
                    shineTexture = Common.assets.getTexture("car_01_shine_01"),
                    maskOffset = new PIXI.Point(maskTexture._uvs.x0 - bodyTexture._uvs.x0, maskTexture._uvs.y0 - bodyTexture._uvs.y0),
                    shineOffset = new PIXI.Point(shineTexture._uvs.x0 - bodyTexture._uvs.x0, shineTexture._uvs.y0 - bodyTexture._uvs.y0),
                    mid = new PIXI.Sprite(bodyTexture);
                mid.shader = new CarShader(this._color, maskOffset, this._shininess, shineOffset);
                var decal = new PIXI.Sprite(this.getDecalTexture(1));
                mid.addChild(decal);
                var kit = Common.garage.myCar.kit;
                if (0 == kit || 4 == kit) {
                    var topLights = new PIXI.Sprite(Common.assets.getTexture("car_01_specialkit_00"));
                    mid.addChild(topLights)
                }
                if (0 == kit) {
                    var spareTyre = new PIXI.Sprite(Common.assets.getTexture("car_01_specialkit_01"));
                    mid.addChild(spareTyre)
                }
                if (3 == kit) {
                    var neonLights = new PIXI.Sprite(Common.assets.getTexture("car_01_specialkit_02"));
                    mid.addChild(neonLights)
                }
                return new PIXI.Sprite(mid.generateTexture(Common.renderer, 1, PIXI.SCALE_MODES.DEFAULT))
            }, StockView.prototype.createBackLayer = function() {
                var bodyTexture = Common.assets.getTexture("car_01_body_02"),
                    maskTexture = Common.assets.getTexture("car_01_mask_02"),
                    shineTexture = Common.assets.getTexture("car_01_shine_02"),
                    maskOffset = new PIXI.Point(maskTexture._uvs.x0 - bodyTexture._uvs.x0, maskTexture._uvs.y0 - bodyTexture._uvs.y0),
                    shineOffset = new PIXI.Point(shineTexture._uvs.x0 - bodyTexture._uvs.x0, shineTexture._uvs.y0 - bodyTexture._uvs.y0),
                    back = new PIXI.Sprite(bodyTexture);
                back.shader = new CarShader(this._color, maskOffset, this._shininess, shineOffset);
                var decal = new PIXI.Sprite(this.getDecalTexture(2));
                back.addChild(decal);
                var name = Common.garage.name,
                    plate = new PIXI.Sprite(Common.garage.saveLicensePlate(name));
                plate.x = .5 * back.width, plate.y = 178, plate.scale = new PIXI.Point(.5, .5), plate.anchor.x = .5, back.addChild(plate);
                var spoiler = this.createSpoilerLayer();
                return spoiler.y = 5, back.addChild(spoiler), new PIXI.Sprite(back.generateTexture(Common.renderer, 1, PIXI.SCALE_MODES.DEFAULT))
            }, StockView.prototype.createSpoilerLayer = function() {
                var bodyTexture = Common.assets.getTexture("car_01_spoiler_02"),
                    maskTexture = Common.assets.getTexture("car_01_maskspoiler_02"),
                    maskOffset = new PIXI.Point(maskTexture._uvs.x0 - bodyTexture._uvs.x0, maskTexture._uvs.y0 - bodyTexture._uvs.y0),
                    spoiler = new PIXI.Sprite(bodyTexture);
                return spoiler.shader = new CarShader(this._color, maskOffset, 0), new PIXI.Sprite(spoiler.generateTexture(Common.renderer, 1, PIXI.SCALE_MODES.DEFAULT))
            }, StockView.prototype.createRearWheel = function() {
                var sequence = new p3.MovieClipSequence;
                return sequence.addTextures([Common.assets.getTexture("car_01_wheels_rear_0"), Common.assets.getTexture("car_01_wheels_rear_1"), Common.assets.getTexture("car_01_wheels_rear_2"), Common.assets.getTexture("car_01_wheels_rear_3")]), new p3.MovieClip(sequence)
            }, StockView.prototype.createShadow = function() {
                return new PIXI.Sprite(Common.assets.getTexture("car_01_shadow"))
            }
        }, {
            "./CarShader": 19,
            "./CarView": 21,
            "./Common": 23
        }],
        99: [function(require, module, exports) {
            function ThreatView(avatar) {
                CarView.call(this, 16777215, avatar);
                var chassisOffset = new PIXI.Point(0, -2);
                this._shadow.offset = new PIXI.Point(0, 26), this._wheels.front.left.offset = new PIXI.Point(-106, 50), this._wheels.front.right.offset = new PIXI.Point(108, 50), this._wheels.rear.left.offset = new PIXI.Point(-124, 78), this._wheels.rear.right.offset = new PIXI.Point(124, 78), this._front.offset = new PIXI.Point(chassisOffset.x, 10 + chassisOffset.y), this._mid.offset = new PIXI.Point(chassisOffset.x, 10 + chassisOffset.y), this._back.offset = new PIXI.Point(chassisOffset.x, 10 + chassisOffset.y)
            }
            var CarView = (require("./CarShader"), require("./CarView")),
                Common = require("./Common");
            module.exports = ThreatView, ThreatView.prototype = Object.create(CarView.prototype), ThreatView.prototype.constructor = ThreatView, ThreatView.prototype.update = function(distance, curvature, gradient, velocity, turnVelocity) {
                var scalar = 140;
                this._curvature += .4 * (turnVelocity + curvature - this._curvature), this._curvature = Math.max(-scalar, Math.min(scalar, this._curvature)), this._front.x = .4 * this._curvature + this._front.offset.x, this._front.y = -gradient * scalar * 1.6 + this._front.offset.y, this._mid.x = .1 * this._curvature + this._mid.offset.x, this._mid.y = -gradient * scalar * 1.3 + this._mid.offset.y, this._back.x = .14 * -this._curvature + this._back.offset.x, this._back.y = gradient * scalar + this._back.offset.y, this._shadow.x = this._back.x, this._shadow.y = this._wheels.rear.left.y + this._shadow.offset.y, this._front.rotation = 8e-4 * this._curvature, this._back.rotation = 8e-4 * this._curvature, this._wheels.front.left.x = this._front.x + this._wheels.front.left.offset.x, this._wheels.front.left.y = gradient * scalar + this._wheels.front.left.offset.y, this._wheels.front.right.x = this._front.x + this._wheels.front.right.offset.x, this._wheels.front.right.y = gradient * scalar + this._wheels.front.right.offset.y, this._wheels.rear.left.x = this._back.x + this._wheels.rear.left.offset.x, this._wheels.rear.left.y = gradient * scalar + this._wheels.rear.left.offset.y, this._wheels.rear.right.x = this._back.x + this._wheels.rear.right.offset.x, this._wheels.rear.right.y = gradient * scalar + this._wheels.rear.right.offset.y;
                var theta;
                theta = .008 * turnVelocity, 0 > theta && (theta *= .112), this._wheels.front.left.rotation = theta, theta = .008 * turnVelocity, theta > 0 && (theta *= .112), this._wheels.front.right.rotation = theta, theta = .008 * turnVelocity, 0 > theta && (theta *= .112), this._wheels.rear.left.rotation = theta, theta = .008 * turnVelocity, theta > 0 && (theta *= .112), this._wheels.rear.right.rotation = theta, velocity = Math.max(0, velocity), this._wheels.front.left.animationSpeed = velocity / .2, this._wheels.front.right.animationSpeed = velocity / .2, this._wheels.rear.left.animationSpeed = velocity / .2, this._wheels.rear.right.animationSpeed = velocity / .2
            }, ThreatView.prototype.createFrontLayer = function() {
                return new PIXI.Sprite(Common.assets.getTexture("car_threat_body_00"))
            }, ThreatView.prototype.createMidLayer = function() {
                return new PIXI.Sprite(Common.assets.getTexture("car_threat_body_01"))
            }, ThreatView.prototype.createBackLayer = function() {
                var back = new PIXI.Sprite(Common.assets.getTexture("car_threat_body_02")),
                    spoiler = this.createSpoilerLayer();
                return spoiler.y = 20, back.addChild(spoiler), back
            }, ThreatView.prototype.createSpoilerLayer = function() {
                var spoiler = new PIXI.Sprite(Common.assets.getTexture("car_threat_spoiler_02"));
                return spoiler.anchor = new PIXI.Point(.5, 1), spoiler
            }, ThreatView.prototype.createFrontWheel = function() {
                var sequence = new p3.MovieClipSequence;
                return sequence.addTextures([Common.assets.getTexture("car_threat_wheels_front_0"), Common.assets.getTexture("car_threat_wheels_front_1"), Common.assets.getTexture("car_threat_wheels_front_2"), Common.assets.getTexture("car_threat_wheels_front_3")]), new p3.MovieClip(sequence)
            }, ThreatView.prototype.createRearWheel = function() {
                var sequence = new p3.MovieClipSequence;
                return sequence.addTextures([Common.assets.getTexture("car_threat_wheels_rear_0"), Common.assets.getTexture("car_threat_wheels_rear_1"), Common.assets.getTexture("car_threat_wheels_rear_2"), Common.assets.getTexture("car_threat_wheels_rear_3")]), new p3.MovieClip(sequence)
            }, ThreatView.prototype.createShadow = function() {
                return new PIXI.Sprite(Common.assets.getTexture("car_threat_shadow"))
            }
        }, {
            "./CarShader": 19,
            "./CarView": 21,
            "./Common": 23
        }],
        100: [function(require, module, exports) {
            function TodorokiView(avatar) {
                CarView.call(this, 16777215, avatar);
                var chassisOffset = new PIXI.Point(0, -2);
                this._shadow.offset = new PIXI.Point(0, 26), this._wheels.front.left.offset = new PIXI.Point(-104, 24), this._wheels.front.right.offset = new PIXI.Point(104, 24), this._wheels.rear.left.offset = new PIXI.Point(-124, 78), this._wheels.rear.right.offset = new PIXI.Point(124, 78), this._front.offset = new PIXI.Point(chassisOffset.x, -4 + chassisOffset.y), this._mid.offset = new PIXI.Point(chassisOffset.x, chassisOffset.y), this._back.offset = new PIXI.Point(chassisOffset.x, chassisOffset.y)
            }
            var CarView = (require("./CarShader"), require("./CarView")),
                Common = require("./Common");
            module.exports = TodorokiView, TodorokiView.prototype = Object.create(CarView.prototype), TodorokiView.prototype.constructor = TodorokiView, TodorokiView.prototype.update = function(distance, curvature, gradient, velocity, turnVelocity) {
                var scalar = 140;
                this._curvature += .4 * (turnVelocity + curvature - this._curvature), this._curvature = Math.max(-scalar, Math.min(scalar, this._curvature)), this._front.x = .4 * this._curvature + this._front.offset.x, this._front.y = -gradient * scalar * 1.6 + this._front.offset.y, this._mid.x = .1 * this._curvature + this._mid.offset.x, this._mid.y = -gradient * scalar * 1.3 + this._mid.offset.y, this._back.x = .14 * -this._curvature + this._back.offset.x, this._back.y = gradient * scalar + this._back.offset.y, this._shadow.x = this._back.x, this._shadow.y = this._wheels.rear.left.y + this._shadow.offset.y, this._front.rotation = 8e-4 * this._curvature, this._back.rotation = 8e-4 * this._curvature, this._wheels.front.left.x = this._front.x + this._wheels.front.left.offset.x, this._wheels.front.left.y = gradient * scalar + this._wheels.front.left.offset.y, this._wheels.front.right.x = this._front.x + this._wheels.front.right.offset.x, this._wheels.front.right.y = gradient * scalar + this._wheels.front.right.offset.y, this._wheels.rear.left.x = this._back.x + this._wheels.rear.left.offset.x, this._wheels.rear.left.y = gradient * scalar + this._wheels.rear.left.offset.y, this._wheels.rear.right.x = this._back.x + this._wheels.rear.right.offset.x, this._wheels.rear.right.y = gradient * scalar + this._wheels.rear.right.offset.y;
                var theta;
                theta = .008 * turnVelocity, 0 > theta && (theta *= .112), this._wheels.front.left.rotation = theta, theta = .008 * turnVelocity, theta > 0 && (theta *= .112), this._wheels.front.right.rotation = theta, theta = .008 * turnVelocity, 0 > theta && (theta *= .112), this._wheels.rear.left.rotation = theta, theta = .008 * turnVelocity, theta > 0 && (theta *= .112), this._wheels.rear.right.rotation = theta, velocity = Math.max(0, velocity), this._wheels.front.left.animationSpeed = velocity / .2, this._wheels.front.right.animationSpeed = velocity / .2, this._wheels.rear.left.animationSpeed = velocity / .2, this._wheels.rear.right.animationSpeed = velocity / .2
            }, TodorokiView.prototype.createFrontLayer = function() {
                return new PIXI.Sprite(Common.assets.getTexture("car_todoroki_body_00"))
            }, TodorokiView.prototype.createMidLayer = function() {
                return new PIXI.Sprite(Common.assets.getTexture("car_todoroki_body_01"))
            }, TodorokiView.prototype.createBackLayer = function() {
                var back = new PIXI.Sprite(Common.assets.getTexture("car_todoroki_body_02")),
                    spoiler = this.createSpoilerLayer();
                return spoiler.y = 20, back.addChild(spoiler), back
            }, TodorokiView.prototype.createSpoilerLayer = function() {
                var spoiler = new PIXI.Sprite(Common.assets.getTexture("car_todoroki_spoiler_02"));
                return spoiler.anchor = new PIXI.Point(.5, 1), spoiler
            }, TodorokiView.prototype.createFrontWheel = function() {
                var sequence = new p3.MovieClipSequence;
                return sequence.addTextures([Common.assets.getTexture("car_todoroki_wheels_front_0"), Common.assets.getTexture("car_todoroki_wheels_front_1"), Common.assets.getTexture("car_todoroki_wheels_front_2"), Common.assets.getTexture("car_todoroki_wheels_front_3")]), new p3.MovieClip(sequence)
            }, TodorokiView.prototype.createRearWheel = function() {
                var sequence = new p3.MovieClipSequence;
                return sequence.addTextures([Common.assets.getTexture("car_todoroki_wheels_rear_0"), Common.assets.getTexture("car_todoroki_wheels_rear_1"), Common.assets.getTexture("car_todoroki_wheels_rear_2"), Common.assets.getTexture("car_todoroki_wheels_rear_3")]), new p3.MovieClip(sequence)
            }, TodorokiView.prototype.createShadow = function() {
                return new PIXI.Sprite(Common.assets.getTexture("car_todoroki_shadow"))
            }
        }, {
            "./CarShader": 19,
            "./CarView": 21,
            "./Common": 23
        }],
        101: [function(require, module, exports) {
            function TrackData(id, country, name, countryName, difficulty) {
                this.id = id, this.country = country, this.name = name, this.countryName = countryName, this.difficulty = difficulty, this.reward = TrackData.REWARD_NONE, this.time = 0, this.races = 0, this.animate = !1, this.requiredTracks = []
            }
            require("./Common");
            module.exports = TrackData, TrackData.DIFFICULTY_EASY = 0, TrackData.DIFFICULTY_INTERMEDIATE = 1, TrackData.DIFFICULTY_HARD = 2, TrackData.REWARD_NONE = -1, TrackData.REWARD_GOLD = 0, TrackData.REWARD_SILVER = 1, TrackData.REWARD_BRONZE = 2, Object.defineProperty(TrackData.prototype, "trackName", {
                get: function() {
                    return this.country + (this.id % 4 + 1)
                }
            }), Object.defineProperty(TrackData.prototype, "unlocked", {
                get: function() {
                    for (var track, unlocked = !0, i = 0; i < this.requiredTracks.length; ++i)
                        if (track = this.requiredTracks[i], 0 == track.races) {
                            unlocked = !1;
                            break
                        }
                    return unlocked
                }
            })
        }, {
            "./Common": 23
        }],
        102: [function(require, module, exports) {
            function TrackLoaderScene() {
                this.loaded = 0, this._loadingText = null, this._loadedSmooth = 0, this._loadingWheel = null, this._velocity = 0, this._rotationSpeed = 6, this._rotationDrag = .98, Scene.call(this)
            }
            var Common = require("./Common"),
                Scene = require("./Scene");
            module.exports = TrackLoaderScene, TrackLoaderScene.prototype = Object.create(Scene.prototype), TrackLoaderScene.prototype.constructor = TrackLoaderScene, TrackLoaderScene.prototype.init = function() {
                var bg = new PIXI.Sprite(Common.assets.getTexture("ui_bg_main_menu"));
                this.addChild(bg), this._loadingWheel = new PIXI.Sprite(Common.assets.getTexture("ui_coin_wheel")), this._loadingWheel.x = .5 * Common.STAGE_WIDTH, this._loadingWheel.y = .5 * Common.STAGE_HEIGHT, this._loadingWheel.anchor = new PIXI.Point(.5, .5), this._loadingWheel.visible = !1, this.addChild(this._loadingWheel);
                var text = new PIXI.Sprite(Common.assets.getTexture("loading_wheel_text"));
                text.anchor = new PIXI.Point(.5, .5), this._loadingWheel.addChild(text), webfont ? (this._loadingText = new PIXI.Text(Common.copy.loading[Common.language], {
                    font: "34px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._loadingText.x = .5 * (Common.STAGE_WIDTH - this._loadingText.width), this._loadingText.y = 680, this.addChild(this._loadingText)) : (this._loadingText = new PIXI.extras.BitmapText(Common.copy.loading[Common.language], {
                    font: "34px Great Escape",
                    align: "center"
                }), this._loadingText.x = .5 * (Common.STAGE_WIDTH - this._loadingText.textWidth), this._loadingText.y = 680, this.addChild(this._loadingText))
            }, TrackLoaderScene.prototype.dispose = function() {
                Common.animator.removeAll(), Scene.prototype.dispose.call(this)
            }, TrackLoaderScene.prototype.appear = function() {
                this.animateIn()
            }, TrackLoaderScene.prototype.show = function() {}, TrackLoaderScene.prototype.animateIn = function(callback, scope) {
                this._loadingWheel.scale = new PIXI.Point, this._loadingWheel.visible = !0, TweenMax.to(this._loadingWheel.scale, .4, {
                    delay: .2,
                    x: 1,
                    y: 1,
                    ease: Back.easeOut,
                    easeParams: [3]
                })
            }, TrackLoaderScene.prototype.animateOut = function(callback, scope) {}, TrackLoaderScene.prototype.resize = function() {
                this.x = .5 * (p3.View.width - Common.STAGE_WIDTH)
            }, TrackLoaderScene.prototype.update = function() {
                this._loadedSmooth += .2 * (this.loaded - this._loadedSmooth), this._velocity += this._rotationSpeed * PIXI.DEG_TO_RAD * p3.Timestep.deltaTime, this._velocity *= this._rotationDrag, this._loadingWheel.rotation += this._velocity;
                var dot = Math.floor(.005 * window.performance.now()) % 4;
                this._loadingText.text = Common.copy.loading[Common.language];
                for (var i = 0; dot > i; ++i) this._loadingText.text = this._loadingText.text + "."
            }
        }, {
            "./Common": 23,
            "./Scene": 83
        }],
        103: [function(require, module, exports) {
            function TrackManager() {
                this._currentTrack = null, this._currentSeries = null, this._tracks = [], this._series = [], this._loadedTrackAssets = {}, this._loadedTrackAssets.brazil = null, this._loadedTrackAssets.germany = null, this._loadedTrackAssets.italy = null, this._loadedTrackAssets.japan = null, this._loadedTrackAssets.usa = null
            }
            var AchievementTypes = require("./AchievementTypes"),
                Common = require("./Common"),
                TrackData = (require("./TrackSeriesData"), require("./TrackData"));
            module.exports = TrackManager, TrackManager.prototype.registerTrack = function(data, requiredTrackIds) {
                for (var track, i = 0; i < requiredTrackIds.length; ++i) track = this.getTrack(requiredTrackIds[i]), data.requiredTracks.push(track);
                this._tracks.push(data)
            }, TrackManager.prototype.registerSeries = function(data, requiredSeriesIds, requiredTrackIds) {
                var series, track, i;
                for (i = 0; i < requiredSeriesIds.length; ++i) series = this.getSeries(requiredSeriesIds[i]), data.requiredSeries.push(series);
                for (i = 0; i < requiredTrackIds.length; ++i) track = this.getTrack(requiredTrackIds[i]), data.requiredTracks.push(track);
                this._series.push(data)
            }, TrackManager.prototype.save = function() {
                var data = {};
                data.tracks = [], data.series = [];
                var track, trackData, series, seriesData, i;
                for (i = 0; i < this._tracks.length; ++i) track = this._tracks[i], trackData = {}, trackData.id = track.id, trackData.reward = track.reward, trackData.time = track.time, trackData.races = track.races, trackData.animate = track.animate, data.tracks.push(trackData);
                for (i = 0; i < this._series.length; ++i) series = this._series[i], seriesData = {}, seriesData.id = series.id, seriesData.reward = series.reward, seriesData.track = series.currentTrack, seriesData.rewards = series.rewards.slice(), seriesData.results = series.results.slice(), seriesData.animate = series.lastTrack, data.series.push(seriesData);
                return data
            }, TrackManager.prototype.load = function(data) {
                var track, trackData, series, seriesData, i;
                for (i = 0; i < this._tracks.length; ++i) trackData = data.tracks[i], track = this.getTrack(trackData.id), track.reward = trackData.reward, track.time = trackData.time, track.races = trackData.races, track.lastTrack = trackData.lastTrack || -1;
                for (i = 0; i < this._series.length; ++i) seriesData = data.series[i], series = this.getSeries(seriesData.id), series.reward = seriesData.reward, series.currentTrack = seriesData.track, series.rewards = seriesData.rewards.slice(), series.results = seriesData.results.slice(), series.lastTrack = seriesData.lastTrack || -1
            }, TrackManager.prototype.loadTrackAssets = function(theme, progress, complete, scope) {
                var loader = Common.assets,
                    prefix = "hd/";
                if ("tutorial" == theme && (theme = "usa"), this._loadedTrackAssets[theme]) complete.call(scope);
                else {
                    this._loadedTrackAssets[theme] = !0;
                    var files, sounds;
                    switch (theme) {
                        case "brazil":
                            files = [{
                                name: "environment_bg_bz",
                                url: "images/" + prefix + "environment_bg_bz.json"
                            }, {
                                name: "environment_bz",
                                url: "images/" + prefix + "environment_bz.json"
                            }, {
                                name: "bz_bg_sky_gradient",
                                url: "images/" + prefix + "bz_bg_sky_gradient.png"
                            }, {
                                name: "brazil1",
                                url: "data/brazil1.json"
                            }, {
                                name: "brazil2",
                                url: "data/brazil2.json"
                            }, {
                                name: "brazil3",
                                url: "data/brazil3.json"
                            }, {
                                name: "brazil4",
                                url: "data/brazil4.json"
                            }], sounds = ["music_brazil_intro_sting_00", "music_brazil_raceloop_00", "sfx_ambience_brazil_00"];
                            break;
                        case "germany":
                            files = [{
                                name: "environment_bg_de",
                                url: "images/" + prefix + "environment_bg_de.json"
                            }, {
                                name: "environment_de",
                                url: "images/" + prefix + "environment_de.json"
                            }, {
                                name: "de_bg_sky_gradient",
                                url: "images/" + prefix + "de_bg_sky_gradient.png"
                            }, {
                                name: "germany1",
                                url: "data/germany1.json"
                            }, {
                                name: "germany2",
                                url: "data/germany2.json"
                            }, {
                                name: "germany3",
                                url: "data/germany3.json"
                            }, {
                                name: "germany4",
                                url: "data/germany4.json"
                            }], sounds = ["music_germany_intro_sting_00", "music_germany_raceloop_00", "sfx_ambience_germany_00"];
                            break;
                        case "italy":
                            files = [{
                                name: "environment_bg_pc",
                                url: "images/" + prefix + "environment_bg_pc.json"
                            }, {
                                name: "environment_pc",
                                url: "images/" + prefix + "environment_pc.json"
                            }, {
                                name: "pc_bg_sky_gradient",
                                url: "images/" + prefix + "pc_bg_sky_gradient.png"
                            }, {
                                name: "italy1",
                                url: "data/italy1.json"
                            }, {
                                name: "italy2",
                                url: "data/italy2.json"
                            }, {
                                name: "italy3",
                                url: "data/italy3.json"
                            }, {
                                name: "italy4",
                                url: "data/italy4.json"
                            }], sounds = ["music_italy_intro_sting_00", "music_italy_raceloop_00", "sfx_ambience_italy_00"];
                            break;
                        case "japan":
                            files = [{
                                name: "environment_bg_tk",
                                url: "images/" + prefix + "environment_bg_tk.json"
                            }, {
                                name: "environment_tk",
                                url: "images/" + prefix + "environment_tk.json"
                            }, {
                                name: "tk_bg_sky_gradient",
                                url: "images/" + prefix + "tk_bg_sky_gradient.png"
                            }, {
                                name: "japan1",
                                url: "data/japan1.json"
                            }, {
                                name: "japan2",
                                url: "data/japan2.json"
                            }, {
                                name: "japan3",
                                url: "data/japan3.json"
                            }, {
                                name: "japan4",
                                url: "data/japan4.json"
                            }], sounds = ["music_japan_intro_sting_00", "music_japan_raceloop_00", "sfx_ambience_tokyo_00"];
                            break;
                        case "usa":
                            files = [{
                                name: "environment_bg_rs",
                                url: "images/" + prefix + "environment_bg_rs2.json"
                            }, {
                                name: "environment_rs",
                                url: "images/" + prefix + "environment_rs2.json"
                            }, {
                                name: "rs_bg_sky_gradient",
                                url: "images/" + prefix + "rs_bg_sky_gradient.png"
                            }, {
                                name: "usa1",
                                url: "data/usa1.json"
                            }, {
                                name: "usa2",
                                url: "data/usa2.json"
                            }, {
                                name: "usa3",
                                url: "data/usa3.json"
                            }, {
                                name: "usa4",
                                url: "data/usa4.json"
                            }], sounds = ["music_usa_intro_sting_00", "music_usa_raceloop_00", "sfx_ambience_usa_desert_00"]
                    }
                    loader.addFiles(files, "assets/"), loader.signalProgress.add(progress, scope), loader.signalCompleted.add(function() {
                        loader.signalProgress.removeAll(), loader.signalCompleted.removeAll(), complete.call(scope)
                    }, scope), loader.load(), Common.audio.addSounds(sounds, [".mp3", ".ogg"], "assets/audio/")
                }
            }, TrackManager.prototype.completeTrack = function(position, isTutorial) {
                var series = this._currentSeries,
                    track = this._currentTrack;
                if (++track.races, series) {
                    this.currentTrack == track && (series.animate = position > series.rewards[series.currentTrack], series.rewards[series.currentTrack++] = position);
                    var finished = series.isFinished;
                    if (finished) {
                        for (var points = 0, i = 0; i < series.rewards.length; ++i) points += Math.max(0, 3 - series.rewards[i]);
                        points >= 4 && 5 >= points ? series.reward = TrackData.REWARD_BRONZE : points >= 6 && 8 >= points ? series.reward = TrackData.REWARD_SILVER : points >= 9 && (series.reward = TrackData.REWARD_GOLD)
                    }
                } else track.animate = position > track.reward, position <= TrackData.REWARD_BRONZE && (track.reward = position);
                return ++Common.garage.races, isTutorial || this.checkAchievements(), series && series.isFinished && series.reset(), Common.saveData.save(), finished
            }, TrackManager.prototype.selectTrack = function(id) {
                this._currentSeries = null, this._currentTrack = this.getTrack(id);
                var garage = Common.garage;
                garage.track = id, Common.saveData.save()
            }, TrackManager.prototype.selectSeries = function(id) {
                var garage = Common.garage;
                garage.series = id;
                var series = this.getSeries(id);
                this._currentSeries = series, this._currentTrack = this.getTrack(series.tracks[series.currentTrack]), Common.saveData.save()
            }, TrackManager.prototype.checkAchievements = function() {
                var track, tracks, series, i;
                Common.garage.races > 0 && Common.achievements.award(AchievementTypes.COMPLETE_FIRST_RACE), track = this.currentTrack, track.reward == TrackData.REWARD_GOLD && Common.achievements.award(AchievementTypes.WIN_FIRST_RACE), series = this.currentSeries, series && 0 == series.id && series.isFinished && Common.achievements.award(AchievementTypes.WIN_BEGINNER_SERIES), series && 1 == series.id && series.isFinished && Common.achievements.award(AchievementTypes.WIN_WORLD_SERIES), series && 2 == series.id && series.isFinished && Common.achievements.award(AchievementTypes.WIN_ADVANCED_WORLD_SERIES), series && 3 == series.id && series.isFinished && Common.achievements.award(AchievementTypes.WIN_ITALY_SERIES), series && 4 == series.id && series.isFinished && Common.achievements.award(AchievementTypes.WIN_GERMANY_SERIES), series && 5 == series.id && series.isFinished && Common.achievements.award(AchievementTypes.WIN_JAPAN_SERIES), series && 6 == series.id && series.isFinished && Common.achievements.award(AchievementTypes.WIN_BRAZIL_SERIES), series && 7 == series.id && series.isFinished && Common.achievements.award(AchievementTypes.WIN_ADVANCED_WORLD_SERIES), track = this.currentTrack, tracks = this.getTracks(track.country);
                var t, count = 0;
                for (i = 0; i < tracks.length; ++i) t = tracks[i], t.reward == TrackData.REWARD_GOLD && ++count;
                for (count == tracks.length && Common.achievements.award(AchievementTypes.WIN_ALL_RACES_ONE_LOCATION), count = 0, i = 0; i < this._tracks.length; ++i) t = this._tracks[i], t.reward == TrackData.REWARD_GOLD && ++count;
                for (count == this._tracks.length && Common.achievements.award(AchievementTypes.WIN_ALL_RACES_ALL_COUNTRIES), count = 0, i = 0; i < this._tracks.length; ++i) t = this._tracks[i], t.races > 0 && ++count;
                count == this._tracks.length && Common.achievements.award(AchievementTypes.RACE_ALL_TRACKS);
                var car = Common.garage.myCar,
                    types = Common.garage.carTypes; - 1 == types.indexOf(car.id) && (types.push(car.id), types.length >= 5 && Common.achievements.award(AchievementTypes.RACE_ONCE_WITH_ALL_CARS)), series = this.currentSeries, types = Common.garage.carTypesSeries, series && series.reward != TrackData.REWARD_NONE && -1 == types.indexOf(car.id) && (types.push(car.id), types.length >= 5 && Common.achievements.award(AchievementTypes.RACE_ONCE_WITH_ALL_CARS))
            }, TrackManager.prototype.getTrack = function(id) {
                for (var track, i = 0; i < this._tracks.length; ++i)
                    if (track = this._tracks[i], track.id == id) return track;
                return null
            }, TrackManager.prototype.getSeries = function(id) {
                for (var series, i = 0; i < this._series.length; ++i)
                    if (series = this._series[i], series.id == id) return series;
                return null
            }, TrackManager.prototype.getTracks = function(country) {
                for (var track, arr = [], i = 0; i < this._tracks.length; ++i) track = this._tracks[i], track.country == country && arr.push(track);
                return arr
            }, Object.defineProperty(TrackManager.prototype, "countries", {
                get: function() {
                    for (var track, arr = [], i = 0; i < this._tracks.length; ++i) track = this._tracks[i], "tutorial" != track.country && -1 == arr.indexOf(track.country) && arr.push(track.country);
                    return arr
                }
            }), Object.defineProperty(TrackManager.prototype, "currentTrack", {
                get: function() {
                    return this._currentTrack
                }
            }), Object.defineProperty(TrackManager.prototype, "currentSeries", {
                get: function() {
                    return this._currentSeries
                }
            }), Object.defineProperty(TrackManager.prototype, "isSeries", {
                get: function() {
                    return null != this._currentSeries
                }
            }), Object.defineProperty(TrackManager.prototype, "allTracks", {
                get: function() {
                    return this._tracks.slice(0)
                }
            }), Object.defineProperty(TrackManager.prototype, "allSeries", {
                get: function() {
                    return this._series.slice(0)
                }
            })
        }, {
            "./AchievementTypes": 4,
            "./Common": 23,
            "./TrackData": 101,
            "./TrackSeriesData": 104
        }],
        104: [function(require, module, exports) {
            function TrackSeriesData(id, type, name, difficulty, tracks) {
                this.id = id, this.type = type, this.name = name, this.reward = TrackData.REWARD_NONE, this.difficulty = difficulty, this.tracks = tracks, this.requiredSeries = [], this.requiredTracks = [], this.currentTrack = 0, this.animate = !1, this.rewards = [], this.results = [];
                var i;
                for (i = 0; i < this.tracks.length; ++i) this.rewards.push(TrackData.REWARD_NONE)
            }
            var TrackData = (require("./Common"), require("./TrackData"));
            module.exports = TrackSeriesData, TrackSeriesData.prototype.reset = function() {
                this.currentTrack = 0;
                for (var i = 0; i < this.tracks.length; ++i) this.rewards[i] = TrackData.REWARD_NONE
            }, Object.defineProperty(TrackSeriesData.prototype, "isFinished", {
                get: function() {
                    for (var reward, count = 0, i = 0; i < this.rewards.length; ++i) reward = this.rewards[i], reward > TrackData.REWARD_NONE && ++count;
                    return count == this.rewards.length
                }
            }), Object.defineProperty(TrackSeriesData.prototype, "unlocked", {
                get: function() {
                    var series, track, i, unlocked = !0;
                    for (i = 0; i < this.requiredSeries.length; ++i)
                        if (series = this.requiredSeries[i], series.reward == TrackData.REWARD_NONE) {
                            unlocked = !1;
                            break
                        }
                    for (i = 0; i < this.requiredTracks.length; ++i)
                        if (track = this.requiredTracks[i], track.reward == TrackData.REWARD_NONE) {
                            unlocked = !1;
                            break
                        }
                    return unlocked
                }
            })
        }, {
            "./Common": 23,
            "./TrackData": 101
        }],
        105: [function(require, module, exports) {
            function Transition() {
                this.signals = {}, this.signals["in"] = new signals.Signal, this.signals.out = new signals.Signal, this.push = !1, this.replace = !0, this.wait = !0, this.requiresWebGL = !1, PIXI.Container.call(this)
            }
            module.exports = Transition, Transition.prototype = Object.create(PIXI.Container.prototype), Transition.prototype.constructor = Transition, Transition.prototype.init = function() {}, Transition.prototype.dispose = function() {
                this.signals["in"].dispose(), this.signals.out.dispose(), this.removeChildren()
            }, Transition.prototype["in"] = function() {
                this.signals["in"].dispatch(this)
            }, Transition.prototype.out = function() {
                this.signals.out.dispatch(this)
            }, Transition.prototype.resize = function() {}, Transition.prototype.fallback = function() {};
        }, {}],
        106: [function(require, module, exports) {
            function TrophyScene() {
                Scene.call(this), this.signals.back = new signals.Signal, this.signals.settings = new signals.Signal, this.signals.achievements = new signals.Signal, this._header = null, this._titleText = null, this._helpButton = null, this._backButton = null, this._settingsButton = null, this._achievementsButton = null, this._scroller = null, this._scrollView = null
            }
            var Common = require("./Common"),
                Scene = require("./Scene"),
                Scroller = require("./Scroller"),
                ScrollView = require("./ScrollView"),
                TrackData = require("./TrackData");
            module.exports = TrophyScene, TrophyScene.prototype = Object.create(Scene.prototype), TrophyScene.prototype.constructor = TrophyScene, TrophyScene.prototype.init = function() {
                var bg = new PIXI.Sprite(Common.assets.getTexture("ui_bg_main_menu"));
                this.addChild(bg), this._header = new PIXI.Sprite(Common.assets.getTexture("ui_top_bar")), this._header.x = .5 * Common.STAGE_WIDTH, this._header.y = 120, this._header.anchor = new PIXI.Point(.5, .5), this.addChild(this._header), webfont ? (this._titleText = new PIXI.Text(Common.copy.trophies[Common.language], {
                    font: "48px Arial",
                    fill: "#FFFFFF",
                    align: "center"
                }), this._titleText.x = .5 * (Common.STAGE_WIDTH - this._titleText.width), this._titleText.y = 96, this.addChild(this._titleText)) : (this._titleText = new PIXI.extras.BitmapText(Common.copy.trophies[Common.language], {
                    font: "48px Great Escape",
                    align: "center"
                }), this._titleText.x = .5 * (Common.STAGE_WIDTH - this._titleText.textWidth), this._titleText.y = 86, this.addChild(this._titleText)), this._backButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_back")), this._backButton.y = 120, this._backButton.animate = !0, this._backButton.overSoundName = "sfx_ui_btn_rollover_00", this._backButton.downSoundName = "sfx_ui_btn_press_00", this._backButton.signals.click.add(this.onBackButtonClick, this), this.addChild(this._backButton), this._helpButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_help")), this._helpButton.animate = !0, this._helpButton.overSoundName = "sfx_ui_btn_rollover_00", this._helpButton.downSoundName = "sfx_ui_btn_press_00", this._helpButton.signals.click.add(this.onHelpButtonClick, this), this.addChild(this._helpButton), this._settingsButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_settings")), this._settingsButton.y = 120, this._settingsButton.animate = !0, this._settingsButton.overSoundName = "sfx_ui_btn_rollover_00", this._settingsButton.downSoundName = "sfx_ui_btn_press_00", this._settingsButton.signals.click.add(this.onSettingsButtonClick, this), this.addChild(this._settingsButton), this._achievementsButton = new p3.Button(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_achievements")), this._achievementsButton.y = 120, this._achievementsButton.animate = !0, this._achievementsButton.overSoundName = "sfx_ui_btn_rollover_00", this._achievementsButton.downSoundName = "sfx_ui_btn_press_00", this._achievementsButton.signals.click.add(this.onAchievementsButtonClick, this), this.addChild(this._achievementsButton), this._scrollView = new ScrollView(800, 602, 0, 660), this._scrollView.x = .5 * Common.STAGE_WIDTH - 400, this._scrollView.y = .5 * Common.STAGE_HEIGHT - 218, this._scrollView.signals.scroll.add(this.onScrollViewScroll, this), this.addChild(this._scrollView), this._scroller = new Scroller(1), this._scroller.x = .5 * Common.STAGE_WIDTH + 380, this._scroller.y = .5 * (Common.STAGE_HEIGHT - this._scroller.height) + 80, this._scroller.visible = !p3.Device.isMobile, this._scroller.signals.scroll.add(this.onScrollerScroll, this), this.addChild(this._scroller), this.load(), Common.input.signals.mouseUp.add(this.onStageMouseUp, this), Common.tracking.track(new p3.TrackingDataPlaydomGameAction("garage", "view_trophies"))
            }, TrophyScene.prototype.dispose = function() {
                Common.animator.removeAll(), Common.input.signals.mouseUp.remove(this.onStageMouseUp), Scene.prototype.dispose.call(this)
            }, TrophyScene.prototype.appear = function() {
                this.animateIn()
            }, TrophyScene.prototype.show = function() {}, TrophyScene.prototype.animateIn = function(callback, scope) {}, TrophyScene.prototype.animateOut = function(callback, scope) {}, TrophyScene.prototype.resize = function() {
                this.x = .5 * (p3.View.width - Common.STAGE_WIDTH), this._header.width = p3.View.width, this._settingsButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width - this._settingsButton.width) - 28, this._helpButton.x = this._settingsButton.x - 112, this._helpButton.y = this._settingsButton.y, this._backButton.x = .5 * (Common.STAGE_WIDTH - p3.View.width + this._backButton.width) + 28, this._achievementsButton.x = this._backButton.x + 112
            }, TrophyScene.prototype.update = function() {
                this._scrollView.update()
            }, TrophyScene.prototype.load = function() {
                var track, medal, award, data, i, texture, trackManager = Common.trackManager,
                    medals = [0, 0, 0];
                for (i = 0; i < trackManager.allTracks.length; ++i) track = trackManager.allTracks[i], track.reward != TrackData.REWARD_NONE && ++medals[track.reward];
                var spacing = 248;
                for (i = 0; 3 > i; ++i) {
                    switch (medal = new PIXI.Sprite(Common.assets.getTexture("ui_medal_bg")), medal.x = i * spacing + .5 * this._scrollView.frameWidth - spacing, medal.y = 132, medal.anchor = new PIXI.Point(.5, .5), this._scrollView.content.addChild(medal), i) {
                        case 0:
                            texture = Common.assets.getTexture("ui_trophies_star_gold");
                            break;
                        case 1:
                            texture = Common.assets.getTexture("ui_trophies_star_silver");
                            break;
                        case 2:
                            texture = Common.assets.getTexture("ui_trophies_star_bronze")
                    }
                    medal.icon = new PIXI.Sprite(texture), medal.icon.x = -40, medal.icon.y = -2, medal.icon.anchor = new PIXI.Point(.5, .5), medal.addChild(medal.icon), medal.name = new PIXI.extras.BitmapText(medals[i].toString(), {
                        font: "64px Great Escape XL",
                        align: "right"
                    }), medal.name.x = .5 * -medal.name.textWidth + 32, medal.name.y = .5 * -medal.name.textHeight - 2, medal.addChild(medal.name)
                }
                spacing = 120;
                var name, arr = ["gold", "silver", "bronze"];
                for (i = 0; i < Common.trackManager.allSeries.length; ++i) data = Common.trackManager.allSeries[i], award = new PIXI.Sprite(Common.assets.getTexture("ui_trophies_bar")), award.x = .5 * this._scrollView.frameWidth, award.y = 300 + i * spacing, award.anchor = new PIXI.Point(.5, .5), this._scrollView.content.addChild(award), webfont ? (award.name = new PIXI.Text(data.name, {
                    font: "44px Arial",
                    fill: "#FFFFFF",
                    align: "right"
                }), award.name.x = r2l ? .5 * award.texture.width - award.name.width - 40 : .5 * -award.width + 40, award.name.y = .5 * -award.name.height, award.addChild(award.name)) : (award.name = new PIXI.extras.BitmapText(data.name, {
                    font: "44px Great Escape",
                    align: "right"
                }), award.name.x = r2l ? .5 * award.texture.width - award.name.textWidth - 40 : .5 * -award.width + 40, award.name.y = .5 * -award.name.textHeight - 4, award.addChild(award.name)), name = data.type.toLowerCase(), texture = data.reward > -1 ? Common.assets.getTexture("ui_trophy_" + arr[data.reward]) : Common.assets.getTexture("ui_trophies_slot"), award.image = new PIXI.Sprite(texture), award.image.x = r2l ? .5 * -award.texture.width + 80 : .5 * award.texture.width - 80, award.image.anchor = new PIXI.Point(.5, .5), award.addChild(award.image), texture = data.reward > -1 ? Common.assets.getTexture("ui_trophy_" + name + "_" + arr[data.reward]) : PIXI.Texture.EMPTY, award.image.icon = new PIXI.Sprite(texture), award.image.icon.anchor = new PIXI.Point(.5, .5), award.image.addChild(award.image.icon)
            }, TrophyScene.prototype.onBackButtonClick = function(button) {
                this.signals.back.dispatch(this)
            }, TrophyScene.prototype.onHelpButtonClick = function(button) {
                this.signals.pause.dispatch(this)
            }, TrophyScene.prototype.onSettingsButtonClick = function(button) {
                this.signals.settings.dispatch(this)
            }, TrophyScene.prototype.onAchievementsButtonClick = function(button) {
                this.signals.achievements.dispatch(this)
            }, TrophyScene.prototype.onScrollerScroll = function(scroller, fraction) {
                var value = fraction * this._scrollView.contentHeight;
                this._scrollView.scroll(0, value, !0)
            }, TrophyScene.prototype.onScrollViewScroll = function(scrollView, position) {
                var value = position.y / this._scrollView.contentHeight * this._scroller.innerHeight;
                this._scroller.scroll(value)
            }, TrophyScene.prototype.onStageMouseUp = function(event) {
                this._scroller.onMouseUp(null), this._scrollView.onMouseUp(null)
            }
        }, {
            "./Common": 23,
            "./Scene": 83,
            "./ScrollView": 87,
            "./Scroller": 88,
            "./TrackData": 101
        }],
        107: [function(require, module, exports) {
            function TurboButton() {
                p3.Button.call(this, Common.assets.getTexture("ui_btn_boost_nocharge"), null, Common.assets.getTexture("ui_btn_boost_down_v2")), this._animateFull = !1, this._chargeOnTexture = Common.assets.getTexture("ui_btn_boost_over_v2"), this._chargeOffTexture = Common.assets.getTexture("ui_btn_boost_up_v2"), this._charge = new PIXI.Sprite(this._chargeOnTexture), this._charge.anchor = new PIXI.Point(.5, .5), this._charge.alpha = 0, this._charge.visible = !1, this.addChild(this._charge)
            }
            var Common = require("./Common");
            module.exports = TurboButton, TurboButton.prototype = Object.create(p3.Button.prototype), TurboButton.prototype.constructor = TurboButton, TurboButton.prototype.animateCharge = function() {
                this._animateFull || (TweenMax.killTweensOf(this._charge), this._charge.visible = !0, TweenMax.to(this._charge, .34, {
                    alpha: 1,
                    ease: Power1.easeInOut,
                    yoyo: !0,
                    onComplete: function() {
                        this._charge.visible = !1
                    },
                    onCompleteScope: this
                }))
            }, TurboButton.prototype.startAnimateFull = function(repeat) {
                function alternate() {
                    this._charge.texture = ++i % 2 == 0 ? this._chargeOnTexture : this._chargeOffTexture, repeat > 0 || -1 == repeat ? (repeat > 0 && --repeat, this._charge.interval = TweenMax.delayedCall(delay, alternate, null, this)) : this.stopAnimateFull()
                }
                if (repeat = repeat || -1, !this._animateFull) {
                    TweenMax.killTweensOf(this._charge), this._animateFull = !0, this._charge.alpha = 1, this._charge.visible = !0;
                    var delay = .3;
                    this._charge.interval = TweenMax.delayedCall(delay, alternate, null, this);
                    var i = 0
                }
            }, TurboButton.prototype.stopAnimateFull = function() {
                this._animateFull && (this._animateFull = !1, this._charge.alpha = 0, this._charge.visible = !1, this._charge.interval && (this._charge.interval.kill(), this._charge.interval = null))
            }
        }, {
            "./Common": 23
        }],
        108: [function(require, module, exports) {
            function Tutorial() {
                PIXI.Container.call(this), this.signals = {}, this.signals.complete = new signals.Signal, this._panel = null, this._message = null
            }
            var Common = require("./Common"),
                MessagePopup = require("./MessagePopup"),
                TutorialPopup = require("./TutorialPopup");
            module.exports = Tutorial, Tutorial.prototype = Object.create(PIXI.Container.prototype), Tutorial.prototype.constructor = Tutorial, Tutorial.prototype.destroy = function() {
                TweenMax.killTweensOf(this._panel.scale), this.signals.complete && (this.signals.complete.dispose(), this.signals.complete = null), this.parent && (this.parent.removeChild(this), this.parent = null)
            }, Tutorial.prototype.show = function(dialogue) {
                Common.animator.paused = !0, this.interactiveChildren = !1, this._panel = new PIXI.Sprite(Common.assets.getTexture("ui_message_bg_tutorial")), this._panel.x = .5 * Common.STAGE_WIDTH, this._panel.y = .5 * Common.STAGE_HEIGHT - 100, this._panel.anchor = new PIXI.Point(.5, .5), this._panel.visible = !1, this.addChild(this._panel), this._message = new TutorialPopup(MessagePopup.CHARACTER_MCQUEEN, dialogue), this._message.x = .5 * (Common.STAGE_WIDTH - p3.View.width) + 20, this._message.y = p3.View.height - this._message.height - 20, this._message.tutorial = !1, this._message.animateIn(), this.addChild(this._message), this.animateIn(this.ready, this)
            }, Tutorial.prototype.hide = function() {
                Common.animator.paused = !1, this.interactiveChildren = !1, this._message.animateOut(), this.animateOut(function() {
                    this.signals.complete && this.signals.complete.dispatch(this), this.destroy()
                }, this)
            }, Tutorial.prototype.animateIn = function(callback, scope) {
                this._panel.scale = new PIXI.Point(.5, .5), this._panel.visible = !0, TweenMax.to(this._panel.scale, .4, {
                    x: 1,
                    y: 1,
                    ease: Back.easeOut,
                    easeParams: [2],
                    onComplete: callback,
                    onCompleteScope: scope
                })
            }, Tutorial.prototype.animateOut = function(callback, scope) {
                TweenMax.to(this._panel.scale, .4, {
                    x: 0,
                    y: 0,
                    ease: Back.easeIn,
                    easeParams: [1],
                    onComplete: callback,
                    onCompleteScope: scope
                })
            }, Tutorial.prototype.ready = function() {
                this.interactiveChildren = !0, console.log("tutorial ready")
            }
        }, {
            "./Common": 23,
            "./MessagePopup": 54,
            "./TutorialPopup": 113
        }],
        109: [function(require, module, exports) {
            function TutorialBoost() {
                Tutorial.call(this), this._ready = !1, this._timeout = -1, Common.input.signals.keyDown.add(this.onKeyDown, this)
            }
            var Common = require("./Common"),
                Input = require("./Input"),
                Tutorial = require("./Tutorial");
            module.exports = TutorialBoost, TutorialBoost.prototype = Object.create(Tutorial.prototype), TutorialBoost.prototype.constructor = TutorialBoost, TutorialBoost.prototype.destroy = function() {
                Common.input.signals.keyDown.remove(this.onKeyDown, this), Tutorial.prototype.destroy.call(this)
            }, TutorialBoost.prototype.show = function(dialogue) {
                if (Tutorial.prototype.show.call(this, dialogue), p3.Device.isMobile) {
                    this._panel.visible = !1;
                    var focus = new PIXI.Sprite(Common.assets.getTexture("ui_highlight"));
                    focus.x = .5 * (Common.STAGE_WIDTH + p3.View.width) - 120, focus.y = p3.View.height - 140, focus.alpha = 0, focus.scale = new PIXI.Point(4, 4), focus.anchor = new PIXI.Point(.5, .5), this.addChild(focus), TweenMax.to(focus, .4, {
                        alpha: 1,
                        ease: Power1.easeInOut
                    })
                } else {
                    var sequence = new p3.MovieClipSequence([Common.assets.getTexture("ui_icon_tutorial_shift"), Common.assets.getTexture("ui_icon_tutorial_shift_2")], "default"),
                        clip = new p3.MovieClip(sequence, "default");
                    clip.animationSpeed = 2, clip.looping = !0, clip.anchor = new PIXI.Point(.5, .5), clip.play(), this._panel.addChild(clip)
                }
                var that = this;
                this._timeout = setTimeout(function() {
                    that.hide()
                }, 3400)
            }, TutorialBoost.prototype.ready = function() {
                Tutorial.prototype.ready.call(this), this._ready = !0
            }, TutorialBoost.prototype.onKeyDown = function(event) {
                if (this._ready) switch (event.keyCode) {
                    case Input.keys.ENTER:
                        Common.input.signals.keyDown.remove(this.onKeyDown, this), clearTimeout(this._timeout), this.hide()
                }
            }
        }, {
            "./Common": 23,
            "./Input": 50,
            "./Tutorial": 108
        }],
        110: [function(require, module, exports) {
            function TutorialBrake() {
                Tutorial.call(this), this._ready = !1, Common.input.signals.keyDown.add(this.onKeyDown, this)
            }
            var Common = require("./Common"),
                Input = require("./Input"),
                Tutorial = require("./Tutorial");
            module.exports = TutorialBrake, TutorialBrake.prototype = Object.create(Tutorial.prototype), TutorialBrake.prototype.constructor = TutorialBrake, TutorialBrake.prototype.destroy = function() {
                Common.input.signals.keyDown.remove(this.onKeyDown, this), Tutorial.prototype.destroy.call(this)
            }, TutorialBrake.prototype.show = function(dialogue) {
                Tutorial.prototype.show.call(this, dialogue);
                var image = new PIXI.Sprite(Common.assets.getTexture("ui_icon_tutorial_brake"));
                image.anchor = new PIXI.Point(.5, .5), this._panel.addChild(image);
                var that = this;
                setTimeout(function() {
                    that.hide()
                }, 3400)
            }, TutorialBrake.prototype.ready = function() {
                Tutorial.prototype.ready.call(this), this._ready = !0
            }, TutorialBrake.prototype.onKeyDown = function(event) {
                if (this._ready) switch (event.keyCode) {
                    case Input.keys.S:
                    case Input.keys.DOWN:
                        Common.input.signals.keyDown.remove(this.onKeyDown, this)
                }
            }
        }, {
            "./Common": 23,
            "./Input": 50,
            "./Tutorial": 108
        }],
        111: [function(require, module, exports) {
            function TutorialHud() {
                Tutorial.call(this)
            }
            var Common = require("./Common"),
                Tutorial = require("./Tutorial");
            module.exports = TutorialHud, TutorialHud.prototype = Object.create(Tutorial.prototype), TutorialHud.prototype.constructor = TutorialHud, TutorialHud.prototype.destroy = function() {
                Tutorial.prototype.destroy.call(this)
            }, TutorialHud.prototype.show = function(dialogue) {
                Tutorial.prototype.show.call(this, dialogue), this._panel.visible = !1;
                var focus = new PIXI.Sprite(Common.assets.getTexture("ui_highlight"));
                focus.x = .5 * (Common.STAGE_WIDTH - p3.View.width) + 160, focus.y = 140, focus.alpha = 0, focus.scale = new PIXI.Point(4, 4), focus.anchor = new PIXI.Point(.5, .5), this.addChild(focus), TweenMax.to(focus, .4, {
                    alpha: 1,
                    ease: Power1.easeInOut
                });
                var that = this;
                setTimeout(function() {
                    that.hide()
                }, 3400)
            }, TutorialHud.prototype.ready = function() {
                Tutorial.prototype.ready.call(this)
            }
        }, {
            "./Common": 23,
            "./Tutorial": 108
        }],
        112: [function(require, module, exports) {
            function TutorialPoint(texture) {
                Tutorial.call(this), this.target = new PIXI.Point, this._texture = texture || PIXI.Texture.EMPTY, this._arrow = null
            }
            var Common = require("./Common"),
                Tutorial = require("./Tutorial");
            module.exports = TutorialPoint, TutorialPoint.prototype = Object.create(Tutorial.prototype), TutorialPoint.prototype.constructor = TutorialPoint, TutorialPoint.prototype.destroy = function() {
                TweenMax.killTweensOf(this._arrow), Tutorial.prototype.destroy.call(this)
            }, TutorialPoint.prototype.show = function(dialogue, target) {
                target = target || new PIXI.Point, Tutorial.prototype.show.call(this, dialogue), this._panel.visible = !1, this._arrow = new PIXI.Sprite(Common.assets.getTexture("ui_fortune_wheel_arrow")), this._arrow.x = .5 * Common.STAGE_WIDTH + target.x, this._arrow.y = target.y - 120, this._arrow.anchor = new PIXI.Point(.5, .5), this._arrow.rotation = .5 * -Math.PI, this.addChild(this._arrow);
                var to = this._arrow.y;
                this._arrow.y = this._arrow.y - 14, TweenMax.to(this._arrow, .4, {
                    y: to,
                    ease: Power1.easeInOut,
                    yoyo: !0,
                    repeat: -1
                });
                var that = this;
                setTimeout(function() {
                    that.hide()
                }, 3400)
            }, TutorialPoint.prototype.ready = function() {
                Tutorial.prototype.ready.call(this)
            }, TutorialPoint.prototype.animateOut = function(callback, scope) {
                Tutorial.prototype.animateOut.call(this, callback, scope)
            }
        }, {
            "./Common": 23,
            "./Tutorial": 108
        }],
        113: [function(require, module, exports) {
            function TutorialPopup(character, dialogue) {
                MessagePopup.call(this, -1, character, dialogue), this._button.interactive = !1, this.auto = !1
            }
            var MessagePopup = (require("./Common"), require("./MessagePopup"));
            module.exports = TutorialPopup, TutorialPopup.prototype = Object.create(MessagePopup.prototype), TutorialPopup.prototype.constructor = MessagePopup, TutorialPopup.prototype.animateIn = function(callback, scope) {
                MessagePopup.prototype.animateIn.call(this, function() {
                    this.show(0, callback, scope)
                }, this)
            }, TutorialPopup.prototype.complete = function(delay, callback, scope) {
                callback && callback.call(scope)
            }
        }, {
            "./Common": 23,
            "./MessagePopup": 54
        }],
        114: [function(require, module, exports) {
            function TutorialSteering() {
                Tutorial.call(this), this._ready = !1, this._timeout = -1, Common.input.signals.keyDown.add(this.onKeyDown, this)
            }
            var Common = require("./Common"),
                Input = require("./Input"),
                Tutorial = require("./Tutorial");
            module.exports = TutorialSteering, TutorialSteering.prototype = Object.create(Tutorial.prototype), TutorialSteering.prototype.constructor = TutorialSteering, TutorialSteering.prototype.destroy = function() {
                Common.input.signals.keyDown.remove(this.onKeyDown, this), Tutorial.prototype.destroy.call(this)
            }, TutorialSteering.prototype.show = function(dialogue) {
                Tutorial.prototype.show.call(this, dialogue);
                var sequence;
                sequence = p3.Device.isMobile ? new p3.MovieClipSequence([Common.assets.getTexture("ui_icon_tutorial_arrows_1"), Common.assets.getTexture("ui_icon_tutorial_arrows_2")], "default") : new p3.MovieClipSequence([Common.assets.getTexture("ui_icon_tutorial_steer"), Common.assets.getTexture("ui_icon_tutorial_steer_2")], "default");
                var clip = new p3.MovieClip(sequence, "default");
                clip.animationSpeed = 2, clip.looping = !0, clip.anchor = new PIXI.Point(.5, .5), clip.play(), this._panel.addChild(clip);
                var that = this;
                this._timeout = setTimeout(function() {
                    that.hide()
                }, 3400)
            }, TutorialSteering.prototype.ready = function() {
                Tutorial.prototype.ready.call(this), this._ready = !0
            }, TutorialSteering.prototype.onKeyDown = function(event) {
                if (this._ready) switch (event.keyCode) {
                    case Input.keys.LEFT:
                    case Input.keys.RIGHT:
                    case Input.keys.A:
                    case Input.keys.D:
                        Common.input.signals.keyDown.remove(this.onKeyDown, this), clearTimeout(this._timeout), this.hide()
                }
            }
        }, {
            "./Common": 23,
            "./Input": 50,
            "./Tutorial": 108
        }],
        115: [function(require, module, exports) {
            function V8View(color, avatar) {
                CarView.call(this, color, avatar);
                var chassisOffset = new PIXI.Point(0, -2);
                this._shadow.offset = new PIXI.Point(0, 20), this._wheels.front.left.visible = !1, this._wheels.front.right.visible = !1, this._wheels.rear.left.offset = new PIXI.Point(-124, 78), this._wheels.rear.right.offset = new PIXI.Point(124, 78), this._front.offset = new PIXI.Point(chassisOffset.x, -4 + chassisOffset.y), this._mid.offset = new PIXI.Point(chassisOffset.x, chassisOffset.y), this._back.offset = new PIXI.Point(chassisOffset.x, chassisOffset.y)
            }
            var CarShader = require("./CarShader"),
                CarView = require("./CarView"),
                Common = require("./Common");
            module.exports = V8View, V8View.prototype = Object.create(CarView.prototype), V8View.prototype.constructor = V8View, V8View.prototype.update = function(distance, curvature, gradient, velocity, turnVelocity) {
                var scalar = 140;
                this._curvature += .4 * (turnVelocity + curvature - this._curvature), this._curvature = Math.max(-scalar, Math.min(scalar, this._curvature)), this._front.x = .3 * this._curvature + this._front.offset.x, this._front.y = -gradient * scalar * 1.6 + this._front.offset.y, this._mid.x = .1 * this._curvature + this._mid.offset.x, this._mid.y = -gradient * scalar * 1.3 + this._mid.offset.y, this._back.x = .2 * -this._curvature + this._back.offset.x, this._back.y = gradient * scalar + this._back.offset.y, this._shadow.x = this._back.x, this._shadow.y = this._wheels.rear.left.y + this._shadow.offset.y, this._front.rotation = 8e-4 * this._curvature, this._back.rotation = 8e-4 * this._curvature, this._wheels.front.left.x = this._front.x + this._wheels.front.left.offset.x, this._wheels.front.left.y = gradient * scalar + this._wheels.front.left.offset.y, this._wheels.front.right.x = this._front.x + this._wheels.front.right.offset.x, this._wheels.front.right.y = gradient * scalar + this._wheels.front.right.offset.y, this._wheels.rear.left.x = this._back.x + this._wheels.rear.left.offset.x, this._wheels.rear.left.y = gradient * scalar + this._wheels.rear.left.offset.y, this._wheels.rear.right.x = this._back.x + this._wheels.rear.right.offset.x, this._wheels.rear.right.y = gradient * scalar + this._wheels.rear.right.offset.y;
                var theta;
                theta = .008 * turnVelocity, 0 > theta && (theta *= .112), this._wheels.front.left.rotation = theta, theta = .008 * turnVelocity, theta > 0 && (theta *= .112), this._wheels.front.right.rotation = theta, theta = .008 * turnVelocity, 0 > theta && (theta *= .112), this._wheels.rear.left.rotation = theta, theta = .008 * turnVelocity, theta > 0 && (theta *= .112), this._wheels.rear.right.rotation = theta, velocity = Math.max(0, velocity), this._wheels.front.left.animationSpeed = velocity / .2, this._wheels.front.right.animationSpeed = velocity / .2, this._wheels.rear.left.animationSpeed = velocity / .2, this._wheels.rear.right.animationSpeed = velocity / .2
            }, V8View.prototype.createFrontLayer = function() {
                var bodyTexture = Common.assets.getTexture("car_00_body_00"),
                    maskTexture = Common.assets.getTexture("car_00_mask_00"),
                    shineTexture = Common.assets.getTexture("car_00_shine_00"),
                    maskOffset = new PIXI.Point(maskTexture._uvs.x0 - bodyTexture._uvs.x0, maskTexture._uvs.y0 - bodyTexture._uvs.y0),
                    shineOffset = new PIXI.Point(shineTexture._uvs.x0 - bodyTexture._uvs.x0, shineTexture._uvs.y0 - bodyTexture._uvs.y0),
                    front = new PIXI.Sprite(bodyTexture);
                front.shader = new CarShader(this._color, maskOffset, this._shininess, shineOffset);
                var decal = new PIXI.Sprite(this.getDecalTexture(0));
                return front.addChild(decal), new PIXI.Sprite(front.generateTexture(Common.renderer, 1, PIXI.SCALE_MODES.DEFAULT))
            }, V8View.prototype.createMidLayer = function() {
                var bodyTexture = Common.assets.getTexture("car_00_body_01"),
                    maskTexture = Common.assets.getTexture("car_00_mask_01"),
                    shineTexture = Common.assets.getTexture("car_00_shine_01"),
                    maskOffset = new PIXI.Point(maskTexture._uvs.x0 - bodyTexture._uvs.x0, maskTexture._uvs.y0 - bodyTexture._uvs.y0),
                    shineOffset = new PIXI.Point(shineTexture._uvs.x0 - bodyTexture._uvs.x0, shineTexture._uvs.y0 - bodyTexture._uvs.y0),
                    mid = new PIXI.Sprite(bodyTexture);
                mid.shader = new CarShader(this._color, maskOffset, this._shininess, shineOffset);
                var decal = new PIXI.Sprite(this.getDecalTexture(1));
                mid.addChild(decal);
                var kit = Common.garage.myCar.kit;
                if (0 == kit || 4 == kit) {
                    var topLights = new PIXI.Sprite(Common.assets.getTexture("car_00_specialkit_00"));
                    mid.addChild(topLights)
                }
                if (0 == kit) {
                    var spareTyre = new PIXI.Sprite(Common.assets.getTexture("car_00_specialkit_01"));
                    mid.addChild(spareTyre)
                }
                if (3 == kit) {
                    var neonLights = new PIXI.Sprite(Common.assets.getTexture("car_00_specialkit_02"));
                    mid.addChild(neonLights)
                }
                return new PIXI.Sprite(mid.generateTexture(Common.renderer, 1, PIXI.SCALE_MODES.DEFAULT))
            }, V8View.prototype.createBackLayer = function() {
                var bodyTexture = Common.assets.getTexture("car_00_body_02"),
                    maskTexture = Common.assets.getTexture("car_00_mask_02"),
                    shineTexture = Common.assets.getTexture("car_00_shine_02"),
                    maskOffset = new PIXI.Point(maskTexture._uvs.x0 - bodyTexture._uvs.x0, maskTexture._uvs.y0 - bodyTexture._uvs.y0),
                    shineOffset = new PIXI.Point(shineTexture._uvs.x0 - bodyTexture._uvs.x0, shineTexture._uvs.y0 - bodyTexture._uvs.y0),
                    back = new PIXI.Sprite(bodyTexture);
                back.shader = new CarShader(this._color, maskOffset, this._shininess, shineOffset);
                var decal = new PIXI.Sprite(this.getDecalTexture(2));
                back.addChild(decal);
                var name = Common.garage.name,
                    plate = new PIXI.Sprite(Common.garage.saveLicensePlate(name));
                plate.x = .5 * back.width, plate.y = 178, plate.scale = new PIXI.Point(.5, .5), plate.anchor.x = .5, back.addChild(plate);
                var spoiler = this.createSpoilerLayer();
                return spoiler.y = 5, back.addChild(spoiler), new PIXI.Sprite(back.generateTexture(Common.renderer, 1, PIXI.SCALE_MODES.DEFAULT))
            }, V8View.prototype.createSpoilerLayer = function() {
                var bodyTexture = Common.assets.getTexture("car_00_spoiler_02"),
                    maskTexture = Common.assets.getTexture("car_00_maskspoiler_02"),
                    maskOffset = new PIXI.Point(maskTexture._uvs.x0 - bodyTexture._uvs.x0, maskTexture._uvs.y0 - bodyTexture._uvs.y0),
                    spoiler = new PIXI.Sprite(bodyTexture);
                return spoiler.shader = new CarShader(this._color, maskOffset, 0), new PIXI.Sprite(spoiler.generateTexture(Common.renderer, 1, PIXI.SCALE_MODES.DEFAULT))
            }, V8View.prototype.createRearWheel = function() {
                var sequence = new p3.MovieClipSequence;
                return sequence.addTextures([Common.assets.getTexture("car_00_wheels_rear_0"), Common.assets.getTexture("car_00_wheels_rear_1"), Common.assets.getTexture("car_00_wheels_rear_2"), Common.assets.getTexture("car_00_wheels_rear_3")]), new p3.MovieClip(sequence)
            }, V8View.prototype.createShadow = function() {
                return new PIXI.Sprite(Common.assets.getTexture("car_00_shadow"))
            }
        }, {
            "./CarShader": 19,
            "./CarView": 21,
            "./Common": 23
        }],
        116: [function(require, module, exports) {
            function VelosoView(avatar) {
                CarView.call(this, 16777215, avatar);
                var chassisOffset = new PIXI.Point(0, -2);
                this._shadow.offset = new PIXI.Point(0, 26), this._wheels.front.left.offset = new PIXI.Point(-82, 14), this._wheels.front.right.offset = new PIXI.Point(82, 14), this._wheels.rear.left.offset = new PIXI.Point(-124, 78), this._wheels.rear.right.offset = new PIXI.Point(124, 78), this._front.offset = new PIXI.Point(chassisOffset.x, -4 + chassisOffset.y), this._mid.offset = new PIXI.Point(chassisOffset.x, chassisOffset.y), this._back.offset = new PIXI.Point(chassisOffset.x, chassisOffset.y)
            }
            var CarView = (require("./CarShader"), require("./CarView")),
                Common = require("./Common");
            module.exports = VelosoView, VelosoView.prototype = Object.create(CarView.prototype), VelosoView.prototype.constructor = VelosoView, VelosoView.prototype.update = function(distance, curvature, gradient, velocity, turnVelocity) {
                var scalar = 140;
                this._curvature += .4 * (turnVelocity + curvature - this._curvature), this._curvature = Math.max(-scalar, Math.min(scalar, this._curvature)), this._front.x = .4 * this._curvature + this._front.offset.x, this._front.y = -gradient * scalar * 1.6 + this._front.offset.y, this._mid.x = .1 * this._curvature + this._mid.offset.x, this._mid.y = -gradient * scalar * 1.3 + this._mid.offset.y, this._back.x = .14 * -this._curvature + this._back.offset.x, this._back.y = gradient * scalar + this._back.offset.y, this._shadow.x = this._back.x, this._shadow.y = this._wheels.rear.left.y + this._shadow.offset.y, this._front.rotation = 8e-4 * this._curvature, this._back.rotation = 8e-4 * this._curvature, this._wheels.front.left.x = this._front.x + this._wheels.front.left.offset.x, this._wheels.front.left.y = gradient * scalar + this._wheels.front.left.offset.y, this._wheels.front.right.x = this._front.x + this._wheels.front.right.offset.x, this._wheels.front.right.y = gradient * scalar + this._wheels.front.right.offset.y, this._wheels.rear.left.x = this._back.x + this._wheels.rear.left.offset.x, this._wheels.rear.left.y = gradient * scalar + this._wheels.rear.left.offset.y, this._wheels.rear.right.x = this._back.x + this._wheels.rear.right.offset.x, this._wheels.rear.right.y = gradient * scalar + this._wheels.rear.right.offset.y;
                var theta;
                theta = .008 * turnVelocity, 0 > theta && (theta *= .112), this._wheels.front.left.rotation = theta, theta = .008 * turnVelocity, theta > 0 && (theta *= .112), this._wheels.front.right.rotation = theta, theta = .008 * turnVelocity, 0 > theta && (theta *= .112), this._wheels.rear.left.rotation = theta, theta = .008 * turnVelocity, theta > 0 && (theta *= .112), this._wheels.rear.right.rotation = theta, velocity = Math.max(0, velocity), this._wheels.front.left.animationSpeed = velocity / .2, this._wheels.front.right.animationSpeed = velocity / .2, this._wheels.rear.left.animationSpeed = velocity / .2, this._wheels.rear.right.animationSpeed = velocity / .2
            }, VelosoView.prototype.createFrontLayer = function() {
                return new PIXI.Sprite(Common.assets.getTexture("car_veloso_body_00"))
            }, VelosoView.prototype.createMidLayer = function() {
                return new PIXI.Sprite(Common.assets.getTexture("car_veloso_body_01"))
            }, VelosoView.prototype.createBackLayer = function() {
                var back = new PIXI.Sprite(Common.assets.getTexture("car_veloso_body_02")),
                    spoiler = this.createSpoilerLayer();
                return spoiler.y = 20, back.addChild(spoiler), back
            }, VelosoView.prototype.createSpoilerLayer = function() {
                var spoiler = new PIXI.Sprite(Common.assets.getTexture("car_veloso_spoiler_02"));
                return spoiler.anchor = new PIXI.Point(.5, 1), spoiler
            }, VelosoView.prototype.createFrontWheel = function() {
                var sequence = new p3.MovieClipSequence;
                return sequence.addTextures([Common.assets.getTexture("car_veloso_wheels_front_0"), Common.assets.getTexture("car_veloso_wheels_front_1"), Common.assets.getTexture("car_veloso_wheels_front_2"), Common.assets.getTexture("car_veloso_wheels_front_3")]), new p3.MovieClip(sequence)
            }, VelosoView.prototype.createRearWheel = function() {
                var sequence = new p3.MovieClipSequence;
                return sequence.addTextures([Common.assets.getTexture("car_veloso_wheels_rear_0"), Common.assets.getTexture("car_veloso_wheels_rear_1"), Common.assets.getTexture("car_veloso_wheels_rear_2"), Common.assets.getTexture("car_veloso_wheels_rear_3")]), new p3.MovieClip(sequence)
            }, VelosoView.prototype.createShadow = function() {
                return new PIXI.Sprite(Common.assets.getTexture("car_veloso_shadow"))
            }
        }, {
            "./CarShader": 19,
            "./CarView": 21,
            "./Common": 23
        }],
        117: [function(require, module, exports) {
            function WelcomeScene() {
                Scene.call(this), this._header = null, this._titleText = null, this._infoText = null, this._muteButton = null, this._playButton = null, this._character = null, this._speechBubble = null
            }
            var Common = require("./Common"),
                Scene = require("./Scene");
            module.exports = WelcomeScene, WelcomeScene.prototype = Object.create(Scene.prototype), WelcomeScene.prototype.constructor = WelcomeScene, WelcomeScene.prototype.init = function() {
                var bg = new PIXI.Sprite(Common.assets.getTexture("ui_bg_main_menu"));
                this.addChild(bg), this._header = new PIXI.Sprite(Common.assets.getTexture("ui_top_bar")), this._header.x = .5 * Common.STAGE_WIDTH, this._header.y = 120, this._header.anchor = new PIXI.Point(.5, .5), this.addChild(this._header), webfont ? (this._titleText = new PIXI.Text(Common.copy.welcome[Common.language], {
                        font: "48px Arial",
                        fill: "#FFFFFF",
                        align: "center"
                    }), this._titleText.x = .5 * (Common.STAGE_WIDTH - this._titleText.width), this._titleText.y = 96, this.addChild(this._titleText)) : (this._titleText = new PIXI.extras.BitmapText(Common.copy.welcome[Common.language], {
                        font: "48px Great Escape",
                        align: "center"
                    }), this._titleText.x = .5 * (Common.STAGE_WIDTH - this._titleText.textWidth), this._titleText.y = 86, this.addChild(this._titleText)), this._muteButton = new p3.MuteButton(Common.assets.getTexture("ui_btn_navigation_up"), Common.assets.getTexture("ui_btn_navigation_over"), Common.assets.getTexture("ui_btn_navigation_down"), Common.assets.getTexture("ui_icon_sound_on"), Common.assets.getTexture("ui_icon_sound_off")), this._muteButton.y = 120, this._muteButton.animate = !0, this._muteButton.visible = !1, this.addChild(this._muteButton), this._playButton = new p3.Button(Common.assets.getTexture("ui_btn_confirm_up"), Common.assets.getTexture("ui_btn_confirm_over"), Common.assets.getTexture("ui_btn_confirm_down"), Common.assets.getTexture("ui_icon_play")), this._playButton.y = .5 * Common.STAGE_HEIGHT + 260, this._playButton.animate = !0,
                    this._playButton.visible = !1, this._playButton.signals.click.add(this.onPlayButtonClick, this), this.addChild(this._playButton), this._character = new PIXI.Container, this._character.x = .5 * Common.STAGE_WIDTH - 160, this._character.y = .5 * Common.STAGE_HEIGHT + 200, this._character.scale = new PIXI.Point(.5, .5), this._character.visible = !1, this.addChild(this._character), this._character.animation = new PIXI.Container, this._character.addChild(this._character.animation), this._character.animation.spine = new PIXI.spine.Spine(Common.assets.getSpineData("lightning_welcome")), this._character.animation.spine.skeleton.setToSetupPose(), this._character.animation.spine.update(0), this._character.animation.spine.autoUpdate = !1, this._character.animation.addChild(this._character.animation.spine), this._speechBubble = new PIXI.Sprite(Common.assets.getTexture("ui_message_bg_help")), this._speechBubble.x = .5 * Common.STAGE_WIDTH, this._speechBubble.y = .5 * Common.STAGE_HEIGHT - 120, this._speechBubble.anchor = new PIXI.Point(.5, .5), this._speechBubble.visible = !1, this.addChild(this._speechBubble), webfont ? (this._infoText = new PIXI.Text(Common.copy.welcome_message[Common.language], {
                        font: "28px Arial",
                        fill: "#FFFFFF",
                        align: r2l ? "center" : "left"
                    }), this._infoText.x = .5 * -this._infoText.width, this._infoText.y = .5 * -this._infoText.height - 2, this._speechBubble.addChild(this._infoText)) : (this._infoText = new PIXI.extras.BitmapText(Common.copy.welcome_message[Common.language], {
                        font: "28px Great Escape Italic",
                        align: r2l ? "center" : "left"
                    }), this._infoText.x = .5 * -this._infoText.textWidth, this._infoText.y = .5 * -this._infoText.textHeight - 2, this._speechBubble.addChild(this._infoText))
            }, WelcomeScene.prototype.dispose = function() {
                Common.animator.removeAll(), this._character.animation.spine.destroy(), Scene.prototype.dispose.call(this)
            }, WelcomeScene.prototype.appear = function() {
                this.animateIn(), this._character.animation.spine.state.setAnimationByName(0, "slide", !1), this._character.animation.spine.state.addAnimationByName(0, "idle", !0, 0)
            }, WelcomeScene.prototype.show = function() {
                this._muteButton.interactive = !0, this._playButton.interactive = !0
            }, WelcomeScene.prototype.animateIn = function(callback, scope) {
                this._playButton.scale = new PIXI.Point, this._playButton.visible = !0, TweenMax.to(this._playButton.scale, .4, {
                    x: 1,
                    y: 1,
                    ease: Back.easeOut,
                    easeParams: [3]
                }), this._muteButton.scale = new PIXI.Point, this._muteButton.visible = !0, TweenMax.to(this._muteButton.scale, .4, {
                    delay: .3,
                    x: 1,
                    y: 1,
                    ease: Back.easeOut,
                    easeParams: [2]
                });
                var x = this._character.x;
                this._character.x = this._character.x - 640, this._character.visible = !0, TweenMax.to(this._character, 1.4, {
                    x: x,
                    ease: Power3.easeOut
                }), this._character.alpha = 0, TweenMax.to(this._character, .2, {
                    alpha: 1,
                    ease: Power1.easeInOut
                }), this._speechBubble.alpha = 0, this._speechBubble.visible = !0, TweenMax.to(this._speechBubble, .2, {
                    delay: .4,
                    alpha: 1,
                    ease: Power1.easeInOut
                })
            }, WelcomeScene.prototype.animateOut = function(callback, scope) {}, WelcomeScene.prototype.resize = function() {
                this.x = .5 * (p3.View.width - Common.STAGE_WIDTH), this._header.width = p3.View.width, this._muteButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width - Math.abs(this._muteButton.width)) - 28, this._playButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width - Math.abs(this._playButton.width)) - 28
            }, WelcomeScene.prototype.update = function() {
                this._character.animation.spine.update(p3.Timestep.deltaTime)
            }, WelcomeScene.prototype.onPlayButtonClick = function() {
                this._muteButton.interactive = !1, this._playButton.interactive = !1, this.signals.next.dispatch()
            }
        }, {
            "./Common": 23,
            "./Scene": 83
        }]
    }, {}, [53])(53)
});