window.links = {
	"ARCADE_URL":"https://www.greenish.xyz",
	"GAME1_URL": "https://www.greenish.xyz",
	"GAME2_URL": "https://www.greenish.xyz",
	"GAME3_URL": "https://www.greenish.xyz",


	"ARCADE_URL_MOBILE":"https://www.greenish.xyz",
	"GAME1_URL_MOBILE": "https://www.greenish.xyz",
	"GAME2_URL_MOBILE": "https://www.greenish.xyz",
	"GAME3_URL_MOBILE": "https://www.greenish.xyz"

}